'use client';
import Link from 'next/link';
import { useState } from 'react';
import { ArrowRight, ArrowUpRight } from 'lucide-react';
import { primaryMedia } from '@/lib/product-media';
import { ProductMediaImage } from './product-media-image';
import { getProduct } from '@/lib/products';
const ids = ['iphone-x', 'iphone-17', 'galaxy-s25', 'xiaomi-15'];
export function DeviceShowcase() {
  const [selected, setSelected] = useState(ids[1]);
  const device = getProduct(selected), asset = primaryMedia(selected);
  if (!device || !asset) return null;
  return <section className="container section device-showcase"><div className="section-heading"><div><span className="section-kicker">THE DEVICE ARCHIVE</span><h2>每一代，都有自己的答案。</h2><p>从经典设计到新一代体验，先看清设备，再选择。</p></div><Link href="/products/" className="text-link">进入产品库 <ArrowRight size={16} /></Link></div>
    <div className="showcase-shell"><div className="showcase-copy"><span className="showcase-index">{device.year} — {device.brand.toUpperCase()}</span><h3>{device.name}</h3><p>{device.tagline}</p><div className="showcase-specs"><div><small>CHIP</small><strong>{device.processor}</strong></div><div><small>DISPLAY</small><strong>{device.screenSize} 英寸</strong></div></div><Link href={`/products/${device.id}/`} className="showcase-cta">了解这款设备 <ArrowUpRight size={15} /></Link><span className="showcase-footnote">{asset.label} · 无实时售价或库存承诺</span></div>
      <div className="showcase-photo" key={selected}><ProductMediaImage key={asset.src} media={asset}/><span className="showcase-photo-caption">{asset.owner} · <Link href="/sources/">官方图像来源</Link></span></div>
      <div className="showcase-tabs" role="tablist" aria-label="浏览设备外观">{ids.map((id, i) => <button key={id} id={`device-tab-${id}`} role="tab" aria-selected={selected === id} tabIndex={selected === id ? 0 : -1} aria-controls="device-showcase-panel" onClick={() => setSelected(id)} onKeyDown={event => { if (!['ArrowLeft', 'ArrowRight', 'Home', 'End'].includes(event.key)) return; event.preventDefault(); const next = event.key === 'Home' ? 0 : event.key === 'End' ? ids.length - 1 : (i + (event.key === 'ArrowRight' ? 1 : -1) + ids.length) % ids.length; setSelected(ids[next]); document.getElementById(`device-tab-${ids[next]}`)?.focus(); }}><span className="showcase-tab-dot" />{getProduct(id)?.name || id}</button>)}</div>
    </div><div id="device-showcase-panel" role="tabpanel" aria-labelledby={`device-tab-${selected}`} className="sr-only">{device.name}，{device.screen}，{device.processor}。外观图不代表具体在售商品。</div>
  </section>;
}
