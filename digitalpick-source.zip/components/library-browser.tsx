'use client';
import Link from 'next/link';
import { useSearchParams } from 'next/navigation';
import { useEffect, useMemo, useState } from 'react';
import { ArrowUpRight, CheckCircle2, Database, FileWarning, Search } from 'lucide-react';
import { libraryDevices, libraryHref } from '@/lib/library/catalog';
import { reviewedDevices } from '@/lib/library/reviewed';
import { librarySources } from '@/lib/library/sources';
import { factLabels, type FactKey } from '@/lib/library/types';
import report from '@/lib/library/import-report.json';
import { assetPath } from '@/lib/deployment';
import { normalizedDeviceName } from '@/lib/ai/retrieval';
import { categoryName } from '@/lib/products';
import { Button } from './ui/button';
import { GlassSelect } from './ui/select';
import { useCompanion } from './companion/provider';

export function LibraryBrowser() {
 const params = useSearchParams(); const { openChat } = useCompanion();
 const [query,setQuery]=useState(''), [category,setCategory]=useState('all'), [review,setReview]=useState('reviewed'), [brand,setBrand]=useState(''), [year,setYear]=useState('all'), [page,setPage]=useState(1);
 const deviceId=params.get('device');
 const selected=libraryDevices.find(d=>d.id===deviceId);
 useEffect(()=>{ if(selected) { setReview(selected.review); setCategory('all'); setBrand(''); setYear('all'); setQuery(''); document.getElementById('library-device-title')?.scrollIntoView({block:'start'}); } else if(params.get('q')) setQuery((params.get('q') || '').slice(0,100)); },[deviceId,params,selected]);
 const brands=useMemo(()=>[...new Set(libraryDevices.map(d=>d.brand))].sort(),[]);
 const searchIndex=useMemo(()=>new Map(libraryDevices.map(d=>[d.id,normalizedDeviceName(`${d.name} ${d.brand} ${d.brand==='Apple'?'苹果':''} ${d.aliases.join(' ')} ${Object.values(d.facts).filter(Boolean).join(' ')} ${d.region}`)])),[]);
 const filtered=useMemo(()=>libraryDevices.filter(d=>(category==='all'||d.category===category)&&(review==='all'||d.review===review)&&(!brand||d.brand===brand)&&(year==='all'||(year==='unknown'?d.year===null:String(d.year)===year))&&(searchIndex.get(d.id)||'').includes(normalizedDeviceName(query.trim()))),[query,category,review,brand,year,searchIndex]);
 useEffect(()=>setPage(1),[query,category,review,brand,year]);
 const shown=filtered.slice((page-1)*30,page*30), pages=Math.max(1,Math.ceil(filtered.length/30));
 return <div className="container page-space library-page">
  <div className="library-heading"><div><span className="section-kicker">THE SPECIFICATION ARCHIVE</span><h1>参数有出处，判断有分寸。</h1><p>先看清具体型号、配置和地区版本。只整理资料，这里没有实时售价或库存。</p></div><Database size={42} strokeWidth={1}/></div>
  <div className="library-stats"><div><strong>{reviewedDevices.length}</strong><span>条已核对字段资料</span></div><div><strong>{report.pendingConfigurations.toLocaleString('en-US')}</strong><span>条待核验配置素材</span></div><div><strong>{brands.length}</strong><span>个来源品牌标签</span></div><div><strong>0</strong><span>条导入售价 / 图片</span></div></div>
  <div className="library-notice"><FileWarning size={18}/><p>覆盖尚不完整。手机素材按来源年份整理 2021–2025，另保留部分旧款 Apple；2021 年的精确边界未核验。992 条笔记本缺发布日期。部分 2026 新品由官方资料补入。<strong>待核验素材不会进入小派的事实检索和预算推荐。</strong></p></div>
  {selected && <section className="library-detail" aria-labelledby="library-device-title"><div className="library-detail-heading"><div><span className={`library-badge ${selected.review}`}>{selected.review==='reviewed'?'已核对列出字段':'待核验 · 不供 AI 引用'}</span><h2 id="library-device-title">{selected.name}</h2><p>{selected.brand} · {categoryName(selected.category)} · {selected.year || '发布年份未确认'}</p></div><Link href="/library/" className="text-link">关闭详情</Link></div>
   <p className="library-region">版本：{selected.region}</p><div className="library-device-notes">{selected.notes.map((note,i)=><p key={i}>{note}</p>)}</div>
   <dl className="library-facts">{(Object.keys(factLabels) as FactKey[]).filter(k=>selected.facts[k]||!['gpuMemory','performanceCores','efficiencyCores','lowPowerCores','warranty'].includes(k)).map(k=><div key={k}><dt>{factLabels[k]}</dt><dd>{selected.facts[k] || '尚未整理或来源未披露'}</dd></div>)}</dl>
   <div className="library-detail-footer"><a href={selected.sourceUrl} target="_blank" rel="noopener noreferrer">{librarySources.find(s=>s.id===selected.sourceId)?.name || '参数来源'} <ArrowUpRight size={13}/></a><span>导入/核对：{selected.importedAt} · 来源日期：{selected.sourceUpdatedAt || '未单独提供'}</span>{selected.review==='reviewed' && <Button size="sm" onClick={()=>openChat(`请按资料解释${selected.name}的主要取舍，注意地区版本。`)}>让小派解释参数</Button>}{selected.productId && <Link href={`/products/${selected.productId}/`} className="text-link">查看选购资料 ↗</Link>}</div>
  </section>}
  {deviceId&&!selected&&<p role="status" className="library-notice">没有找到这一资料条目，请重新搜索具体型号。</p>}
  <div className="library-toolbar"><div className="search-input"><Search size={18}/><input maxLength={100} aria-label="搜索参数素材库" placeholder="搜索型号、品牌或芯片，例如 iQOO 13、RTX 4060" value={query} onChange={e=>setQuery(e.target.value)}/></div><GlassSelect label="参数资料状态" value={review} onValueChange={setReview} options={[{value:'reviewed',label:'已核对字段',description:'小派只引用这部分参数'},{value:'pending',label:'待核验素材',description:'含未核验和已发现冲突，不作为结论'},{value:'all',label:'全部资料',description:'同时显示，逐条标明状态'}]}/><GlassSelect label="参数品牌" value={brand} onValueChange={setBrand} options={[{value:'',label:'全部品牌'},...brands.map(b=>({value:b,label:b}))]}/><GlassSelect label="发布年份" value={year} onValueChange={setYear} options={[{value:'all',label:'全部年份'},{value:'unknown',label:'年份未确认'},...[2026,2025,2024,2023,2022,2021,2020,2019,2018,2017].map(y=>({value:String(y),label:String(y)}))]}/></div>
  <div className="browser-tabs"><div className="tabs" role="group" aria-label="参数设备类别">{[{id:'all',name:'全部设备'},{id:'phone',name:'手机'},{id:'tablet',name:'平板'},{id:'laptop',name:'笔记本'}].map(c=><button key={c.id} aria-pressed={category===c.id} className={category===c.id?'selected':''} onClick={()=>setCategory(c.id)}>{c.name}</button>)}</div><span className="small muted" aria-live="polite">{filtered.length} 条配置资料 · 不等于独立机型数</span></div>
  <div className="library-grid">{shown.map(d=><Link href={libraryHref(d.id)} prefetch={false} scroll={false} className="library-card" key={d.id}><div><span className={`library-badge ${d.review}`}>{d.review==='reviewed'?<CheckCircle2 size={12}/>:<FileWarning size={12}/>} {d.review==='reviewed'?'已核对字段':'待核验素材'}</span><span className="small muted">{d.year || '年份未确认'}</span></div><span className="library-brand">{d.brand} · {categoryName(d.category)}</span><h3>{d.name}</h3><p>{d.review==='reviewed'?(d.facts.processor || '查看已核对参数'):'原始来源参数待核验，点击查看素材与限制'}</p><span className="library-card-link">查看参数与来源 <ArrowUpRight size={14}/></span></Link>)}</div>
  {!shown.length&&<div className="empty-state"><Search size={30}/><h2>暂未找到资料</h2><p>可切换到待核验素材，或减少关键词。没有结果不代表这款设备不存在。</p></div>}
  <div className="library-pagination"><Button variant="outline" disabled={page<=1} onClick={()=>setPage(n=>n-1)}>上一页</Button><span>{page} / {pages}</span><Button variant="outline" disabled={page>=pages} onClick={()=>setPage(n=>n+1)}>下一页</Button></div>
  <details className="library-sources"><summary>来源、许可证与覆盖缺口</summary><p>归档版本：{report.importedAt}。不是近五年全品牌全参数数据库。缺失字段保持为空，不从芯片、商品名或年份推测。</p>{librarySources.map(s=><article key={s.id}><h3>{s.name}</h3><p>许可：{s.license} · 版本：{s.revision}</p><ul>{s.limitations.map(note=><li key={note}>{note}</li>)}</ul><a href={s.url} target="_blank" rel="noopener noreferrer">查看原始来源 ↗</a>{s.licensePath&&<a href={assetPath(s.licensePath)} target="_blank" rel="noopener noreferrer">查看许可文本 ↗</a>}</article>)}<p>未导入 GSMArena 批量镜像：原站限制资料再发布，且抽查发现导出过程覆盖了重名字段。Wikidata 的批量查询此次超时，未将查询失败说成完成导入。</p></details>
 </div>;
}
