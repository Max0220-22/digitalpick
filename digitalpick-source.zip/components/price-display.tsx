'use client';
import { useEffect, useState } from 'react';
import type { Price } from '@/lib/products';
import { isStale, priceText } from '@/lib/prices';
export function PriceDisplay({ price, label }: { price: Price | null; label: string }) { const [stale, setStale] = useState(false); useEffect(() => { setStale(price ? isStale(price) : false); }, [price]); return <div className="price-display"><span className="price-label">{label}</span><div><strong className={!price ? 'no-price' : ''}>{priceText(price)}</strong>{price && <span className="price-demo">{price.demo ? '演示' : '参考'}</span>}</div>{price && <small>记录于 {price.collectedAt}{stale ? ' · 已过期，请重新核实' : ' · 非实时价格'}</small>}</div>; }
