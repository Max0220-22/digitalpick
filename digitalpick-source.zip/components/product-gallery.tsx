'use client';
import Link from 'next/link';
import { useRef, useState } from 'react';
import { ArrowUpRight, MoveHorizontal, RotateCcw } from 'lucide-react';
import { galleryMedia } from '@/lib/product-media';
import type { Product } from '@/lib/products';
import { DeviceArt } from './device-art';
import { ProductMediaImage } from './product-media-image';

export function ProductGallery({ product }: { product: Product }) {
  const plate = useRef<HTMLDivElement>(null);
  const [view, setView] = useState(0), [moved, setMoved] = useState(false);
  const views = galleryMedia(product.id), current = views[view] || views[0];
  function reset() { plate.current?.style.setProperty('--photo-x', '0deg'); plate.current?.style.setProperty('--photo-y', '0deg'); }
  function move(event: React.PointerEvent<HTMLDivElement>) {
    if (matchMedia('(prefers-reduced-motion: reduce)').matches || (event.pointerType !== 'mouse' && event.buttons !== 1)) return;
    const bounds = event.currentTarget.getBoundingClientRect();
    const x = Math.max(-1, Math.min(1, (event.clientX - bounds.left) / bounds.width * 2 - 1));
    const y = Math.max(-1, Math.min(1, (event.clientY - bounds.top) / bounds.height * 2 - 1));
    plate.current?.style.setProperty('--photo-y', `${x * 10}deg`); plate.current?.style.setProperty('--photo-x', `${-y * 6}deg`); setMoved(true);
  }
  return <figure className="product-gallery">
    <div className="gallery-heading"><span>THE DEVICE, UP CLOSE.</span><span>{product.year || '年份待核实'} / {product.brand.toUpperCase()}</span></div>
    <div className="gallery-stage" onPointerMove={move} onPointerLeave={reset} onPointerUp={event => { if (event.pointerType !== 'mouse') reset(); }} onPointerCancel={reset}>
      <div ref={plate} className="gallery-photo-plate">{current ? <ProductMediaImage key={current.src} media={current} eager/> : <DeviceArt productId={product.id} category={product.category}/>}</div>
      <span className="gallery-image-label">{current?.label || '外观待补充'}</span>
      {current && <button className="gallery-reset" onClick={reset} aria-label="复位产品展示视角"><RotateCcw size={14}/></button>}
    </div>
    {views.length > 1 && <div className="gallery-view-tabs" role="group" aria-label="设备图片视图">{views.map((item, i) => <button key={item.src} aria-pressed={i === view} onClick={() => { setView(i); reset(); }}>{i === 0 ? '官方标准图' : item.label}</button>)}</div>}
    <figcaption className="gallery-caption">{current ? <><span><MoveHorizontal size={13}/>{moved ? '平面视差 · 非 360° 模型' : '移动鼠标或拖动，轻转视角'}</span><small>{current.owner} · <a href={current.sourceUrl} target="_blank" rel="noopener noreferrer">{current.clip ? '原片与许可' : '品牌官方来源'}<ArrowUpRight size={10}/></a> · {current.rights}</small><small>{current.notes} <Link href="/sources/">素材说明</Link></small><a className="gallery-official" href={product.source.url} target="_blank" rel="noopener noreferrer">核对品牌官方规格 <ArrowUpRight size={12}/></a></> : <span>外观与细节请以品牌官方资料为准。</span>}</figcaption>
  </figure>;
}
