'use client';
import Link from 'next/link';
import { useState } from 'react';
import { ArrowUpRight, Search, Sparkles, X } from 'lucide-react';
import { filterGlossary, glossary } from '@/lib/beginner-content';
import { useCompanion } from '@/components/companion/provider';
const steps = [
 { title: '定预算', text: '写下总上限，给必要配件、保修或维修留出余量。', href: '/recommend/?budget=2000', label: '整理我的预算' },
 { title: '定用途', text: '列出每天必须完成的事，把最重要的一项放在前面。', href: '/recommend/', label: '进入需求问卷' },
 { title: '看懂核心参数', text: '先弄懂内存、存储和屏幕，再查与你的用途有关的参数。', href: '#glossary', label: '打开术语速查' },
 { title: '全新 / 二手决策', text: '把省心程度、售后和验机成本一起比较，别只看标价。', href: '/guides/used-phone-basics/', label: '读懂二手取舍' },
];
export function BeginnerGuide() {
 const [query, setQuery] = useState(''); const terms = filterGlossary(query); const { openChat } = useCompanion();
 return <><ol className="beginner-steps" aria-label="五步选购路径">{steps.map((step, i) => <li key={step.title}><span className="step-orbit">0{i + 1}</span><div><h2>{step.title}</h2><p>{step.text}</p><Link href={step.href} className="text-link">{step.label}<ArrowUpRight size={15}/></Link></div></li>)}<li id="ask-xiaopai"><span className="step-orbit"><Sparkles size={20}/></span><div><h2>用小派聊聊</h2><p>把预算和用途告诉小派，一起找出值得核价的备选与取舍。</p><button className="text-link" onClick={() => openChat('我是第一次买数码设备，请帮我从预算和主要用途开始整理需求。')}>和小派聊聊<ArrowUpRight size={15}/></button><small>只填入问题，点击发送后才调用顾问服务。</small></div></li></ol><section id="glossary" className="glossary-section" aria-labelledby="glossary-title"><div className="section-heading"><div><span className="section-kicker">LESS JARGON. MORE CLARITY.</span><h2 id="glossary-title">参数，不必靠猜。</h2><p>{glossary.length} 个常见术语，一句话看懂。</p></div></div><div className="glossary-search"><Search size={19}/><label htmlFor="glossary-query" className="sr-only">搜索术语或解释</label><input id="glossary-query" value={query} onChange={e => setQuery(e.target.value)} maxLength={80} placeholder="试试 SoC、刷新率、IP68…" type="search"/>{query && <button aria-label="清空术语搜索" onClick={() => setQuery('')}><X size={16}/></button>}</div><p className="glossary-count" role="status">{query ? `找到 ${terms.length} 个术语` : '从常见参数开始了解'}</p>{terms.length ? <dl className="glossary-grid">{terms.map(term => <div key={term.id}><dt>{term.term}</dt><dd>{term.explanation}</dd></div>)}</dl> : <div className="empty-state"><Search size={30}/><h3>这个词还没收录</h3><p>换个短词试试，例如“屏幕”或“电池”。</p><button className="button button-outline" onClick={() => setQuery('')}>查看全部术语</button></div>}</section></>;
}
