import Link from 'next/link';
import { ArrowUpRight, BookOpen } from 'lucide-react';
import { historicalReferences } from '@/lib/research';
export function ReviewEvidence({ productId }: { productId: string }) {
  const references = historicalReferences(productId);
  return <section className="detail-section product-research"><div className="section-heading"><div><span className="section-kicker">REVIEWS IN CONTEXT</span><h2>参考评测，也看清条件。</h2></div><Link href="/methodology/" className="text-link"><BookOpen size={15}/>推荐依据</Link></div><p className="muted">{references.length ? '这些来源讨论了同一型号，但本轮只核对到公开简介；测试配置与地区未确认，不能直接作为当前配置的分项评分。' : '尚未录入该具体型号与配置的可用评测结论。其他Pro版本、地区或年份的结论不会自动套用到它身上。'}</p>{references.length > 0 && <div className="product-research-list">{references.map(s => <article key={s.id}><span>{s.publishedAt} · {s.creator}</span><h3><a href={s.url} target="_blank" rel="noopener noreferrer">{s.title} <ArrowUpRight size={13}/></a></h3><p>{s.summary}</p><small>{s.limitations}</small></article>)}</div>}<p className="small muted">资料库适用场景和0–5等级是本站编辑判断。历史评测不证明今天的二手电池、维修史、系统维护状态或价格。</p></section>;
}
