import { ExternalLink } from 'lucide-react';
import type { OfferAssessment } from '@/lib/recommend';
import { priceText } from '@/lib/prices';
export function RecommendationOffer({ offer, budget }: { offer: OfferAssessment; budget: number }) {
 const evidence = offer.evidence; const gap = Math.max(0, offer.totalCeiling - budget);
 return <div className="recommendation-price-evidence"><div className="planning-price-heading"><span>{offer.mode === 'new' ? '全新' : '二手'} · {evidence?.label || '报价参考'}</span><strong>{priceText(offer.price)}</strong></div><dl><div><dt>价格对应配置</dt><dd>{evidence?.configuration || '以报价来源为准'}</dd></div>{evidence?.region && <div><dt>价格地区</dt><dd>{evidence.region}</dd></div>}<div><dt>记录日期</dt><dd>{evidence?.checkedAt || offer.price.collectedAt} · 非实时价格</dd></div><div><dt>含预留核算</dt><dd>¥{offer.totalCeiling.toLocaleString('zh-CN')}{gap ? ` · 超出原预算 ¥${gap.toLocaleString('zh-CN')}` : ' · 未超出原预算'}</dd></div></dl>{evidence?.note && <p>{evidence.note}</p>}{evidence?.sourceUrl && <a href={evidence.sourceUrl} target="_blank" rel="noopener noreferrer">{evidence.sourceLabel}<ExternalLink size={12}/></a>}</div>;
}
export function RecommendationExclusions({ items }: { items: { productId: string; name: string; code: string; reason: string }[] }) {
 return <ul className="recommendation-exclusion-list" aria-label="逐台设备的未入选原因" tabIndex={0}>{items.map(item => <li key={item.productId} data-exclusion-code={item.code}><strong>{item.name}</strong><p>{item.reason}</p></li>)}</ul>;
}
