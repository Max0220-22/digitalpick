'use client';
import { createContext, useCallback, useContext, useEffect, useRef, useState, type MutableRefObject } from 'react';
import { bindThemeScheduler, createThemeTimeline, readingPalette, sceneDaylight, resolveTheme, THEME_STORAGE, type Theme, type ThemeFrame } from '@/lib/theme';
interface ThemeValue { theme: Theme; busy: boolean; ready: boolean; sequence: number; frame: MutableRefObject<ThemeFrame>; toggle: () => boolean; subscribe: (listener: () => void) => () => void }
const ThemeContext = createContext<ThemeValue | null>(null);
export function ThemeProvider({ children }: { children: React.ReactNode }) {
 const [theme, setTheme] = useState<Theme>('dark'), [busy, setBusy] = useState(false), [ready, setReady] = useState(false), [sequence, setSequence] = useState(0);
 const frame = useRef<ThemeFrame>({ daylight: 0, lighting: 0, ui: 0, breath: 0, progress: 1, from: 'dark', to: 'dark', startedAt: 0, duration: 0, sequence: 0, busy: false });
 const timeline = useRef<ReturnType<typeof createThemeTimeline> | null>(null);
 const listeners = useRef(new Set<() => void>());
 const explicit = useRef(false);
 const subscribe = useCallback((listener: () => void) => { listeners.current.add(listener); return () => { listeners.current.delete(listener); }; }, []);
 const toggle = useCallback(() => {
  const controller = timeline.current; if (!controller) return false;
  const next = controller.state.to === 'dark' ? 'light' : 'dark';
  const accepted = controller.start(next, matchMedia('(prefers-reduced-motion: reduce)').matches);
  if (accepted) { explicit.current = true; try { localStorage.setItem(THEME_STORAGE, next); } catch {} }
  return accepted;
 }, []);
 useEffect(() => {
  const system = matchMedia('(prefers-color-scheme: dark)'), motion = matchMedia('(prefers-reduced-motion: reduce)');
  let stored: string | null = null; try { stored = localStorage.getItem(THEME_STORAGE); } catch {}
  explicit.current = stored === 'dark' || stored === 'light';
  const initial = resolveTheme(stored, system.matches);
  let finishTimer: ReturnType<typeof setTimeout> | undefined;
  const paint = (value: ThemeFrame) => {
   const root = document.documentElement, palette = readingPalette(value.ui), dark = !palette.darkInk;
   // All reading surfaces use one palette, with a contrast-safe ink polarity crossover.
   root.classList.toggle('dark', dark); root.dataset.theme = dark ? 'dark' : 'light';
   root.dataset.themeTransition = value.busy ? 'running' : 'idle'; root.style.colorScheme = dark ? 'dark' : 'light';
   root.style.setProperty('--daylight', String(value.daylight));
   root.style.setProperty('--scene-daylight', String(sceneDaylight(value)));
   root.style.setProperty('--lighting', String(value.lighting));
   root.style.setProperty('--ui-daylight', String(value.ui));
   root.style.setProperty('--sky-breath', String(value.breath));
   root.style.setProperty('--reading-surface', palette.surface);
   root.style.setProperty('--reading-ink', palette.ink);
   root.dataset.themeProgress = value.progress.toFixed(3);
   for (const listener of listeners.current) listener();
  };
  const controller = createThemeTimeline(initial, { ...bindThemeScheduler(window),
   paint, start: value => { setTheme(value.to); setBusy(value.busy); setSequence(value.sequence); if (value.busy) finishTimer = setTimeout(() => controller.finish(), value.duration + 20); }, finish: () => { clearTimeout(finishTimer); setBusy(false); } });
  timeline.current = controller; frame.current = controller.state; setTheme(initial); setReady(true); paint(controller.state);
  const systemChange = () => { if (!explicit.current) controller.start(system.matches ? 'dark' : 'light', motion.matches); };
  const motionChange = () => { if (motion.matches && controller.state.busy) controller.finish(); };
  const storageChange = (event: StorageEvent) => {
   if (event.key !== THEME_STORAGE && event.key !== null) return;
   explicit.current = event.newValue === 'dark' || event.newValue === 'light';
   if (!controller.state.busy) controller.start(resolveTheme(event.newValue, system.matches), motion.matches);
  };
  const visibilityChange = () => { if (document.hidden && controller.state.busy) controller.finish(); };
  document.addEventListener('visibilitychange', visibilityChange);
  system.addEventListener('change', systemChange); motion.addEventListener('change', motionChange); window.addEventListener('storage', storageChange);
  return () => { clearTimeout(finishTimer); controller.dispose(); timeline.current = null; document.removeEventListener('visibilitychange', visibilityChange); system.removeEventListener('change', systemChange); motion.removeEventListener('change', motionChange); window.removeEventListener('storage', storageChange); };
 }, []);
 return <ThemeContext value={{ theme, busy, ready, sequence, frame, toggle, subscribe }}>{children}</ThemeContext>;
}
export function useTheme() { const value = useContext(ThemeContext); if (!value) throw new Error('ThemeProvider is required'); return value; }
