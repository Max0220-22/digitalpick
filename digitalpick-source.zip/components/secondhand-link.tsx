import type { Product } from '@/lib/products';
import { secondhandSearch, priceCheckSteps } from '@/lib/secondhand';
export function SecondhandLink({product}:{product:Product}) {
 return <div className="secondhand-link"><a href={secondhandSearch(product)} target="_blank" rel="noopener" aria-label={`在闲鱼查看 ${product.name} 实时价`}>闲鱼实时价 →</a><small>实时价格以平台页面为准</small><details className="price-check"><summary>核价三步</summary><ol>{priceCheckSteps(product).map((step,index)=><li key={step.title}><strong>{index+1}. {step.title}</strong><p>{step.text}</p></li>)}</ol><small>非实时价格，购买前请核实；平台搜索结果不代表本站推荐卖家。</small></details></div>;
}
