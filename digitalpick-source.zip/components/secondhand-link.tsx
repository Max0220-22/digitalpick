import type { Product } from '@/lib/products';
import { secondhandSearch } from '@/lib/secondhand';
export function SecondhandLink({ product }: { product: Product }) {
 return <div className="secondhand-link"><a href={secondhandSearch(product)} target="_blank" rel="noopener" aria-label={`在闲鱼查看 ${product.name} 实时价`}>闲鱼实时价 →</a><small>实时价格以平台页面为准</small></div>;
}
