'use client';
import Link from 'next/link';
import { useEffect, useSyncExternalStore } from 'react';
import { Heart } from 'lucide-react';
import { products } from '@/lib/products';
import { createWishlistStore, WISHLIST_KEY, WISHLIST_LIMIT } from '@/lib/wishlist';
const store = createWishlistStore(new Set(products.map(product => product.id)), () => window.localStorage);
export function useWishlist() {
 const snapshot = useSyncExternalStore(store.subscribe, store.getSnapshot, store.getServerSnapshot);
 useEffect(() => { store.refresh(); const sync = (event: StorageEvent) => { if (event.key === WISHLIST_KEY || event.key === null) store.refresh(); }; window.addEventListener('storage', sync); return () => window.removeEventListener('storage', sync); }, []);
 return snapshot;
}
export function WishlistButton({ id, name }: { id: string; name: string }) {
 const { ids, ready, error } = useWishlist(); const saved = ids.includes(id); const full = !saved && ids.length >= WISHLIST_LIMIT;
 return <span className="wishlist-action"><button type="button" className={`wishlist-button ${saved ? 'is-saved' : ''}`} aria-pressed={saved} aria-label={`${saved ? '取消收藏' : '收藏'} ${name}`} disabled={!ready || full} title={full ? `最多收藏 ${WISHLIST_LIMIT} 款，请先移除一些设备` : undefined} onClick={() => store.toggle(id)}><Heart size={15} fill={saved ? 'currentColor' : 'none'} aria-hidden="true"/><span>{saved ? '已收藏' : '收藏'}</span></button>{error && <span className="wishlist-storage-warning" role="status">仅本次页面保留，浏览器存储不可用</span>}</span>;
}
export function WishlistNav() {
 const { ids } = useWishlist();
 return <Link href="/wishlist/" className="wishlist-nav" aria-label={`我的收藏${ids.length ? `，${ids.length}款` : ''}`}><Heart size={18} aria-hidden="true"/><span>我的收藏</span>{ids.length > 0 && <small>{ids.length}</small>}</Link>;
}
