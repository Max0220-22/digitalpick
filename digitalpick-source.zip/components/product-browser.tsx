'use client';
import { useEffect, useMemo, useState } from 'react';
import Link from 'next/link';
import { Search, SlidersHorizontal, X } from 'lucide-react';
import { products, categories, type Category, type PurchaseMode } from '@/lib/products';
import { brandLabels, normalizeCatalogQuery, catalogCoverage } from '@/lib/catalog-expanded';
import { ProductCard } from './product-card';
import { primaryMedia } from '@/lib/product-media';
import { preloadMedia } from '@/lib/media-preload';
import { Button } from './ui/button';
import { GlassSelect } from './ui/select';
const validCategory=(c:string):c is Category=>['phone','tablet','laptop'].includes(c);
const PAGE_SIZE=24;
export function ProductBrowser() {
 const [query,setQuery]=useState(''),[category,setCategory]=useState('all'),[mode,setMode]=useState<PurchaseMode>('either'),[sort,setSort]=useState('year'),[brand,setBrand]=useState(''),[year,setYear]=useState('all'),[page,setPage]=useState(1);
 useEffect(()=>{const p=new URLSearchParams(window.location.search);setQuery((p.get('q')||'').slice(0,100));const b=p.get('brand')||'';if(products.some(d=>d.brand===b))setBrand(b);const c=p.get('category')||'';if(validCategory(c))setCategory(c);const m=p.get('mode');if(m==='new'||m==='used')setMode(m);const y=p.get('year');if(y&&/^20\d\d$/.test(y))setYear(y);},[]);
 const index=useMemo(()=>new Map(products.map(p=>[p.id,normalizeCatalogQuery(`${p.name} ${p.brand} ${brandLabels[p.brand]||''} ${(p.aliases||[]).join(' ')} ${p.processor} ${Object.values(p.facts||{}).filter(Boolean).join(' ')}`)])),[]);
 const filtered=useMemo(()=>products.filter(p=>(category==='all'||p.category===category)&&(!brand||p.brand===brand)&&(year==='all'||(year==='unknown'?p.year===null:String(p.year)===year))&&(index.get(p.id)||'').includes(normalizeCatalogQuery(query.trim()))).sort((a,b)=>sort==='year'?(b.year??0)-(a.year??0)||(a.name<b.name?-1:a.name>b.name?1:0):sort==='weight'?(a.weight??Infinity)-(b.weight??Infinity):0),[category,query,sort,brand,year,index]);
 useEffect(()=>setPage(1),[category,query,sort,brand,year]);
 const pages=Math.max(1,Math.ceil(filtered.length/PAGE_SIZE)),currentPage=Math.min(page,pages),shown=filtered.slice((currentPage-1)*PAGE_SIZE,currentPage*PAGE_SIZE);
 const brands=[...new Set(products.filter(p=>category==='all'||p.category===category).map(p=>p.brand))];
 function warmCategory(next: string) {
  const preview=products.filter(p=>(next==='all'||p.category===next)&&(year==='all'||(year==='unknown'?p.year===null:String(p.year)===year))&&(index.get(p.id)||'').includes(normalizeCatalogQuery(query.trim()))).sort((a,b)=>sort==='year'?(b.year??0)-(a.year??0)||(a.name<b.name?-1:1):sort==='weight'?(a.weight??Infinity)-(b.weight??Infinity):0);
  preloadMedia(preview.slice(0,3).map(p=>primaryMedia(p.id)?.src));
 }
 function warmNextPage(){preloadMedia(filtered.slice(currentPage*PAGE_SIZE,currentPage*PAGE_SIZE+3).map(p=>primaryMedia(p.id)?.src));}
 function reset(){setQuery('');setCategory('all');setMode('either');setSort('year');setBrand('');setYear('all');setPage(1);}
 return <><div className="catalog-summary">{categories.map(c=><button key={c.id} aria-pressed={category===c.id} onPointerEnter={()=>warmCategory(c.id)} onFocus={()=>warmCategory(c.id)} onPointerDown={()=>warmCategory(c.id)} onClick={()=>{setCategory(c.id);setBrand('');}}><strong>{products.filter(p=>p.category===c.id).length}</strong><span>{c.name}型号 / 版本</span></button>)}<Link href="/products/coverage/"><strong>{catalogCoverage.length}</strong><span>清单条目核验 ↗</span></Link></div>
 <div className="browser-toolbar"><div className="search-input"><Search size={19}/><input aria-label="搜索产品型号、品牌或用途" placeholder="搜索型号、品牌或芯片，例如 小米平板、MatePad" value={query} onChange={e=>setQuery(e.target.value)} maxLength={100}/>{query&&<button aria-label="清除搜索" onClick={()=>setQuery('')}><X size={16}/></button>}</div><div className="select-inline"><span>价格展示</span><GlassSelect label="购买方式" value={mode} onValueChange={v=>setMode(v as PurchaseMode)} options={[{value:'either',label:'全新与二手',description:'全部型号，不因缺报价隐藏'},{value:'new',label:'全新参考',description:'显示全新参考栏，缺价仍可查参数'},{value:'used',label:'二手参考',description:'显示二手参考栏，缺价仍可查参数'}]}/></div><div className="select-inline"><span>代际</span><GlassSelect label="产品发布年份" value={year} onValueChange={setYear} options={[{value:'all',label:'全部年份'},{value:'unknown',label:'年份待核实'},...[2026,2025,2024,2023,2022,2021,2020,2019,2018,2017].map(y=>({value:String(y),label:`${y} 年`}))]}/></div><div className="select-inline"><span><SlidersHorizontal size={14}/>排序</span><GlassSelect label="产品排序" value={sort} onValueChange={setSort} options={[{value:'year',label:'最近发布'},{value:'default',label:'资料顺序'},{value:'weight',label:'更轻的在前'}]}/></div></div>
 <div className="browser-tabs"><div className="tabs" role="group" aria-label="产品分类">{[{id:'all',name:'全部设备'},...categories].map(c=><button key={c.id} aria-pressed={category===c.id} className={category===c.id?'selected':''} onPointerEnter={()=>warmCategory(c.id)} onFocus={()=>warmCategory(c.id)} onPointerDown={()=>warmCategory(c.id)} onClick={()=>{setCategory(c.id);setBrand('');}}>{c.name}</button>)}</div><span className="small muted" aria-live="polite">{filtered.length} 款型号 / 地区版本</span></div><div className="brand-filter" role="group" aria-label="品牌筛选">{['',...brands].map(b=><button key={b} aria-pressed={brand===b} onClick={()=>setBrand(b)}>{b?brandLabels[b]||b:'全部品牌'}</button>)}</div>
 <p className="small muted catalog-price-note">缺少报价不代表没有这款设备。这里仍可查看型号与已核对参数；具体在售状态、完整配置与实测结论需继续确认。</p>
 {shown.length?<div className="product-grid">{shown.map(p=><ProductCard key={p.id} product={p} mode={mode}/>)}</div>:<div className="empty-state"><Search size={32}/><h2>还没找到符合条件的设备</h2><p>试试更短的型号或切换品牌。未确认名称可在清单核验页查看说明。</p><Button variant="outline" onClick={reset}>清除筛选</Button><Link className="text-link" href="/products/coverage/">查看清单核验 ↗</Link></div>}
 <div className="library-pagination"><Button variant="outline" disabled={currentPage<=1} onClick={()=>setPage(currentPage-1)}>上一页</Button><span>{currentPage} / {pages}</span><Button variant="outline" disabled={currentPage>=pages} onPointerEnter={warmNextPage} onFocus={warmNextPage} onClick={()=>setPage(currentPage+1)}>下一页</Button></div></>;
}
