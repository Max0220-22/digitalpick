'use client';
import Link from 'next/link';
import { Heart, ArrowUpRight } from 'lucide-react';
import { getProduct } from '@/lib/products';
import { ProductCard } from './product-card';
import { useWishlist } from './wishlist';
export function WishlistBrowser() {
 const { ids, ready, error } = useWishlist();
 if (!ready) return <div className="wishlist-loading" role="status">正在读取这台设备的收藏…</div>;
 const saved = ids.map(id => getProduct(id)).filter(product => !!product);
 return <>{error && <p className="notice-box" role="status">当前浏览器无法使用本地存储。收藏仅在本次页面中保留，刷新后可能丢失。</p>}<div className="wishlist-toolbar"><span role="status">{saved.length} 款心愿设备</span><span>只存在这台设备的当前浏览器 · 无需登录</span></div>{saved.length ? <><div className="product-grid">{saved.map(product => <ProductCard key={product.id} product={product}/>)}</div><p className="wishlist-footnote">点击“已收藏”即可移除；点击“对比”可带入对比页，最多比较 3 款。收藏不代表价格或库存承诺。</p></> : <div className="empty-state wishlist-empty"><span className="empty-heart"><Heart size={30} strokeWidth={1.3}/></span><h2>把心动的设备，先放在这里。</h2><p>在产品卡片上点一下爱心，就能慢慢比较。<br/>刷新后还在，清理浏览器数据后会移除。</p><Link href="/products/" className="button button-primary">去产品库逛逛<ArrowUpRight size={16}/></Link><Link href="/start/" className="text-link">还没想好？从新人指南开始</Link></div>}</>;
}
