import { Laptop, Smartphone, Tablet } from 'lucide-react';
import type { Category } from '@/lib/products';
import { primaryMedia } from '@/lib/product-media';
import { ProductMediaImage } from './product-media-image';
import { cn } from '@/lib/utils';
export function productVisualLabel(id: string) { return primaryMedia(id)?.label || '外观待补充'; }
export function DeviceArt({ category, productId, className = '' }: { category: Category; productId?: string; color?: string; className?: string }) {
  const media = productId ? primaryMedia(productId) : undefined;
  if (media) return <div className={cn('product-photograph official-product', className)}><ProductMediaImage key={media.src} media={media}/><span className="photo-source-hint">{media.owner} · 官方来源见详情</span></div>;
  const Icon = category === 'phone' ? Smartphone : category === 'tablet' ? Tablet : Laptop;
  return <div className={cn('product-no-photo', className)} role="img" aria-label="暂缺已核对的官方外观图"><Icon size={70} strokeWidth={.7}/><span>外观请查看品牌官方资料</span></div>;
}
