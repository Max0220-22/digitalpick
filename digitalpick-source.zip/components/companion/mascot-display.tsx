'use client';

import dynamic from 'next/dynamic';
import { Component, useCallback, useEffect, useState, useRef, type ReactNode } from 'react';
import { useCompanion } from './provider';
import { MascotFallback } from './fallback';
import { useTheme } from '../theme-provider';
import { isModelTap } from '@/lib/companion/model-hit';

export type RendererState = 'loading' | 'starting' | '3d' | '2d' | 'failed';
const Scene = dynamic(() => import('./mascot-scene'), { ssr: false, loading: () => <MascotFallback /> });
class SceneBoundary extends Component<{ children: ReactNode; fallback: ReactNode; onFailure: () => void }, { failed: boolean }> {
  state = { failed: false };
  static getDerivedStateFromError() { return { failed: true }; }
  componentDidCatch() { this.props.onFailure(); }
  render() { return this.state.failed ? this.props.fallback : this.props.children; }
}
export function MascotDisplay({ compact = false, lightweight = false, visible = true, onRendererChange, onActivate }: { compact?: boolean; lightweight?: boolean; visible?: boolean; onRendererChange?: (state: RendererState) => void; onActivate?: () => boolean }) {
  const { state, gaze, flight, active, reducedMotion } = useCompanion();
  const { busy, theme, sequence } = useTheme();
  const pointerStart = useRef({ x: 0, y: 0 }), dragged = useRef(false);
  const fallback = <div className={onActivate ? 'fallback-theme-target' : 'fallback-static'} onClick={onActivate ? event => { if (event.detail === 0 || !dragged.current) onActivate(); } : undefined}><MascotFallback mood={state.phase}/></div>;
  const [failed, setFailed] = useState(false);
  const [ready, setReady] = useState(false);
  const [created, setCreated] = useState(false);
  const onFailure = useCallback(() => setFailed(true), []);
  const onReady = useCallback(() => setCreated(true), []);
  const renderer: RendererState = lightweight ? '2d' : failed ? 'failed' : !ready ? 'loading' : created ? '3d' : 'starting';
  useEffect(() => { onRendererChange?.(renderer); }, [renderer, onRendererChange]);
  useEffect(() => {
    const timer = setTimeout(() => setReady(true), 180);
    return () => clearTimeout(timer);
  }, []);
  return <div className={`mascot-display ${compact ? 'compact' : ''}`} data-renderer={renderer} data-mood={state.phase} data-theme-pose={busy ? theme === 'light' ? 'wake' : 'sleep' : 'idle'} data-theme-sequence={sequence}
    aria-hidden={onActivate ? undefined : true} role={onActivate ? 'button' : undefined} tabIndex={onActivate ? 0 : undefined}
    aria-label={onActivate ? `点击小派${theme === 'dark' ? '点亮天空' : '切回星河'}；支持回车或空格` : undefined} aria-disabled={onActivate ? busy : undefined}
    onKeyDown={onActivate ? event => { if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); onActivate(); } } : undefined}
    onPointerDown={event => { pointerStart.current = { x: event.clientX, y: event.clientY }; dragged.current = false; }}
    onPointerMove={event => { if (event.buttons && !isModelTap(pointerStart.current, { x: event.clientX, y: event.clientY })) dragged.current = true; }}>
    <SceneBoundary onFailure={onFailure} fallback={fallback}>
      {!ready || failed || lightweight ? fallback : <Scene compact={compact} mood={state.phase} focus={state.focus} gaze={gaze} flight={flight} active={active && visible} animate={state.motion && !reducedMotion} onFailure={onFailure} onReady={onReady} onActivate={onActivate} />}
    </SceneBoundary>
  </div>;
}
