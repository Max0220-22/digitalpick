'use client';

import dynamic from 'next/dynamic';
import { Component, useCallback, useEffect, useRef, useState, type ReactNode } from 'react';
import { useCompanion } from './provider';
import { MascotFallback } from './fallback';

const Scene = dynamic(() => import('./mascot-scene'), { ssr: false, loading: () => <MascotFallback /> });
class SceneBoundary extends Component<{ children: ReactNode; fallback: ReactNode }, { failed: boolean }> {
  state = { failed: false };
  static getDerivedStateFromError() { return { failed: true }; }
  render() { return this.state.failed ? this.props.fallback : this.props.children; }
}
export function MascotDisplay({ compact = false, lightweight = false, visible = true }: { compact?: boolean; lightweight?: boolean; visible?: boolean }) {
  const { state, gaze, flight, active, reducedMotion } = useCompanion();
  const [failed, setFailed] = useState(false);
  const [ready, setReady] = useState(false);
  const host = useRef<HTMLDivElement>(null);
  const onFailure = useCallback(() => setFailed(true), []);
  useEffect(() => {
    // Keep the server-rendered fallback visible while the main page becomes interactive.
    const timer = setTimeout(() => setReady(true), 180);
    return () => clearTimeout(timer);
  }, []);
  return <div ref={host} className={`mascot-display ${compact ? 'compact' : ''}`} data-renderer={failed || lightweight ? '2d' : ready ? '3d' : 'loading'} data-mood={state.phase} aria-hidden="true">
    <SceneBoundary fallback={<MascotFallback mood={state.phase} />}>
      {!ready || failed || lightweight ? <MascotFallback mood={state.phase} /> : <Scene compact={compact} mood={state.phase} focus={state.focus} gaze={gaze} flight={flight} active={active && visible} animate={state.motion && !reducedMotion} onFailure={onFailure} />}
    </SceneBoundary>
  </div>;
}
