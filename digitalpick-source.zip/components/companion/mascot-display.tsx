'use client';

import dynamic from 'next/dynamic';
import { Component, useCallback, useEffect, useState, type ReactNode } from 'react';
import { useCompanion } from './provider';
import { MascotFallback } from './fallback';

export type RendererState = 'loading' | 'starting' | '3d' | '2d' | 'failed';
const Scene = dynamic(() => import('./mascot-scene'), { ssr: false, loading: () => <MascotFallback /> });
class SceneBoundary extends Component<{ children: ReactNode; fallback: ReactNode; onFailure: () => void }, { failed: boolean }> {
  state = { failed: false };
  static getDerivedStateFromError() { return { failed: true }; }
  componentDidCatch() { this.props.onFailure(); }
  render() { return this.state.failed ? this.props.fallback : this.props.children; }
}
export function MascotDisplay({ compact = false, lightweight = false, visible = true, onRendererChange }: { compact?: boolean; lightweight?: boolean; visible?: boolean; onRendererChange?: (state: RendererState) => void }) {
  const { state, gaze, flight, active, reducedMotion } = useCompanion();
  const [failed, setFailed] = useState(false);
  const [ready, setReady] = useState(false);
  const [created, setCreated] = useState(false);
  const onFailure = useCallback(() => setFailed(true), []);
  const onReady = useCallback(() => setCreated(true), []);
  const renderer: RendererState = lightweight ? '2d' : failed ? 'failed' : !ready ? 'loading' : created ? '3d' : 'starting';
  useEffect(() => { onRendererChange?.(renderer); }, [renderer, onRendererChange]);
  useEffect(() => {
    const timer = setTimeout(() => setReady(true), 180);
    return () => clearTimeout(timer);
  }, []);
  return <div className={`mascot-display ${compact ? 'compact' : ''}`} data-renderer={renderer} data-mood={state.phase} aria-hidden="true">
    <SceneBoundary onFailure={onFailure} fallback={<MascotFallback mood={state.phase} />}>
      {!ready || failed || lightweight ? <MascotFallback mood={state.phase} /> : <Scene compact={compact} mood={state.phase} focus={state.focus} gaze={gaze} flight={flight} active={active && visible} animate={state.motion && !reducedMotion} onFailure={onFailure} onReady={onReady} />}
    </SceneBoundary>
  </div>;
}
