'use client';

import dynamic from 'next/dynamic';
import { Component, useCallback, useEffect, useState, type ReactNode } from 'react';
import { useCompanion } from './provider';
import { MascotFallback } from './fallback';
import { useTheme } from '../theme-provider';

export type RendererState = 'loading' | 'starting' | '3d' | '2d' | 'failed';
const Scene = dynamic(() => import('./mascot-scene'), { ssr: false, loading: () => <MascotFallback /> });
class SceneBoundary extends Component<{ children: ReactNode; fallback: ReactNode; onFailure: () => void }, { failed: boolean }> {
  state = { failed: false };
  static getDerivedStateFromError() { return { failed: true }; }
  componentDidCatch() { this.props.onFailure(); }
  render() { return this.state.failed ? this.props.fallback : this.props.children; }
}
export function MascotDisplay({ compact = false, lightweight = false, visible = true, onRendererChange, onActivate, onChat }: { compact?: boolean; lightweight?: boolean; visible?: boolean; onRendererChange?: (state: RendererState) => void; onActivate?: () => boolean; onChat?: () => void }) {
  const { state, gaze, flight, active, reducedMotion } = useCompanion();
  const { busy, theme, sequence } = useTheme();
  const interactive = !!(onActivate || onChat);
  const themeLabel = theme === 'dark' ? '点胸前按钮切换为日间' : '点胸前按钮切换为夜间';
  const fallback = <div className={interactive ? 'fallback-theme-target' : 'fallback-static'}><MascotFallback mood={state.phase} onChat={onChat} onTheme={onActivate} themeBusy={busy} themeLabel={themeLabel}/></div>;
  const [failed, setFailed] = useState(false);
  const [ready, setReady] = useState(false);
  const [created, setCreated] = useState(false);
  const onFailure = useCallback(() => setFailed(true), []);
  const onReady = useCallback(() => setCreated(true), []);
  const renderer: RendererState = lightweight ? '2d' : failed ? 'failed' : !ready ? 'loading' : created ? '3d' : 'starting';
  useEffect(() => { onRendererChange?.(renderer); }, [renderer, onRendererChange]);
  useEffect(() => {
    const timer = setTimeout(() => setReady(true), 180);
    return () => clearTimeout(timer);
  }, []);
  return <div className={`mascot-display ${compact ? 'compact' : ''}`} data-renderer={renderer} data-mood={state.phase} data-theme-pose={busy ? theme === 'light' ? 'wake' : 'sleep' : 'idle'} data-theme-sequence={sequence}
    aria-hidden={interactive ? undefined : true} role={interactive ? 'group' : undefined} aria-label={interactive ? '小派：点头聊天，点胸前按钮切换日夜' : undefined}>
    <SceneBoundary onFailure={onFailure} fallback={fallback}>
      {!ready || failed || lightweight ? fallback : <Scene compact={compact} mood={state.phase} focus={state.focus} gaze={gaze} flight={flight} active={active && visible} animate={state.motion && !reducedMotion} onFailure={onFailure} onReady={onReady} onActivate={onActivate} onChat={onChat} />}
    </SceneBoundary>
    {interactive && ready && !failed && !lightweight && <>
      {onChat && <button type="button" className="mascot-keyboard-action" onClick={onChat}>点小派的头打开对话</button>}
      {onActivate && <button type="button" className="mascot-keyboard-action" disabled={busy} onClick={onActivate}>{themeLabel}</button>}
    </>}
  </div>;
}
