'use client';

import { Canvas, useFrame, useThree, type ThreeElements } from '@react-three/fiber';
import { useEffect, useMemo, useRef } from 'react';
import { Color, Group, Mesh, MeshStandardMaterial, PMREMGenerator, MathUtils, Shape, ExtrudeGeometry } from 'three';
import { RoundedBoxGeometry } from 'three/addons/geometries/RoundedBoxGeometry.js';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import type { CompanionMood, DeviceFocus } from '@/lib/companion/state';
import { MascotFallback } from './fallback';

type Gaze = { current: { x: number; y: number } };
interface SceneProps { mood: CompanionMood; focus: DeviceFocus; gaze: Gaze; flight: { current: { at: number; x: number; y: number } }; animate: boolean; active: boolean; compact?: boolean; onFailure: () => void }

function SoftBox({ args, children, ...props }: { args: [number, number, number, number]; children: React.ReactNode } & Omit<ThreeElements['mesh'], 'args' | 'children'>) {
  const geometry = useMemo(() => new RoundedBoxGeometry(args[0], args[1], args[2], 3, args[3]), [args[0], args[1], args[2], args[3]]);
  useEffect(() => () => geometry.dispose(), [geometry]);
  return <mesh {...props}><primitive object={geometry} attach="geometry" />{children}</mesh>;
}
function RoundedPanel({ width, height, depth, radius, children, ...props }: { width: number; height: number; depth: number; radius: number; children: React.ReactNode } & Omit<ThreeElements['mesh'], 'args' | 'children'>) {
  const geometry = useMemo(() => {
    const x = -width / 2, y = -height / 2, r = radius;
    const shape = new Shape();
    shape.moveTo(x + r, y); shape.lineTo(x + width - r, y); shape.quadraticCurveTo(x + width, y, x + width, y + r);
    shape.lineTo(x + width, y + height - r); shape.quadraticCurveTo(x + width, y + height, x + width - r, y + height);
    shape.lineTo(x + r, y + height); shape.quadraticCurveTo(x, y + height, x, y + height - r);
    shape.lineTo(x, y + r); shape.quadraticCurveTo(x, y, x + r, y);
    const result = new ExtrudeGeometry(shape, { depth, bevelEnabled: true, bevelSize: 0.018, bevelThickness: 0.015, bevelSegments: 2, steps: 1, curveSegments: 7 });
    result.translate(0, 0, -depth / 2);
    return result;
  }, [width, height, depth, radius]);
  useEffect(() => () => geometry.dispose(), [geometry]);
  return <mesh {...props}><primitive object={geometry} attach="geometry" />{children}</mesh>;
}
function Environment({ onFailure }: { onFailure: () => void }) {
  const { gl, scene } = useThree();
  useEffect(() => {
    const generator = new PMREMGenerator(gl);
    const room = new RoomEnvironment();
    const target = generator.fromScene(room, 0.04);
    scene.environment = target.texture;
    const handleLoss = (event: Event) => { event.preventDefault(); onFailure(); };
    gl.domElement.addEventListener('webglcontextlost', handleLoss);
    return () => { scene.environment = null; target.dispose(); room.dispose(); generator.dispose(); gl.domElement.removeEventListener('webglcontextlost', handleLoss); };
  }, [gl, scene, onFailure]);
  return null;
}

function Robot({ mood, focus, gaze, flight, animate, compact }: Omit<SceneProps, 'onFailure' | 'active'>) {
  const body = useRef<Group>(null!);
  const head = useRef<Group>(null!);
  const eyes = useRef<Group>(null!);
  const leftEye = useRef<Mesh>(null!);
  const rightEye = useRef<Mesh>(null!);
  const leftArm = useRef<Group>(null!);
  const rightArm = useRef<Group>(null!);
  const pedestal = useRef<Mesh>(null!);
  const core = useRef<MeshStandardMaterial>(null!);
  const ring = useRef<Group>(null!);
  const elapsed = useRef(0);
  const camera = useThree(s => s.camera);
  const accent = useMemo(() => new Color(focus === 'tablet' ? '#9d7dff' : focus === 'laptop' ? '#40c5bd' : '#4288ff'), [focus]);
  useFrame((_, delta) => {
    const dt = Math.min(delta, 0.05);
    if (animate) elapsed.current += dt;
    const t = elapsed.current;
    const target = animate ? gaze.current : { x: 0, y: 0 };
    const sinceClick = (performance.now() - flight.current.at) / 1000;
    const flightAmount = animate && flight.current.at > 0 && sinceClick >= 0 && sinceClick < 2 ? Math.sin(sinceClick / 2 * Math.PI) * .8 : 0;
    const waving = animate && (t < 3 || t % 13 < 2.2 || flightAmount > .1);
    const excited = mood === 'greeting' || mood === 'success' || waving;
    const listening = mood === 'listening';
    const sleepy = mood === 'sleeping';
    const thinking = mood === 'thinking';
    const sway = animate && !sleepy;
    const travel = compact ? .08 : .5;
    body.current.position.x = MathUtils.damp(body.current.position.x, sway ? target.x * travel + flight.current.x * flightAmount * travel * .7 : 0, 2.5, dt);
    body.current.position.y = MathUtils.damp(body.current.position.y, sway ? Math.sin(t * 1.2) * .11 + target.y * travel * .5 + flight.current.y * flightAmount * .25 : 0, 3, dt);
    body.current.position.z = MathUtils.damp(body.current.position.z, flightAmount * (compact ? .1 : .6), 3, dt);
    body.current.rotation.z = MathUtils.damp(body.current.rotation.z, sway ? Math.sin(t * 0.8) * 0.025 - target.x * 0.025 : 0, 4, dt);
    body.current.rotation.y = MathUtils.damp(body.current.rotation.y, target.x * 0.16 - 0.12, 4, dt);
    head.current.rotation.y = MathUtils.damp(head.current.rotation.y, target.x * 0.35 + (thinking && sway ? Math.sin(t * 1.5) * 0.08 : 0), 5, dt);
    head.current.rotation.x = MathUtils.damp(head.current.rotation.x, -target.y * 0.19 + (listening ? 0.1 : 0), 5, dt);
    head.current.rotation.z = MathUtils.damp(head.current.rotation.z, mood === 'error' ? -0.16 : excited ? 0.07 : 0, 4, dt);
    const blink = animate && ((t % 4.8 > 4.55 && t % 4.8 < 4.72) || (t % 11 > 10.6 && t % 11 < 10.72));
    const eyeScale = sleepy ? 0.12 : blink ? 0.08 : excited ? 1.1 : 1;
    leftEye.current.scale.y = MathUtils.damp(leftEye.current.scale.y, 0.19 * eyeScale, 30, dt);
    rightEye.current.scale.y = MathUtils.damp(rightEye.current.scale.y, 0.19 * (mood === 'error' ? 0.5 : eyeScale), 30, dt);
    eyes.current.position.x = MathUtils.damp(eyes.current.position.x, target.x * 0.055, 6, dt);
    eyes.current.position.y = MathUtils.damp(eyes.current.position.y, target.y * 0.04, 6, dt);
    leftArm.current.rotation.z = MathUtils.damp(leftArm.current.rotation.z, excited && sway ? -0.5 + Math.sin(t * 7) * 0.2 : -0.2 + (sway ? Math.sin(t * 1.5) * 0.045 : 0), 5, dt);
    rightArm.current.position.x = MathUtils.damp(rightArm.current.position.x, waving ? 1.05 : .7, 5, dt);
    rightArm.current.position.y = MathUtils.damp(rightArm.current.position.y, waving ? .18 : -.64, 5, dt);
    rightArm.current.rotation.z = MathUtils.damp(rightArm.current.rotation.z, waving ? 2.3 + Math.sin(t * 9) * .32 : .22 + (sway ? Math.cos(t * 1.5) * .045 : 0), 5, dt);
    core.current.emissiveIntensity = thinking && sway ? 0.8 + Math.sin(t * 3) * 0.35 : 0.7;
    core.current.color.lerp(accent, 0.05); core.current.emissive.lerp(accent, 0.05);
    if (ring.current && sway) ring.current.rotation.z = t * 0.13;
    if (pedestal.current) pedestal.current.scale.setScalar(.55 + flightAmount * .5);
    // Camera stays fixed so motion never interferes with page navigation or scroll.
    camera.lookAt(0, compact ? 0.05 : -0.03, 0);
  });

  return <>
    <group ref={body} position={[0, 0, 0]}>
      <group ref={head} position={[0, 0.55, 0]}>
        <SoftBox args={[2.14, 1.62, 1.17, 0.48]}>
          <meshPhysicalMaterial color="#dae3f1" metalness={0.42} roughness={0.19} clearcoat={1} clearcoatRoughness={0.08} iridescence={compact ? 0 : 0.2} iridescenceIOR={1.3} />
        </SoftBox>
        <RoundedPanel width={1.91} height={1.34} depth={0.12} radius={0.36} position={[0, -0.02, 0.59]}>
          <meshStandardMaterial color="#627490" roughness={0.18} metalness={0.82} />
        </RoundedPanel>
        <RoundedPanel width={1.8} height={1.22} depth={0.045} radius={0.31} position={[0, -0.03, 0.7]}>
          <meshPhysicalMaterial color="#070d19" roughness={0.15} clearcoat={1} clearcoatRoughness={0.04} metalness={0.23} />
        </RoundedPanel>
        <group ref={eyes} position={[0, 0.01, 0.77]}>
          <mesh ref={leftEye} position={[-0.37, 0.02, 0]} scale={[0.13, 0.19, 0.07]}><sphereGeometry args={[1, 20, 16]} /><meshBasicMaterial color="#c1e6ff" toneMapped={false} /></mesh>
          <mesh ref={rightEye} position={[0.37, 0.02, 0]} scale={[0.13, 0.19, 0.07]}><sphereGeometry args={[1, 20, 16]} /><meshBasicMaterial color="#c1e6ff" toneMapped={false} /></mesh>
          <mesh position={[0, -0.25, 0]} rotation={[0, 0, Math.PI]}><torusGeometry args={[0.12, 0.019, 8, 20, Math.PI]} /><meshBasicMaterial color="#71c6ef" toneMapped={false} /></mesh>
          {[-0.64, 0.64].map(x => <mesh key={x} position={[x, -0.17, -0.007]} scale={[0.075, 0.017, 0.02]}><sphereGeometry args={[1, 12, 8]} /><meshBasicMaterial color="#8ca8e4" transparent opacity={0.35} /></mesh>)}
        </group>
        <SoftBox args={[0.47, 0.055, 0.035, 0.02]} position={[-0.45, 0.64, 0.46]} rotation={[0, 0, 0.03]}><meshBasicMaterial color="#ffffff" transparent opacity={0.8} /></SoftBox>
        {[-1, 1].map(side => <group key={side} position={[side * 1.13, -0.02, 0]} rotation={[0, 0, side * -0.07]}><mesh rotation={[0, 0, Math.PI / 2]}><cylinderGeometry args={[0.27, 0.27, 0.14, 28]} /><meshPhysicalMaterial color="#a7b8d1" metalness={0.8} roughness={0.18} /></mesh><mesh position={[side * 0.08, 0, 0]} rotation={[0, 0, Math.PI / 2]}><torusGeometry args={[0.17, 0.026, 8, 28]} /><meshBasicMaterial color="#b2cef2" /></mesh></group>)}
        <mesh position={[0.59, 0.91, 0]}><cylinderGeometry args={[0.035, 0.055, 0.26, 12]} /><meshStandardMaterial color="#b0cae9" metalness={0.5} roughness={0.3} /></mesh>
        <mesh position={[0.59, 1.04, 0]}><sphereGeometry args={[0.07, 18, 14]} /><meshStandardMaterial color="#94caff" emissive="#4b99ff" emissiveIntensity={0.7} roughness={0.2} /></mesh>
      </group>
      <mesh position={[0, -0.43, 0]}><cylinderGeometry args={[0.26, 0.32, 0.2, 28]} /><meshPhysicalMaterial color="#9dbadc" metalness={0.6} roughness={0.25} /></mesh>
      <SoftBox args={[1.13, 0.85, 0.83, 0.33]} position={[0, -0.87, 0]} rotation={[0.03, 0, 0]}><meshPhysicalMaterial color="#d0ddef" roughness={0.19} metalness={0.46} clearcoat={1} clearcoatRoughness={0.1} /></SoftBox>
      <mesh position={[0, -0.81, 0.44]}><torusGeometry args={[0.15, 0.025, 10, 32]} /><meshStandardMaterial color="#91c5ff" metalness={0.5} roughness={0.22} /></mesh>
      <mesh position={[0, -0.81, 0.45]} rotation={[Math.PI / 2, 0, 0]}><cylinderGeometry args={[0.09, 0.09, 0.025, 28]} /><meshStandardMaterial ref={core} color={accent} emissive={accent} emissiveIntensity={0.7} roughness={0.2} /></mesh>
      <group ref={leftArm} position={[-0.7, -0.64, 0]}><mesh position={[-0.08, -0.23, 0]} scale={[0.17, 0.36, 0.2]} rotation={[0, 0, -0.18]}><sphereGeometry args={[1, 24, 18]} /><meshPhysicalMaterial color="#b7c9e1" roughness={0.18} clearcoat={1} metalness={0.55} /></mesh></group>
      <group ref={rightArm} position={[0.7, -0.64, 0]}><mesh position={[0.08, -0.23, 0]} scale={[0.17, 0.36, 0.2]} rotation={[0, 0, 0.18]}><sphereGeometry args={[1, 24, 18]} /><meshPhysicalMaterial color="#b7c9e1" roughness={0.18} clearcoat={1} metalness={0.55} /></mesh></group>
      <mesh position={[0, -1.4, 0]} scale={[0.26, 0.14, 0.26]}><sphereGeometry args={[1, 24, 16]} /><meshBasicMaterial color="#7cc5ff" transparent opacity={0.22} /></mesh>
    </group>
    {!compact && <>
      <group ref={ring} rotation={[Math.PI / 2.6, 0.12, 0]} position={[0, -0.02, -2.5]}>
        <mesh><torusGeometry args={[2.01, 0.012, 6, 100]} /><meshBasicMaterial color="#a5caff" transparent opacity={0.19} /></mesh>
        <mesh position={[1.69, 1.07, 0]}><sphereGeometry args={[0.045, 14, 10]} /><meshBasicMaterial color="#6da7ff" /></mesh>
      </group>
      <mesh ref={pedestal} rotation={[-Math.PI / 2, 0, 0]} position={[0, -1.5, -.1]} scale={[.3, .6, .3]}><circleGeometry args={[1, 40]} /><meshBasicMaterial color="#8bbaff" transparent opacity={0.04} depthWrite={false} /></mesh>
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -.1, -2.1]}><ringGeometry args={[1.78, 1.785, 70]} /><meshBasicMaterial color="#87b7ff" transparent opacity={0.12} /></mesh>
    </>}
  </>;
}

export default function MascotScene(props: SceneProps) {
  return <Canvas className="mascot-canvas" dpr={[1, props.compact || (typeof window !== 'undefined' && window.matchMedia('(max-width: 640px)').matches) ? 1 : 1.5]} camera={{ position: [0, 0.35, props.compact ? 6.3 : 6.5], fov: props.compact ? 37 : 41 }} frameloop={props.active && props.animate && props.mood !== 'sleeping' ? 'always' : 'demand'} gl={{ antialias: true, alpha: true, powerPreference: 'low-power' }} fallback={<MascotFallback mood={props.mood} />}>
    <ambientLight intensity={0.55} />
    <directionalLight position={[3, 5, 5]} intensity={3.6} color="#f4f5ff" />
    <directionalLight position={[-4, 1, 2]} intensity={2.2} color="#b0c2ff" />
    <pointLight position={[0, -1, 3]} intensity={5} color="#a2c8ff" distance={9} />
    <Environment onFailure={props.onFailure} />
    <Robot {...props} />
  </Canvas>;
}
