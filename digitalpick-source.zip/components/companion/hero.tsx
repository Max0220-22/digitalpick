'use client';

import Link from 'next/link';
import { HERO_OPENING } from '@/lib/brand';
import { useCallback, useEffect, useRef, useState } from 'react';
import { ArrowDown, ArrowRight, ArrowUpRight, Check, Cpu, Hand, Laptop, MessageCircle, MousePointer2, Pause, Play, RotateCcw, ShieldCheck, Smartphone, Sparkles, Tablet } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { normalizePointer, type DeviceFocus } from '@/lib/companion/state';
import { useCompanion } from './provider';
import { MascotDisplay, type RendererState } from './mascot-display';
import { useTheme } from '../theme-provider';
import { claimSkyHint, themeMessages } from '@/lib/theme';

const focusItems = [
  { id: 'phone' as DeviceFocus, label: '手机', icon: Smartphone, note: '每天都用的，选得更合心意。', prompt: '我的预算是 3000 元，想选一台手机。' },
  { id: 'tablet' as DeviceFocus, label: '平板', icon: Tablet, note: '从课堂笔记，到下一个灵感。', prompt: '想买一台学习用的平板，怎么选？' },
  { id: 'laptop' as DeviceFocus, label: '笔记本', icon: Laptop, note: '装下你的作业，也装下创作。', prompt: '大学生买什么笔记本？' },
];
export function CompanionHero() {
  const { state, dispatch, gaze, reducedMotion, active, openChat, setHeroVisible, ai } = useCompanion();
  const { theme, busy, ready: themeReady, sequence, toggle } = useTheme();
  const activateTheme = useCallback(() => toggle(), [toggle]);
  const [themeBubble, setThemeBubble] = useState<{ text: string; id: number } | null>(null);
  const lastMessage = useRef(-1);
  useEffect(() => {
    if (!themeReady) return;
    try { if (!claimSkyHint(localStorage)) return; } catch {}
    setThemeBubble({ text: '点我试试，能把天点亮哦', id: 0 });
  }, [themeReady]);
  useEffect(() => {
    if (!sequence || busy) return;
    const messages = themeMessages[theme];
    const index = (lastMessage.current + 1 + Math.floor(Math.random() * (messages.length - 1))) % messages.length;
    lastMessage.current = index; setThemeBubble({ text: messages[index], id: sequence });
  }, [sequence, theme, busy]);
  useEffect(() => { if (!themeBubble) return; const timer = setTimeout(() => setThemeBubble(null), themeBubble.id === 0 ? 5500 : 2200); return () => clearTimeout(timer); }, [themeBubble]);
  const section = useRef<HTMLElement>(null);
  const stage = useRef<HTMLDivElement>(null);
  const dragStart = useRef<{ x: number; y: number } | null>(null);
  const dragged = useRef(false);
  const [visible, setVisible] = useState(true);
  const [lightweight, setLightweight] = useState(false);
  const [renderer, setRenderer] = useState<RendererState>('loading');
  const [rendererAttempt, setRendererAttempt] = useState(0);
  const [touched, setTouched] = useState(false);
  const [compact, setCompact] = useState(false);
  const selected = focusItems.find(item => item.id === state.focus)!;
  useEffect(() => {
    const query = matchMedia('(max-width: 640px)');
    const sync = () => setCompact(query.matches);
    sync(); query.addEventListener('change', sync);
    return () => query.removeEventListener('change', sync);
  }, []);
  useEffect(() => {
    const observer = new IntersectionObserver(([entry]) => { setVisible(entry.isIntersecting); setHeroVisible(entry.isIntersecting); }, { threshold: 0.2 });
    if (section.current) observer.observe(section.current);
    return () => { observer.disconnect(); setHeroVisible(false); };
  }, [setHeroVisible]);
  useEffect(() => {
    const root = section.current;
    if (!root) return;
    const move = (event: PointerEvent) => {
      if (reducedMotion || !state.motion || event.pointerType !== 'mouse') return;
      const bounds = root.getBoundingClientRect();
      const p = normalizePointer(event.clientX - bounds.left, event.clientY - bounds.top, bounds.width, bounds.height);
      root.style.setProperty('--gaze-x', String(p.x)); root.style.setProperty('--gaze-y', String(p.y));
    };
    const reset = () => { root.style.setProperty('--gaze-x', '0'); root.style.setProperty('--gaze-y', '0'); };
    root.addEventListener('pointermove', move, { passive: true });
    root.addEventListener('pointerleave', reset);
    return () => { root.removeEventListener('pointermove', move); root.removeEventListener('pointerleave', reset); };
  }, [reducedMotion, state.motion]);
  function touchGaze(event: React.PointerEvent<HTMLDivElement>) {
    if ((event.pointerType === 'mouse' && !matchMedia('(max-width: 640px)').matches) || reducedMotion || !state.motion || !dragStart.current) return;
    const rect = event.currentTarget.getBoundingClientRect();
    gaze.current = normalizePointer(event.clientX - rect.left, event.clientY - rect.top, rect.width, rect.height);
    if (Math.hypot(event.clientX - dragStart.current.x, event.clientY - dragStart.current.y) > 8) { dragged.current = true; setTouched(true); }
  }
  return <section className="companion-hero" ref={section} data-focus={state.focus} data-motion={state.motion && !reducedMotion && active ? 'on' : 'off'}>
    <div className="companion-hero-grid" aria-hidden="true" />
    <div className="container companion-hero-inner">
      <div className="companion-hero-copy">
        <div className="companion-eyebrow"><span className="live-dot" /><span>YOUR NEXT CHOICE, IN ORBIT.</span><span className="intro-version">小派 · 数码领航员</span></div>
        <h1><span className="hero-opening">{HERO_OPENING.split("，").map((part,index)=><span key={part} className="hero-phrase">{index ? part : part+"，"}</span>)}</span><span className="hero-closing">陪你选，刚刚好的。</span></h1>
        <p className="companion-lead">嗨，我是小派。<span className="hello-spark">✦</span><br />你的下一台数码设备，应该更适合你。<br /><span>告诉我预算和用途，让选择从此轻松一点。</span></p>
        <div className="companion-hero-actions"><Button size="lg" onClick={() => openChat()}><MessageCircle size={17} />和小派聊聊 <ArrowUpRight size={17} /></Button><Button asChild variant="ghost" size="lg"><Link href="/recommend/">直接开始选购 <ArrowRight size={17} /></Link></Button></div>
        <div className="companion-trust"><span><Check size={13} />无需注册</span><span><ShieldCheck size={13} />信息有来源</span><span><Cpu size={13} />{!ai.ready ? '正在连接顾问' : ai.enabled ? 'DeepSeek V4 Pro' : '本地规则导览'}</span></div>
        <div className="hero-device-selector" role="group" aria-label="和小派选择设备类型">{focusItems.map(item => <button key={item.id} className={state.focus === item.id ? 'is-selected' : ''} aria-pressed={state.focus === item.id} onClick={() => dispatch({ type: 'focus', focus: item.id })}><item.icon size={17} strokeWidth={1.6} />{item.label}<ArrowUpRight size={12} /></button>)}</div>
      </div>
      <div className="companion-stage" ref={stage}
        onPointerDown={event => { if ((event.pointerType !== 'mouse' || matchMedia('(max-width: 640px)').matches) && (event.target as HTMLElement).closest('.hero-mascot')) { (event.target as HTMLElement).setPointerCapture(event.pointerId); dragStart.current = { x: event.clientX, y: event.clientY }; dragged.current = false; touchGaze(event); } }}
        onPointerMove={touchGaze}
        onPointerUp={() => { dragStart.current = null; }}
        onPointerCancel={() => { dragStart.current = null; dragged.current = true; gaze.current = { x: 0, y: 0 }; }}>
        <span className="stage-coordinate" aria-hidden="true">DESIGNED AROUND YOU<br /><b>漂浮星河，陪你探索。</b></span>
        <div className="stage-orb" aria-hidden="true" /><div className="stage-orbit one" aria-hidden="true" /><div className="stage-orbit two" aria-hidden="true" />
        <div className="hero-mascot"><MascotDisplay key={rendererAttempt} onRendererChange={setRenderer} onActivate={activateTheme} lightweight={lightweight} visible={visible && (!state.open || !compact)} /></div>
        <div className={`stage-greeting ${themeBubble ? themeBubble.id === 0 ? 'theme-bubble theme-discovery' : 'theme-bubble' : ''}`} key={themeBubble?.id ?? 'greeting'} role="status" aria-live="polite"><span className="greeting-spark"><Sparkles size={15} /></span><span>{busy ? theme === 'light' ? '晨光正在抵达。' : '星河正在亮起。' : themeBubble?.text || '嗨！一起探索数码宇宙。'}</span><span className="greeting-dot" /></div>
        <button className="orbit-device orbit-phone" onClick={() => { dispatch({ type: 'focus', focus: 'phone' }); }} aria-label="让小派关注手机"><Smartphone size={29} strokeWidth={1.35} /><span>PHONE<small>更懂你的日常</small></span></button>
        <button className="orbit-device orbit-laptop" onClick={() => dispatch({ type: 'focus', focus: 'laptop' })} aria-label="让小派关注笔记本"><Laptop size={31} strokeWidth={1.3} /><span>LAPTOP<small>为下一个作品</small></span></button>
        <button className="orbit-device orbit-tablet" onClick={() => dispatch({ type: 'focus', focus: 'tablet' })} aria-label="让小派关注平板"><Tablet size={28} strokeWidth={1.3} /><span>TABLET<small>灵感不设限</small></span></button>
        <div className="mascot-nameplate"><span className="nameplate-dot" /><strong>小派 <span>PICK</span></strong><span>你的数码伙伴</span><button onClick={() => openChat(selected.prompt)} aria-label={`咨询小派关于${selected.label}的问题`}><ArrowUpRight size={14} /></button></div>
        <div className="stage-tools"><button onClick={() => dispatch({ type: 'motion', enabled: !state.motion })} disabled={reducedMotion} aria-label={reducedMotion ? '系统已启用减少动态效果' : state.motion ? '暂停星河与小派动态' : '播放星河与小派动态'} title={reducedMotion ? '跟随系统减少动态效果设置' : '暂停或播放动态'}>{state.motion && !reducedMotion ? <Pause size={13} /> : <Play size={13} />}</button><button onClick={() => { gaze.current = { x: 0, y: 0 }; dispatch({ type: 'phase', phase: 'idle' }); }} aria-label="复位精灵视角"><RotateCcw size={13} /></button><button className="quality-toggle" aria-pressed={lightweight} onClick={() => { if (renderer === 'failed') setRendererAttempt(n => n + 1); else setLightweight(!lightweight); }} aria-label={renderer === 'failed' ? '重试3D形象' : lightweight ? '切换为3D形象' : '切换为轻量2D形象'}>{renderer === 'failed' ? '重试' : lightweight ? '2D' : renderer === '3d' ? '3D' : '…'}</button></div>
        {(renderer === 'failed' || reducedMotion || !state.motion) && <div className="stage-status" role="status">{renderer === 'failed' ? '3D 未启动，已显示 2D 形象。' : reducedMotion ? '动态效果跟随系统设置暂停。' : '动态效果已暂停。'} <Link href="/diagnostics/">运行自检 ↗</Link></div>}
        <div className="stage-interaction-hint"><MousePointer2 size={12} className="desktop-hint-icon" /><Hand size={12} className="touch-hint-icon" /><span className="desktop-hint">移动光标带我飞 · 点我切换日夜</span><span className="touch-hint">{touched ? '轻触我，切换日夜' : '轻触小派，点亮天空'}</span></div>
      </div>
    </div>
    <div className="container hero-bottom-line"><span><span className="small-cross">+</span>不买最贵的，只买最适合的。</span><span className="focus-note" aria-live="polite">{selected.note}</span><a href="#explore" aria-label="继续向下探索">SCROLL TO EXPLORE <ArrowDown size={12} /></a></div>
  </section>;
}
