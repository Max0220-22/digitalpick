'use client';
import { useEffect, useRef } from 'react';
import { sceneDaylight } from '@/lib/theme';
import { useTheme } from '../theme-provider';
import { useCompanion } from './provider';

/** Sun, cirrus and airborne dust: one local rAF clock; no video, textures or extra WebGL context. */
export function DaylightScene({ home }: { home: boolean }) {
 const host = useRef<HTMLDivElement>(null), canvas = useRef<HTMLCanvasElement>(null);
 const { frame: theme, subscribe } = useTheme();
 const { active, reducedMotion, state, heroVisible } = useCompanion();
 const running = home && active && heroVisible && state.motion && !reducedMotion;
 const runningRef = useRef(running); runningRef.current = running;
 const sync = useRef<() => void>(() => {});
 useEffect(() => {
  const root = host.current!, surface = canvas.current!, ctx = surface.getContext('2d');
  if (!ctx) return;
  let width=0, height=0, mobile=false, raf=0, previous=0, elapsed=0, samples=0, sampleStart=0;
  // Fixed seed keeps dust positions stable through every theme switch and resize.
  const dust = Array.from({length:40}, (_,i) => ({ x: ((i*47+13)%101)/101, y: ((i*31+7)%97)/97, phase: i*2.39996, size: .6+(i%3)*.22 }));
  const sun = root.querySelector<HTMLElement>('.dawn-sun')!, clouds = root.querySelectorAll<HTMLElement>('.dawn-cloud');
  const canRun = () => runningRef.current && !document.hidden && sceneDaylight(theme.current) > 0;
  function paint() {
   sun.style.transform=`translate(-50%,-50%) scale(${1+Math.sin(elapsed*Math.PI/4)*.015})`;
   clouds.forEach((cloud,i) => { cloud.style.transform=`translate3d(${Math.sin(elapsed/(i?39:57))*(i?35:55)}px,${Math.sin(elapsed/47+i)*5}px,0)`; });
   ctx!.clearRect(0,0,width,height);
   const count=mobile?20:40;
   surface.dataset.particles=String(count);
   for(let i=0;i<count;i++) {
    const d=dust[i], x=width*(mobile?.32:.61)+d.x*width*(mobile?.55:.29)+Math.sin(elapsed/9+d.phase)*8;
    const y=height*(.38+((d.y-elapsed*.009+100)%1)*.4);
    const a=.16+Math.sin(elapsed*.35+d.phase)**2*.22;
    ctx!.fillStyle=`rgba(255,249,219,${a})`;ctx!.beginPath();ctx!.arc(x,y,d.size,0,Math.PI*2);ctx!.fill();
   }
  }
  function loop(now:number) {
   raf=0;if(!canRun())return;
   raf=requestAnimationFrame(loop);
   if(previous && now-previous<(mobile?32:15))return;
   elapsed+=previous?Math.min((now-previous)/1000,.05):0;previous=now;paint();
   if(!sampleStart)sampleStart=now;if(++samples===90){root.dataset.observedFps=(89000/(now-sampleStart)).toFixed(1);samples=0;sampleStart=0;}
  }
  function resize() {
   width=root.clientWidth;height=root.clientHeight;mobile=width<=640;
   const dpr=Math.min(devicePixelRatio||1,mobile?1:1.5);
   surface.width=Math.round(width*dpr);surface.height=Math.round(height*dpr);ctx!.setTransform(dpr,0,0,dpr,0,0);paint();
  }
  sync.current=()=>{ if(canRun()&&!raf){previous=0;raf=requestAnimationFrame(loop);}else if(!canRun()){cancelAnimationFrame(raf);raf=0;previous=0;if(!document.hidden)paint();} };
  const observer=new ResizeObserver(resize);observer.observe(root);resize();sync.current();
  const visibility=()=>sync.current();document.addEventListener('visibilitychange',visibility);
  return ()=>{observer.disconnect();cancelAnimationFrame(raf);document.removeEventListener('visibilitychange',visibility);sync.current=()=>{};};
 },[]);
 useEffect(()=>{sync.current();return subscribe(()=>sync.current());},[running,subscribe]);
 return <div ref={host} className="dawn-sky">
  <div className="dawn-horizon"/><div className="dawn-rays"/>
  <div className="dawn-cloud dawn-cloud-high"/><div className="dawn-cloud dawn-cloud-low"/>
  <div className="dawn-sun"><svg className="dawn-sun-disc" viewBox="0 0 160 160" aria-hidden="true"><circle cx="80" cy="80" r="77" fill="#fff1bc" stroke="#ffcd76" strokeWidth="1.5"/><circle cx="80" cy="80" r="74" fill="#fff4ca"/></svg></div>
  <canvas ref={canvas} className="daylight-dust"/>
  <svg className="dawn-mountains" viewBox="0 0 1400 170" preserveAspectRatio="none"><path d="M0 170L0 155 510 146 670 105 790 117 960 41 1110 104 1230 71 1400 133 1400 170Z" fill="#8399a4" opacity=".15"/><path d="M0 170L0 160 680 151 870 113 990 139 1160 88 1300 135 1400 114 1400 170Z" fill="#a2958a" opacity=".14"/></svg>
 </div>;
}
