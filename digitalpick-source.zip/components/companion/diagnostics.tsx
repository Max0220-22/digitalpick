'use client';
import Link from 'next/link';
import { useEffect, useState } from 'react';
import {diagnosticVersion} from '@/lib/release-version';
import {clearValidationHistory,readValidationHistory,validationCategoryLabels,validationHistoryEvent,validationHistoryKey,type ValidationHistoryEntry} from '@/lib/ai/validation-history';
import { Button } from '@/components/ui/button';
import { assistantEndpoint } from '@/lib/deployment';
import { useCompanion } from './provider';
import { MascotDisplay, type RendererState } from './mascot-display';

export function RuntimeDiagnostics() {
  const { ai, reconnectAi, active, reducedMotion, state } = useCompanion();
  const [renderer, setRenderer] = useState<RendererState>('loading');
  const [attempt, setAttempt] = useState(0);
  const [client, setClient] = useState<{ browser: string; origin: string } | null>(null);
  useEffect(() => {
    const ua = navigator.userAgent;
    setClient({ browser: /Edg\//.test(ua) ? 'Microsoft Edge' : /Chrome\//.test(ua) ? 'Chrome / Chromium' : /Firefox\//.test(ua) ? 'Firefox' : /Safari\//.test(ua) ? 'Safari' : '其他浏览器', origin: location.origin });
  }, []);
  const graphics = renderer === '3d' ? '3D 场景已创建' : renderer === 'failed' ? '3D 启动失败，当前显示 2D' : '正在加载 3D 场景';
  return <div className="container page-space runtime-diagnostics">
    <span className="section-kicker">ELVORA · RUNTIME CHECK</span>
    <h1>连接与 3D 自检</h1>
    <p className="muted">在出现问题的电脑上打开本页。自检不发送聊天内容、不调用付费模型；结果仅显示在当前页面。</p>
    <div className="diagnostic-layout">
      <div className="diagnostic-card"><div className="diagnostic-mascot"><MascotDisplay key={attempt} compact onRendererChange={setRenderer} /></div><p role="status">{graphics}</p><Button variant="outline" onClick={() => setAttempt(n => n + 1)}>重试 3D</Button></div>
      <div className="diagnostic-card"><dl className="diagnostic-results" aria-live="polite">
        <div><dt>自检版本</dt><dd>{diagnosticVersion}</dd></div>
        <div><dt>浏览器 / 页面来源</dt><dd>{client ? `${client.browser} · ${client.origin}` : '等待浏览器启动'}</dd></div>
        <div><dt>3D 渲染</dt><dd>{graphics}</dd></div>
        <div><dt>动画状态</dt><dd>{!active ? '页面在后台，已暂停' : reducedMotion ? '系统要求减少动态效果' : !state.motion ? '手动暂停' : state.phase === 'sleeping' ? '精灵休息中，移动光标可唤醒' : '允许播放 · 移动光标查看响应'}</dd></div>
        <div><dt>AI 连接</dt><dd>{ai.connecting ? '正在连接，请稍候' : ai.enabled ? '免费会话连接成功（尚未测试模型回复）' : ai.error || '等待连接'}</dd></div>
        <div><dt>AI 状态码</dt><dd>{ai.connecting ? 'connecting' : ai.enabled ? 'connected' : ai.reason || 'unknown'}</dd></div>
        <div><dt>AI 入口</dt><dd>{client ? assistantEndpoint() : '等待配置'}</dd></div>
      </dl><Button onClick={reconnectAi} disabled={ai.connecting}>{ai.connecting ? '连接中…' : '重新连接 AI（不调用模型）'}</Button></div>
    </div>
    <ValidationHistory />
    <div className="diagnostic-card diagnostic-help"><h2>根据结果排查</h2>
      <p><strong>3D 启动失败：</strong>当前场景需要 WebGL 2。更新 Chrome / Edge，检查浏览器“图形加速”设置及显卡驱动；远程桌面或受管理的电脑也可能限制图形能力。可以重试 3D 或保留 2D 继续选购。</p>
      <p><strong>系统要求减少动态效果：</strong>网站会遵循系统的无障碍偏好，因此小派和星河保持静止。Windows 的动画效果设置可能触发这一状态。</p>
      <p><strong>AI 为 network / timeout：</strong>当前浏览器到 AI 入口的请求失败或超时，可能涉及网络、DNS 或扩展拦截。换手机热点、无痕窗口对照测试，再点重新连接。浏览器无法仅凭此状态区分这些原因。</p>
      <p><strong>AI 为 limited / forbidden / disabled：</strong>分别表示连接限流、本站来源未获允许、服务未启用。刷新不能绕过额度；请把本页状态提供给维护者。</p>
      <p>若本页一直停在“等待浏览器启动”，说明前端脚本尚未运行。请强制刷新（Windows：Ctrl + F5），并检查浏览器是否拦截了本站脚本。连接成功只证明会话和跨域可用，不代表已完成模型付费调用。</p>
      <Link href="/">返回首页 ↗</Link>
    </div>
    <noscript>浏览器未启用 JavaScript，3D 和在线聊天无法启动。请允许本站运行 JavaScript。</noscript>
  </div>;
}

function ValidationHistory() {
 const [entries,setEntries]=useState<ValidationHistoryEntry[]>([]),[ready,setReady]=useState(false),[available,setAvailable]=useState(true);
 useEffect(()=>{
  const refresh=()=>{const result=readValidationHistory();setEntries(result.entries);setAvailable(result.available);setReady(true);};
  const storage=(event:StorageEvent)=>{if(event.key===validationHistoryKey||event.key===null)refresh();};
  refresh();window.addEventListener(validationHistoryEvent,refresh);window.addEventListener('storage',storage);
  return()=>{window.removeEventListener(validationHistoryEvent,refresh);window.removeEventListener('storage',storage);};
 },[]);
 return <section className="diagnostic-card validation-history" aria-labelledby="validation-history-title">
  <div className="validation-history-heading"><h2 id="validation-history-title">资料校验失败日志</h2><span>{entries.length} / 50 条</span></div>
  <p className="muted">产品回复被现有校验删除、改写或退回本地整理时自动记录。仅保存在当前浏览器，保留最近 50 条；刷新仍在，不会上传或汇总其他访客的记录。清除浏览器数据会删除这些记录。</p>
  <p className="muted">机型、分数、价格口径与回复结构按实际触发规则分别标注；没有执行的参数或预算检查不会伪装成失败原因。</p>
  {!ready?<p role="status">正在读取本机记录…</p>:!available?<p role="status">当前浏览器不允许读取本地存储，无法保证日志刷新后保留。</p>:!entries.length?<p className="validation-history-empty" role="status">本机暂无资料校验失败记录。正常回答、问候、额度耗尽和网络错误不会冒充资料校验失败。</p>:<>
   <div className="validation-history-list">{entries.map((entry,index)=><details className="validation-history-entry" key={entry.id} open={index===0}>
    <summary><time dateTime={entry.time}>{new Date(entry.time).toLocaleString('zh-CN',{timeZone:'Asia/Shanghai',hour12:false})}</time><strong>{entry.outcome==='adjusted'?'局部删改':'转为本地整理'}</strong><span>{[...new Set(entry.issues.flatMap(issue=>issue.products))].join('、')||'整条回复 / 对应字段'}</span></summary>
    <dl className="diagnostic-results"><div><dt>用户原问题</dt><dd>{entry.question}</dd></div><div><dt>记录版本</dt><dd>{entry.version}</dd></div></dl>
    <h3>被改机型与具体原因</h3><ul className="validation-issues">{entry.issues.map((issue,i)=><li key={i}><strong>{validationCategoryLabels[issue.category]||'校验规则'} · {issue.products.join('、')||'未指向单一机型'}</strong><p>{issue.reason}</p><small>规则：{issue.rule} · 字段：{issue.fields.join('、')}</small></li>)}</ul>
    <h3>最终呈现给用户的版本</h3><p className="muted">{entry.final.mode==='ai'?`模型回答 · ${entry.final.model}`:'本地整理'}{entry.final.notice?' · '+entry.final.notice:''}</p><pre className="validation-final">{entry.final.answer}</pre>
    {!!entry.final.recommendations.length&&<ul className="validation-final-cards">{entry.final.recommendations.map((rec,i)=><li key={i}><strong>{rec.name}</strong><p>{rec.reason}</p><p>注意：{rec.caution}</p></li>)}</ul>}
    {!!entry.final.followUpQuestions.length&&<p className="muted">继续追问：{entry.final.followUpQuestions.join('；')}</p>}
   </details>)}</div>
   <Button variant="outline" onClick={()=>{if(clearValidationHistory()){setEntries([]);setAvailable(true);}else setAvailable(false);}}>清空本机校验日志</Button>
  </>}
 </section>;
}
