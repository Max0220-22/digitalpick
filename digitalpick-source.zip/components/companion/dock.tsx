'use client';

import { usePathname } from 'next/navigation';
import { useEffect, useRef, useState } from 'react';
import { MessageCircle, X } from 'lucide-react';
import { contextBubble } from '@/lib/companion/guide';
import { useCompanion } from './provider';
import { MascotDisplay } from './mascot-display';
import { CompanionChat } from './chat';

const hints = [
  { label: '告诉我预算，我们从需求开始。', prompt: '我的预算是 3000 元，想选一台手机。' },
  { label: '买全新还是二手？先看你的需求。', prompt: '全新还是二手更划算？' },
  { label: '纠结两台设备？一起看清取舍。', prompt: '帮我比较两款设备。' },
  { label: '二手设备怎么验？清单准备好了。', prompt: '二手手机怎么验机？' },
];
export function CompanionDock() {
  const { state, dispatch, active, heroVisible, openChat } = useCompanion();
  const path = usePathname();
  const onHero = path === '/' && heroVisible;
  const [hint, setHint] = useState<{ label: string; prompt: string } | null>(null);
  const [dismissed, setDismissed] = useState(false);
  const lastHint = useRef(-1);
  const shown = useRef(false);
  const lastLabel = useRef('');
  useEffect(() => { try { setDismissed(sessionStorage.getItem('dp-hints-dismissed') === '1'); } catch {} }, []);
  useEffect(() => {
    if (!active || state.open || onHero || dismissed) { setHint(null); return; }
    let showTimer: ReturnType<typeof setTimeout>;
    let hideTimer: ReturnType<typeof setTimeout>;
    let stopped = false;
    function schedule(delay: number) {
      showTimer = setTimeout(() => {
        if (stopped) return;
        const index = (lastHint.current + 1 + Math.floor(Math.random() * (hints.length - 1))) % hints.length;
        let current = !shown.current || Math.random() > 0.5 ? contextBubble(path) : hints[index];
        if (current.label === lastLabel.current) current = hints.find(h => h.label !== lastLabel.current) || current;
        lastLabel.current = current.label;
        shown.current = true; lastHint.current = index; setHint(current);
        hideTimer = setTimeout(() => setHint(null), 5000);
        schedule(20000 + Math.random() * 10000);
      }, delay);
    }
    schedule(shown.current ? 20000 + Math.random() * 10000 : 5000);
    return () => { stopped = true; clearTimeout(showTimer); clearTimeout(hideTimer); setHint(null); };
  }, [active, state.open, onHero, dismissed, path]);
  function dismiss() { setHint(null); setDismissed(true); try { sessionStorage.setItem('dp-hints-dismissed', '1'); } catch {} }
  return <>
    {!state.open && !onHero && <div className="companion-dock" data-active={active} data-hints={dismissed ? 'dismissed' : 'enabled'}>
      {hint && <div className="companion-bubble"><button onClick={() => openChat(hint.prompt)}>{hint.label}</button><button onClick={dismiss} aria-label="本次会话不再显示提示气泡"><X size={12} /></button></div>}
      <button className="companion-dock-button" onClick={() => openChat()} aria-label="打开小派数码导览" onPointerEnter={() => dispatch({ type: 'phase', phase: 'hover' })} onPointerLeave={() => dispatch({ type: 'phase', phase: 'idle' })}><MascotDisplay compact /><span className="dock-chat-badge"><MessageCircle size={13} /></span></button><span className="dock-caption">小派在这里</span>
    </div>}
    <CompanionChat />
  </>;
}
