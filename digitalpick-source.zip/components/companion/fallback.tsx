'use client';
import type { CompanionMood } from '@/lib/companion/state';

export function MascotFallback({ mood = 'idle', className = '' }: { mood?: CompanionMood; className?: string }) {
  return <div className={`mascot-fallback ${className}`} data-mood={mood} role="img" aria-label="小派，蓝白色圆润数字精灵">
    <div className="fallback-halo" />
    <div className="fallback-antenna"><i /></div>
    <div className="fallback-head"><span className="fallback-highlight" /><div className="fallback-face"><i /><i /><b /></div><span className="fallback-ear left" /><span className="fallback-ear right" /></div>
    <div className="fallback-neck" /><div className="fallback-body"><span className="fallback-core" /></div>
    <div className="fallback-hand left" /><div className="fallback-hand right" /><div className="fallback-shadow" />
  </div>;
}
