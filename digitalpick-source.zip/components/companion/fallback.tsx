'use client';
import { useRef, type PointerEvent, type MouseEvent } from 'react';
import type { CompanionMood } from '@/lib/companion/state';
import { isModelTap } from '@/lib/companion/state';

type FallbackProps = { mood?: CompanionMood; className?: string; onChat?: () => void; onTheme?: () => boolean; themeBusy?: boolean; themeLabel?: string };
export function MascotFallback({ mood = 'idle', className = '', onChat, onTheme, themeBusy = false, themeLabel = '点胸前按钮切换日夜' }: FallbackProps) {
  const press = useRef({ x: 0, y: 0 }), dragged = useRef(false);
  const start = (event: PointerEvent<HTMLButtonElement>) => { press.current = { x: event.clientX, y: event.clientY }; dragged.current = false; };
  const move = (event: PointerEvent<HTMLButtonElement>) => { if (event.buttons && !isModelTap(press.current, { x: event.clientX, y: event.clientY })) dragged.current = true; };
  const activate = (event: MouseEvent<HTMLButtonElement>, action: () => void) => { if (event.detail === 0 || (!dragged.current && isModelTap(press.current, { x: event.clientX, y: event.clientY }))) action(); };
  return <div className={`mascot-fallback ${className}`} data-mood={mood} role={onChat || onTheme ? 'group' : 'img'} aria-label="小派，蓝白色圆润数字精灵">
    <div className="fallback-halo" />
    <div className="fallback-antenna"><i /></div>
    <div className="fallback-head"><span className="fallback-highlight" /><div className="fallback-face"><i /><i /><b /></div><span className="fallback-ear left" /><span className="fallback-ear right" />
      {onChat && <button type="button" className="fallback-head-action" aria-label="点小派的头打开对话" title="点头打开对话" onPointerDown={start} onPointerMove={move} onPointerCancel={() => { dragged.current = true; }} onClick={event => activate(event, onChat)}/>}
    </div>
    <div className="fallback-neck" /><div className="fallback-body">
      {onTheme ? <button type="button" className="fallback-core fallback-core-action" aria-label={themeLabel} title="点胸前按钮切换日夜" disabled={themeBusy} onPointerDown={start} onPointerMove={move} onPointerCancel={() => { dragged.current = true; }} onClick={event => activate(event, onTheme)}><span aria-hidden="true">⏻</span></button> : <span className="fallback-core" />}
    </div>
    <div className="fallback-hand left" /><div className="fallback-hand right" /><div className="fallback-shadow" />
  </div>;
}
