'use client';
import { useEffect, useRef } from 'react';
import { useCompanion } from './provider';

interface Star { orbit: number; angle: number; depth: number; size: number; phase: number; arm: number; dx: number; dy: number; vx: number; vy: number; x: number; y: number; backdrop: boolean }
interface Pulse { x: number; y: number; born: number }
/** A local, procedural star river. No downloaded video, external tracker or pointer replacement. */
export function GalaxyBackground() {
  const { active, reducedMotion, state } = useCompanion();
  const canvas = useRef<HTMLCanvasElement>(null);
  const host = useRef<HTMLDivElement>(null);
  const clock = useRef(0);
  const pulses = useRef<Pulse[]>([]);
  const pointer = useRef({ x: -1000, y: -1000, live: false });
  const count = useRef(0);
  const running = active && state.motion && !reducedMotion;
  const runningRef = useRef(running);
  const syncPlayback = useRef<() => void>(() => {});
  runningRef.current = running;
  useEffect(() => {
    const surface = canvas.current, ctx = surface?.getContext('2d', { alpha: false });
    if (!surface || !ctx) return;
    let width = 0, height = 0, stars: Star[] = [], frame = 0, previous = 0;
    let nebula: HTMLCanvasElement;
    const random = (a: number, b: number) => a + Math.random() * (b - a);
    function resize() {
      width = innerWidth; height = innerHeight;
      const ratio = Math.min(devicePixelRatio || 1, width < 641 ? 1.25 : 1.5);
      surface!.width = Math.round(width * ratio); surface!.height = Math.round(height * ratio); ctx!.setTransform(ratio, 0, 0, ratio, 0, 0);
      stars = Array.from({ length: width < 641 ? 740 : 1750 }, (_, i) => ({ orbit: Math.pow(Math.random(), .65), angle: i % 5 === 0 ? random(0, Math.PI * 2) : random(-.38, .38), depth: random(.5, 1.5), size: random(.45, 1.65), phase: random(0, 20), arm: i % 4, dx: 0, dy: 0, vx: 0, vy: 0, x: 0, y: 0, backdrop: i % 5 === 0 }));
      nebula = document.createElement('canvas'); nebula.width = Math.round(width); nebula.height = Math.round(height);
      const cloud = nebula.getContext('2d')!;
      const cx = width * (width < 641 ? .65 : .72), cy = height * .45;
      for (let i = 0; i < 48; i++) {
        const orbit = (i % 12) / 12, a = Math.floor(i / 12) * Math.PI / 2 + orbit * 3.8;
        const distance = orbit * Math.max(width * .64, height * .57), u = Math.cos(a) * distance, v = Math.sin(a) * distance * .34;
        const x = cx + u * .91 - v * .42, y = cy + u * .42 + v * .91;
        const radius = Math.max(65, width * .12), g = cloud.createRadialGradient(x, y, 0, x, y, radius);
        g.addColorStop(0, i % 3 === 0 ? 'rgba(89,53,164,.15)' : i % 3 === 1 ? 'rgba(34,112,177,.14)' : 'rgba(62,78,167,.15)'); g.addColorStop(1, 'rgba(0,0,0,0)');
        cloud.fillStyle = g; cloud.fillRect(x - radius, y - radius, radius * 2, radius * 2);
      }
      render(0, false);
    }
    function render(dt: number, advance: boolean) {
      const t = clock.current; ctx!.fillStyle = '#03050d'; ctx!.fillRect(0, 0, width, height);
      ctx!.save(); ctx!.translate(Math.sin(t * .08) * 14, Math.cos(t * .06) * 10); ctx!.drawImage(nebula, -20, -20, width + 40, height + 40); ctx!.restore();
      const cx = width * (width < 641 ? .64 : .73), cy = height * .46, radius = Math.max(width * .64, height * .57);
      const p = pointer.current;
      ctx!.globalCompositeOperation = 'screen';
      for (const star of stars) {
        const a = star.angle + t * .035 / (star.orbit + .45);
        const r = star.orbit * radius;
        let x: number, y: number;
        if (star.backdrop) { x = (star.angle / (Math.PI * 2) * width + t * star.depth * 2) % width; y = star.orbit * height; }
        else {
          const spiral = a + star.arm * Math.PI / 2 + star.orbit * 3.8;
          const u = Math.cos(spiral) * r, v = Math.sin(spiral) * r * .34;
          x = cx + u * .91 - v * .42; y = cy + u * .42 + v * .91;
          x += Math.sin(star.phase * 12.2) * 25 * star.orbit; y += Math.cos(star.phase * 5.8) * 23 * star.orbit;
        }
        if (advance) {
          if (p.live && !star.backdrop) { const dx = x + star.dx - p.x, dy = y + star.dy - p.y, d = Math.hypot(dx, dy); if (d < 100 && d > 1) { const force = (1 - d / 100) * dt * 55; star.vx += dx / d * force; star.vy += dy / d * force; } }
          star.vx += -star.dx * dt * 1.9; star.vy += -star.dy * dt * 1.9;
          const friction = Math.exp(-dt * 3.5); star.vx *= friction; star.vy *= friction; star.dx += star.vx * dt; star.dy += star.vy * dt;
        }
        star.x = x + star.dx; star.y = y + star.dy;
        const twinkle = .42 + Math.sin(t * .7 + star.phase) * .2;
        ctx!.fillStyle = star.arm === 0 ? `rgba(153,192,255,${twinkle})` : star.arm === 1 ? `rgba(193,167,255,${twinkle * .8})` : `rgba(206,228,255,${twinkle})`;
        ctx!.beginPath(); ctx!.arc(star.x, star.y, star.size * (star.backdrop ? .65 : 1), 0, Math.PI * 2); ctx!.fill();
        if (!star.backdrop && star.size > 1.5 && star.orbit < .7) { ctx!.fillStyle = 'rgba(126,171,255,.035)'; ctx!.beginPath(); ctx!.arc(star.x, star.y, star.size * 4.5, 0, Math.PI * 2); ctx!.fill(); }
      }
      // A few fine luminous filaments make the slow spiral flow legible.
      for (let i = 0; i < 3; i++) { ctx!.save(); ctx!.translate(cx, cy); ctx!.rotate(.42); ctx!.scale(1, .35); ctx!.strokeStyle = `rgba(113,154,255,${.025 - i * .005})`; ctx!.lineWidth = 1; ctx!.beginPath(); ctx!.ellipse(0, 0, radius * (.28 + i * .17), radius * (.28 + i * .17), 0, t * .04 + i, t * .04 + i + 2.1); ctx!.stroke(); ctx!.restore(); }
      const now = performance.now(); pulses.current = pulses.current.filter(pulse => now - pulse.born < 1600);
      for (const pulse of pulses.current) { const age = (now - pulse.born) / 1600, r = 12 + age * Math.min(width, 650); ctx!.strokeStyle = `rgba(155,205,255,${(1 - age) ** 2 * .6})`; ctx!.lineWidth = 1.3 - age; ctx!.beginPath(); ctx!.arc(pulse.x, pulse.y, r, 0, Math.PI * 2); ctx!.stroke(); const light = ctx!.createRadialGradient(pulse.x, pulse.y, r * .7, pulse.x, pulse.y, r); light.addColorStop(0, 'rgba(75,126,255,0)'); light.addColorStop(.9, `rgba(99,147,255,${(1-age)*.045})`); light.addColorStop(1, 'rgba(75,126,255,0)'); ctx!.fillStyle = light; ctx!.fillRect(pulse.x-r,pulse.y-r,r*2,r*2); }
      if (p.live && runningRef.current) { const g = ctx!.createRadialGradient(p.x,p.y,0,p.x,p.y,75); g.addColorStop(0,'rgba(112,180,255,.065)');g.addColorStop(1,'rgba(112,180,255,0)');ctx!.fillStyle=g;ctx!.fillRect(p.x-75,p.y-75,150,150); }
      ctx!.globalCompositeOperation = 'source-over';
    }
    function loop(time: number) {
      if (!runningRef.current) { frame = 0; return; }
      frame = requestAnimationFrame(loop);
      if (time - previous < (width < 641 ? 33 : 24)) return;
      const dt = Math.min((time - previous) / 1000 || .016, .045); previous = time; clock.current += dt; render(dt, true);
    }
    function move(event: PointerEvent) { pointer.current = { x: event.clientX, y: event.clientY, live: event.pointerType === 'mouse' }; }
    function burst(event: PointerEvent) {
      if (!runningRef.current) return;
      const x = event.clientX, y = event.clientY; pulses.current.push({ x, y, born: performance.now() }); pulses.current = pulses.current.slice(-5);
      count.current++; host.current?.setAttribute('data-bursts', String(count.current));
      for (const star of stars) { const dx = star.x-x, dy = star.y-y, d = Math.hypot(dx,dy); if (d < 350 && d > .5) { const force = (1-d/350)*500; star.vx += dx/d*force;star.vy += dy/d*force; } }
    }
    syncPlayback.current = () => {
      if (runningRef.current && !frame) { previous = 0; frame = requestAnimationFrame(loop); }
      else if (!runningRef.current) { cancelAnimationFrame(frame); frame = 0; }
    };
    resize(); syncPlayback.current();
    window.addEventListener('resize',resize);window.addEventListener('pointermove',move,{passive:true});window.addEventListener('pointerdown',burst,{passive:true});
    const leave = () => { pointer.current.live=false; }; document.addEventListener('pointerleave',leave);
    return () => { cancelAnimationFrame(frame);syncPlayback.current=()=>{};window.removeEventListener('resize',resize);window.removeEventListener('pointermove',move);window.removeEventListener('pointerdown',burst);document.removeEventListener('pointerleave',leave); };
  }, []);
  useEffect(() => { syncPlayback.current(); }, [running]);
  return <div ref={host} className="cosmic-background" data-motion={running ? 'flowing' : 'still'} data-bursts="0" aria-hidden="true"><canvas ref={canvas} /><div className="cosmic-reading-shade" /></div>;
}
