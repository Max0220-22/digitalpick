'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useEffect, useRef, useState } from 'react';
import { ArrowUp, ArrowUpRight, Info, MessageCircle, Minimize2, RotateCcw, ShieldCheck, X } from 'lucide-react';
import { type GuideMemory, type GuideReply } from '@/lib/companion/guide';
import { quotaFallback, failureReason, type LocalFallbackReason } from '@/lib/companion/quota-fallback';
import { chatReplyNotice } from '@/lib/ai/presentation';
import type { AssistantReply } from '@/lib/ai/schema';
import { chatHistory, normalizeFollowUpAnswer } from '@/lib/companion/chat-history';
import { assistantEndpoint, remoteAssistant, appPath } from '@/lib/deployment';
import { getProduct } from '@/lib/products';
import { DeviceArt } from '@/components/device-art';
import { useCompanion } from './provider';
import { MascotFallback } from './fallback';
import { SecondhandLink } from '@/components/secondhand-link';
import { CopyRecommendations } from '@/components/copy-recommendations';
import { recommendationText } from '@/lib/recommendation-share';
import { createRequestTiming } from '@/lib/ai/timing';
import {rememberValidationReply} from '@/lib/ai/validation-history';

interface ChatEntry { id: number; role: 'user' | 'assistant'; text: string; contextText?: string; reply?: GuideReply; aiReply?: AssistantReply; error?: boolean; retry?: string }
const prompts = ['3000元买什么手机？', '全新还是二手更划算？', '帮我比较两款设备。', '大学生买什么笔记本？', '二手手机怎么避坑？', '苹果16和15哪个好？', '内存和存储有什么区别？'];
export function CompanionChat() {
  const { state, dispatch, ai, reconnectAi } = useCompanion();
  const path = appPath(usePathname());
  const [messages, setMessages] = useState<ChatEntry[]>([]);
  const [busy, setBusy] = useState(false);
  const [mobile, setMobile] = useState(false);
  const memory = useRef<GuideMemory>({});
  const quotaLimit = useRef<{reason:LocalFallbackReason;until:number}|null>(null);
  const serial = useRef(0);
  const controller = useRef<AbortController | null>(null);
  const input = useRef<HTMLTextAreaElement>(null);
  const panel = useRef<HTMLDivElement>(null);
  const history = useRef<HTMLDivElement>(null);
  const restoreFocus = useRef<HTMLElement | null>(null);
  const open = useRef(state.open);
  open.current = state.open;

  useEffect(() => {
    const query = matchMedia('(max-width: 640px)');
    const sync = () => setMobile(query.matches);
    sync(); query.addEventListener('change', sync);
    return () => { query.removeEventListener('change', sync); controller.current?.abort(); };
  }, []);
  useEffect(() => {
    if (!state.open) return;
    restoreFocus.current = document.activeElement instanceof HTMLElement ? document.activeElement : null;
    // Avoid forcing the mobile keyboard open just by visiting the assistant.
    if (!matchMedia('(max-width: 640px)').matches) input.current?.focus({ preventScroll: true });
    else panel.current?.focus({ preventScroll: true });
    const oldOverflow = document.body.style.overflow;
    if (matchMedia('(max-width: 640px)').matches) document.body.style.overflow = 'hidden';
    const syncViewport = () => {
      const viewport = window.visualViewport;
      panel.current?.style.setProperty('--chat-height', `${viewport?.height || innerHeight}px`);
      panel.current?.style.setProperty('--chat-offset', `${Math.max(0, innerHeight - (viewport?.height || innerHeight) - (viewport?.offsetTop || 0))}px`);
    };
    syncViewport();
    window.visualViewport?.addEventListener('resize', syncViewport);
    window.visualViewport?.addEventListener('scroll', syncViewport);
    return () => { document.body.style.overflow = oldOverflow; window.visualViewport?.removeEventListener('resize', syncViewport); window.visualViewport?.removeEventListener('scroll', syncViewport); const returnTarget = restoreFocus.current?.isConnected ? restoreFocus.current : document.querySelector<HTMLButtonElement>('.companion-dock-button'); returnTarget?.focus({ preventScroll: true }); };
  }, [state.open]);
  useEffect(() => { if (state.open && history.current) history.current.scrollTop = history.current.scrollHeight; }, [messages, busy, state.open]);

  function reset() {
    controller.current?.abort(); controller.current=null;
    setMessages([]); memory.current = {}; setBusy(false); dispatch({ type: 'reset' }); input.current?.focus({ preventScroll: true });
  }
  async function submit() {
    const text = state.draft.trim();
    if (!text || busy || controller.current || !ai.ready) return;
    const previous = chatHistory(messages);
    const lastAssistant = messages.filter(m => m.role === 'assistant' && !m.error).at(-1);
    const contextText = normalizeFollowUpAnswer(text, [lastAssistant?.text || '', ...(lastAssistant?.aiReply?.followUpQuestions || [])].join('\n'));
    setMessages(m => [...m.slice(-22), { id: ++serial.current, role: 'user', text, contextText }]);
    dispatch({ type: 'input', value: '' }); dispatch({ type: 'phase', phase: 'thinking' }); setBusy(true);
    const abort = new AbortController(); controller.current = abort;
    const timeout = setTimeout(() => abort.abort('timeout'), 40000);
    const timing=createRequestTiming();
    try {
      if (ai.enabled && (!quotaLimit.current || Date.now() >= quotaLimit.current.until)) {
        const response = await timing.measure('dp-client-transport',()=>fetch(assistantEndpoint(), { method: 'POST', credentials: remoteAssistant ? 'omit' : 'same-origin', headers: { 'Content-Type': 'application/json', ...(ai.token ? { Authorization: `Bearer ${ai.token}` } : {}) }, body: JSON.stringify({message:contextText,history:previous,path,requestId:crypto.randomUUID()}), signal: abort.signal }));
        console.info('[assistant:server-timing]',{timing:response.headers.get('Server-Timing')});
        let reply = await timing.measure('dp-client-read',()=>response.json());
        const limited = quotaFallback(response.status,reply.error,response.headers.get('retry-after'),Date.now(),reply.code);
        if (limited) {
          quotaLimit.current = limited;
          const { localQuotaReply } = await timing.measure('dp-local-import',()=>import('@/lib/ai/local-fallback'));
          reply = timing.sync('dp-local-rules',()=>localQuotaReply({message:contextText,history:previous,path},limited.reason));
        }
        if(!response.ok&&!limited){
          const reason=failureReason(response.status,reply.code),{localQuotaReply}=await import('@/lib/ai/local-fallback');
          reply={...localQuotaReply({message:contextText,history:previous,path},reason),...(reply.code==='UPSTREAM_TIMEOUT'?{fallbackDetail:'timeout'}:{})};
        }
        if(process.env.NODE_ENV==='development'&&reply.debugQuota)console.info('[assistant:quota]',reply.debugQuota);
        if (reply.validationCode) console.info('[assistant] response fallback', { code: reply.validationCode });
        if (!abort.signal.aborted) {
          rememberValidationReply(text,reply as AssistantReply,id=>getProduct(id)?.name||id);
          setMessages(m => [...m.slice(-23), { id: ++serial.current, role: 'assistant', text: reply.answer, aiReply: reply as AssistantReply }]);
        }
      } else {
        const reason=quotaLimit.current&&Date.now()<quotaLimit.current.until?quotaLimit.current.reason:ai.reason==='limited'?'limited':ai.reason==='network'||ai.reason==='timeout'?'model-failure':'other';
        const {localQuotaReply}=await timing.measure('dp-local-import',()=>import('@/lib/ai/local-fallback'));
        if(abort.signal.aborted)return;
        const reply=timing.sync('dp-local-rules',()=>localQuotaReply({message:contextText,history:previous,path},reason));
        setMessages(m => [...m.slice(-23), { id: ++serial.current, role: 'assistant', text: reply.answer, aiReply: reply }]);
      }
      if (!abort.signal.aborted && open.current) dispatch({ type: 'phase', phase: 'speaking' });
    } catch (cause) {
      if (!abort.signal.aborted || abort.signal.reason === 'timeout') {
        const {localQuotaReply}=await import('@/lib/ai/local-fallback');
        if(abort.signal.aborted&&abort.signal.reason!=='timeout')return;
        const reply:AssistantReply={...localQuotaReply({message:contextText,history:previous,path},'model-failure'),fallbackDetail:abort.signal.reason==='timeout'?'timeout':'network'};
        setMessages(m=>[...m.slice(-23),{id:++serial.current,role:'assistant',text:reply.answer,aiReply:reply}]);
        if(open.current)dispatch({type:'phase',phase:'speaking'});
      }
    } finally { console.info('[assistant:client-timing]',timing.snapshot()); clearTimeout(timeout); if (controller.current === abort) { controller.current = null; setBusy(false); } }
  }
  function keyboard(event: React.KeyboardEvent<HTMLDivElement>) {
    if (event.key === 'Escape') { event.stopPropagation(); dispatch({ type: 'close' }); }
    if (event.key === 'Tab') {
      const elements = panel.current?.querySelectorAll<HTMLElement>('button:not([disabled]), a[href], textarea:not([disabled])');
      if (!elements?.length) return;
      const first = elements[0], last = elements[elements.length - 1];
      if (event.shiftKey && (document.activeElement === first || document.activeElement === panel.current)) { event.preventDefault(); last.focus(); }
      else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
    }
  }
  if (!state.open) return null;
  return <>
    <div className="companion-chat-backdrop" aria-hidden="true" onClick={() => dispatch({ type: 'close' })} />
    <div className="companion-chat" ref={panel} role="dialog" aria-modal={mobile} aria-labelledby="companion-chat-title" tabIndex={-1} onKeyDown={keyboard}>
      <header className="companion-chat-header"><div className="chat-avatar"><MascotFallback mood={state.phase} /></div><div><h2 id="companion-chat-title">小派 <span>未域 ELVORA</span></h2><p><span />{!ai.ready ? '正在连接顾问…' : ai.enabled ? `${ai.model || 'deepseek-flash'} · 数码顾问` : '本地规则导览'}</p></div><div className="chat-header-tools"><button onClick={reset} aria-label="重新开始对话" title="重新开始"><RotateCcw size={15} /></button><button onClick={() => dispatch({ type: 'close' })} aria-label="最小化聊天" title="最小化"><Minimize2 size={15} /></button><button onClick={() => dispatch({ type: 'close' })} aria-label="关闭聊天"><X size={17} /></button></div></header>
      <div className="chat-mode-note"><Info size={13} /><div><p>{ai.connecting ? '正在连接在线顾问，请稍候…' : quotaLimit.current && Date.now() < quotaLimit.current.until ? chatReplyNotice({mode:'guide',fallbackReason:quotaLimit.current.reason}) : ai.enabled ? '发送后由 DeepSeek 模型处理本次问题与最近对话；若未能完成，将明确标为本地参考。价格非实时，购买前请核实。' : ai.error || '当前未启用云端模型，由本地规则整理需求。'}</p>{!ai.enabled && <div className="chat-connection-actions"><Link href="/diagnostics/" onClick={() => dispatch({ type: 'close' })}>运行连接自检 ↗</Link><button type="button" onClick={reconnectAi} disabled={ai.connecting}><RotateCcw size={12} />{ai.connecting ? '正在连接' : '重新连接 AI'}</button>{!ai.connecting && (ai.reason === 'network' || ai.reason === 'timeout') && <span>微信中可点右上角 ···，选择在浏览器打开</span>}</div>}</div></div>
      <div className="companion-chat-history" ref={history} role="log" aria-live="polite" aria-relevant="additions text">
        <div className="chat-welcome"><span className="chat-welcome-icon"><MessageCircle size={23} strokeWidth={1.4} /></span><h3>选数码，不必一个人纠结。</h3><p>嗨！我是小派。告诉我预算、用途和偏好，我可以先帮你整理条件，再带你找到合适的选购工具。</p><div className="chat-prompt-chips">{prompts.map(prompt => <button key={prompt} onClick={() => { dispatch({ type: 'input', value: prompt }); input.current?.focus({ preventScroll: true }); }}>{prompt}<ArrowUpRight size={12} /></button>)}</div><span className="chat-prefill-hint">点选只填入问题，发送后开始咨询。</span></div>
        {messages.map(message => { const product = message.reply?.productId ? getProduct(message.reply.productId) : undefined; return <div key={message.id} className={`companion-message from-${message.role}`}><span className="chat-message-label">{message.role === 'user' ? '你' : message.error ? '服务提示' : message.aiReply?.mode === 'ai' ? '小派 · DeepSeek 模型回答' : message.aiReply?.mode === 'guide' ? '小派 · 本地整理' : '小派 · 本地导览'}</span>{message.aiReply?.mode==='guide' && <small className="chat-response-notice">{chatReplyNotice(message.aiReply)}</small>}<p>{message.text}</p>{message.aiReply && message.aiReply.mode!=='guide' && chatReplyNotice(message.aiReply) && <small className="chat-response-notice">{chatReplyNotice(message.aiReply)}</small>}{product && <div className="chat-product-preview"><DeviceArt productId={product.id} category={product.category} color={product.color} /><div><strong>{product.name}</strong><span>{product.configuration}</span><small>产品库示例 · 价格不作为市场依据</small></div></div>}{product && !message.aiReply?.recommendations.some(rec => rec.id === product.id) && <SecondhandLink product={product}/>} {(message.aiReply?.links || message.reply?.links) && <div className="chat-response-links">{(message.aiReply?.links || message.reply?.links || []).map(link => <Link key={link.href} href={link.href} onClick={() => dispatch({ type: 'close' })}>{link.label}<ArrowUpRight size={13} /></Link>)}</div>}{message.aiReply?.recommendations.map(rec => { const device = getProduct(rec.id); return device && <div key={rec.id} className="chat-recommendation-group"><Link className="chat-recommendation" href={`/products/${rec.id}/`} onClick={() => dispatch({ type: 'close' })}><strong>{device.name}<ArrowUpRight size={14} /></strong>{message.aiReply?.recommendationScope==='reference'&&<small>核价备选 · 非实时价格 · 未通过购买预算审核</small>}<span>{rec.reason}</span><small>注意：{rec.caution}</small></Link><SecondhandLink product={device}/></div>; })}{!!message.aiReply?.recommendations.some(rec => !!getProduct(rec.id)) && <CopyRecommendations text={recommendationText({ items: message.aiReply.recommendations, scope: message.aiReply.recommendationScope === 'verified' && message.aiReply.budgetQualified ? 'verified' : 'reference' })}/>}
{message.aiReply?.followUpQuestions.length ? <div className="chat-prompt-chips follow-up">{message.aiReply.followUpQuestions.map(q => <button key={q} onClick={() => { dispatch({ type: 'input', value: q }); input.current?.focus({ preventScroll: true }); }}>{q}<ArrowUpRight size={12} /></button>)}</div> : null}{message.error && <button className="chat-retry" onClick={() => { dispatch({ type: 'input', value: message.retry || '' }); input.current?.focus({ preventScroll: true }); }}><RotateCcw size={12} />重新填入问题</button>}</div>; })}
        {busy && <div className="chat-thinking" role="status"><span><i /><i /><i /></span>{ai.enabled ? '小派正在整理资料与取舍…' : '本地规则正在整理条件…'}</div>}
      </div>
      <form className="companion-chat-composer" onSubmit={event => { event.preventDefault(); submit(); }}><div className="chat-input-wrap"><label htmlFor="companion-message" className="sr-only">告诉小派你的预算、用途与偏好</label><textarea id="companion-message" ref={input} rows={2} maxLength={800} placeholder="预算、用途，还有你在意的…" value={state.draft} onChange={event => dispatch({ type: 'input', value: event.target.value })} onKeyDown={event => { if (event.key === 'Enter' && !event.shiftKey && !event.nativeEvent.isComposing && !mobile) { event.preventDefault(); submit(); } }} /><button type="submit" disabled={!state.draft.trim() || busy || !ai.ready} aria-label="发送给小派"><ArrowUp size={19} /></button></div><div className="chat-composer-foot"><span><ShieldCheck size={10} />校验记录仅存本机</span><span>{state.draft.length}/800</span></div></form>
    </div>
  </>;
}
