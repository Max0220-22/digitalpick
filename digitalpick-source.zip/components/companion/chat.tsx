'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useEffect, useRef, useState } from 'react';
import { ArrowUp, ArrowUpRight, Info, MessageCircle, Minimize2, RotateCcw, ShieldCheck, X } from 'lucide-react';
import { localGuide, type GuideMemory, type GuideReply } from '@/lib/companion/guide';
import type { AssistantReply } from '@/lib/ai/schema';
import { chatHistory, normalizeFollowUpAnswer } from '@/lib/companion/chat-history';
import { assistantEndpoint, remoteAssistant, appPath } from '@/lib/deployment';
import { getProduct } from '@/lib/products';
import { DeviceArt } from '@/components/device-art';
import { useCompanion } from './provider';
import { MascotFallback } from './fallback';
import { SecondhandLink } from '@/components/secondhand-link';
import { CopyRecommendations } from '@/components/copy-recommendations';
import { recommendationText } from '@/lib/recommendation-share';

interface ChatEntry { id: number; role: 'user' | 'assistant'; text: string; contextText?: string; reply?: GuideReply; aiReply?: AssistantReply; error?: boolean; retry?: string }
const prompts = ['3000元买什么手机？', '全新还是二手更划算？', '帮我比较两款设备。', '大学生买什么笔记本？', '二手手机怎么避坑？', '苹果16和15哪个好？', '内存和存储有什么区别？'];
export function CompanionChat() {
  const { state, dispatch, ai, reconnectAi } = useCompanion();
  const path = appPath(usePathname());
  const [messages, setMessages] = useState<ChatEntry[]>([]);
  const [busy, setBusy] = useState(false);
  const [mobile, setMobile] = useState(false);
  const memory = useRef<GuideMemory>({});
  const serial = useRef(0);
  const controller = useRef<AbortController | null>(null);
  const input = useRef<HTMLTextAreaElement>(null);
  const panel = useRef<HTMLDivElement>(null);
  const history = useRef<HTMLDivElement>(null);
  const restoreFocus = useRef<HTMLElement | null>(null);
  const open = useRef(state.open);
  open.current = state.open;

  useEffect(() => {
    const query = matchMedia('(max-width: 640px)');
    const sync = () => setMobile(query.matches);
    sync(); query.addEventListener('change', sync);
    return () => { query.removeEventListener('change', sync); controller.current?.abort(); };
  }, []);
  useEffect(() => {
    if (!state.open) return;
    restoreFocus.current = document.activeElement instanceof HTMLElement ? document.activeElement : null;
    // Avoid forcing the mobile keyboard open just by visiting the assistant.
    if (!matchMedia('(max-width: 640px)').matches) input.current?.focus({ preventScroll: true });
    else panel.current?.focus({ preventScroll: true });
    const oldOverflow = document.body.style.overflow;
    if (matchMedia('(max-width: 640px)').matches) document.body.style.overflow = 'hidden';
    const syncViewport = () => {
      const viewport = window.visualViewport;
      panel.current?.style.setProperty('--chat-height', `${viewport?.height || innerHeight}px`);
      panel.current?.style.setProperty('--chat-offset', `${Math.max(0, innerHeight - (viewport?.height || innerHeight) - (viewport?.offsetTop || 0))}px`);
    };
    syncViewport();
    window.visualViewport?.addEventListener('resize', syncViewport);
    window.visualViewport?.addEventListener('scroll', syncViewport);
    return () => { document.body.style.overflow = oldOverflow; window.visualViewport?.removeEventListener('resize', syncViewport); window.visualViewport?.removeEventListener('scroll', syncViewport); const returnTarget = restoreFocus.current?.isConnected ? restoreFocus.current : document.querySelector<HTMLButtonElement>('.companion-dock-button'); returnTarget?.focus({ preventScroll: true }); };
  }, [state.open]);
  useEffect(() => { if (state.open && history.current) history.current.scrollTop = history.current.scrollHeight; }, [messages, busy, state.open]);

  function reset() {
    controller.current?.abort();
    setMessages([]); memory.current = {}; setBusy(false); dispatch({ type: 'reset' }); input.current?.focus({ preventScroll: true });
  }
  async function submit() {
    const text = state.draft.trim();
    if (!text || busy || !ai.ready) return;
    const previous = chatHistory(messages);
    const lastAssistant = messages.filter(m => m.role === 'assistant' && !m.error).at(-1);
    const contextText = normalizeFollowUpAnswer(text, [lastAssistant?.text || '', ...(lastAssistant?.aiReply?.followUpQuestions || [])].join('\n'));
    setMessages(m => [...m.slice(-22), { id: ++serial.current, role: 'user', text, contextText }]);
    dispatch({ type: 'input', value: '' }); dispatch({ type: 'phase', phase: 'thinking' }); setBusy(true);
    const abort = new AbortController(); controller.current = abort;
    const timeout = setTimeout(() => abort.abort('timeout'), 40000);
    try {
      if (ai.enabled) {
        const response = await fetch(assistantEndpoint(), { method: 'POST', credentials: remoteAssistant ? 'omit' : 'same-origin', headers: { 'Content-Type': 'application/json', ...(ai.token ? { Authorization: `Bearer ${ai.token}` } : {}) }, body: JSON.stringify({ message: contextText, history: previous, path }), signal: abort.signal });
        const reply = await response.json();
        if (!response.ok) throw new Error(typeof reply.error === 'string' ? reply.error : 'AI 暂时没有完成回复。');
        if (!abort.signal.aborted) setMessages(m => [...m.slice(-23), { id: ++serial.current, role: 'assistant', text: reply.answer, aiReply: reply as AssistantReply }]);
      } else {
        const [{ buildContext }, { safeGuideReply }] = await Promise.all([import('@/lib/ai/context'), import('@/lib/ai/reply')]);
        if (abort.signal.aborted) return;
        const context = buildContext({ message: contextText, history: previous, path });
        if (context.task.intent === 'purchase-advice') {
          memory.current = context.memory;
          const reply = safeGuideReply(context, 'LOCAL_GUIDE');
          setMessages(m => [...m.slice(-23), { id: ++serial.current, role: 'assistant', text: reply.answer, aiReply: reply }]);
        } else {
          const reply = localGuide(text, memory.current, path); memory.current = reply.memory;
          setMessages(m => [...m.slice(-23), { id: ++serial.current, role: 'assistant', text: reply.text, reply }]);
        }
      }
      if (!abort.signal.aborted && open.current) dispatch({ type: 'phase', phase: 'speaking' });
    } catch (cause) {
      if (!abort.signal.aborted || abort.signal.reason === 'timeout') {
        setMessages(m => [...m.slice(-23), { id: ++serial.current, role: 'assistant', text: abort.signal.reason === 'timeout' ? '等待回复超时了。可以重试，或先使用规则选购。' : cause instanceof Error ? cause.message : '网络连接暂时不可用，请稍后重试。', error: true, retry: text }]);
        if (open.current) dispatch({ type: 'phase', phase: 'error' });
      }
    } finally { clearTimeout(timeout); if (controller.current === abort) { controller.current = null; setBusy(false); } }
  }
  function keyboard(event: React.KeyboardEvent<HTMLDivElement>) {
    if (event.key === 'Escape') { event.stopPropagation(); dispatch({ type: 'close' }); }
    if (event.key === 'Tab') {
      const elements = panel.current?.querySelectorAll<HTMLElement>('button:not([disabled]), a[href], textarea:not([disabled])');
      if (!elements?.length) return;
      const first = elements[0], last = elements[elements.length - 1];
      if (event.shiftKey && (document.activeElement === first || document.activeElement === panel.current)) { event.preventDefault(); last.focus(); }
      else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
    }
  }
  if (!state.open) return null;
  return <>
    <div className="companion-chat-backdrop" aria-hidden="true" onClick={() => dispatch({ type: 'close' })} />
    <div className="companion-chat" ref={panel} role="dialog" aria-modal={mobile} aria-labelledby="companion-chat-title" tabIndex={-1} onKeyDown={keyboard}>
      <header className="companion-chat-header"><div className="chat-avatar"><MascotFallback mood={state.phase} /></div><div><h2 id="companion-chat-title">小派 <span>未域 ELVORA</span></h2><p><span />{!ai.ready ? '正在连接顾问…' : ai.enabled ? `${ai.model || 'DeepSeek'} · 数码顾问` : '本地规则导览'}</p></div><div className="chat-header-tools"><button onClick={reset} aria-label="重新开始对话" title="重新开始"><RotateCcw size={15} /></button><button onClick={() => dispatch({ type: 'close' })} aria-label="最小化聊天" title="最小化"><Minimize2 size={15} /></button><button onClick={() => dispatch({ type: 'close' })} aria-label="关闭聊天"><X size={17} /></button></div></header>
      <div className="chat-mode-note"><Info size={13} /><div><p>{ai.connecting ? '正在连接在线顾问，请稍候…' : ai.enabled ? '发送后将由 DeepSeek 处理本次问题与最近对话。价格仅以可靠来源为准，AI 回复供参考。' : ai.error || '当前未启用云端模型，由本地规则整理需求。'}</p>{!ai.enabled && <div className="chat-connection-actions"><Link href="/diagnostics/" onClick={() => dispatch({ type: 'close' })}>运行连接自检 ↗</Link><button type="button" onClick={reconnectAi} disabled={ai.connecting}><RotateCcw size={12} />{ai.connecting ? '正在连接' : '重新连接 AI'}</button>{!ai.connecting && (ai.reason === 'network' || ai.reason === 'timeout') && <span>微信中可点右上角 ···，选择在浏览器打开</span>}</div>}</div></div>
      <div className="companion-chat-history" ref={history} role="log" aria-live="polite" aria-relevant="additions text">
        <div className="chat-welcome"><span className="chat-welcome-icon"><MessageCircle size={23} strokeWidth={1.4} /></span><h3>选数码，不必一个人纠结。</h3><p>嗨！我是小派。告诉我预算、用途和偏好，我可以先帮你整理条件，再带你找到合适的选购工具。</p><div className="chat-prompt-chips">{prompts.map(prompt => <button key={prompt} onClick={() => { dispatch({ type: 'input', value: prompt }); input.current?.focus({ preventScroll: true }); }}>{prompt}<ArrowUpRight size={12} /></button>)}</div><span className="chat-prefill-hint">点选只填入问题，发送后开始咨询。</span></div>
        {messages.map(message => { const product = message.reply?.productId ? getProduct(message.reply.productId) : undefined; return <div key={message.id} className={`companion-message from-${message.role}`}><span className="chat-message-label">{message.role === 'user' ? '你' : message.error ? '服务提示' : message.aiReply?.mode === 'ai' ? '小派 · DeepSeek' : message.aiReply?.mode === 'guide' ? '小派 · 本地整理' : '小派 · 本地导览'}</span><p>{message.text}</p>{message.aiReply?.notice && <small className="chat-response-notice">{message.aiReply.notice}</small>}{product && <div className="chat-product-preview"><DeviceArt productId={product.id} category={product.category} color={product.color} /><div><strong>{product.name}</strong><span>{product.configuration}</span><small>产品库示例 · 价格不作为市场依据</small></div></div>}{product && !message.aiReply?.recommendations.some(rec => rec.id === product.id) && <SecondhandLink product={product}/>} {(message.aiReply?.links || message.reply?.links) && <div className="chat-response-links">{(message.aiReply?.links || message.reply?.links || []).map(link => <Link key={link.href} href={link.href} onClick={() => dispatch({ type: 'close' })}>{link.label}<ArrowUpRight size={13} /></Link>)}</div>}{message.aiReply?.recommendations.map(rec => { const device = getProduct(rec.id); return device && <div key={rec.id} className="chat-recommendation-group"><Link className="chat-recommendation" href={`/products/${rec.id}/`} onClick={() => dispatch({ type: 'close' })}><strong>{device.name}<ArrowUpRight size={14} /></strong>{message.aiReply?.recommendationScope==='reference'&&<small>核价备选 · 非实时价格 · 未通过购买预算审核</small>}<span>{rec.reason}</span><small>注意：{rec.caution}</small></Link><SecondhandLink product={device}/></div>; })}{!!message.aiReply?.recommendations.some(rec => !!getProduct(rec.id)) && <CopyRecommendations text={recommendationText({ items: message.aiReply.recommendations, scope: message.aiReply.recommendationScope === 'verified' && message.aiReply.budgetQualified ? 'verified' : 'reference' })}/>}
{message.aiReply?.followUpQuestions.length ? <div className="chat-prompt-chips follow-up">{message.aiReply.followUpQuestions.map(q => <button key={q} onClick={() => { dispatch({ type: 'input', value: q }); input.current?.focus({ preventScroll: true }); }}>{q}<ArrowUpRight size={12} /></button>)}</div> : null}{message.error && <button className="chat-retry" onClick={() => { dispatch({ type: 'input', value: message.retry || '' }); input.current?.focus({ preventScroll: true }); }}><RotateCcw size={12} />重新填入问题</button>}</div>; })}
        {busy && <div className="chat-thinking" role="status"><span><i /><i /><i /></span>{ai.enabled ? '小派正在整理资料与取舍…' : '本地规则正在整理条件…'}</div>}
      </div>
      <form className="companion-chat-composer" onSubmit={event => { event.preventDefault(); submit(); }}><div className="chat-input-wrap"><label htmlFor="companion-message" className="sr-only">告诉小派你的预算、用途与偏好</label><textarea id="companion-message" ref={input} rows={2} maxLength={800} placeholder="预算、用途，还有你在意的…" value={state.draft} onChange={event => dispatch({ type: 'input', value: event.target.value })} onKeyDown={event => { if (event.key === 'Enter' && !event.shiftKey && !event.nativeEvent.isComposing && !mobile) { event.preventDefault(); submit(); } }} /><button type="submit" disabled={!state.draft.trim() || busy || !ai.ready} aria-label="发送给小派"><ArrowUp size={19} /></button></div><div className="chat-composer-foot"><span><ShieldCheck size={10} />本站不保存对话正文</span><span>{state.draft.length}/800</span></div></form>
    </div>
  </>;
}
