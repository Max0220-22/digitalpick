'use client';

import { createContext, useCallback, useContext, useEffect, useReducer, useRef, useState, type Dispatch, type MutableRefObject } from 'react';
import { createAssistantConnection, initialAiConnection, type AiConnectionState } from '@/lib/companion/connection';
import { assistantEndpoint, isStaticDeployment, remoteAssistant } from '@/lib/deployment';
import { companionReducer, initialCompanionState, normalizePointer, type CompanionEvent, type CompanionState } from '@/lib/companion/state';

interface CompanionContextValue {
  state: CompanionState;
  dispatch: Dispatch<CompanionEvent>;
  flight: MutableRefObject<{ at: number; x: number; y: number }>;
  gaze: MutableRefObject<{ x: number; y: number }>;
  active: boolean;
  reducedMotion: boolean;
  heroVisible: boolean;
  setHeroVisible: (visible: boolean) => void;
  openChat: (prompt?: string) => void;
  ai: AiConnectionState;
  reconnectAi: () => void;
}
const CompanionContext = createContext<CompanionContextValue | null>(null);

export function CompanionProvider({ children }: { children: React.ReactNode }) {
  const [state, dispatch] = useReducer(companionReducer, initialCompanionState);
  const gaze = useRef({ x: 0, y: 0 });
  const flight = useRef({ at: 0, x: 0, y: 0 });
  const [active, setActive] = useState(true);
  const [reducedMotion, setReducedMotion] = useState(false);
  const [heroVisible, setHeroVisible] = useState(true);
  const [ai, setAi] = useState<AiConnectionState>(initialAiConnection);
  const aiRef = useRef(ai); aiRef.current = ai;
  const connection = useRef<ReturnType<typeof createAssistantConnection> | null>(null);
  const reconnectAi = useCallback(() => { void connection.current?.connect(true); }, []);
  const idleTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const phase = useRef(state.phase); phase.current = state.phase;
  const openChat = useCallback((prompt?: string) => dispatch({ type: 'open', prompt }), []);

  useEffect(() => {
    if (isStaticDeployment && !remoteAssistant) { setAi({ ...initialAiConnection, ready: true, connecting: false, reason: 'disabled', error: '尚未配置 AI 后端，当前使用本地规则导览。' }); return; }
    const client = createAssistantConnection({ endpoint: assistantEndpoint(), remote: remoteAssistant, onChange: setAi });
    connection.current = client;
    void client.connect();
    const recover = () => { if (!document.hidden && !aiRef.current.enabled) void client.connect(); };
    window.addEventListener('online', recover);
    document.addEventListener('visibilitychange', recover);
    return () => { client.dispose(); if (connection.current === client) connection.current = null; window.removeEventListener('online', recover); document.removeEventListener('visibilitychange', recover); };
  }, []);
  useEffect(() => {
    if (state.open && !aiRef.current.enabled) void connection.current?.connect();
  }, [state.open]);

  useEffect(() => {
    const query = matchMedia('(prefers-reduced-motion: reduce)');
    const compactQuery = matchMedia('(max-width: 640px)');
    const syncMotion = () => setReducedMotion(query.matches);
    const syncVisibility = () => setActive(!document.hidden && document.hasFocus());
    const userActivity = () => { if (!document.hidden) setActive(true); };
    const fly = (event: PointerEvent) => {
      const scene = document.querySelector<HTMLElement>('.hero-mascot');
      const bounds = scene?.getBoundingClientRect();
      // The hero lives in the right column: direction is relative to the character, not the window.
      const point = bounds && bounds.bottom > 0 && bounds.top < innerHeight
        ? normalizePointer(event.clientX - bounds.left, event.clientY - bounds.top, bounds.width, bounds.height)
        : normalizePointer(event.clientX, event.clientY, innerWidth, innerHeight);
      flight.current = { at: performance.now(), ...point };
    };
    const resetGaze = () => { gaze.current = { x: 0, y: 0 }; syncVisibility(); };
    const move = (event: PointerEvent) => {
      if (event.pointerType === 'mouse' && !compactQuery.matches) gaze.current = normalizePointer(event.clientX, event.clientY, innerWidth, innerHeight);
    };
    syncMotion(); syncVisibility();
    query.addEventListener('change', syncMotion);
    document.addEventListener('visibilitychange', syncVisibility);
    window.addEventListener('blur', resetGaze);
    window.addEventListener('focus', syncVisibility);
    window.addEventListener('pointermove', move, { passive: true });
    window.addEventListener('pointerdown', userActivity, { passive: true });
    window.addEventListener('pointerdown', fly, { passive: true });
    window.addEventListener('keydown', userActivity);
    return () => {
      query.removeEventListener('change', syncMotion);
      document.removeEventListener('visibilitychange', syncVisibility);
      window.removeEventListener('blur', resetGaze);
      window.removeEventListener('focus', syncVisibility);
      window.removeEventListener('pointermove', move);
      window.removeEventListener('pointerdown', userActivity);
      window.removeEventListener('pointerdown', fly);
      window.removeEventListener('keydown', userActivity);
    };
  }, []);

  useEffect(() => {
    if (state.open) return;
    const wake = () => {
      if (phase.current === 'sleeping') dispatch({ type: 'phase', phase: 'idle' });
      if (idleTimer.current) clearTimeout(idleTimer.current);
      idleTimer.current = setTimeout(() => dispatch({ type: 'phase', phase: 'sleeping' }), 45000);
    };
    let lastMove = 0;
    const pointerWake = () => { const now = performance.now(); if (now - lastMove > 2500) { lastMove = now; wake(); } };
    wake();
    window.addEventListener('pointermove', pointerWake, { passive: true });
    window.addEventListener('focus', wake);
    window.addEventListener('pointerdown', wake, { passive: true });
    window.addEventListener('keydown', wake);
    return () => {
      if (idleTimer.current) clearTimeout(idleTimer.current);
      window.removeEventListener('pointermove', pointerWake);
      window.removeEventListener('focus', wake);
      window.removeEventListener('pointerdown', wake);
      window.removeEventListener('keydown', wake);
    };
  }, [state.open]);

  useEffect(() => {
    if (!['greeting', 'success', 'speaking'].includes(state.phase)) return;
    const timer = setTimeout(() => dispatch({ type: 'phase', phase: state.open && state.draft ? 'listening' : 'idle' }), 2200);
    return () => clearTimeout(timer);
  }, [state.phase, state.open, state.draft]);

  return <CompanionContext value={{ state, dispatch, gaze, flight, active, reducedMotion, heroVisible, setHeroVisible, openChat, ai, reconnectAi }}>{children}</CompanionContext>;
}
export function useCompanion() {
  const value = useContext(CompanionContext);
  if (!value) throw new Error('CompanionProvider is required');
  return value;
}
