'use client';
import Link from 'next/link';
import { useEffect, useState } from 'react';
import type { Product, PurchaseMode } from '@/lib/products';
import { pricingFor, priceReferenceText, usedPriceScenario, type PriceReference } from '@/lib/price-reference';

const UNESTIMATED_PRICE_LABEL = '\u6682\u672a\u4f30\u7b97';

function PriceFact({ price, label, detailed }: { price: PriceReference | null; label: string; detailed: boolean }) {
 const [expired,setExpired]=useState(false);
 useEffect(()=>{if(price?.kind==='official-current') { const days=(Date.now()-Date.parse(price.checkedAt+'T00:00:00+08:00'))/86400000;setExpired(days>30||days<0); }},[price]);
 return <div className="price-display"><span className="price-label">{label}</span><div><strong className={!price?'no-price':''}>{price?priceReferenceText(price):'暂未核实'}</strong>{price&&<span className="price-demo">{price.kind==='launch'?'历史':price.kind==='official-msrp'?'建议价':'官网'}</span>}</div>{price&&<><small>{price.region} · {price.configuration}</small><small>{price.kind==='launch'?`发布于 ${price.publishedAt||'日期待核'}`:`核对于 ${price.checkedAt}`}{expired?' · 已过期，购买前重新核实':''}</small>{detailed&&<><a className="price-source" href={price.sourceUrl} target="_blank" rel="noopener noreferrer">{price.sourceLabel} ↗</a>{price.note&&<small>{price.note}</small>}</>}</>}{!price&&detailed&&<small>未找到足以确认这一价格口径的来源</small>}</div>;
}
export function ProductPrices({product,mode='either',detailed=false}:{product:Product;mode?:PurchaseMode;detailed?:boolean}) {
 const info=pricingFor(product.id), estimate=usedPriceScenario(product);
 const primary=info.official||info.launch||info.msrp;
 const primaryLabel=info.official?'官网参考价格':info.launch?'发售起价':info.msrp?'官方建议零售价':'官方价格';
 return <div className={detailed?'product-pricing detailed':'product-pricing'}>
 {detailed&&<div className="price-status"><span>{info.statusLabel}</span><small>核对日期：{info.checkedAt} · 官网列售不代表有货</small>{info.statusSource&&<a href={info.statusSource} target="_blank" rel="noopener noreferrer">核对在售目录 ↗</a>}</div>}
 <div className="card-prices">
 {mode!=='used'&&<PriceFact price={primary} label={primaryLabel} detailed={detailed}/>}
 {detailed&&info.official&&<PriceFact price={info.launch} label="发售起价" detailed/>}
 {detailed&&!info.launch&&info.official&&info.msrp&&<PriceFact price={info.msrp} label="官方建议零售价（非发售价）" detailed/>}
 {mode!=='new'&&(estimate?<div className="price-display estimated-price"><span className="price-label">二手估算区间</span><div><strong>¥{estimate.min.toLocaleString('zh-CN')}–¥{estimate.max.toLocaleString('zh-CN')}</strong><span className="price-demo">估算</span></div><small>折旧模型 · 无平台市场样本</small><small>{estimate.anchor.configuration} · {estimate.anchor.region}</small>{detailed&&<><small>按发售参考价 × {Math.round(estimate.factors[0]*100)}%–{Math.round(estimate.factors[1]*100)}%，按年份计算约 {estimate.age} 年，金额向外取整至 50 元。该比例是编辑设定，未用成交数据校准。</small><small>{estimate.condition}</small><small>估算日期：{estimate.date}；不保证能买到，不用于预算推荐或折旧率结论。</small><Link className="price-source" href="/pricing/">查看估算方法与限制 ↗</Link></>}</div>:<div className="price-display"><span className="price-label">二手估算区间</span><div><strong className="no-price">{UNESTIMATED_PRICE_LABEL}</strong></div><small>{info.status==='listed'?'官网列售机型优先展示官方价格':/fold|flip|pocket|mate\s*x|折叠/i.test(product.name)?'折叠屏不适用当前普通设备折旧模型':'缺少已核实发售价，不用猜测数字补齐'}</small></div>)}
 </div>
 {detailed&&<><p className="small muted price-boundary">价格独立标注地区与配置，可能与本页参数资料版本不同；“起”仅代表基础版本，不代表所有内存、容量或蜂窝版本。历史价、建议价和模型估算均不是当前可购买报价。</p>{info.notes.map((note,i)=><p className="small muted" key={i}>{note}</p>)}{info.launch?.variants&&<details className="price-variants"><summary>查看已核对的配置价格</summary><ul>{info.launch.variants.map(v=><li key={v.configuration}>{v.configuration}<strong>¥{v.amount.toLocaleString('zh-CN')}</strong></li>)}</ul></details>}<Link href="/pricing/" className="text-link">价格来源与覆盖进度 ↗</Link></>}
 </div>;
}
