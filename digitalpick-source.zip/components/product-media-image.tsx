'use client';
import { useId, useState } from 'react';
import { ImageOff } from 'lucide-react';
import { assetPath } from '@/lib/deployment';
import type { ProductMedia } from '@/lib/product-media';
export function ProductMediaImage({ media, eager = false }: { media: ProductMedia; eager?: boolean }) {
  const id = useId().replace(/:/g, '');
  const [failed, setFailed] = useState(false);
  if (failed) return <div className="media-unavailable" role="img" aria-label="官方图片暂不可用，请通过下方来源查看"><ImageOff size={36} strokeWidth={1}/><span>图片暂不可用</span><small>可通过官方来源查看外观</small></div>;
  return <div className={`device-media${media.paper ? ' media-paper' : ''}${media.clip ? ' media-cutout' : ''}`} data-source={media.label}>
    {media.clip ? <svg viewBox={media.clip.viewBox} role="img" aria-label={media.alt}><defs><clipPath id={`photo-${id}`}><path d={media.clip.path}/></clipPath></defs><image href={assetPath(media.src)} width={media.clip.width} height={media.clip.height} clipPath={`url(#photo-${id})`} onError={() => setFailed(true)}/></svg> : <img src={assetPath(media.src)} alt={media.alt} loading={eager ? 'eager' : 'lazy'} decoding="async" width={1000} height={1000} referrerPolicy="no-referrer" onError={() => setFailed(true)}/>} 
  </div>;
}
