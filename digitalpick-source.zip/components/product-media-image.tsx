'use client';
import { useEffect, useId, useRef, useState } from 'react';
import { ImageOff } from 'lucide-react';
import { assetPath } from '@/lib/deployment';
import type { ProductMedia } from '@/lib/product-media';
export function ProductMediaImage({ media, eager = false }: { media: ProductMedia; eager?: boolean }) {
  const id = useId().replace(/:/g, '');
  const image = useRef<HTMLImageElement>(null);
  const [status, setStatus] = useState<'loading'|'ready'|'failed'>('loading');
  useEffect(() => {
    const element = image.current;
    // Cached images may finish before hydration attaches the load listener.
    if (element?.complete && element.naturalWidth > 0) setStatus('ready');
  }, [media.src]);
  if (status === 'failed') return <div className="media-unavailable" role="img" aria-label="官方图片暂不可用，请通过下方来源查看"><ImageOff size={36} strokeWidth={1}/><span>图片暂不可用</span><small>可通过官方来源查看外观</small></div>;
  return <div className={`device-media media-${status}${media.paper ? ' media-paper' : ''}${media.clip ? ' media-cutout' : ''}`} data-source={media.label} aria-busy={status === 'loading'}>
    <div className="media-skeleton" aria-hidden="true"><span/></div>
    {media.clip ? <svg viewBox={media.clip.viewBox} role="img" aria-label={media.alt}><defs><clipPath id={`photo-${id}`}><path d={media.clip.path}/></clipPath></defs><image href={assetPath(media.src)} width={media.clip.width} height={media.clip.height} clipPath={`url(#photo-${id})`} onLoad={() => setStatus('ready')} onError={() => setStatus('failed')}/></svg> : <img ref={image} src={assetPath(media.src)} alt={media.alt} loading={eager ? 'eager' : 'lazy'} decoding="async" width={media.width || 1000} height={media.height || 1000} referrerPolicy="no-referrer" onLoad={() => setStatus('ready')} onError={() => setStatus('failed')}/>} 
  </div>;
}
