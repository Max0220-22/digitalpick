'use client';
import { useEffect, useRef, useState } from 'react';
import { Check, Copy, X } from 'lucide-react';
export function CopyRecommendations({ text }: { text: string }) {
 const [copied, setCopied] = useState(false); const dialog = useRef<HTMLDialogElement>(null); const manual = useRef<HTMLTextAreaElement>(null); const timer = useRef<ReturnType<typeof setTimeout> | null>(null);
 useEffect(() => () => { if (timer.current) clearTimeout(timer.current); }, []);
 async function copy() {
  try { await navigator.clipboard.writeText(text); setCopied(true); if (timer.current) clearTimeout(timer.current); timer.current = setTimeout(() => setCopied(false), 2500); }
  catch { dialog.current?.showModal(); manual.current?.focus(); manual.current?.select(); }
 }
 return <><button type="button" className="button button-outline copy-recommendations" onClick={copy}>{copied ? <Check size={15}/> : <Copy size={15}/>}复制推荐清单</button>{copied && <span className="copy-toast" role="status"><Check size={16}/>已复制，可直接粘贴给微信好友</span>}<dialog ref={dialog} className="copy-dialog" aria-labelledby="copy-dialog-title" onClick={event => { if (event.target === dialog.current) dialog.current?.close(); }}><div className="copy-dialog-heading"><h2 id="copy-dialog-title">手动复制清单</h2><button type="button" onClick={() => dialog.current?.close()} aria-label="关闭复制窗口"><X size={20}/></button></div><p>浏览器限制了自动复制。请长按或全选下方文字，使用系统的复制功能。</p><label className="copy-manual-label">推荐清单<textarea ref={manual} aria-label="可手动复制的推荐清单" value={text} readOnly rows={10}/></label><button type="button" className="button button-primary" onClick={() => { manual.current?.focus(); manual.current?.select(); }}>全选文字</button></dialog></>;
}
