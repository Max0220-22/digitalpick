import Link from 'next/link';
import { Plus, ArrowUpRight } from 'lucide-react';
import { faqs } from '@/lib/beginner-content';
export function HomeFAQ() {
 return <section className="container section faq-section" id="faq" aria-labelledby="faq-title"><div className="faq-intro"><span className="section-kicker">A LITTLE CLARITY</span><span className="feature-eyebrow">小派答疑</span><h2 id="faq-title">你可能还想问。</h2><p>先把疑问讲清楚，<br/>再安心做决定。</p><Link href="/start/" className="text-link">第一次选购？走这条路 <ArrowUpRight size={16}/></Link></div><div className="faq-list">{faqs.map((faq, i) => <details key={faq.id} name="digitalpick-faq" className="faq-item" id={`faq-${faq.id}`}><summary><span className="faq-number">{String(i + 1).padStart(2, '0')}</span><span>{faq.question}</span><Plus size={18} aria-hidden="true"/></summary><div className="faq-answer"><p>{faq.answer}</p>{faq.id === 'after' && <Link href="/guides/after-unboxing/">阅读开箱之后指南 ↗</Link>}</div></details>)}</div></section>;
}
