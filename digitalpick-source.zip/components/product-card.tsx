import Link from 'next/link';
import { ArrowUpRight, Plus } from 'lucide-react';
import type { Product, PurchaseMode } from '@/lib/products';
import { DeviceArt, productVisualLabel } from './device-art';
import { Badge } from './ui/badge';
import { ProductPrices } from './product-prices';
import { WishlistButton } from './wishlist';
export function ProductCard({product,mode='either'}:{product:Product;mode?:PurchaseMode}) {
 const specs=[product.facts?.processor||product.processor,product.facts?.storage||(product.storage===null?null:`${product.storage}GB`),product.facts?.weight||(product.weight===null?null:product.weight<1000?`${product.weight}g`:`${product.weight/1000}kg`)].filter((s):s is string=>!!s&&!/尚未整理/.test(s));
 return <article className="product-card"><Link href={`/products/${product.id}/`} prefetch={false} className={`product-art-wrap tone-${product.color}`}><span className="card-topline"><Badge>{product.brand}</Badge><span className="art-label">{productVisualLabel(product.id)}</span></span><DeviceArt productId={product.id} category={product.category} color={product.color}/><span className="art-detail-arrow"><ArrowUpRight size={17}/></span></Link><div className="product-card-content"><div className="product-card-title"><Link href={`/products/${product.id}/`} prefetch={false}><h3>{product.name}</h3></Link><span className="small muted">{product.year||'年份待核实'}</span></div><p className="product-tagline">{product.tagline}</p><div className="spec-chips">{specs.length?specs.map((s,i)=><span key={i}>{s}</span>):<span>正式型号已核对 · 参数待补</span>}</div><ProductPrices product={product} mode={mode}/><div className="card-bottom"><Link className="text-link" href={`/products/${product.id}/`} prefetch={false}>查看参数与来源 <ArrowUpRight size={15}/></Link><div className="product-card-actions"><WishlistButton id={product.id} name={product.name}/><Link className="compare-small" href={`/compare/?add=${product.id}`} prefetch={false} aria-label={`将 ${product.name} 加入对比`}><Plus size={14}/>对比</Link></div></div></div></article>;
}
