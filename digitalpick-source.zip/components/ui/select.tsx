'use client';

import * as Select from '@radix-ui/react-select';
import { Check, ChevronDown, ChevronUp } from 'lucide-react';
import { cn } from '@/lib/utils';

export interface SelectOption { value: string; label: string; description?: string; disabled?: boolean }
export function GlassSelect({ value, onValueChange, options, label, placeholder = '请选择', disabled, id, className }: {
  value: string; onValueChange: (value: string) => void; options: SelectOption[]; label: string; placeholder?: string; disabled?: boolean; id?: string; className?: string;
}) {
  // Radix reserves the empty value for its placeholder.
  const sentinel = '__any__';
  return <Select.Root value={value === '' ? sentinel : value} onValueChange={next => onValueChange(next === sentinel ? '' : next)} disabled={disabled}>
    <Select.Trigger id={id} aria-label={label} className={cn('glass-select-trigger', className)}><Select.Value placeholder={placeholder} /><Select.Icon><ChevronDown size={15} /></Select.Icon></Select.Trigger>
    <Select.Portal><Select.Content className="glass-select-content" position="popper" sideOffset={8} collisionPadding={12}>
      <Select.ScrollUpButton className="glass-select-scroll"><ChevronUp size={15} /></Select.ScrollUpButton>
      <Select.Viewport className="glass-select-viewport"><Select.Group><Select.Label className="glass-select-label">{label}</Select.Label>{options.map(option => <Select.Item value={option.value === '' ? sentinel : option.value} key={option.value} disabled={option.disabled} className="glass-select-item" textValue={option.label}>
        <span className="glass-option-copy"><Select.ItemText>{option.label}</Select.ItemText>{option.description && <small>{option.description}</small>}</span><Select.ItemIndicator className="glass-option-check"><Check size={15} /></Select.ItemIndicator>
      </Select.Item>)}</Select.Group></Select.Viewport>
      <Select.ScrollDownButton className="glass-select-scroll"><ChevronDown size={15} /></Select.ScrollDownButton>
    </Select.Content></Select.Portal>
  </Select.Root>;
}
