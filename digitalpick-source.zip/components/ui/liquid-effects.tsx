'use client';
import { useEffect } from 'react';
const controls = '.button, .hero-device-selector>button, .orbit-device, .glass-select-trigger, .glass-select-content, .showcase-tabs>button, .stage-tools>button, .desktop-nav, .mode-choice, .choice, .gallery-view-tabs, .header-actions>.button-icon';
export function LiquidEffects() {
  useEffect(() => {
    let current: HTMLElement | null = null; const timers = new Set<ReturnType<typeof setTimeout>>();
    const move = (event: PointerEvent) => {
      const target = event.target instanceof Element ? event.target.closest<HTMLElement>(controls) : null;
      if (current !== target) { current?.classList.remove('liquid-hover'); current = target; current?.classList.add('liquid-hover'); }
      if (!target) return;
      const bounds = target.getBoundingClientRect(); target.style.setProperty('--light-x',`${(event.clientX-bounds.left)/bounds.width*100}%`); target.style.setProperty('--light-y',`${(event.clientY-bounds.top)/bounds.height*100}%`);
    };
    const press = (event: PointerEvent) => {
      move(event); if (!current) return; const element = current; element.classList.remove('liquid-pressed'); element.getBoundingClientRect(); element.classList.add('liquid-pressed');
      const timer = setTimeout(()=>{element.classList.remove('liquid-pressed');timers.delete(timer);},650); timers.add(timer);
    };
    document.addEventListener('pointermove',move,{passive:true}); document.addEventListener('pointerdown',press,{passive:true});
    return ()=>{document.removeEventListener('pointermove',move);document.removeEventListener('pointerdown',press);current?.classList.remove('liquid-hover');for(const timer of timers)clearTimeout(timer);};
  }, []);
  return <svg className="liquid-filter-defs" aria-hidden="true" width="0" height="0"><defs><filter id="dp-liquid-lens" x="-10%" y="-10%" width="120%" height="120%" colorInterpolationFilters="sRGB"><feGaussianBlur in="SourceGraphic" stdDeviation=".45" result="soft"/><feTurbulence type="fractalNoise" baseFrequency=".014 .025" numOctaves="2" seed="7" result="noise"/><feDisplacementMap in="soft" in2="noise" scale="15" xChannelSelector="R" yChannelSelector="G"/></filter></defs></svg>;
}
