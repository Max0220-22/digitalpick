# 部署 DigitalPick

**优先免费路线：[GitHub Pages + Cloudflare Workers 完整步骤](docs/FREE-DEPLOYMENT.md)。**

前端静态构建输出 `out-pages/`，Worker 代理 DeepSeek 并通过 SQLite Durable Object 原子保存额度。所有现有页面、3D、聊天与原 Node 接口均保留。需要 Cloudflare Free 账号与 GitHub 仓库授权；托管免费额度不包含 DeepSeek 模型调用费。上线前先轮换此前分享过的 Key。

原有 Node 路线仍使用 `output: 'standalone'`，说明保留如下。不要上传旧 `out/` 或 localhost 联调产物代替新 Pages 工作流。

## 本机与单台 Node 主机

推荐 Node.js 24 LTS 或更新兼容版本。本机已在 Node.js 26.8.1 / npm 11.19.0 验证；服务端使用内置 `node:sqlite`，不要改成不含该模块的运行时。

```bash
npm ci
npm run typecheck
npm test
npm run build
npm run check:site
npm start
```

服务默认绑定 `127.0.0.1:3000`，适合放在 HTTPS 反向代理后。需要绑定容器/平台分配地址时可用 `DIGITALPICK_HOST=0.0.0.0 npm start`。修改端口使用 `PORT=3001 npm start`。启动脚本会将公开静态资源复制到 standalone 目录、读取本机忽略的 `.env.local`，并把额度文件解析为项目根目录下的绝对路径，避免重建时丢失计数。守护进程必须在项目目录运行，保留 `.data` 的写权限与持久性。

源码包不包含凭据。复制 `.env.example` 到 `.env.local`，按需配置：

| 变量 | 用途 |
|---|---|
| `NEXT_PUBLIC_SITE_URL` | 公开 HTTPS 域名，用于 SEO 与反向代理下同源检查 |
| `AI_ENABLED` | `true` 开启 AI；其他值使用本地导览 |
| `AI_API_KEY` | DeepSeek 密钥，仅限服务端 |
| `AI_BASE_URL` | 当前允许 `https://api.deepseek.com` 或 `/v1` 路径 |
| `AI_MODEL` | `deepseek-flash` |
| `AI_SESSION_SECRET` | 至少 32 字符的随机服务端签名密钥 |
| `AI_QUOTA_PATH` | 持久 SQLite 文件，默认 `.data/ai-quota.sqlite` |
| `AI_DAILY_CALL_LIMIT` | 全站每日次数，默认 30 |
| `AI_USER_DAILY_LIMIT` | 每匿名会话每日次数，默认 10 |
| `AI_DAILY_TOKEN_LIMIT` | 全站每日保守预留 token，默认 180000 |

可用 `node -e "console.log(require('node:crypto').randomBytes(32).toString('hex'))"` 生成会话签名密钥。API Key 不得加 `NEXT_PUBLIC_` 前缀，不进 Git、日志、镜像或源码 ZIP。部署平台建议使用 Secret 配置；本机 `.env.local` 已忽略。

生产构建不需要 AI 凭据。请在服务器运行时注入，避免 Next standalone 输出在本地复制环境文件时把秘密带入分发物。不要直接分享整个 `.next/standalone` 目录。更新公开域名需要重新构建；仅更改 AI 密钥或额度后重启服务即可。

## Docker

已提供 `Dockerfile` 与 `.dockerignore`。环境文件被排除在构建上下文之外，构建阶段不接入 API Key：

```bash
docker build -t digitalpick .
docker volume create digitalpick-data
docker run --rm --name digitalpick -p 127.0.0.1:3000:3000 \
  --env-file .env.local \
  -v digitalpick-data:/app/.data \
  digitalpick
```

使用单个容器实例，反向代理负责域名与 HTTPS。需要 SEO 域名时，在构建命令增加 `--build-arg NEXT_PUBLIC_SITE_URL=你的实际HTTPS域名`，并在运行环境设置相同值；公开变量需要构建时提供。首次挂载空的命名卷会保留镜像中 `.data` 的所有者；绑定已有宿主目录时需让 UID 1001 可写。不要把 `.env.local` 复制进容器镜像。

Docker 配置已提供，当前开发环境未进行 Docker 镜像运行验证；已验证的是本机 Node 生产构建与启动。

## 持久化与部署限制

当前 SQLite 是**单主机持久磁盘**方案。可以多进程访问同一文件，事务用于控制并发额度。不能将多个独立容器卷当作统一总额度；不能在临时文件系统的 Serverless 服务上直接开启 AI。数据库不可用时接口停止调用模型。

选择支持 Node 及持久磁盘的服务器或容器平台即可。公开试用规模扩大前，应将额度迁移到共享事务存储，并在可信入口增加防刷限制。匿名 Cookie 可被清除，全站限额是本版的最终调用上限，详见 [AI 说明](docs/AI.md)。

## Cloudflare 与 GitHub Pages

已增加独立 `worker/` 实现，使用 Web API 与 SQLite Durable Object；不再把 Node 的 `node:sqlite` 文件搬到 Worker。静态前端通过精确 CORS 和匿名签名会话请求 Worker，无第三方 Cookie 依赖。生产 Secrets、免费配额、GitHub Actions 变量和上线检查见 [免费部署步骤](docs/FREE-DEPLOYMENT.md)。

本轮通过真实本地 workerd 的并发与重启验证，尚未在你的云端账号发布。当前没有采用完整 Next.js OpenNext 迁移；现有页面可导出，独立代理改动更小。

## 官方图片与动态效果

当前主图通过品牌公开CDN远程加载，访问用户的浏览器需要联网；失效时显示图片不可用提示。源码包不包含官方位图副本。公开发布前应确认品牌图片使用许可，详见 [官方素材记录](docs/OFFICIAL-MEDIA.md)，不能把来源已核实视为开放授权。星河与小派本身由本地代码生成，不依赖外部视频或贴图。

## 发布前验证

- 用 HTTPS 正确域名访问首页、产品详情、来源页、文章及 404。
- 输入一条无私人信息的数码问题，确认返回真实 AI；不要循环跑付费测试。
- 验证 AI 未启用、超时、额度耗尽时，规则问答、产品库、验机清单仍可用。
- 确认 SQLite 跨服务重启保留计数，源码包和静态资源不含密钥。
- 核对每张照片的作者、来源和许可，保留署名与处理说明。
- 确认所有数字示例价仍标明演示，新收录且无现价的产品显示“暂无可靠报价”。

本轮没有创建云端账号、购买服务或执行云端发布。


## 访客体验与维护者验收

本轮保持已部署的公开配额不变：全站 30 次/UTC 日，会话 10 次/日、3 次/分钟，同 IP 20 次/日、6 次/分钟；全站保守预留量 180,000。数值集中在 `wrangler.toml` 的 AI_*_LIMIT 环境变量，服务端缺省解析统一在 `lib/ai/limits.ts`。维护者自行填写配额；本轮没有扩大公开限额。模型调用仍使用 DeepSeek 余额。

问候、闲聊和产品咨询均走模型并正常预留额度；只有 GET/刷新做独立的会话初始化限速。问候跳过产品机型/分数校对，不使用本地问候短路。实际模型调用包括校验未通过、失败、超时的调用，仍保留预留，避免通过失败重试绕过成本上限。前端同步请求锁阻止连点重复发送，Worker 按会话与 requestId 原子去重：同一发送ID重投返回409，不再次调用；主动重问使用新的ID并正常计数。

只有 `AI_DEBUG_QUOTA=true` 且来源为 localhost 时，响应附开发用已用/上限数据；前端只在 development 控制台打印，不在公开页面或生产响应暴露。该调试开关不免额。额度响应使用 `AI_DAILY_QUOTA` 或 `AI_RATE_LIMIT` 结构化码，模型错误不会归类为额度耗尽。

Worker 支持专用 `AI_TEST_SECRET` Secret（随机至少 32 字符）签发的 15 分钟验收凭据，绑定当前匿名会话与站点 origin；测试进入独立 40 次/日、20 次/分钟、2,000,000 预留单位的计数池。授权生成器见 `worker/test-access.ts`，仅在受信的维护者 CLI 中使用，不向网页开放此请求头，不依据前端标志或设备指纹免额。测试池耗尽也停止调用；原访客计数键和 Durable Object 不变。原 Node 代理仍按访客配额计数，不提供该专用通道。

部署新代码与新增测试 Secret 时先 `wrangler versions upload` 暂存版本，再通过 stdin 向 `wrangler versions secret bulk` 添加 Secret，最后只对最终版本执行一次 `wrangler versions deploy <版本ID>@100% --yes`。Secret 不放命令参数、日志、源码 ZIP 或 Git。后续维护者测试可在暂存发布时轮换专用 Secret。

`AI_TIMING_LOGS=true` 输出不含问答正文的耗时日志；`Server-Timing` 区分规则整理、额度预留、上游响应头、模型响应体与安全校验，Pages 入口另附总转发时长。网关时长包含 Worker 时长，不能相加当作串行延迟；上游响应体耗时包含生成与传输，不能当作纯模型计算。浏览器控制台还记录客户端传输/解码或本地规则耗时，不采集用户正文。验收目标同题三次 P50 <8 秒，以实测报告为准，不保证所有访客网络。

首页桌面以放大的 3D 小派为主视觉；窄屏按比例上下布局保留 3D，不遮挡标题或两个入口。普通手机不再因宽度自动改成 2D；节流模式、低资源或 WebGL 失败时保留可手动切换的降级形象。其他页面浮动小派仍优先轻量显示。日夜与头部/胸前交互保留。星空移动端数量为桌面一半；真机不可用时小屏回归仅代表布局与功能验证，触控键盘、发热与实际帧率需真机补验。


## 产品回复局部校对（2026-10-27）

产品回答只对机型身份与本站规则分做资料校对：未知型号仅移除对应句/卡；别名映射为正式ID；已知分数按同条件原规则修正，无对应分数时删去该分数，不编造评分。其余模型正文、Markdown 与自然表达保留。普通正文或元数据缺失可补充本站资料库核价备选，并说明补充来自资料库。报价、库存、来源和诚实标注仍独立处理，不能将模型数字当作已核实的在售报价。

真正空回复、传输超时或截断仍透明降级并给出本地机型。不会自动重试收费调用。问候/闲聊走模型且计入原有额度，跳过产品校对。

开发日志：本地 Node 开发环境设置 `AI_DEBUG_VALIDATION=true` 后运行 `npm run dev`；本地 Worker 在忽略的 `.dev.vars` 中打开同名开关，并将 `ALLOWED_ORIGINS` 设置为本地前端 origin（例如 `http://127.0.0.1:3000`）后联调。每次局部校对失败记录 `[assistant:validation]` 的 `rawReply` 完整原文、`rule`、`fields` 和 `products`。只在显式开启的 localhost 开发来源生效，正式配置为 false，原始模型全文不拼进 API 响应；安全的规则名、字段、机型与原因摘要随当前回答返回，由浏览器保存到诊断页的本机日志。原文可能含对话内容，勿在公网开启或提交开发日志。上线前的旧校验器受控复现日志保存在本机 `.deploy/oct27-before-validation.log`，不进入源码包。


本次真实多轮验收在上游强制 JSON 模式遇到 `finish_reason=stop`、正文为125个空格的响应，属于实际空回复。现统一请求普通 `text` 正文，并从正文匹配机型卡片；仍兼容已有 JSON/Markdown 正文，但不再强制供应商 JSON 模式。输出上限仍为1600、不自动重试。空正文单独提示“模型未返回有效正文”，截断提示“模型回复不完整”，不再误称为机型资料不符。


### 诊断版本与本机校验历史

`/diagnostics/` 的自检版本由构建时自动注入：上海日期 + `diagnostics-2-<GITHUB_SHA前7位>`。非 GitHub 构建使用时间戳作为标识，不需要每次手改页面文案；部署工作流和域名不变。

产品问答发生现有规则删改或校验退回时，API 只返回该次回答的安全校验摘要，不保存服务器对话日志。浏览器在 `elvora.validation-history.v1` 中保留最近50条原问题、实际触发规则/字段/机型、最终正文与推荐卡；刷新保留，支持清空，仅当前浏览器可见。问候、正常未修改回答、额度耗尽、网络失败不计作资料校验失败。旧版本没有记录的历史无法追溯补写。原始模型全文仍只在显式开启的 localhost 开发日志中提供。
