import test from 'node:test';
import assert from 'node:assert/strict';
import { buildContext } from '../lib/ai/context';
import { products, type Product } from '../lib/products';
import { analyzeRecommendations, type Preferences } from '../lib/recommend';
import { parseBudgetChange } from '../lib/companion/budget';
import { localGuide } from '../lib/companion/guide';
import { requestSchema } from '../lib/ai/schema';
import { completeModelReply, safeGuideReply } from '../lib/ai/reply';
const ctx=(message='预算2000买什么手机',history:{role:'user'|'assistant';content:string}[]=[])=>buildContext(requestSchema.parse({message,history}));
const response=(body:unknown)=>({choices:[{finish_reason:'stop',message:{content:JSON.stringify(body)}}]});
test('simple budget query gets concrete reference directions without claiming verified purchase candidates',()=>{
 const c=ctx();assert.equal(c.candidates.length,0);assert.ok(c.advisory.length>0);assert.equal(c.payload.recommendationPolicy.scope,'reference');assert.ok(c.advisory.every(s=>s.budgetVerified===false));assert.match(c.payload.conversation.nextQuestion||'',/用来/);
 const rec={id:c.advisory[0].product.id,reason:c.advisory[0].product.processor,caution:'实际配置与卖家报价待核实'};
 const reply=completeModelReply(response({answer:'预算上限2000元，可以先把'+c.advisory[0].product.name+'列为核价方向。',recommendations:[rec],followUpQuestions:[]}),c,'test-model');
 assert.equal(reply.mode,'ai');assert.equal(reply.recommendationScope,'reference');assert.equal(reply.budgetQualified,false);assert.match(reply.answer,/非实时价格/);assert.match(reply.notice||'',/购买前请核实/);assert.equal(reply.followUpQuestions.length,1);
});
test('new-only and used-only modes never mix; known game and budget survive follow-up',()=>{
 assert.ok(ctx('预算2000元只买全新手机').advisory.every(s=>s.mode==='new'));
 const c=ctx('二手，主要王者荣耀',[{role:'user',content:'预算2000买什么手机'}]);assert.equal(c.memory.budget,2000);assert.equal(c.memory.mode,'used');assert.deepEqual(c.payload.conversation.games,['王者荣耀']);assert.ok(c.advisory.length>0);assert.ok(c.advisory.every(s=>s.mode==='used'));assert.ok(!/全新.*二手/.test(c.payload.conversation.nextQuestion||''));
});
test('unresolved hard constraints and absent price basis do not manufacture recommendations',()=>{
 for(const message of ['预算2000元手机，必须支持解锁刷机','预算2000元手机，存储至少512GB','预算2000元手机，只买苹果'])assert.equal(ctx(message).advisory.length,0,message);
 const c=buildContext(requestSchema.parse({message:'预算2000买什么手机'}),[]);assert.equal(c.advisory.length,0);
 assert.equal(ctx('苹果16什么芯片').advisory.length,0);
});
test('局部处理未知ID和未核实售价/库存，保留模型其他内容及诚实标注',()=>{
 const c=ctx(),id=c.advisory[0].product.id;
 for(const body of [{answer:'这台只要1999元。仍需检查电池。',recommendations:[{id,reason:'处理器参考',caution:'核实配置'}]},{answer:'保证有货而且一定在预算内。仍需检查电池。',recommendations:[{id,reason:'处理器参考',caution:'核实配置'}]},{answer:'参考看看。仍需检查电池。',recommendations:[{id:'fake',reason:'处理器参考',caution:'核实配置'}]}]){
  const result=completeModelReply(response(body),c,'test-model');assert.equal(result.mode,'ai');assert.equal(result.budgetQualified,false);assert.ok(!result.recommendations.some(r=>r.id==='fake'));assert.ok(!result.answer.includes('1999元'));assert.match(result.answer,/仍需检查电池/);assert.match(result.answer,/非实时价格/);
 }
});

test('省略预算和元的自然购买表达仍提取3000；型号、年份、硬件单位不当预算',()=>{
 for(const text of ['想买3000左右的手机','3000左右的手机','买一部3000的手机','3000买手机','选3000元以内的平板']) {
  assert.deepEqual(parseBudgetChange(text),{kind:'absolute',amount:3000},text);
  assert.equal(localGuide(text,{},'/').memory.budget,3000,text);
 }
 for(const text of ['iPhone 15','小米14','2025款手机','想买2025年的手机','想买5000mAh的手机','120Hz手机','3000万像素手机','16GB内存手机','电池3000左右的手机'])assert.notEqual(parseBudgetChange(text).kind,'absolute',text);
 assert.equal(parseBudgetChange('想买2000到3000左右的手机').kind,'unclear');
 const c=ctx('想买3000左右的手机'); assert.equal(c.memory.budget,3000); assert.equal(c.memory.category,'phone');
 assert.equal(c.payload.conversation.questionKey,'use'); assert.ok(!/预算上限.*多少/.test(safeGuideReply(c,'LOCAL_GUIDE').followUpQuestions.join('')));
});
test('线上复现：3000左右手机与问卷日常使用的型号、分数、方式逐一一致',()=>{
 const now=new Date('2026-10-22T10:00:00+08:00');
 const c=buildContext({message:'想买3000左右的手机',history:[],path:'/'},products,now);
 const prefs:Preferences={category:'phone',maxBudget:3000,mode:'either',uses:['日常使用'],primaryUse:'日常使用',brand:'',os:'',storage:0,maxWeight:null,maxScreen:null,reserveBudget:0,purchasePriority:'balanced'};
 const wizard=analyzeRecommendations(prefs,products,now,{pricePolicy:'reference-guidance'});
 assert.deepEqual(c.advisory.map(s=>({id:s.product.id,score:s.score,mode:s.mode})),wizard.recommendations.map(s=>({id:s.product.id,score:s.score,mode:s.offer.mode})));
 assert.equal(c.advisory[0].product.id,'xiaomi-14');
 assert.equal(c.advisory[1].product.id,'iphone-15');
 assert.ok(c.advisory.every(s=>s.basis.includes('基于估算价')&&s.budgetVerified===false));
 assert.deepEqual(c.payload.decisionPreferences?.uses,[]);assert.ok(c.payload.conversation.assumptions.some(a=>a.includes('暂按日常使用')));
 const reply=safeGuideReply(c,'LOCAL_GUIDE'); assert.equal(reply.mode,'guide');assert.equal(reply.model,null);assert.equal(reply.budgetQualified,false);
 assert.deepEqual(reply.recommendations.map(s=>s.id),wizard.recommendations.map(s=>s.product.id));
 for(const phrase of ['Xiaomi 14','iPhone 15','基于估算价','非实时价格','购买前请核实','先按日常使用'])assert.ok(reply.answer.includes(phrase),phrase);
 assert.ok(!reply.answer.includes('缺少满足条件的可靠报价'));assert.match(reply.notice||'',/未调用云端模型/);
});
test('补充用途和二手后，两路径仍一致且不重复问已知预算、方式和用途',()=>{
 const c=ctx('二手，主要日常使用',[{role:'user',content:'想买3000左右的手机'}]);
 assert.equal(c.memory.budget,3000); assert.equal(c.memory.mode,'used');assert.deepEqual(c.payload.decisionPreferences?.uses,['日常使用']);
 const wizard=analyzeRecommendations(c.payload.decisionPreferences!,products,new Date(),{pricePolicy:'reference-guidance'});
 assert.deepEqual(c.advisory.map(s=>[s.product.id,s.score,s.mode]),wizard.recommendations.map(s=>[s.product.id,s.score,s.offer.mode]));
 assert.ok(c.advisory.every(s=>!s.assumedUse));assert.ok(!/预算.*多少|全新.*二手|主要.*什么/.test(safeGuideReply(c).followUpQuestions.join('')));
});
test('低预算使用问卷相同的20%与最近备选策略；仍超预算必须诚实标注',()=>{
 for(const budget of [1400,500,1]) {
  const c=ctx(`预算${budget}元手机，日常使用`),audit=analyzeRecommendations(c.payload.decisionPreferences!,products,new Date(),{pricePolicy:'reference-guidance'});
  assert.deepEqual(c.advisory.map(s=>s.product.id),audit.recommendations.map(s=>s.product.id));
  assert.equal(c.payload.recommendationBudgetContext?.stage,audit.budgetContext?.stage);
  const reply=safeGuideReply(c);assert.match(reply.answer,/已放宽预算条件/); assert.equal(reply.budgetQualified,false);
  for(const s of c.advisory) {assert.ok(s.overBudget>0);const rec=reply.recommendations.find(r=>r.id===s.product.id)!;assert.ok(rec.caution.includes(`超原预算¥${s.overBudget}`));}
 }
});
test('同条件无用途依据或无价格资料时与问卷同为空；真实报价仍可本地接续',()=>{
 const source=products.find(p=>p.id==='iphone-15')!;
 const data:Product[]=[{...source,id:'no-price-fixture'},{...source,useScores:{}}];
 const c=buildContext({message:'想买3000左右的手机',history:[],path:'/'},data);
 assert.equal(c.advisory.length,0);
 const quoted:Product={...source,newPrice:{min:2000,max:2000,demo:false,collectedAt:new Date().toISOString().slice(0,10),source:'受控测试报价'}};
 const verified=buildContext({message:'预算3000元手机日常使用',history:[],path:'/'},[quoted]);
 assert.equal(verified.candidates.length,1);const reply=safeGuideReply(verified);assert.deepEqual(reply.recommendations.map(s=>s.id),[source.id]);assert.equal(reply.recommendationScope,'verified');
});
