import test from 'node:test';
import assert from 'node:assert/strict';
import { buildContext } from '../lib/ai/context';
import { requestSchema } from '../lib/ai/schema';
import { completeModelReply } from '../lib/ai/reply';
const ctx=(message='预算2000买什么手机',history:{role:'user'|'assistant';content:string}[]=[])=>buildContext(requestSchema.parse({message,history}));
const response=(body:unknown)=>({choices:[{finish_reason:'stop',message:{content:JSON.stringify(body)}}]});
test('simple budget query gets concrete reference directions without claiming verified purchase candidates',()=>{
 const c=ctx();assert.equal(c.candidates.length,0);assert.ok(c.advisory.length>0);assert.equal(c.payload.recommendationPolicy.scope,'reference');assert.ok(c.advisory.every(s=>s.budgetVerified===false));assert.match(c.payload.conversation.nextQuestion||'',/用来/);
 const rec={id:c.advisory[0].product.id,reason:c.advisory[0].product.processor,caution:'实际配置与卖家报价待核实'};
 const reply=completeModelReply(response({answer:'预算上限2000元，可以先把'+c.advisory[0].product.name+'列为核价方向。',recommendations:[rec],followUpQuestions:[]}),c,'test-model');
 assert.equal(reply.mode,'ai');assert.equal(reply.recommendationScope,'reference');assert.equal(reply.budgetQualified,false);assert.match(reply.answer,/非实时价格/);assert.match(reply.notice||'',/购买前请核实/);assert.equal(reply.followUpQuestions.length,1);
});
test('new-only and used-only modes never mix; known game and budget survive follow-up',()=>{
 assert.ok(ctx('预算2000元只买全新手机').advisory.every(s=>s.mode==='new'));
 const c=ctx('二手，主要王者荣耀',[{role:'user',content:'预算2000买什么手机'}]);assert.equal(c.memory.budget,2000);assert.equal(c.memory.mode,'used');assert.deepEqual(c.payload.conversation.games,['王者荣耀']);assert.ok(c.advisory.length>0);assert.ok(c.advisory.every(s=>s.mode==='used'));assert.ok(!/全新.*二手/.test(c.payload.conversation.nextQuestion||''));
});
test('unresolved hard constraints, absent price basis and impossible budget do not manufacture recommendations',()=>{
 for(const message of ['预算2000元手机，必须支持解锁刷机','预算2000元手机，存储至少512GB','预算1元手机','预算2000元手机，只买苹果'])assert.equal(ctx(message).advisory.length,0,message);
 const c=buildContext(requestSchema.parse({message:'预算2000买什么手机'}),[]);assert.equal(c.advisory.length,0);
 assert.equal(ctx('苹果16什么芯片').advisory.length,0);
});
test('disclaimer does not permit invented prices, unknown IDs or guaranteed stock',()=>{
 const c=ctx(),id=c.advisory[0].product.id;
 for(const body of [
  {answer:'这台只要1999元，非实时价格，购买前请核实',recommendations:[{id,reason:'处理器参考',caution:'核实配置'}],followUpQuestions:[]},
  {answer:'保证有货而且一定在预算内',recommendations:[{id,reason:'处理器参考',caution:'核实配置'}],followUpQuestions:[]},
  {answer:'参考看看',recommendations:[{id:'fake',reason:'处理器参考',caution:'核实配置'}],followUpQuestions:[]}
 ]){const r=completeModelReply(response(body),c,'test-model');assert.equal(r.mode,'guide');assert.equal(r.budgetQualified,false);assert.ok(!r.recommendations.some(r=>r.id==='fake'));assert.ok(!r.answer.includes('1999元'));}
});
