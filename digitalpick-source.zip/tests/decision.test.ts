import { ruleProducts as products } from './fixtures/rule-products';
import test from 'node:test';
import assert from 'node:assert/strict';
import { type Product } from '../lib/products';
import { analyzeRecommendations, recommend, preferenceHref, type Preferences } from '../lib/recommend';
import { buildContext } from '../lib/ai/context';
import { requestSchema } from '../lib/ai/schema';
import { matchingProduct } from '../lib/ai/product-match';
import { preferencesForTurns } from '../lib/ai/preferences';
import { researchSources, historicalReferences } from '../lib/research';
const now = new Date('2026-10-16T12:00:00+08:00');
const base: Preferences = { category: 'phone', maxBudget: 5000, mode: 'either', uses: ['日常使用'], primaryUse: '日常使用', brand: '', os: '', storage: 0, maxWeight: null, maxScreen: null };
const phone = products.find(p => p.id === 'iphone-15')!;
const verified = (p: Product): Product => ({ ...p, newPrice: p.newPrice && { ...p.newPrice, demo: false, source: '受控测试用有效报价来源' }, usedPrice: p.usedPrice && { ...p.usedPrice, demo: false, source: '受控测试用有效报价来源' } });
test('游戏短板不能由学习和办公的高分补齐', () => {
  const prefs = { ...base, category: 'laptop' as const, maxBudget: 100000, uses: ['游戏', '学习', '日常办公'], primaryUse: '游戏' };
  const audit = analyzeRecommendations(prefs, products, now);
  assert.equal(audit.recommendations.length, 0);
  assert.ok(audit.exclusions.some(e => e.productId === 'macbook-air-m2' && e.code === 'use-shortfall'));
});
test('未知、无效和未核验用途不会被其他高分掩盖', () => {
  for (const grade of [undefined, NaN, Infinity, -1, 6]) {
    const candidate = { ...phone, useScores: { '日常使用': 5, '续航': grade } } as Product;
    const audit = analyzeRecommendations({ ...base, uses: ['日常使用', '续航'] }, [candidate], now);
    assert.equal(audit.recommendations.length, 0); assert.equal(audit.exclusions[0].code, 'use-unverified');
  }
});
test('显式主用途改变排序，所有用途仍必须先过门槛', () => {
  const a = { ...phone, id: 'a', useScores: { '日常使用': 3, '游戏性能': 5 } };
  const b = { ...phone, id: 'b', useScores: { '日常使用': 5, '游戏性能': 3 } };
  const prefs = { ...base, uses: ['日常使用', '游戏性能'] };
  assert.equal(recommend({ ...prefs, primaryUse: '游戏性能' }, [a, b], now)[0].product.id, 'a');
  assert.equal(recommend({ ...prefs, primaryUse: '日常使用' }, [a, b], now)[0].product.id, 'b');
});
test('总预算含用户预留，区间上限与预算边界不被取舍分突破', () => {
  const prefs = { ...base, mode: 'used' as const, maxBudget: 3000, reserveBudget: 500 };
  const result = recommend(prefs, products, now);
  assert.equal(result[0].product.id, 'xiaomi-14'); assert.equal(result[0].offer.totalCeiling, 3000);
  assert.equal(recommend({ ...prefs, reserveBudget: 501 }, products, now).length, 0);
  for (const reserveBudget of [-1, NaN, Infinity, .5, 3000]) assert.equal(recommend({ ...prefs, reserveBudget }, products, now).length, 0);
});
test('两种合格方式都保留，同价优先全新，低价不会默认为二手更适合', () => {
  const candidate = { ...phone, usedPrice: { ...phone.newPrice! } };
  const result = recommend(base, [candidate], now)[0];
  assert.equal(result.offers.length, 2); assert.equal(result.offer.mode, 'new');
  const near = { ...phone, newPrice: { ...phone.newPrice!, min: 3000, max: 3000 }, usedPrice: { ...phone.usedPrice!, min: 2400, max: 2400 } };
  assert.equal(recommend({ ...base, purchasePriority: 'balanced' }, [near], now)[0].offer.mode, 'new');
  assert.equal(recommend({ ...base, purchasePriority: 'price' }, [near], now)[0].offer.mode, 'used');
  assert.equal(recommend({ ...base, mode: 'used' }, [near], now)[0].offer.mode, 'used');
});
test('正式策略拒绝所有演示报价，真实报价仍须满足用途与预算', () => {
  assert.equal(recommend(base, products, now, { pricePolicy: 'verified-only' }).length, 0);
  assert.equal(recommend(base, [verified(phone)], now, { pricePolicy: 'verified-only' }).length, 1);
  assert.equal(recommend({ ...base, maxBudget: 1000 }, [verified(phone)], now, { pricePolicy: 'verified-only' }).length, 0);
});
test('AI候选与相同完整条件的规则引擎一致，不直接取数据库前八款', () => {
  const dataset = products.map(verified);
  const context = buildContext(requestSchema.parse({ message: '预算5000元，手机，日常使用，全新二手都可以' }), dataset, now);
  assert.equal(context.payload.needsRequirementClarification, false);
  const expected = recommend(context.payload.decisionPreferences!, dataset, now, { pricePolicy: 'verified-only' });
  assert.deepEqual(context.candidates.map(p => p.id), expected.map(r => r.product.id));
  assert.equal(buildContext(requestSchema.parse({ message: '预算10000元，电脑，主要玩游戏，也要学习' }), dataset, now).candidates.length, 0);
});
test('未确认用途或无法解析的必要能力，不产生AI候选', () => {
  const dataset = [verified(phone)];
  for (const message of ['预算5000元，手机', '预算5000元，手机日常使用，必须高刷', '预算5000元，手机，AI和刷机']) {
    assert.equal(buildContext(requestSchema.parse({ message }), dataset, now).candidates.length, 0);
  }
  assert.equal(recommend({ ...base, uses: ['AI和系统可玩性'], primaryUse: 'AI和系统可玩性' }, products, now).length, 0);
});
test('预留费用不会覆盖总预算；相对预算不会被重复增加', () => {
  const parsed = preferencesForTurns(['预算5000元，手机日常使用', '预留500元']);
  assert.equal(parsed.preferences?.maxBudget, 5000); assert.equal(parsed.preferences?.reserveBudget, 500);
  const ctx = buildContext(requestSchema.parse({ message: '增加500元', history: [{ role: 'user', content: '预算3000元，手机日常使用' }] }), [verified(phone)], now);
  assert.equal(ctx.memory.budget, 3500); assert.ok(ctx.guide.links[0].href.includes('budget=3500')); assert.ok(!ctx.guide.links[0].href.includes('budget=4000'));
});
test('历史中的未解析降预算不会在下一轮恢复更高旧预算', () => {
  const ctx = buildContext(requestSchema.parse({ message: '主要日常使用', history: [{ role: 'user', content: '预算5000元，手机' }, { role: 'user', content: '预算降低一档' }] }), [verified(phone)], now);
  assert.equal(ctx.memory.budget, undefined); assert.equal(ctx.candidates.length, 0);
});
test('后续增加用途保留原有必要用途，明确否定可移除', () => {
  assert.deepEqual(preferencesForTurns(['预算5000元手机主要游戏', '还要续航']).preferences?.uses, ['游戏性能', '续航']);
  assert.deepEqual(preferencesForTurns(['预算5000元手机主要游戏', '还需要续航']).preferences?.uses, ['游戏性能', '续航']);
  assert.deepEqual(preferencesForTurns(['预算5000元手机主要游戏', '不玩游戏，只要日常使用']).preferences?.uses, ['日常使用']);
  assert.equal(preferencesForTurns(['预算5000元手机主要拍照，也玩游戏']).preferences?.primaryUse, '拍照摄影');
});
test('绝对预算调整覆盖旧预算，重量与屏幕限制不会被误当作金额', () => {
  for (const change of ['最多2000', '预算降到2000']) {
    const context = buildContext(requestSchema.parse({ message: change, history: [{ role: 'user', content: '预算5000元手机日常使用' }] }), [verified(phone)], now);
    assert.equal(context.memory.budget, 2000); assert.equal(context.candidates.length, 0);
    assert.ok(context.guide.links.some(l => l.href.includes('budget=2000')));
  }
  const bounded = preferencesForTurns(['预算5000元手机日常使用', '最多180克', '屏幕最多6.2英寸']);
  assert.equal(bounded.preferences?.maxBudget, 5000); assert.equal(bounded.preferences?.maxWeight, 180); assert.equal(bounded.preferences?.maxScreen, 6.2);
  assert.equal(preferencesForTurns(['预算5000元手机日常使用', '不能超过180克']).preferences?.maxWeight, 180);
});
test('未支持的硬品牌要求先澄清，不偷换成软偏好', () => {
  for (const requirement of ['只买苹果', '不要小米']) {
    const context = buildContext(requestSchema.parse({ message: requirement, history: [{ role: 'user', content: '预算5000元手机日常使用' }] }), [verified(phone)], now);
    assert.equal(context.candidates.length, 0); assert.equal(context.payload.needsRequirementClarification, true);
    assert.ok(context.payload.unresolvedRequirements.includes('hard-brand'));
  }
});
test('问答交接保留已确认的预算、用途、主用途和配置', () => {
  const prefs = { ...base, uses: ['日常使用', '续航'], primaryUse: '续航', reserveBudget: 500, purchasePriority: 'price' as const, storage: 256, maxWeight: 200, maxScreen: 6.5, os: 'iOS' };
  const query = new URL(preferenceHref(prefs), 'https://digitalpick.example').searchParams;
  assert.equal(query.get('budget'), '5000'); assert.equal(query.get('reserve'), '500'); assert.equal(query.get('purchasePriority'), 'price');
  assert.deepEqual(query.getAll('use'), prefs.uses); assert.equal(query.get('primaryUse'), '续航');
  assert.equal(query.get('storage'), '256'); assert.equal(query.get('maxWeight'), '200'); assert.equal(query.get('maxScreen'), '6.5'); assert.equal(query.get('os'), 'iOS');
});
test('XS、XR、标准版与Pro精确区分，未知Pro不回退到标准版页面', () => {
  assert.equal(matchingProduct('iPhone XS 适合吗', '/')?.id, 'iphone-xs');
  assert.equal(matchingProduct('iPhoneXR适合吗', '/')?.id, 'iphone-xr');
  assert.equal(matchingProduct('iPhone 15 Ultra 怎么样', '/products/iphone-15/'), undefined);
  assert.equal(matchingProduct('iPhone 18 Pro 怎么样', '/')?.id, 'iphone-18-pro');
  assert.equal(matchingProduct('这款怎么样', '/products/iphone-15/')?.id, 'iphone-15');
  assert.equal(matchingProduct('iPhone X 对比 iPhone XS', '/'), undefined);
  for (const name of ['iPhone XS Max怎么样', 'vivo X200 Ultra Max怎么样', 'iPhone16e值得买吗']) assert.equal(matchingProduct(name, '/products/iphone-15/'), undefined);
});
test('点赞变更不改变任何分数，Pro社交体验不绑定标准版', () => {
  const before = recommend(base, products, now).map(r => [r.product.id, r.score]);
  const sample = researchSources.find(s => s.engagement)!; const value = sample.engagement!.value;
  try { sample.engagement!.value = 99999999; assert.deepEqual(recommend(base, products, now).map(r => [r.product.id, r.score]), before); }
  finally { sample.engagement!.value = value; }
  assert.ok(!historicalReferences('iphone-15').some(s => s.id.startsWith('S')));
  assert.ok(historicalReferences('iphone-15').every(s => s.access === 'description' && s.configuration === null));
});
test('来源有日期、读取范围与限制，没有声称获得完整视频或实时最高赞', () => {
  assert.equal(researchSources.filter(s => s.platform === 'YouTube').length, 10);
  assert.equal(researchSources.filter(s => s.platform === 'Reddit').length, 6);
  for (const source of researchSources) { assert.ok(new URL(source.url).protocol === 'https:'); assert.ok(source.checkedAt); assert.ok(source.limitations); assert.ok(source.access); }
  assert.equal(researchSources.find(s => s.id === 'X01')?.engagement, null);
});
