import test from 'node:test';
import assert from 'node:assert/strict';
import { createElement } from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import { products, type Product } from '../lib/products';
import { analyzeRecommendations, type Preferences } from '../lib/recommend';
import { planningOffers } from '../lib/recommendation-prices';
import { recommendationText } from '../lib/recommendation-share';
import { RecommendationExclusions, RecommendationOffer } from '../components/recommendation-offer';
const now = new Date('2026-10-20T10:00:00+08:00');
const options = { pricePolicy: 'reference-guidance' as const };
const base: Preferences = { category: 'phone', maxBudget: 10000, mode: 'either', uses: ['日常使用'], brand: '', os: '', storage: 0, maxWeight: null, maxScreen: null };
const phone = products.find(product => product.id === 'iphone-13')!;
test('真实公开数据：手机一万、手机三千、平板一万学习笔记都返回参考推荐', () => {
 for (const preferences of [base, { ...base, maxBudget: 3000 }, { ...base, category: 'tablet' as const, uses: ['学习笔记'] }]) {
  const audit = analyzeRecommendations(preferences, products, now, options);
  assert.ok(audit.recommendations.length > 0 && audit.recommendations.length <= 3);
  assert.equal(audit.budgetContext?.stage, 'original');
  for (const result of audit.recommendations) { assert.equal(result.offer.evidence?.estimated, true); assert.equal(result.offer.price.budgetEligible, false); assert.ok(result.offer.totalCeiling <= preferences.maxBudget); }
 }
 assert.ok(products.every(product => product.newPrice === null && product.usedPrice === null));
});
test('500 元进入最近三款兜底，按总支出差额排序，明确仍超原预算和20%上限', () => {
 const preferences = { ...base, maxBudget: 500 }; const audit = analyzeRecommendations(preferences, products, now, options);
 assert.equal(audit.budgetContext?.stage, 'closest'); assert.equal(audit.budgetContext?.relaxedLimit, 600); assert.match(audit.budgetContext!.message, /已放宽预算条件/); assert.match(audit.budgetContext!.message, /仍超预算/);
 assert.equal(audit.recommendations.length, 3);
 const totals = audit.recommendations.map(result => result.offer.totalCeiling); assert.deepEqual(totals, [...totals].sort((a, b) => a - b)); assert.ok(totals.every(total => total > 600)); assert.equal(preferences.maxBudget, 500);
 assert.ok(audit.recommendations.every(result => result.cautions.some(caution => caution.includes('比原预算高'))));
});
test('原预算无结果时先放宽20%，不会直接进入无限预算最近列表', () => {
 const audit = analyzeRecommendations({ ...base, maxBudget: 1400, mode: 'used' }, products, now, options);
 assert.equal(audit.budgetContext?.stage, 'relaxed'); assert.equal(audit.budgetContext?.relaxedLimit, 1680); assert.ok(audit.recommendations.length);
 for (const result of audit.recommendations) assert.ok(result.offer.totalCeiling > 1400 && result.offer.totalCeiling <= 1680);
});
test('预留费用计入兜底与差额，区间使用上限而非低价引流', () => {
 const audit = analyzeRecommendations({ ...base, maxBudget: 1400, reserveBudget: 200, mode: 'used' }, [phone], now, options);
 assert.equal(audit.budgetContext?.stage, 'closest'); assert.equal(audit.recommendations[0].offer.totalCeiling, 1700); assert.equal(audit.recommendations[0].offer.price.min, 550); assert.equal(audit.recommendations[0].offer.price.max, 1500);
});
test('同方式已有有效报价时不降级套用更便宜的发售参考价', () => {
 const priced: Product = { ...phone, newPrice: { min: 20000, max: 20000, demo: false, source: '受控同配置报价', collectedAt: '2026-10-20' } };
 const audit = analyzeRecommendations({ ...base, maxBudget: 3000, mode: 'new' }, [priced], now, options);
 assert.equal(audit.budgetContext?.stage, 'closest'); assert.equal(audit.recommendations[0].offer.totalCeiling, 20000); assert.equal(audit.recommendations[0].offer.evidence?.estimated, false);
 const within = analyzeRecommendations({ ...base, maxBudget: 25000, mode: 'new' }, [priced], now, options); assert.equal(within.budgetContext?.stage, 'original');
});
test('购买方式和配置限制始终保持，基础容量价格不套给更大存储需求', () => {
 const bigger: Product = { ...phone, storage: 256 };
 assert.equal(planningOffers(bigger, 'new', 256, now).length, 0);
 const audit = analyzeRecommendations({ ...base, maxBudget: 500, os: 'Android' }, [phone], now, options); assert.equal(audit.recommendations.length, 0); assert.match(audit.exclusions[0].reason, /系统为iOS，需要Android/);
 for (const mode of ['new', 'used'] as const) { const result = analyzeRecommendations({ ...base, mode }, [phone], now, options); assert.ok(result.recommendations.length); assert.ok(result.recommendations.every(item => item.offers.every(offer => offer.mode === mode))); }
});
test('无价格或无用途评级仍诚实说明缺口，不伪造评分或套用邻近型号', () => {
 const noPrice = { ...phone, id: 'unknown-price-test' }; const unknownUse = { ...phone, id: 'unknown-use-test', useScores: {} };
 const audit = analyzeRecommendations(base, [noPrice, unknownUse], now, options); assert.equal(audit.recommendations.length, 0); assert.equal(audit.exclusions.length, 2);
 assert.equal(audit.exclusions[0].code, 'price'); assert.match(audit.exclusions[0].reason, /缺少有效报价/); assert.equal(audit.exclusions[1].code, 'use-unverified'); assert.match(audit.exclusions[1].reason, /日常使用/);
 const text = recommendationText({ items: [], preferences: base, budgetContext: audit.budgetContext, gapNotes: audit.exclusions.map(item => item.reason) });
 assert.match(text, /待核实的缺口/); assert.match(text, /缺少有效报价/); assert.match(text, /主要用途：日常使用/);
});
test('每台未选设备都有具体原因，合格但未进前三也列出排序原因', () => {
 const dataset = Array.from({ length: 5 }, (_, i): Product => ({ ...phone, id: `quoted-${i}`, newPrice: { min: 1000 + i * 100, max: 1000 + i * 100, demo: false, source: '受控测试报价', collectedAt: '2026-10-20' } }));
 const audit = analyzeRecommendations({ ...base, mode: 'new' }, dataset, now, options);
 assert.equal(audit.recommendations.length, 3); assert.equal(audit.exclusions.length, 2); assert.ok(audit.exclusions.every(item => item.code === 'ranking' && item.reason.includes('未进入前三')));
 const publicAudit = analyzeRecommendations(base, products, now, options); const ids = new Set([...publicAudit.recommendations.map(item => item.product.id), ...publicAudit.exclusions.map(item => item.productId)]); assert.equal(ids.size, products.filter(product => product.category === 'phone').length);
 assert.ok(publicAudit.exclusions.every(item => item.reason.length > 10));
});
test('未入选清单实际渲染原因正文，估算卡显示来源与具体差额', () => {
 const audit = analyzeRecommendations({ ...base, maxBudget: 500 }, [phone], now, options);
 const html = renderToStaticMarkup(createElement(RecommendationOffer, { offer: audit.recommendations[0].offer, budget: 500 }));
 assert.match(html, /二手折旧模型估算/); assert.match(html, /超出原预算 ¥1,000/); assert.match(html, /无平台成交样本/); assert.match(html, /价格对应配置/);
 const list = renderToStaticMarkup(createElement(RecommendationExclusions, { items: [{ productId: 'sample', name: '测试设备', code: 'configuration', reason: '系统为iOS，需要Android。' }] }));
 assert.match(list, /测试设备/); assert.match(list, /<p>系统为iOS，需要Android。<\/p>/);
});
test('分享最近备选保留放宽状态、估算标签及超预算差额', () => {
 const audit = analyzeRecommendations({ ...base, maxBudget: 500 }, [phone], now, options);
 const text = recommendationText({ items: [{ id: phone.id, configuration: '来源对应128GB配置', pricingNote: '基于估算价；含预留¥1500；超出原预算¥1000' }], preferences: { ...base, maxBudget: 500 }, budgetContext: audit.budgetContext, scope: 'reference' });
 for (const word of ['基于演示数据，购买前请核实', '已放宽预算条件', '仍超预算', '超出原预算¥1000', '基于估算价', '配置：来源对应128GB配置']) assert.ok(text.includes(word));
});
