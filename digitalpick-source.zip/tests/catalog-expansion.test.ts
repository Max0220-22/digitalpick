import test from 'node:test';
import assert from 'node:assert/strict';
import requested from '../data/catalog-expansion/requested-models.json';
import {products,type Product} from '../lib/products';
import {catalogCoverage,expansionRecords,unmatchedCoverage} from '../lib/catalog-expanded';
import {reviewedDevices} from '../lib/library/reviewed';
import {factLabels} from '../lib/library/types';
import {buildContext} from '../lib/ai/context';
import {analyzeRecommendations,type Preferences} from '../lib/recommend';
const context=(message:string,history:{role:'user'|'assistant';content:string}[]=[])=>buildContext({message,history,path:'/'});
test('原清单520项逐一有核验结果，已确认条目都能进入正式产品详情',()=>{
 assert.equal(requested.length,520);assert.equal(catalogCoverage.length,requested.length);assert.deepEqual(unmatchedCoverage,[]);
 for(const entry of catalogCoverage){
  assert.ok(['verified','corrected','unconfirmed'].includes(entry.status));
  if(entry.status!=='unconfirmed'){
   assert.ok(entry.recordIds.length,entry.requestedName);assert.ok(entry.sourceUrls.length,entry.requestedName);
   for(const id of entry.recordIds)assert.ok(products.some(p=>p.id===id||p.catalogRecordIds?.includes(id)),`${entry.requestedName}: ${id}`);
  }
 }
});
test('九个清单品牌均有正式平板，所有类别进入同一产品库而非仅归档',()=>{
 assert.ok(products.length>400);assert.ok(products.filter(p=>p.category==='tablet').length>=80);assert.ok(products.filter(p=>p.category==='laptop').length>=50);
 for(const brand of ['Apple','HUAWEI','Samsung','OPPO','vivo','Xiaomi','OnePlus','iQOO','RedMagic'])assert.ok(products.some(p=>p.category==='tablet'&&p.brand===brand),brand);
 for(const p of products){assert.match(p.id,/^[a-z0-9-]+$/);assert.equal(products.filter(other=>other.id===p.id).length,1,p.id);}
});
test('扩充仅使用官方HTTPS事实，缺失字段不伪造售价、评分或图片',()=>{
 const official=['apple.com','huawei.com','samsung.com','mi.com','oppo.com','vivo.com','vivo.com.cn','iqoo.com','oneplus.com','oneplus.cn','vmall.com','nubia.com','redmagic.gg','redmagic.com','opposhop.cn','samsung.com.cn'];
 assert.equal(new Set(expansionRecords.map(d=>d.id)).size,expansionRecords.length);
 for(const d of expansionRecords){
  const url=new URL(d.sourceUrl);assert.equal(url.protocol,'https:');assert.ok(official.some(domain=>url.hostname===domain||url.hostname.endsWith('.'+domain)),d.sourceUrl);
  for(const [key,value] of Object.entries(d.facts)){assert.ok(key in factLabels,key);assert.ok(value===null||typeof value==='string');}
  assert.ok(!('price' in d));assert.ok(!('image' in d));assert.ok(!('score' in d));
  const p=products.find(p=>p.catalogRecordIds?.includes(d.id));assert.ok(p,d.id);
  if(p.specificationStatus==='partial'){assert.equal(p.newPrice,null);assert.equal(p.usedPrice,null);assert.deepEqual(p.useScores,{});}
 }
});
test('未知数值留空，带硬要求时不能把未知存储/重量/屏幕当成通过',()=>{
 const template:Product={...products[0],id:'unknown-configuration-test',storage:null,weight:null,screenSize:null,useScores:{日常使用:5},newPrice:{min:1000,max:1000,demo:false,source:'测试用可信来源',collectedAt:'2026-10-17'}};
 const base:Preferences={category:'phone',maxBudget:2000,mode:'new',uses:['日常使用'],brand:'',os:'',storage:0,maxWeight:null,maxScreen:null};
 for(const prefs of [{...base,storage:128},{...base,maxWeight:200},{...base,maxScreen:7}]){
  const audit=analyzeRecommendations(prefs,[template],new Date('2026-10-17T12:00:00+08:00'));
  assert.equal(audit.recommendations.length,0);assert.equal(audit.exclusions[0].code,'configuration');
 }
});
test('地区说明中的“勿套用国行”不会把印度参数变成国行，短问继承地区',()=>{
 const india=context('印度版iQOO13什么电池');assert.equal(india.references.length,1);assert.match(india.references[0].region,/^印度/);assert.match(india.references[0].facts.battery!,/6000/);
 const cn=context('国行iQOO13什么电池');assert.ok(cn.references.length);assert.ok(cn.references.every(d=>/^中国大陆|^国行/.test(d.region)));assert.ok(cn.references.every(d=>!/^印度/.test(d.region)));
 const follow=context('续航呢',[{role:'user',content:'印度版iQOO13什么电池'}]);assert.deepEqual(follow.references.map(d=>d.id),india.references.map(d=>d.id));
 const absent=context('美国版iQOO13什么电池');assert.equal(absent.references.length,0);assert.equal(absent.task.intent,'unknown-device');
});
test('正式参数与素材库同步，旧引用ID和产品链接仍可打开',()=>{
 for(const id of ['iphone-15','iphone-x','ipad-air-m2','xiaomi-pad-6','macbook-air-m2','macbook-pro-m3'])assert.ok(products.some(p=>p.id===id),id);
 for(const id of ['iqoo-13-in','oneplus-13-us','ipad-pro-11-m4'])assert.ok(reviewedDevices.some(d=>d.id===id),id);
 assert.equal(new Set(reviewedDevices.map(d=>d.id)).size,reviewedDevices.length);
 assert.ok(reviewedDevices.every(d=>products.some(p=>p.id===d.productId)));
});
