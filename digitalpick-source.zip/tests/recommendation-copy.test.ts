import test from 'node:test';
import assert from 'node:assert/strict';
import { createElement } from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import { analyzeRecommendations, type Preferences } from '../lib/recommend';
import { products } from '../lib/products';
import { RecommendationCautions } from '../components/recommendation-offer';
const now = new Date('2026-10-20T10:00:00+08:00');
const preferences: Preferences = { category: 'phone', maxBudget: 500, mode: 'either', uses: ['日常使用', '续航'], primaryUse: '日常使用', brand: '', os: '', storage: 0, maxWeight: null, maxScreen: null };
const options = { pricePolicy: 'reference-guidance' as const };
const editorial = '适配等级是本站编辑判断，不等于在你的地区、版本和使用场景下完成实测。';
const battery = '续航受网络、信号、系统版本、应用负载和电池状态影响，不等同于不同条件下的屏幕亮起时长。';
test('500 元兜底的三句确认文案逐字正确，差额来自对应卡片总支出', () => {
 const audit = analyzeRecommendations(preferences, products, now, options);
 assert.equal(audit.budgetContext?.stage, 'closest'); assert.ok(audit.recommendations.length);
 for (const result of audit.recommendations) {
  const budget = `按当前核算，此机比原预算高¥${result.offer.totalCeiling - 500}，请先决定是否调整预算，不建议直接下单。`;
  assert.ok(result.cautions.includes(editorial)); assert.ok(result.cautions.includes(battery)); assert.ok(result.cautions.includes(budget));
  const html = renderToStaticMarkup(createElement(RecommendationCautions, { cautions: result.cautions }));
  assert.match(html, /translate="no"/);
  assert.deepEqual([...html.matchAll(/<li>([^<>]*)<\/li>/g)].map(match => match[1]), result.cautions);
 }
});
test('同一需求重复计算及静态渲染 50 次，完整警示文本和顺序保持一致', () => {
 const render = () => analyzeRecommendations(preferences, products, now, options).recommendations.map(result => ({ id: result.product.id, cautions: result.cautions, html: renderToStaticMarkup(createElement(RecommendationCautions, { cautions: result.cautions })) }));
 const expected = render();
 for (let i = 0; i < 50; i++) assert.deepEqual(render(), expected);
});
test('预算内及未选续航的分支不会误报超预算或混入续航文案', () => {
 const audit = analyzeRecommendations({ ...preferences, maxBudget: 3000, uses: ['日常使用'] }, products, now, options);
 assert.ok(audit.recommendations.length);
 for (const result of audit.recommendations) { assert.ok(result.cautions.includes(editorial)); assert.ok(!result.cautions.includes(battery)); assert.ok(!result.cautions.some(text => text.startsWith('按当前核算，此机比原预算高'))); }
});
test('警示渲染保留整句并转义 HTML，不进行 HTML 或字符解码', () => {
 const html = renderToStaticMarkup(createElement(RecommendationCautions, { cautions: ['核对 A&B <测试>，¥500。'] }));
 assert.ok(html.includes('<li>核对 A&amp;B &lt;测试&gt;，¥500。</li>'));
});
