import test from 'node:test';
import assert from 'node:assert/strict';
import { buildContext } from '../lib/ai/context';
import { completeModelReply, safeGuideReply } from '../lib/ai/reply';
import { chatReplyNotice } from '../lib/ai/presentation';
import { products } from '../lib/products';
const history = [{ role: 'user' as const, content: '想买3000左右的手机' }, { role: 'assistant' as const, content: '主要用途是什么？' }];
const ctx = (message: string) => buildContext({ message, history, path: '/' });
const response = (content: unknown, finish_reason='stop') => ({ choices: [{ finish_reason, message: { content: typeof content==='string'?content:JSON.stringify(content) } }] });
test('本轮芯片比较、幻想、知识和闲聊不继承旧预算或进入推荐池',()=>{
 for(const [message,intent] of [['骁龙8 Elite和天玑9400哪个好','component-comparison'],['我想买一台能穿越时空的手机','impossible-request'],['内存和存储有什么区别','knowledge'],['你好','conversation'],['不知道为什么手机发烫','knowledge']] as const){
  const c=ctx(message);assert.equal(c.task.intent,intent);assert.equal(c.task.requiresPrice,false);
  assert.deepEqual(c.candidates,[]);assert.deepEqual(c.advisory,[]);assert.deepEqual(c.payload.constraints,{});assert.deepEqual(c.payload.conversation.known,[]);assert.equal(c.payload.conversation.nextQuestion,null);
  const local=safeGuideReply(c);assert.deepEqual(local.recommendations,[]);assert.ok(!/已记住|3000|Xiaomi 14|iPhone 15/.test(local.answer));
 }
 const chips=safeGuideReply(ctx('骁龙8 Elite和天玑9400哪个好'));assert.match(chips.answer,/Oryon/);assert.match(chips.answer,/Cortex-X925/);assert.match(chips.answer,/Adreno/);assert.match(chips.answer,/Immortalis/);
 const fantasy=safeGuideReply(ctx('我想买一台能穿越时空的手机'));assert.match(fantasy.answer,/目前没有这样的产品/);
});
test('已有可用报价也不能因历史购买条件误入非购买咨询',()=>{
 const source=products.find(p=>p.id==='iphone-15')!;
 const dataset=[{...source,newPrice:{min:2000,max:2000,demo:false,collectedAt:new Date().toISOString().slice(0,10),source:'测试用报价'}}];
 const c=buildContext({message:'骁龙8 Elite和天玑9400哪个好',history:[{role:'user',content:'预算3000元手机日常使用'}],path:'/'},dataset);
 assert.deepEqual(c.candidates,[]);assert.deepEqual(c.payload.candidates,[]);assert.deepEqual(c.advisory,[]);
});
test('非购买问题保留模型正文，无购买ID、普通纯文本或多余推荐字段不触发预算接管',()=>{
 const c=ctx('骁龙8 Elite和天玑9400哪个好');
 for(const body of [
  {answer:'骁龙使用 Oryon，天玑采用 Arm 架构组合，具体体验要看整机散热。'},
  '骁龙使用 Oryon，天玑采用 Arm 架构组合，具体体验要看整机散热。',
  {answer:'先比较 CPU 与 GPU 架构，再看同条件整机测试。',recommendations:[{id:'not-a-purchase-candidate'}]},
 ]){const reply=completeModelReply(response(body),c,'deepseek-flash');assert.equal(reply.mode,'ai');assert.equal(reply.model,'deepseek-flash');assert.deepEqual(reply.recommendations,[]);assert.ok(!reply.answer.includes('3000'));}
});
test('非购买路径不解析半截JSON，不接受虚构金额、任意URL、密钥或隐藏推理',()=>{
 const c=ctx('骁龙8 Elite和天玑9400哪个好');
 for(const body of ['{"answer":"没写完', {answer:'这款只要2999元'}, {answer:'访问 https://evil.example'}, {answer:'sk-'+'x'.repeat(20)}]){
  const reply=completeModelReply(response(body),c,'deepseek-flash');assert.equal(reply.mode,'guide');assert.ok(!/2999元|evil.example|sk-/.test(reply.answer));assert.ok(!/3000|已记住/.test(reply.answer));
 }
 const reasoning={choices:[{finish_reason:'stop',message:{content:'',reasoning_content:'private reasoning'}}]};assert.ok(!completeModelReply(reasoning,c,'deepseek-flash').answer.includes('private reasoning'));
});
test('不可能需求正面回应；购买续问仍提取预算并保留估算方向',()=>{
 const impossible=ctx('我想买一台能穿越时空的手机');
 const accepted=completeModelReply(response({answer:'目前没有这样的产品，穿越时空还是留给科幻电影吧。'}),impossible,'deepseek-flash');assert.equal(accepted.mode,'ai');assert.deepEqual(accepted.recommendations,[]);
 const rejected=completeModelReply(response({answer:'推荐以下几款手机，完美实现穿越。'}),impossible,'deepseek-flash');assert.equal(rejected.mode,'guide');assert.match(rejected.answer,/目前没有/);
 for(const message of ['想买3000左右的手机','二手，主要日常使用','只买苹果'])assert.equal(ctx(message).task.intent,'purchase-advice',message);
 const purchase=ctx('想买3000左右的手机');assert.equal(purchase.memory.budget,3000);assert.deepEqual(purchase.advisory.slice(0,2).map(s=>s.product.id),['xiaomi-14','iphone-15']);assert.match(safeGuideReply(purchase).answer,/基于估算价/);assert.ok(!safeGuideReply(purchase).answer.startsWith('已记住'));
});
test('聊天展示层不渲染服务端内部notice，无论来自旧版或新版接口',()=>{
 const internal='回复模式未通过检查，已按资料库由本地规则接管；没有再次调用模型';
 assert.equal(chatReplyNotice({mode:'ai',notice:internal}),null);
 const guide=chatReplyNotice({mode:'guide',notice:internal})!;assert.match(guide,/本地资料参考/);assert.ok(!/未通过|接管|再次调用/.test(guide));
 const reference=chatReplyNotice({mode:'ai',recommendationScope:'reference',notice:internal})!;assert.match(reference,/非实时价格/);assert.ok(!reference.includes(internal));
});
