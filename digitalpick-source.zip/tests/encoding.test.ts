import test from 'node:test';
import assert from 'node:assert/strict';
import { createElement } from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import { getProduct } from '../lib/products';
import { ProductCard } from '../components/product-card';
import { textEncodingIssue, checkTextEncoding } from '../scripts/check-text-encoding.mjs';
test('UTF-8 guard rejects split multibyte text, BOM and replacement characters',()=>{
 assert.equal(textEncodingIssue(Buffer.from('暂未估算')) ,null);
 assert.equal(textEncodingIssue(Buffer.from([0xe7,0xae])), 'INVALID_UTF8');
 assert.equal(textEncodingIssue(Buffer.from([0xef,0xbb,0xbf,0x61])), 'UTF8_BOM');
 assert.equal(textEncodingIssue(Buffer.from(String.fromCodePoint(0xfffd))), 'REPLACEMENT_CHARACTER');
});
test('REDMI Book 16 2026 card renders the complete unestimated label',()=>{
 const product=getProduct('xiaomi-redmi-book-16-2026')!;assert.equal(product.weight,1860);assert.match(product.processor,/125H/);
 const html=renderToStaticMarkup(createElement(ProductCard,{product}));assert.ok(html.includes('暂未估算'));assert.ok(!html.includes(String.fromCodePoint(0xfffd)));
});
test('published source and content stay strict UTF-8 without BOM',async()=>{assert.ok(await checkTextEncoding()>0);});
