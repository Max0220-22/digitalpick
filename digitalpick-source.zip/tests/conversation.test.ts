import test from 'node:test';
import assert from 'node:assert/strict';
import { preferencesForTurns } from '../lib/ai/preferences';
import { buildContext } from '../lib/ai/context';
import { requestSchema, validateModelReply } from '../lib/ai/schema';
import { completeModelReply } from '../lib/ai/reply';
import { repeatsKnownQuestion } from '../lib/ai/conversation';
import { chatHistory } from '../lib/companion/chat-history';
const history = [{ role: 'user' as const, content: '预算2000，打游戏' }, { role: 'assistant' as const, content: '常玩的游戏是哪一款？' }];
const input = { message: '王者荣耀', history };
const context = () => buildContext(requestSchema.parse(input));
const reply = (answer: string, followUpQuestions: string[] = []) => ({ answer, followUpQuestions, recommendations: [] });
const response = (content: unknown, finish_reason = 'stop') => ({ choices: [{ finish_reason, message: { content: typeof content === 'string' ? content : JSON.stringify(content) } }] });

test('截图回归：王者荣耀承接先前预算与游戏用途，手机方向明确标为假设', () => {
  const ctx = context(), plan = ctx.payload.conversation;
  assert.equal(ctx.memory.budget, 2000); assert.equal(ctx.memory.category, 'phone');
  assert.deepEqual(plan.games, ['王者荣耀']); assert.deepEqual(ctx.payload.decisionPreferences?.uses, ['游戏性能']);
  assert.equal(ctx.payload.needsRequirementClarification, false);
  assert.equal(plan.categoryInferred, true); assert.equal(plan.questionKey, 'mode');
  assert.ok(plan.known.includes('预算上限2000元')); assert.equal(ctx.candidates.length, 0);
  assert.ok(ctx.guide.links.some(l => l.href.includes('budget=2000') && l.href.includes('use=')));
});
test('类型未明确时先问类型；原神不被擅自认定只能用手机', () => {
  const first = buildContext(requestSchema.parse({ message: '预算2000，打游戏' })).payload.conversation;
  assert.equal(first.isGaming, true); assert.equal(first.questionKey, 'category');
  const ambiguous = buildContext(requestSchema.parse({ message: '原神', history: [history[0]] }));
  assert.equal(ambiguous.memory.category, undefined); assert.deepEqual(ambiguous.payload.conversation.games, ['原神']);
  assert.equal(ambiguous.payload.conversation.questionKey, 'category');
});
test('二手、降低预算及类型纠正保留游戏名，不反复问已知条件', () => {
  const state = preferencesForTurns(['预算2000，打游戏', '王者荣耀', '二手', '预算降到1500', '是手机']);
  assert.equal(state.memory.budget, 1500); assert.equal(state.memory.mode, 'used');
  assert.equal(state.categoryInferred, false); assert.deepEqual(state.games, ['王者荣耀']);
  const corrected = preferencesForTurns(['预算2000，打游戏', '王者荣耀', '我指的是平板']);
  assert.equal(corrected.memory.category, 'tablet'); assert.equal(corrected.categoryInferred, false);
  assert.deepEqual(corrected.games, ['王者荣耀']);
});
test('换游戏与否定旧游戏正确更新，不把未验证游戏性能转成实测结论', () => {
  const state = preferencesForTurns(['预算2000元手机玩王者荣耀', '只玩原神，不玩王者了']);
  assert.deepEqual(state.games, ['原神']); assert.deepEqual(state.preferences?.uses, ['游戏性能']);
  assert.deepEqual(preferencesForTurns(['预算2000元手机玩王者荣耀', '不打游戏，只要日常使用']).games, []);
});
test('只允许正文开头复述明确且数值一致的预算，不放开虚构报价', () => {
  for (const answer of ['预算上限2000元，主要玩王者荣耀。', '明白，你的预算是2,000元。继续看取舍。']) {
    assert.equal(validateModelReply(reply(answer), [], { budget: 2000 }).answer, answer);
  }
  for (const answer of ['预算上限3000元，主要打游戏。', '这款手机只要2000元。', '预算上限2000元，手机售价2000元。', '预算上限2000元就能买到新手机。']) {
    assert.throws(() => validateModelReply(reply(answer), [], { budget: 2000 }));
  }
  assert.throws(() => validateModelReply(reply('预算上限2000元，主要打游戏。'), []));
});
test('完整JSON围栏可恢复；正常预算和游戏回答无需再次调用模型', () => {
  const answer = reply('预算上限2000元，主要玩《王者荣耀》。我先按手机看，可纠正。', ['是否接受二手？']);
  const result = completeModelReply(response('```json\n' + JSON.stringify(answer) + '\n```'), context(), 'test-model');
  assert.equal(result.mode, 'ai'); assert.equal(result.answer, answer.answer);
  assert.deepEqual(result.followUpQuestions, ['是否接受二手？']);
});
test('无效JSON、截断、金额及未知ID触发明确本地接续，保留原问题条件', () => {
  for (const body of [
    response('invalid-json'), response(reply('未完成'), 'length'),
    response(reply('这款手机只要999元')), response({ ...reply('推荐'), recommendations: [{ id: 'fake', reason: '好', caution: '注意' }] }),
  ]) {
    const result = completeModelReply(body, context(), 'test-model');
    assert.equal(result.mode, 'guide'); assert.equal(result.model, null); assert.ok(result.notice?.includes('本地规则'));
    assert.ok(result.answer.includes('2000元')); assert.ok(result.answer.includes('王者荣耀'));
    assert.ok(!result.answer.includes('999元')); assert.deepEqual(result.recommendations, []);
    assert.equal(result.followUpQuestions.length, 1); assert.ok(result.followUpQuestions[0].includes('二手'));
  }
});
test('拦住重复问预算/游戏，保留针对游戏要求的正常问题', () => {
  const plan = context().payload.conversation;
  assert.equal(repeatsKnownQuestion('你的预算是多少？', plan), true);
  assert.equal(repeatsKnownQuestion('最常玩的游戏是哪一款？', plan), true);
  assert.equal(repeatsKnownQuestion('《王者荣耀》对手机有什么要求？', plan), false);
  assert.equal(completeModelReply(response(reply('你的预算是多少？')), context(), 'test-model').mode, 'guide');
});
test('一次至多一个后续问题，已知条件不再出现在问题按钮里', () => {
  const result = completeModelReply(response(reply('明白，接着看购买方式。', ['预算多少？', '是否接受二手？', '有偏好品牌吗？'])), context(), 'test-model');
  assert.equal(result.mode, 'ai'); assert.deepEqual(result.followUpQuestions, ['是否接受二手？']);
});
test('验机知识问答先解释，不强迫用户填写预算和品牌', () => {
  const ctx = buildContext(requestSchema.parse({ message: '二手手机怎么验机？' }));
  assert.equal(ctx.payload.conversation.nextQuestion, null);
});
test('历史优先保留七轮真实用户条件，并遵守8条/16KB请求限制', () => {
  const entries: { role: 'user' | 'assistant'; text: string }[] = [];
  for (const text of ['预算2000元手机', '王者荣耀', '二手', '还要拍照', '续航也要', '屏幕不超过6.5英寸']) {
    entries.push({ role: 'user', text }, { role: 'assistant', text: '已经记住。' });
  }
  const packed = chatHistory(entries);
  assert.ok(packed.some(m => m.content === '预算2000元手机')); assert.equal(packed.length, 7);
  assert.equal(packed.filter(m => m.role === 'assistant').length, 1);
  const long = chatHistory(Array.from({ length: 24 }, (_, i) => ({ role: i % 2 ? 'assistant' : 'user', text: '你'.repeat(i % 2 ? 1600 : 800) })));
  assert.ok(long.length <= 8);
  assert.ok(new TextEncoder().encode(JSON.stringify({ message: '你'.repeat(800), history: long, path: '/products/iphone-x/' })).length <= 16000);
});

test('短答可以/不接受承接二手追问，裸数字只在预算提问后解析', () => {
  const user = { role: 'user' as const, content: '预算2000，王者荣耀' };
  const askMode = { role: 'assistant' as const, content: '更倾向全新，还是也接受二手？' };
  assert.equal(buildContext(requestSchema.parse({ message: '可以', history: [user, askMode] })).memory.mode, 'either');
  assert.equal(buildContext(requestSchema.parse({ message: '不接受', history: [user, askMode] })).memory.mode, 'new');
  for (const message of ['不接受二手', '不能接受二手', '二手我不接受', '不想要二手']) assert.equal(buildContext(requestSchema.parse({ message, history: [user, askMode] })).memory.mode, 'new');
  for (const message of ['可以接受二手', '二手也可以', '可以二手']) assert.equal(buildContext(requestSchema.parse({ message, history: [user, askMode] })).memory.mode, 'either');
  assert.equal(buildContext(requestSchema.parse({ message: '2000', history: [{ role: 'assistant', content: '总预算上限是多少？' }] })).memory.budget, 2000);
  assert.equal(buildContext(requestSchema.parse({ message: '120', history: [user, { role: 'assistant', content: '已记录预算。你希望的帧率是多少？' }] })).memory.budget, 2000);
});
test('追问按钮与已解析短答进入后续历史，原始显示文本不被改写', () => {
  const packed = chatHistory([
    { role: 'user', text: '预算2000，王者荣耀' },
    { role: 'assistant', text: '继续确认购买方式。', aiReply: { followUpQuestions: ['是否接受二手？'] } },
    { role: 'user', text: '可以', contextText: '全新二手都可以' },
  ]);
  assert.ok(packed.some(m => m.content.includes('是否接受二手？')));
  assert.equal(packed.at(-1)?.content, '全新二手都可以');
  const ctx = buildContext(requestSchema.parse({ message: '还要拍照', history: packed }));
  assert.equal(ctx.memory.mode, 'either'); assert.equal(ctx.memory.budget, 2000);
});
