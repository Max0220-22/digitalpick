import test from 'node:test';
import assert from 'node:assert/strict';
import { createAssistantHandler } from '../worker/handler';
import { allowedOrigin, hmac, issueSession, verifySession } from '../worker/security';
import { QuotaError, reserve, type Bucket, type QuotaStore } from '../worker/quota';
import type { WorkerEnv } from '../worker/types';
const origin = 'https://example-user.github.io', now = Date.parse('2026-10-16T12:00:00Z');
const secret = 'test-only-session-signature-material-long-enough';
const envBase = { AI_ENABLED: 'true', AI_API_KEY: 'test-api-credential', AI_SESSION_SECRET: secret, ALLOWED_ORIGINS: origin };
function store() {
  const rows = new Map<string, Bucket & { day: string }>();
  return { rows, read: key => rows.get(key), increment: (key, tokens, day) => { const before = rows.get(key); rows.set(key, { calls: (before?.calls || 0) + 1, tokens: (before?.tokens || 0) + tokens, day }); }, prune: day => { for (const [key, row] of rows) if (row.day < day) rows.delete(key); } } satisfies QuotaStore & { rows: typeof rows };
}
function fixture(options: { upstream?: typeof fetch; timeoutMs?: number; env?: Partial<WorkerEnv> } = {}) {
  const quota = store(); let calls = 0;
  const env: WorkerEnv = { ...envBase, ...options.env, AI_QUOTA: { idFromName: name => name, get: () => ({ fetch: async request => {
    try { reserve(quota, await request.json(), env, new Date(now)); return Response.json({ ok: true }); }
    catch (cause) { return cause instanceof QuotaError ? Response.json({ code: cause.code, retryAfter: cause.retryAfter }, { status: 429 }) : new Response(null, { status: 503 }); }
  } }) } };
  const handle = createAssistantHandler({ now: () => now, timeoutMs: options.timeoutMs, fetchImpl: async (input, init) => { calls++; assert.equal(String(input), 'https://api.deepseek.com/chat/completions'); assert.equal(new Headers(init?.headers).get('authorization'), `Bearer ${envBase.AI_API_KEY}`); return options.upstream ? options.upstream(input, init) : modelResponse(); } });
  const request = (method = 'GET', body?: string, extra: HeadersInit = {}) => new Request('https://worker.example/api/assistant/', { method, headers: { origin, 'cf-connecting-ip': '203.0.113.5', ...Object.fromEntries(new Headers(extra)) }, ...(body === undefined ? {} : { body }) });
  const session = async () => { const response = await handle(request(), env); assert.equal(response.status, 200); return (await response.json()).sessionToken as string; };
  const post = async (token: string, body = JSON.stringify({ message: '预算5000元手机日常使用' }), extra: HeadersInit = {}) => handle(request('POST', body, { 'content-type': 'application/json', authorization: `Bearer ${token}`, ...Object.fromEntries(new Headers(extra)) }), env);
  return { env, handle, request, session, post, quota, calls: () => calls };
}
function modelResponse(reply: unknown = { answer: '当前缺少完整可靠报价，请先确认必要用途。', followUpQuestions: ['主要是日常使用还是游戏？'], recommendations: [] }, reason = 'stop') { return Response.json({ choices: [{ finish_reason: reason, message: { content: JSON.stringify(reply) } }] }); }
test('CORS精确匹配来源，拒绝伪装域名、null与通配符', () => {
  assert.equal(allowedOrigin(origin, `${origin}, https://other.example`), origin);
  for (const value of ['https://example-user.github.io.evil.test', 'null', null, 'http://example-user.github.io']) assert.equal(allowedOrigin(value, origin), null);
  assert.equal(allowedOrigin(origin, '*'), null);
});
test('预检允许必要请求头；未知来源和请求头不获得跨域权限', async () => {
  const f = fixture();
  const ok = await f.handle(f.request('OPTIONS', undefined, { 'access-control-request-method': 'POST', 'access-control-request-headers': 'content-type,authorization' }), f.env);
  assert.equal(ok.status, 204); assert.equal(ok.headers.get('access-control-allow-origin'), origin);
  assert.equal(ok.headers.get('access-control-allow-credentials'), null);
  const denied = await f.handle(f.request('GET', undefined, { origin: 'https://evil.example' }), f.env);
  assert.equal(denied.status, 403); assert.equal(denied.headers.get('access-control-allow-origin'), null);
  assert.equal((await f.handle(f.request('OPTIONS', undefined, { 'access-control-request-method': 'POST', 'access-control-request-headers': 'x-bypass' }), f.env)).status, 403);
  assert.equal(f.calls(), 0);
});
test('会话签名拒绝篡改、过期和伪造，不依赖跨站Cookie', async () => {
  const session = await issueSession(secret, now);
  assert.ok(await verifySession(secret, session.token, now));
  for (const token of [`x${session.token}`, session.token.replace(/.$/, 'x'), `${session.token}.extra`]) assert.equal(await verifySession(secret, token, now), null);
  assert.equal(await verifySession(secret, session.token, now + 86400000), null);
  assert.equal(await verifySession('different-secret', session.token, now), null);
});
test('会话状态不返回模型密钥；无效会话先于付费调用被拒绝', async () => {
  const f = fixture(), response = await f.handle(f.request(), f.env), data = await response.json();
  assert.ok(data.sessionToken); assert.equal(response.headers.get('cache-control'), 'no-store');
  assert.ok(!JSON.stringify(data).includes(envBase.AI_API_KEY)); assert.equal(response.headers.get('set-cookie'), null);
  assert.equal((await f.post('forged')).status, 401); assert.equal(f.calls(), 0);
});
test('Worker与原有资料规则共享上下文，演示价仍不能进入正式推荐', async () => {
  const f = fixture({ upstream: async (_url, init) => {
    const request = JSON.parse(String(init?.body)); const data = JSON.parse(request.messages.at(-1).content).data;
    assert.deepEqual(data.candidates, []); assert.ok(data.researchPrinciples.length); assert.equal(request.model, 'deepseek-flash'); assert.equal(request.max_tokens, 1600); assert.deepEqual(request.thinking, { type: 'disabled' }); assert.equal(request.stream, false); return modelResponse();
  } });
  const response = await f.post(await f.session()), data = await response.json();
  assert.equal(response.status, 200); assert.equal(data.mode, 'ai'); assert.ok(data.links.length); assert.equal(f.calls(), 1);
});
test('输入长度、历史条数、错误JSON和流式字节上限均在调用模型前检查', async () => {
  const f = fixture(), token = await f.session();
  for (const body of ['{', JSON.stringify({ message: 'x'.repeat(801) }), JSON.stringify({ message: '手机', history: Array(9).fill({ role: 'user', content: '你好' }) })]) assert.equal((await f.post(token, body)).status, 400);
  assert.equal((await f.post(token, 'x'.repeat(16001))).status, 413);
  assert.equal((await f.post(token, '{}', { 'content-type': 'text/plain' })).status, 415); assert.equal(f.calls(), 0);
});
test('Worker拦截不安全或未完成的回复并明确转本地整理，不重试付费调用', async () => {
  for (const reply of [{ answer: '999元', followUpQuestions: [], recommendations: [] }, { answer: '访问 https://evil.example', followUpQuestions: [], recommendations: [] }, { answer: '推荐', followUpQuestions: [], recommendations: [{ id: 'fake', reason: '好', caution: '注意' }] }]) {
    const f = fixture({ upstream: async () => modelResponse(reply) });
    const response = await f.post(await f.session()), data = await response.json();
    assert.equal(response.status, 200); assert.equal(data.mode, 'guide'); assert.equal(data.model, null);
    assert.ok(data.recommendations.every((rec:{id:string})=>rec.id!=='fake')); assert.equal(data.budgetQualified,false); assert.ok(!data.answer.includes('999元')); assert.ok(!data.answer.includes('evil.example')); assert.equal(f.calls(), 1);
  }
  const incomplete = fixture({ upstream: async () => modelResponse(undefined, 'length') });
  assert.equal((await (await incomplete.post(await incomplete.session())).json()).mode, 'guide'); assert.equal(incomplete.calls(), 1);
});
test('上游鉴权错误不透传响应体或密钥，不自动重试', async () => {
  const f = fixture({ upstream: async () => new Response('private upstream data', { status: 401 }) });
  const response = await f.post(await f.session()); assert.equal(response.status, 502); const text = await response.text();
  assert.ok(!text.includes('private upstream data')); assert.ok(!text.includes(envBase.AI_API_KEY)); assert.equal(f.calls(), 1);
});
test('超时中断上游请求，失败仍保留已预留额度', async () => {
  const f = fixture({ timeoutMs: 10, upstream: async (_url, init) => new Promise((_accept, reject) => init?.signal?.addEventListener('abort', () => reject(new DOMException('Aborted', 'AbortError')), { once: true })) });
  const response = await f.post(await f.session()); assert.equal(response.status, 504); assert.equal(f.calls(), 1); assert.equal(f.quota.read('g:2026-10-16')?.calls, 1);
});
test('全站调用/Token额度无法通过更换会话突破；额度失败不调用模型', async () => {
  const f = fixture({ env: { AI_DAILY_CALL_LIMIT: '2' } });
  assert.equal((await f.post(await f.session())).status, 200); assert.equal((await f.post(await f.session())).status, 200);
  const blocked = await f.post(await f.session()); assert.equal(blocked.status, 429); assert.ok(Number(blocked.headers.get('retry-after')) > 0); assert.equal(f.calls(), 2);
  const tokens = fixture({ env: { AI_DAILY_TOKEN_LIMIT: '1' } }); assert.equal((await tokens.post(await tokens.session())).status, 429); assert.equal(tokens.calls(), 0);
});
test('每会话每分钟和IP每日限额独立生效，刷新会话不绕过IP限额', async () => {
  const f = fixture(), token = await f.session();
  for (let i = 0; i < 3; i++) assert.equal((await f.post(token)).status, 200);
  assert.equal((await f.post(token)).status, 429);
  const ip = fixture({ env: { AI_IP_DAILY_LIMIT: '1' } }); assert.equal((await ip.post(await ip.session())).status, 200); assert.equal((await ip.post(await ip.session())).status, 429); assert.equal(ip.calls(), 1);
});
test('会话创建接口自身限速，错误存储绑定失败时关闭模型调用', async () => {
  const f = fixture(); for (let i = 0; i < 20; i++) assert.equal((await f.handle(f.request(), f.env)).status, 200);
  assert.equal((await f.handle(f.request(), f.env)).status, 429);
  const broken = fixture(); broken.env.AI_QUOTA.get = () => { throw new Error('storage offline'); };
  assert.equal((await broken.handle(broken.request(), broken.env)).status, 503); assert.equal(broken.calls(), 0);
});
test('UTC跨日重置计数并清除旧桶；IP只以每日HMAC摘要进入额度存储', async () => {
  const s = store(), ip = await hmac(secret, 'ip:2026-10-16:203.0.113.5'), user = 'a'.repeat(32), env = fixture().env;
  reserve(s, { kind: 'call', ip, user, tokens: 10 }, { ...env, AI_DAILY_CALL_LIMIT: '1' }, new Date(now));
  assert.throws(() => reserve(s, { kind: 'call', ip, user, tokens: 10 }, { ...env, AI_DAILY_CALL_LIMIT: '1' }, new Date(now)), /GLOBAL_LIMIT/);
  reserve(s, { kind: 'call', ip, user, tokens: 10 }, env, new Date(now + 86400000));
  assert.ok([...s.rows.keys()].every(key => !key.includes('2026-10-16') && !key.includes('203.0.113.5')));
});
test('关闭AI与健康检查不消耗模型额度，基础工具不依赖在线模型', async () => {
  const f = fixture({ env: { AI_ENABLED: 'false' } });
  assert.equal((await (await f.handle(f.request(), f.env)).json()).enabled, false);
  assert.equal((await f.handle(new Request('https://worker.example/health'), f.env)).status, 200);
  assert.equal((await f.post('anything')).status, 503); assert.equal(f.calls(), 0);
});

test('完整两轮代理回归：预算2000打游戏→王者荣耀，可正常复述预算并继续下一问', async () => {
  let turn = 0;
  const f = fixture({ upstream: async (_url, init) => {
    const data = JSON.parse(JSON.parse(String(init?.body)).messages.at(-1).content).data;
    assert.equal(data.constraints.budget, 2000);
    if (++turn === 2) {
      assert.deepEqual(data.conversation.games, ['王者荣耀']);
      assert.equal(data.conversation.questionKey, 'mode');
      return modelResponse({ answer: '预算上限2000元，主要玩《王者荣耀》。先按手机方向核对游戏稳定性与发热，可纠正设备类型。', followUpQuestions: ['是否接受二手？'], recommendations: [] });
    }
    return modelResponse({ answer: '预算上限2000元，主要打游戏，已记住。', followUpQuestions: ['常玩的游戏是哪一款？'], recommendations: [] });
  } });
  const token = await f.session(), question = '预算2000，打游戏';
  const first = await (await f.post(token, JSON.stringify({ message: question }))).json();
  assert.equal(first.mode, 'ai');
  const second = await f.post(token, JSON.stringify({ message: '王者荣耀', history: [{ role: 'user', content: question }, { role: 'assistant', content: first.answer + '\n' + first.followUpQuestions.join(' ') }] }));
  const data = await second.json();
  assert.equal(second.status, 200); assert.equal(data.mode, 'ai'); assert.ok(data.answer.includes('2000元')); assert.ok(data.answer.includes('王者荣耀'));
  assert.equal(data.followUpQuestions.length, 1); assert.equal(f.calls(), 2);
});

test('网络和异常格式仅返回固定诊断码，不泄露异常正文或上游内容', async () => {
  for (const [upstream, code] of [
    [async () => { throw new Error('private credential and request'); }, 'UPSTREAM_CONNECTION'],
    [async () => new Response('<html>private upstream data</html>'), 'UPSTREAM_FORMAT'],
  ] as const) {
    const f = fixture({ upstream });
    const response = await f.post(await f.session()), data = await response.json();
    assert.equal(response.status, 502); assert.equal(data.code, code);
    assert.ok(!JSON.stringify(data).includes('private')); assert.equal(f.calls(), 1);
  }
});

test('上游跳转不跟随，也不把密钥或跳转地址发送给浏览器', async () => {
  const f = fixture({ upstream: async (_url, init) => {
    assert.equal(init?.redirect, 'manual');
    return new Response(null, { status: 302, headers: { location: 'https://untrusted.example/private' } });
  } });
  const response = await f.post(await f.session()), body = await response.text();
  assert.equal(response.status, 502); assert.equal(f.calls(), 1);
  assert.ok(!body.includes('untrusted.example')); assert.ok(!body.includes(envBase.AI_API_KEY));
});


test('线上复现路径：芯片比较与幻想需求确实调用上游一次，不被旧预算接管',async()=>{
 for(const [message,intent,answer] of [
  ['骁龙8 Elite和天玑9400哪个好','component-comparison','骁龙采用 Oryon CPU 和 Adreno GPU，天玑采用 Arm CPU 和 Immortalis GPU；同条件整机测试才可比较实际体验。'],
  ['我想买一台能穿越时空的手机','impossible-request','目前没有这样的产品，时空穿越还是留给电影吧。'],
 ]){
  const f=fixture({upstream:async(_url,init)=>{
   const sent=JSON.parse(String(init?.body)),data=JSON.parse(sent.messages.at(-1).content).data;
   assert.equal(data.task.intent,intent);assert.equal(sent.response_format.type,'text');assert.match(sent.messages[0].content,/只输出自然中文正文/);assert.deepEqual(data.constraints,{});assert.deepEqual(data.candidates,[]);assert.deepEqual(data.referenceSuggestions,[]);
   return Response.json({choices:[{finish_reason:'stop',message:{content:answer}}]});
  }});
  const reply=await(await f.post(await f.session(),JSON.stringify({message,history:[{role:'user',content:'想买3000左右的手机'},{role:'assistant',content:'主要用途是什么？'}]}))).json();
  assert.equal(f.calls(),1);assert.equal(reply.mode,'ai');assert.equal(reply.model,'deepseek-flash');assert.equal(reply.answer,answer);assert.deepEqual(reply.recommendations,[]);assert.equal(reply.notice,undefined);
 }
});
