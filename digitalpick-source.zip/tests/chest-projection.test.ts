import test from 'node:test';
import assert from 'node:assert/strict';
import { Group, Mesh, CylinderGeometry, MeshBasicMaterial, PerspectiveCamera, BoxGeometry } from 'three';
import { createModelPicker } from '../lib/companion/model-hit';
import { createChestProjection } from '../lib/companion/project-target';
function fixture(){
 const model=new Group(),button=new Group(),material=new MeshBasicMaterial();button.position.set(0,-.5,.4);button.userData.companionAction='theme';
 const face=new Mesh(new CylinderGeometry(.217,.217,.06,32),material);face.rotation.x=Math.PI/2;button.add(face);model.add(button);
 const camera=new PerspectiveCamera(41,1,.1,100);camera.position.set(0,0,6);camera.lookAt(0,0,0);camera.updateMatrixWorld();
 const project=createChestProjection(button,camera,createModelPicker(model,camera));
 return {model,button,camera,project,material,dispose(){face.geometry.dispose();material.dispose();}};
}
test('投影仅覆盖胸前圆钮且随模型位移旋转更新，旧位置不能借用整机热区',()=>{
 const f=fixture(),a=f.project(400,400)!;assert.ok(a.width>10&&a.width<60);assert.ok(a.height>10&&a.height<60);
 f.model.position.set(.8,.3,.2);f.model.rotation.y=.2;const b=f.project(400,400)!;assert.ok(b.x>a.x+20);assert.ok(b.y<a.y);assert.ok(b.width<60);
 assert.equal(f.project(0,400),null);f.dispose();
});
test('身体或前景模型表面遮住胸前圆钮时，不能隔着模型生成热点',()=>{
 const f=fixture(),cover=new Mesh(new BoxGeometry(1,1,.1),new MeshBasicMaterial());cover.position.set(0,-.5,.8);f.model.add(cover);assert.equal(f.project(400,400),null);cover.visible=false;assert.ok(f.project(400,400));cover.geometry.dispose();(cover.material as MeshBasicMaterial).dispose();f.dispose();
});
