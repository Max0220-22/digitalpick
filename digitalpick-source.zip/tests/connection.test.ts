import test from 'node:test';
import assert from 'node:assert/strict';
import { createAssistantConnection, type AiConnectionState } from '../lib/companion/connection';
import gateway from '../pages-gateway/public/_worker.js';
const ok = () => Response.json({ enabled: true, model: 'fixture-model', sessionToken: 'fixture-session' });
test('首次网络失败可手动恢复，连接恢复只发GET，不重复模型请求', async () => {
  const changes: AiConnectionState[] = []; let calls = 0;
  const client = createAssistantConnection({ endpoint: 'https://test.example/api/assistant/', remote: true, onChange: s => changes.push(s), fetchImpl: async (_url, init) => {
    calls++; assert.equal(init?.method, undefined); assert.equal(init?.credentials, 'omit');
    if (calls === 1) throw new TypeError('private transport data'); return ok();
  } });
  await client.connect(); assert.equal(changes.at(-1)?.reason, 'network'); assert.ok(!changes.at(-1)?.error?.includes('private'));
  await client.connect(true); assert.equal(changes.at(-1)?.enabled, true); assert.equal(changes.at(-1)?.token, 'fixture-session'); assert.equal(calls, 2); client.dispose();
});
test('弱网超时后可恢复；取消卸载后的请求不回写状态', async () => {
  const changes: AiConnectionState[] = []; let calls = 0;
  const client = createAssistantConnection({ endpoint: 'https://test.example/api/assistant/', remote: true, timeoutMs: 5, onChange: s => changes.push(s), fetchImpl: async (_url, init) => {
    calls++; if (calls > 1) return ok();
    return new Promise((_resolve, reject) => init?.signal?.addEventListener('abort', () => reject(new DOMException('Aborted', 'AbortError')), { once: true }));
  } });
  await client.connect(); assert.equal(changes.at(-1)?.reason, 'timeout');
  await client.connect(true); assert.equal(changes.at(-1)?.enabled, true); client.dispose();
  const states: AiConnectionState[] = [];
  const stopped = createAssistantConnection({ endpoint: 'https://test.example', remote: true, onChange: s => states.push(s), fetchImpl: async () => { await new Promise(r => setTimeout(r, 5)); return ok(); } });
  const pending = stopped.connect(); stopped.dispose(); await pending; assert.equal(states.length, 1);
});
test('重复打开和网络事件合并请求，并遵守自动重连间隔及服务端429等待时间', async () => {
  let calls = 0, now = 100; const changes: AiConnectionState[] = [];
  const client = createAssistantConnection({ endpoint: 'https://test.example', remote: true, now: () => now, onChange: s => changes.push(s), fetchImpl: async () => { calls++; return calls === 1 ? new Response(null, { status: 429, headers: { 'Retry-After': '60' } }) : ok(); } });
  await Promise.all([client.connect(), client.connect(true), client.connect()]); assert.equal(calls, 1); assert.equal(changes.at(-1)?.reason, 'limited');
  await client.connect(true); assert.equal(calls, 1);
  now += 60000; await client.connect(); assert.equal(calls, 2); assert.equal(changes.at(-1)?.enabled, true);
  await client.connect(); assert.equal(calls, 2); client.dispose();
});
test('配置关闭、缺失会话、403与502分别说明原因', async () => {
  for (const [response, reason] of [[Response.json({ enabled: false }), 'disabled'], [Response.json({ enabled: true }), 'invalid'], [new Response(null, { status: 403 }), 'forbidden'], [new Response(null, { status: 502 }), 'network']] as const) {
    const states: AiConnectionState[] = []; const client = createAssistantConnection({ endpoint: 'https://test.example', remote: true, onChange: s => states.push(s), fetchImpl: async () => response });
    await client.connect(); assert.equal(states.at(-1)?.reason, reason); assert.equal(states.at(-1)?.enabled, false); client.dispose();
  }
});
const origin = 'https://max0220-22.github.io';
test('Pages入口通过内部绑定保留用户来源、会话、IP和额度响应，不使用公网fetch', async () => {
  let calls = 0;
  const backend = { fetch: async (request: Request) => { calls++; assert.equal(new URL(request.url).hostname, 'digitalpick.internal'); assert.equal(request.headers.get('origin'), origin); assert.equal(request.headers.get('authorization'), 'Bearer fake-session'); assert.equal(request.headers.get('cf-connecting-ip'), '203.0.113.5'); assert.equal(await request.text(), '{"message":"hello"}'); return new Response('{"error":"limited"}', { status: 429, headers: { 'Retry-After': '60', 'Access-Control-Allow-Origin': origin } }); } };
  const response = await gateway.fetch(new Request('https://gateway.example/api/assistant/?url=https://evil.example', { method: 'POST', headers: { origin, authorization: 'Bearer fake-session', 'cf-connecting-ip': '203.0.113.5' }, body: '{"message":"hello"}' }), { ALLOWED_ORIGIN: origin, AI_BACKEND: backend });
  assert.equal(calls, 1); assert.equal(response.status, 429); assert.equal(response.headers.get('retry-after'), '60'); assert.equal(response.headers.get('access-control-allow-origin'), origin);
});
test('Pages入口拒绝未知来源和任意路径，缺少绑定或异常时关闭调用', async () => {
  let calls = 0; const env = { ALLOWED_ORIGIN: origin, AI_BACKEND: { fetch: async () => { calls++; throw new Error('private backend info'); } } };
  assert.equal((await gateway.fetch(new Request('https://gateway.example/api/assistant/', { headers: { origin: 'https://evil.example' } }), env)).status, 403);
  assert.equal((await gateway.fetch(new Request('https://gateway.example/arbitrary'), env)).status, 404); assert.equal(calls, 0);
  const failed = await gateway.fetch(new Request('https://gateway.example/api/assistant/', { headers: { origin } }), env); assert.equal(failed.status, 503); assert.ok(!(await failed.text()).includes('private'));
  assert.equal((await gateway.fetch(new Request('https://gateway.example/api/assistant/', { headers: { origin } }), { ALLOWED_ORIGIN: origin })).status, 503);
});
