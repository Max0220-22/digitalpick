import test from 'node:test';
import assert from 'node:assert/strict';
import {buildAssistantContext} from '../lib/ai/context';
import {completeModelReply} from '../lib/ai/reply';
import {readValidationHistory,rememberValidationReply,clearValidationHistory,validationHistoryKey,validationHistoryLimit} from '../lib/ai/validation-history';
import {createReleaseVersion} from '../lib/release-version';
const context=()=>buildAssistantContext({message:'预算 3000、主用途打游戏',history:[],path:'/'});
const rawReply=(text:string)=>({choices:[{finish_reason:'stop',message:{content:text}}]});
const repaired=()=>completeModelReply(rawReply('Xiaomi 14（评分999分）可核价。iPhone 99 Ultra很适合游戏。保留这句一般建议。'),context(),'deepseek-flash');
function memoryStorage(){const values=new Map<string,string>();return {getItem:(key:string)=>values.get(key)??null,setItem:(key:string,value:string)=>{values.set(key,value);},removeItem:(key:string)=>{values.delete(key);}};}

test('线上安全校验摘要含未知机型和真实分数差异，不携带模型原始全文',()=>{
 const reply=repaired();assert.equal(reply.mode,'ai');assert.equal(reply.validationReview?.outcome,'adjusted');assert.ok(!reply.answer.includes('iPhone 99 Ultra'));
 const unknown=reply.validationReview!.issues.find(i=>i.rule==='UNKNOWN_MODEL');assert.ok(unknown?.products.includes('iPhone 99 Ultra'));assert.equal(unknown?.category,'model');
 const score=reply.validationReview!.issues.find(i=>i.rule==='SCORE_MISMATCH');assert.match(score!.reason,/999.*91/);assert.ok(score!.fields.includes('answer'));assert.ok(!JSON.stringify(reply.validationReview).includes('保留这句一般建议'));
});
test('价格删改日志说明金额和机型，输出与既有诚实标注保持一致',()=>{
 const reply=completeModelReply(rawReply('Xiaomi 14只要2999元。购买前核实机况。'),context(),'deepseek-flash');
 assert.match(reply.answer,/价格待核实/);const issue=reply.validationReview!.issues.find(i=>i.category==='price');assert.match(issue!.reason,/2999元/);assert.ok(issue!.products.includes('Xiaomi 14'));
});
test('校验退回日志和局部修正分别记录最终实际回复，原问题不使用补全后的问题',()=>{
 const storage=memoryStorage(),reply=repaired(),question='预算 3000、主用途打游戏';
 assert.equal(rememberValidationReply(question,reply,id=>id,storage,new Date('2026-10-30T06:00:00Z')),true);
 const entry=readValidationHistory(storage).entries[0];assert.equal(entry.question,question);assert.equal(entry.time,'2026-10-30T06:00:00.000Z');assert.equal(entry.final.answer,reply.answer);assert.deepEqual(entry.final.recommendations.map(r=>r.id),reply.recommendations.map(r=>r.id));assert.equal(entry.outcome,'adjusted');
 const failed=completeModelReply(rawReply('iPhone 99 Ultra值得买。'),context(),'deepseek-flash');assert.equal(failed.mode,'guide');assert.equal(failed.validationReview?.outcome,'rejected');
 rememberValidationReply('资料库里没有的机型',failed,id=>id,storage);assert.equal(readValidationHistory(storage).entries[0].final.answer,failed.answer);
});
test('正常产品回答、问候、额度或网络降级不伪造校验失败日志',()=>{
 const storage=memoryStorage(),normal=completeModelReply(rawReply('Xiaomi 14可以先核对配置。'),context(),'deepseek-flash');assert.equal(normal.validationReview,undefined);
 const greeting=completeModelReply(rawReply('你好！我是小派。'),buildAssistantContext({message:'你好',history:[],path:'/'}),'deepseek-flash');assert.equal(greeting.validationReview,undefined);
 rememberValidationReply('正常',normal,id=>id,storage);rememberValidationReply('你好',greeting,id=>id,storage);rememberValidationReply('额度不足',{...normal,mode:'guide',fallbackReason:'daily-quota'},id=>id,storage);assert.equal(storage.getItem(validationHistoryKey),null);
});
test('刷新重读保留最近50条，至少20条，按最新在前；可清空本机数据',()=>{
 const storage=memoryStorage(),reply=repaired();for(let i=0;i<57;i++)rememberValidationReply('问题'+i,reply,id=>id,storage,new Date(1793336400000+i));
 const refreshed=readValidationHistory(storage);assert.equal(refreshed.available,true);assert.equal(refreshed.entries.length,validationHistoryLimit);assert.ok(refreshed.entries.length>=20);assert.equal(refreshed.entries[0].question,'问题56');assert.equal(refreshed.entries.at(-1)?.question,'问题7');assert.equal(clearValidationHistory(storage),true);assert.equal(readValidationHistory(storage).entries.length,0);
});
test('存储被禁用、写满或损坏不打断聊天回答，诊断读取报告状态',()=>{
 const broken={getItem:()=>{throw Error('blocked');},setItem:()=>{throw Error('full');},removeItem:()=>{throw Error('blocked');}};
 assert.equal(rememberValidationReply('问题',repaired(),id=>id,broken),false);assert.equal(readValidationHistory(broken).available,false);assert.equal(clearValidationHistory(broken),false);
 const storage=memoryStorage();storage.setItem(validationHistoryKey,'broken-json');assert.equal(readValidationHistory(storage).available,false);storage.setItem(validationHistoryKey,JSON.stringify([{id:'invalid'}]));assert.deepEqual(readValidationHistory(storage).entries,[]);
});
test('自检构建版本自动使用上海日期与当前提交，非CI构建也有唯一时间标识',()=>{
 const sha='1234567'+'0'.repeat(33),a=createReleaseVersion(new Date('2026-10-29T17:00:00Z'),sha),b=createReleaseVersion(new Date('2026-11-01T00:00:00Z'),'abcdef0123456789');assert.deepEqual(a,{date:'2026-10-30',id:'diagnostics-2-1234567'});assert.equal(b.date,'2026-11-01');assert.notEqual(b.id,a.id);assert.notEqual(createReleaseVersion(new Date('2026-10-30T00:00:00Z')).id,createReleaseVersion(new Date('2026-10-30T00:00:01Z')).id);
});
