import test from 'node:test';
import assert from 'node:assert/strict';
import {buildAssistantContext} from '../lib/ai/context';
import {completeModelReply} from '../lib/ai/reply';
import {reviewProductReply} from '../lib/ai/product-review';
import {products} from '../lib/products';
import {validateModelReply} from '../lib/ai/schema';
import type {ValidationDiagnostic} from '../lib/ai/validation-diagnostics';
const ctx=()=>buildAssistantContext({message:'预算 3000 主要打游戏推荐哪款',history:[],path:'/'});
const envelope=(content:unknown)=>({choices:[{finish_reason:'stop',message:{content:typeof content==='string'?content:JSON.stringify(content)}}]});
test('用户原句在线上下文也提供明确披露的手机方向和91分备选',()=>{
 const c=ctx();assert.equal(c.advisory[0].product.id,'xiaomi-14');assert.equal(c.advisory[0].score,91);assert.equal(c.payload.conversation.categoryInferred,true);
});
test('一个未知型号只删对应句/卡，已知机型与一般建议仍是模型回答',()=>{
 const raw={answer:'Xiaomi 14可以先核价。iPhone 99 Ultra适合穿戴。保留这句关于机况的一般建议。',recommendations:[{id:'xiaomi-14',reason:'处理器可核对',caution:'核实机况'},{id:'iphone-99-ultra',name:'iPhone 99 Ultra',reason:'未知',caution:'未知'}]};
 const reply=completeModelReply(envelope(raw),ctx(),'deepseek-flash');assert.equal(reply.mode,'ai');assert.ok(!reply.answer.includes('iPhone 99 Ultra'));assert.match(reply.answer,/保留这句关于机况的一般建议/);assert.deepEqual(reply.recommendations.map(r=>r.id),['xiaomi-14']);assert.equal(reply.reviewAdjusted,true);
});
test('已知型号别名映射到站内ID，未收录变体不会偷换标准版',()=>{
 const accepted=completeModelReply(envelope({answer:'小米14可先核价。',recommendations:[{id:'小米14',reason:'参数参考'}]}),ctx(),'deepseek-flash');assert.equal(accepted.recommendations[0].id,'xiaomi-14');
 const rejected=completeModelReply(envelope({answer:'iPhone 15 Ultra非常好。Xiaomi 14可核价。',recommendations:[{id:'iphone-15-ultra',name:'iPhone 15 Ultra'},{id:'xiaomi-14'}]}),ctx(),'deepseek-flash');assert.ok(!rejected.answer.includes('iPhone 15 Ultra'));assert.deepEqual(rejected.recommendations.map(r=>r.id),['xiaomi-14']);
});
test('错分数按同条件规则局部校对，两款分数互不串用且机型保留',()=>{
 const c=ctx(),raw={answer:'Xiaomi 14（评分999/100），iPhone 15（评分888/100）。其他判断仍需核实。',recommendations:[{id:'xiaomi-14',score:999,reason:'评分999分，处理器参考'},{id:'iphone-15',score:888,reason:'评分888分'}]};
 const reply=completeModelReply(envelope(raw),c,'deepseek-flash');assert.equal(reply.mode,'ai');assert.ok(!/999|888/.test(reply.answer));assert.match(reply.answer,/91\/100/);assert.match(reply.answer,/64\/100/);assert.match(reply.answer,/其他判断仍需核实/);assert.equal(reply.recommendations.length,2);assert.match(reply.recommendations[0].reason,/91\/100/);const single=completeModelReply(envelope({answer:'评分999/100，仍应核实机况。',recommendations:[{id:'xiaomi-14',score:999}]}),c,'deepseek-flash');assert.match(single.answer,/91\/100/);assert.ok(!single.answer.includes('999'));
});
test('Markdown、长字段、普通正文和可恢复信封均不因格式整条失败',()=>{
 for(const content of ['## 先看需求\n- **Xiaomi 14**：可以核价。\n- 电池和维修史仍应检查。',{answer:'Xiaomi 14可先核价。',recommendations:[{id:'xiaomi-14',reason:'完整理由'.repeat(80)}]},'{"answer":"Xiaomi 14可核价。保留正文。","recommendations": broken}']){
  const reply=completeModelReply(envelope(content),ctx(),'deepseek-flash');assert.equal(reply.mode,'ai');assert.ok(reply.recommendations.some(r=>r.id==='xiaomi-14'));assert.equal(reply.fallbackReason,undefined);
 }
});
test('没有可核对规则分时只移除分数，不编造其他机型的分数',()=>{
 const c=ctx(),product=products.find(p=>p.id==='ipad-air-m2')!;
 const reply=completeModelReply(envelope({answer:product.name+'（评分999/100）可查看参数。',recommendations:[{id:product.id,score:999,reason:'评分999分'}]}),c,'deepseek-flash');assert.equal(reply.mode,'ai');assert.ok(!reply.answer.includes('999'));assert.match(reply.answer,/评分尚未核实/);assert.match(reply.recommendations[0].caution,/未确认符合本次预算/);
});
test('资料库中的每个正式名称均可保留，不被通用机型正则误删',()=>{
 const c=ctx();for(const product of products){const value={answer:product.name+'。保留此设备的参数入口。',recommendations:[{id:product.id,reason:'参数入口',caution:'核实配置'}]};const reply=validateModelReply(value,products.map(p=>p.id));const reviewed=reviewProductReply(reply,value,c,JSON.stringify(value));assert.ok(reviewed.reply.answer.includes(product.name),product.id);assert.equal(reviewed.reply.recommendations[0]?.id,product.id);}
});
test('问候跳过产品核对，保留模型正文，不返回本地问候标志',()=>{
 const c=buildAssistantContext({message:'你好',history:[{role:'user',content:'预算3000手机'}],path:'/'}),records:ValidationDiagnostic[]=[];
 const reply=completeModelReply(envelope({answer:'你好！我是小派。',recommendations:[{id:'unknown'}]}),c,'deepseek-flash',{enabled:true,emit:r=>records.push(r)});assert.equal(reply.mode,'ai');assert.equal(reply.model,'deepseek-flash');assert.equal(reply.answer,'你好！我是小派。');assert.deepEqual(reply.recommendations,[]);assert.equal(records.length,0);
});

test('常用三星别名不因缺少Galaxy字样被误删',()=>{const reply=completeModelReply(envelope({answer:'三星S25可以先看参数。',recommendations:[{id:'三星S25',reason:'参数入口'}]}),ctx(),'deepseek-flash');assert.ok(reply.recommendations.some(r=>r.id==='galaxy-s25'));assert.match(reply.answer,/三星S25/);});

test('逗号后的裸分数也校对，不把分钟或帧率当规则分',()=>{const reply=completeModelReply(envelope({answer:'Xiaomi 14，999分。时长120分钟，帧率120fps均不是规则分。'}),ctx(),'deepseek-flash');assert.ok(!reply.answer.includes('999分'));assert.match(reply.answer,/91\/100/);assert.match(reply.answer,/120分钟/);assert.match(reply.answer,/120fps/);});

test('真实上游纯空格样本仍诚实降级，原因是空正文而非产品资料校验',()=>{
 const reply=completeModelReply(envelope(' '.repeat(125)),ctx(),'deepseek-flash');assert.equal(reply.mode,'guide');assert.equal(reply.validationCode,'EMPTY_RESPONSE');assert.equal(reply.fallbackDetail,'empty');assert.equal(reply.recommendations[0].id,'xiaomi-14');
});
