import test from 'node:test';
import assert from 'node:assert/strict';
import {products, type Price} from '../lib/products';
import {pricingFor,productPricing,usedPriceScenario,priceReferenceText} from '../lib/price-reference';
import {eligiblePrices,reliableSavings} from '../lib/prices';
const now=new Date('2026-10-19T12:00:00+08:00');
test('公开产品已移除演示价格，全部型号有价格核对状态',()=>{
 assert.equal(Object.keys(productPricing).length,products.length);
 for(const p of products){assert.equal(p.newPrice,null);assert.equal(p.usedPrice,null);assert.ok(productPricing[p.id]);}
 for(const id of Object.keys(productPricing))assert.ok(products.some(p=>p.id===id),id);
});
test('价格按口径分离，来源HTTPS、金额与日期明确；官网价只来自品牌',()=>{
 const official=['apple.com.cn','huawei.com','vivo.com.cn','opposhop.cn'];
 for(const info of Object.values(productPricing)){
  assert.match(info.checkedAt,/^\d{4}-\d{2}-\d{2}$/);
  for(const [key,kind] of [['launch','launch'],['official','official-current'],['msrp','official-msrp']] as const){
   const q=info[key];if(!q)continue;
   assert.equal(q.kind,kind);assert.ok(Number.isSafeInteger(q.amount)&&q.amount>0);
   const u=new URL(q.sourceUrl);assert.equal(u.protocol,'https:');assert.equal(u.username,'');assert.equal(u.password,'');assert.equal(q.currency,'CNY');assert.ok(q.region&&q.configuration&&q.sourceLabel);
   if(key==='official'){assert.ok(official.some(h=>u.hostname===h||u.hostname.endsWith('.'+h)),q.sourceUrl);assert.equal(info.status,'listed');}
   if(key==='launch')assert.match(q.publishedAt||'',/^\d{4}-\d{2}/);
  }
  if(info.status==='not-listed')assert.equal(info.official,null);
 }
});
test('当前官网价与历史发售价可以不同，不用现价覆盖首发价',()=>{
 const ipad=pricingFor('ipad-air-11-m4');assert.equal(ipad.launch?.amount,4799);assert.equal(ipad.official?.amount,5999);
 const mac=pricingFor('macbook-air-13-m5');assert.equal(mac.launch?.amount,8499);assert.equal(mac.official?.amount,9999);
 const pro=pricingFor('catalog-ipad-pro-13-m5');assert.equal(pro.official?.amount,13299);assert.equal(pro.official?.configuration,'256GB · Wi-Fi · 标准玻璃');
});
test('官方建议价不能被自动改成首发价，已下架配置的旧标价不作官网现价',()=>{
 const x70=products.find(p=>p.name==='vivo X70')!;const d=pricingFor(x70.id);
 assert.equal(d.msrp?.amount,3699);assert.equal(d.launch,null);assert.equal(d.official,null);assert.equal(d.status,'not-listed');assert.equal(usedPriceScenario(x70),null);
});
test('二手估算显示公式与无样本限制，官网列售或折叠设备不套普通模型',()=>{
 const p=products.find(p=>p.id==='iphone-13')!;const e=usedPriceScenario(p)!;
 assert.ok(e);assert.equal(e.marketSampleCount,0);assert.equal(e.budgetEligible,false);assert.equal(e.confidence,'low');assert.equal(e.anchor.amount,5999);assert.ok(e.min<=e.max);assert.equal(e.min%50,0);assert.equal(e.max%50,0);
 assert.equal(usedPriceScenario(products.find(p=>p.id==='iphone-16')!),null);
 assert.equal(usedPriceScenario({...p,name:'Galaxy Z Fold3'}),null);
 assert.equal(usedPriceScenario(p,'2020-10-19'),null);
});
test('历史、建议价、估算、异币种或仅起价参考均不能进入预算或真实差价',()=>{
 const template:Price={min:1000,max:1200,demo:false,source:'https://www.apple.com.cn/',collectedAt:'2026-10-19'};
 for(const price of [{...template,kind:'launch'},{...template,kind:'estimate'},{...template,kind:'msrp'},{...template,currency:'USD'},{...template,budgetEligible:false}] as Price[]){
  const p={...products[0],newPrice:price,usedPrice:price};assert.deepEqual(eligiblePrices(p,'either',2000,now),[]);assert.equal(reliableSavings(p,now),null);
 }
});
test('起售价、具体配置价具有不同的展示口径',()=>{
 const d=pricingFor('iphone-16').official!;assert.match(priceReferenceText(d),/起$/);assert.ok(!priceReferenceText({...d,scope:'configuration'}).endsWith('起'));
});
