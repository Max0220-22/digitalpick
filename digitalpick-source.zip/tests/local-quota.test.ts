import test from 'node:test';
import assert from 'node:assert/strict';
import { localQuotaReply } from '../lib/ai/local-fallback';
import { quotaFallback } from '../lib/companion/quota-fallback';
import { chatReplyNotice } from '../lib/ai/presentation';
import { analyzeRecommendations, type Preferences } from '../lib/recommend';
import { products } from '../lib/products';
const input=(message:string,history:{role:'user'|'assistant';content:string}[]=[])=>({message,history,path:'/'});
const prefs:Preferences={category:'phone',maxBudget:3000,mode:'either',uses:['游戏性能','续航'],primaryUse:'游戏性能',brand:'',os:'',storage:0,maxWeight:null,maxScreen:null};
test('仅429进入额度降级；区分每日与短期限额，遵守Retry-After且不影响正常200',()=>{
 assert.equal(quotaFallback(200,undefined,null),null);assert.equal(quotaFallback(502,'上游繁忙',null),null);
 assert.deepEqual(quotaFallback(429,'今日 AI 体验额度已用完','3600',1000),{reason:'daily-quota',until:3601000});
 assert.deepEqual(quotaFallback(429,'对话过于频繁或已达今日限额，请稍后再聊。','60',1000),{reason:'limited',until:61000});
 assert.equal(quotaFallback(429,'限额','999999999',1000)!.until,86401000);
});
test('额度用尽连续四条：评分、对比、预算和无关请求均有对应本地内容',()=>{
 const questions=['为什么问卷推Xiaomi 14','Xiaomi 14和iPhone 15选哪个','想买3000左右的手机','帮我写个请假条'];
 const replies=questions.map(question=>localQuotaReply(input(question),'daily-quota'));
 for(const reply of replies){assert.equal(reply.mode,'guide');assert.equal(reply.model,null);assert.equal(reply.fallbackReason,'daily-quota');assert.ok(reply.answer.length>30);assert.match(chatReplyNotice(reply)!,/今日在线顾问额度已用完/);assert.ok(!reply.answer.includes('回复模式未通过'));}
 for(const label of ['用途匹配','总预算余量','购买取舍','品牌偏好','配置要求'])assert.ok(replies[0].answer.includes(label));
 assert.match(replies[0].answer,/演示同一套规则/);assert.match(replies[0].answer,/不代表你当时的得分/);
 for(const label of ['Xiaomi 14','iPhone 15','芯片','屏幕','电池','重量','价格口径','更倾向','非|估算|参考'])assert.match(replies[1].answer,new RegExp(label));
 assert.equal(replies[2].recommendations[0].id,'xiaomi-14');assert.equal(replies[2].recommendations[1].id,'iphone-15');assert.match(replies[2].answer,/基于估算价/);
 assert.match(replies[3].answer,/暂时不能处理/);assert.match(replies[3].answer,/小派/);assert.deepEqual(replies[3].recommendations,[]);
});
test('解释复用同条件问卷原始五项分数，主游戏次续航仍由Xiaomi14领先',()=>{
 const audit=analyzeRecommendations(prefs,products,new Date(),{pricePolicy:'reference-guidance'});assert.equal(audit.recommendations[0].product.id,'xiaomi-14');
 const result=audit.recommendations[0], history=[{role:'user' as const,content:'预算3000元手机，主要游戏性能，也很在意续航，全新二手都可以'}];
 const reply=localQuotaReply(input('为什么问卷推Xiaomi 14',history),'daily-quota');
 assert.ok(reply.answer.includes(`${result.score}/100`));
 for(const item of result.breakdown)assert.ok(reply.answer.includes(`${item.label}：${item.score}/${item.max}。${item.reason}`),item.label);
 assert.ok(!reply.answer.includes('演示同一套规则'));
});
test('对比短问承接上一组机型，不变成预算推荐；未知变体不能偷换',()=>{
 const reply=localQuotaReply(input('那选哪个',[{role:'user',content:'Xiaomi 14和iPhone 15选哪个'}]),'limited');assert.match(reply.answer,/Xiaomi 14/);assert.match(reply.answer,/iPhone 15/);assert.deepEqual(reply.recommendations,[]);
 const missing=localQuotaReply(input('iPhone 15 Ultra和Xiaomi 14选哪个'),'limited');assert.match(missing.answer,/只识别到一款|完整型号/);assert.ok(!missing.answer.includes('iPhone 15：'));
});
test('未解析预算与硬要求不伪造问卷五项分数或原条件入选结论',()=>{
 const reply=localQuotaReply(input('为什么问卷推Xiaomi 14',[{role:'user',content:'预算两千五手机，必须支持解锁刷机'}]),'daily-quota');assert.match(reply.answer,/不能伪造分数/);assert.ok(!/用途匹配：\d/.test(reply.answer));
});

test('降级推荐后问那两款时承接上一条推荐，已知预算始终明确展示',()=>{
 const first=localQuotaReply(input('想买3000左右的手机'),'daily-quota');
 const history=[{role:'user' as const,content:'想买3000左右的手机'},{role:'assistant' as const,content:first.answer}];
 const reply=localQuotaReply(input('那两款选哪个',history),'daily-quota');
 assert.match(reply.answer,/Xiaomi 14/);assert.match(reply.answer,/iPhone 15/);
 assert.match(reply.answer,/预算3000元/);assert.match(reply.answer,/已知条件/);
 assert.ok(!reply.answer.includes('未拿到完整的条件'));
 assert.deepEqual(reply.recommendations,[]);
});
test('降级对比沿用非默认预算、品类、游戏续航与二手要求，后续调整预算覆盖旧值',()=>{
 const history=[{role:'user' as const,content:'预算2600元手机，主要游戏性能，也很在意续航，只考虑二手'},{role:'assistant' as const,content:'可以先核价：Xiaomi 14；iPhone 15。非实时价格，购买前请核实。'}];
 const reply=localQuotaReply(input('那两款选哪个',history),'limited');
 for(const text of ['预算2600元','手机','游戏性能','续航','只考虑二手'])assert.ok(reply.answer.includes(text),text);
 assert.ok(!reply.answer.includes('补用'));
 const changed=localQuotaReply(input('预算改为4000元，那两款选哪个',history),'limited');
 assert.match(changed.answer,/预算4000元/);assert.ok(!changed.answer.includes('预算2600元'));
});
test('只继承回复中的设备名称，不把助手演示条件当作用户预算或用途',()=>{
 const history=[{role:'user' as const,content:'想买2800左右的手机'},{role:'assistant' as const,content:'预算8000元，只考虑全新，以视频剪辑为主。Xiaomi 14和iPhone 15可以对比。'}];
 const reply=localQuotaReply(input('那两款选哪个',history),'limited');
 assert.match(reply.answer,/预算2800元/);assert.ok(!reply.answer.includes('预算8000元'));assert.ok(!reply.answer.includes('以视频剪辑为主'));
});
test('纯问候友好介绍且不复读预算，混合无关请求仍保持数码边界',()=>{
 for(const message of ['你好','你好，小派！','小派你好','您好','嗨','哈喽','早上好','hello','Hi!']){
  const reply=localQuotaReply(input(message,[{role:'user',content:'想买3000左右的手机'}]),'daily-quota');
  assert.match(reply.answer,/我是小派/);assert.ok(!reply.answer.includes('暂时不能处理'),message);assert.ok(!reply.answer.includes('预算3000'));
  assert.deepEqual(reply.recommendations,[]);assert.equal(reply.fallbackReason,'daily-quota');
 }
 assert.match(localQuotaReply(input('你好，帮我写个请假条'),'daily-quota').answer,/暂时不能处理/);
});

test('三类降级提示准确且均提供预算游戏需求的具体机型',()=>{
 const notices:string[]=[];
 for(const reason of ['daily-quota','model-failure','other'] as const){
  const reply=localQuotaReply(input('预算 3000 主要打游戏推荐哪款'),reason);
  const notice=chatReplyNotice(reply)!;notices.push(notice);
  assert.match(notice,/已切换为本地整理/);assert.match(notice,/本地资料参考，非模型回答/);
  assert.ok(reply.recommendations.length>=1&&reply.recommendations.length<=3);
  assert.equal(reply.recommendations[0].id,'xiaomi-14');assert.match(reply.answer,/Xiaomi 14/);assert.match(reply.answer,/先按手机方向/);assert.match(reply.answer,/基于估算价/);
 }
 assert.equal(new Set(notices).size,3);assert.match(notices[0],/额度已用完/);assert.match(notices[1],/模型调用失败/);assert.match(notices[2],/当前不可用/);
});
test('上游错误不是额度耗尽；结构化错误码优先于文案关键词',()=>{
 assert.equal(quotaFallback(502,'今日额度已用完',null),null);
 assert.equal(quotaFallback(429,'任意旧文案','60',1000,'AI_RATE_LIMIT')!.reason,'limited');
 assert.equal(quotaFallback(429,'无中文关键词','60',1000,'AI_DAILY_QUOTA')!.reason,'daily-quota');
 const reply=localQuotaReply(input('想买3000左右的手机'),'model-failure');
 assert.ok(!chatReplyNotice(reply)!.includes('额度'));
});
