import test from 'node:test';
import assert from 'node:assert/strict';
import { localQuotaReply } from '../lib/ai/local-fallback';
import { quotaFallback } from '../lib/companion/quota-fallback';
import { chatReplyNotice } from '../lib/ai/presentation';
import { analyzeRecommendations, type Preferences } from '../lib/recommend';
import { products } from '../lib/products';
const input=(message:string,history:{role:'user'|'assistant';content:string}[]=[])=>({message,history,path:'/'});
const prefs:Preferences={category:'phone',maxBudget:3000,mode:'either',uses:['游戏性能','续航'],primaryUse:'游戏性能',brand:'',os:'',storage:0,maxWeight:null,maxScreen:null};
test('仅429进入额度降级；区分每日与短期限额，遵守Retry-After且不影响正常200',()=>{
 assert.equal(quotaFallback(200,undefined,null),null);assert.equal(quotaFallback(502,'上游繁忙',null),null);
 assert.deepEqual(quotaFallback(429,'今日 AI 体验额度已用完','3600',1000),{reason:'daily-quota',until:3601000});
 assert.deepEqual(quotaFallback(429,'对话过于频繁或已达今日限额，请稍后再聊。','60',1000),{reason:'limited',until:61000});
 assert.equal(quotaFallback(429,'限额','999999999',1000)!.until,86401000);
});
test('额度用尽连续四条：评分、对比、预算和无关请求均有对应本地内容',()=>{
 const questions=['为什么问卷推Xiaomi 14','Xiaomi 14和iPhone 15选哪个','想买3000左右的手机','帮我写个请假条'];
 const replies=questions.map(question=>localQuotaReply(input(question),'daily-quota'));
 for(const reply of replies){assert.equal(reply.mode,'guide');assert.equal(reply.model,null);assert.equal(reply.fallbackReason,'daily-quota');assert.ok(reply.answer.length>30);assert.match(chatReplyNotice(reply)!,/AI 额度今天用完了/);assert.ok(!reply.answer.includes('回复模式未通过'));}
 for(const label of ['用途匹配','总预算余量','购买取舍','品牌偏好','配置要求'])assert.ok(replies[0].answer.includes(label));
 assert.match(replies[0].answer,/演示同一套规则/);assert.match(replies[0].answer,/不代表你当时的得分/);
 for(const label of ['Xiaomi 14','iPhone 15','芯片','屏幕','电池','重量','价格口径','更倾向','非|估算|参考'])assert.match(replies[1].answer,new RegExp(label));
 assert.equal(replies[2].recommendations[0].id,'xiaomi-14');assert.equal(replies[2].recommendations[1].id,'iphone-15');assert.match(replies[2].answer,/基于估算价/);
 assert.match(replies[3].answer,/暂时不能处理/);assert.match(replies[3].answer,/小派/);assert.deepEqual(replies[3].recommendations,[]);
});
test('解释复用同条件问卷原始五项分数，主游戏次续航仍由Xiaomi14领先',()=>{
 const audit=analyzeRecommendations(prefs,products,new Date(),{pricePolicy:'reference-guidance'});assert.equal(audit.recommendations[0].product.id,'xiaomi-14');
 const result=audit.recommendations[0], history=[{role:'user' as const,content:'预算3000元手机，主要游戏性能，也很在意续航，全新二手都可以'}];
 const reply=localQuotaReply(input('为什么问卷推Xiaomi 14',history),'daily-quota');
 assert.ok(reply.answer.includes(`${result.score}/100`));
 for(const item of result.breakdown)assert.ok(reply.answer.includes(`${item.label}：${item.score}/${item.max}。${item.reason}`),item.label);
 assert.ok(!reply.answer.includes('演示同一套规则'));
});
test('对比短问承接上一组机型，不变成预算推荐；未知变体不能偷换',()=>{
 const reply=localQuotaReply(input('那选哪个',[{role:'user',content:'Xiaomi 14和iPhone 15选哪个'}]),'limited');assert.match(reply.answer,/Xiaomi 14/);assert.match(reply.answer,/iPhone 15/);assert.deepEqual(reply.recommendations,[]);
 const missing=localQuotaReply(input('iPhone 15 Ultra和Xiaomi 14选哪个'),'limited');assert.match(missing.answer,/只识别到一款|完整型号/);assert.ok(!missing.answer.includes('iPhone 15：'));
});
test('未解析预算与硬要求不伪造问卷五项分数或原条件入选结论',()=>{
 const reply=localQuotaReply(input('为什么问卷推Xiaomi 14',[{role:'user',content:'预算两千五手机，必须支持解锁刷机'}]),'daily-quota');assert.match(reply.answer,/不能伪造分数/);assert.ok(!/用途匹配：\d/.test(reply.answer));
});
