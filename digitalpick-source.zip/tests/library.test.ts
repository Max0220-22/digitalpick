import test from 'node:test';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFileSync } from 'node:fs';
import archive from '../lib/library/archive.json';
import report from '../lib/library/import-report.json';
import { reviewedDevices } from '../lib/library/reviewed';
import { libraryDevices } from '../lib/library/catalog';
import { factLabels, type LibraryDevice } from '../lib/library/types';
import { retrieveDeviceReferences, referencePayload, normalizedDeviceName } from '../lib/ai/retrieval';
import { buildContext } from '../lib/ai/context';
import { requestSchema } from '../lib/ai/schema';
import { parseBudgetChange } from '../lib/companion/budget';
import { completeModelReply } from '../lib/ai/reply';
const ctx=(message:string,history:{role:'user'|'assistant';content:string}[]=[],path='/')=>buildContext(requestSchema.parse({message,history,path}));

test('素材导入可追溯且严格隔离价格、图片、评分与未知年份',()=>{
 assert.equal(archive.length,report.pendingConfigurations); assert.equal(archive.filter(d=>d.category==='laptop').length,992);
 assert.equal(new Set(libraryDevices.map(d=>d.id)).size,libraryDevices.length);
 for(const d of libraryDevices) {
  assert.ok(d.name&&d.brand); assert.match(d.id,/^[a-z0-9-]+$/); assert.equal(new URL(d.sourceUrl).protocol,'https:');
  assert.ok(['reviewed','pending'].includes(d.review));
  for(const [key,value] of Object.entries(d.facts)) { assert.ok(key in factLabels,key); assert.ok(value===null||typeof value==='string'); assert.ok(!/price|rating|image|score/i.test(key)); }
 }
 assert.ok(archive.every(d=>d.review==='pending')); assert.ok(archive.filter(d=>d.category==='laptop').every(d=>d.year===null));
 assert.ok(archive.some(d=>d.notes.some((n:string)=>n.includes('来源冲突')))); assert.equal(report.completeCoverage,false);
 for(const [name,hash] of Object.entries(report.snapshotSha256)) assert.equal(createHash('sha256').update(readFileSync(new URL('../data/library-sources/'+name,import.meta.url))).digest('hex'),hash);
});
test('简单中文型号直接找到官方芯片，不引用公开数据集的错误iPhone16参数',()=>{
 const c=ctx('苹果16什么芯片'); assert.equal(c.task.intent,'device-question'); assert.equal(c.references.length,1);
 assert.match(c.references[0].facts.processor!,/A18/); assert.ok(!JSON.stringify(c.payload.referenceContext).includes('A17 Bionic'));
 assert.equal(c.payload.conversation.nextQuestion,null); assert.deepEqual(c.candidates,[]);
 assert.ok(c.links.some(l=>l.href.startsWith('/library/?device=')));
});
test('对比的简写和续航短答承接两台设备，不重新索要预算',()=>{
 const first=ctx('苹果16和15哪个好'); assert.equal(first.task.intent,'comparison'); assert.deepEqual(first.references.map(d=>d.name),['iPhone 16','iPhone 15']);
 const second=ctx('续航呢',[{role:'user',content:'苹果16和15哪个好'},{role:'assistant',content:'先看你更在意的取舍。'}]);
 assert.equal(second.task.intent,'comparison'); assert.equal(second.references.length,2); assert.equal(second.payload.referenceContext.inheritedFromUserHistory,true); assert.equal(second.payload.conversation.nextQuestion,null);
});
test('新型号覆盖旧设备，未知Pro与Ultra不能偷换成标准版',()=>{
 const history=[{role:'user' as const,content:'苹果16什么芯片'}];
 const other=ctx('那小米15呢',history); assert.deepEqual(other.references.map(d=>d.name),['Xiaomi 15']);
 const unknown=ctx('iPhone 16 Ultra怎么样',history); assert.equal(unknown.references.length,0); assert.equal(unknown.task.intent,'unknown-device');
 const pending=ctx('续航呢',[{role:'user' as const,content:'iPhone 16 Ultra怎么样'},...history].reverse()); assert.equal(pending.references.length,0);
});
test('手机、平板、笔记本别名与地区版本、容量绑定保持精确',()=>{
 for(const [q,expected] of [['印度版iQOO13能玩原神吗','iQOO 13'],['菲律宾版小米平板7什么处理器','Xiaomi Pad 7'],['新加坡版三星S26Ultra参数','Samsung Galaxy S26 Ultra'],['iPad Air M4内存多少','iPad Air 11 英寸 (M4)'],['MacBook Air 13 M5适合学习吗','MacBook Air 13 英寸 (M5)']]) {
  const c=ctx(q); assert.equal(normalizedDeviceName(c.references[0]?.name||'').replace(/^samsung/,''),normalizedDeviceName(expected).replace(/^samsung/,'')); assert.equal(c.payload.conversation.nextQuestion,null);
 }
 assert.match(ctx('印度版iQOO13什么电池').references[0].facts.battery!,/6000mAh/);
 assert.match(ctx('印度版iQOO13什么电池').references[0].region,/印度/);
 const pro=reviewedDevices.find(d=>d.id==='ipad-pro-11-m4')!; assert.match(pro.facts.ram!,/256\/512GB(?:：|配)8GB/); assert.match(pro.facts.ram!,/1\/2TB(?:：|配)16GB/);
});
test('待核验条目即使命名完全匹配，也无法进入AI事实检索',()=>{
 const fake={...reviewedDevices[0],review:'pending',name:'iPhone 16',facts:{processor:'UNTRUSTED-PROCESSOR'}} as LibraryDevice;
 assert.equal(retrieveDeviceReferences({message:'iPhone16芯片',history:[],path:'/'},[fake]).devices.length,0);
 assert.equal(referencePayload([fake]).length,0);
 assert.ok(JSON.stringify(ctx('iPhone16芯片').payload).length<16000);
});
test('库内参数页可直接承接“这款”；概念问答不强迫填预算',()=>{
 const c=ctx('这款什么芯片',[],'/library/?device=iqoo-13-in'); assert.equal(c.references[0]?.name,'iQOO 13');
 const knowledge=ctx('内存和存储有什么区别'); assert.equal(knowledge.task.intent,'knowledge'); assert.equal(knowledge.payload.conversation.nextQuestion,null);
 const changed=ctx('换个问题，笔记本怎么选',[{role:'user',content:'iPhone16怎么样'}]); assert.equal(changed.references.length,0);
});
test('模型格式失败后按本轮官方参数接续，仍明确标为本地而不是假AI',()=>{
 const result=completeModelReply({choices:[]},ctx('苹果16什么芯片'),'test-model');
 assert.equal(result.mode,'guide'); assert.equal(result.model,null); assert.match(result.answer,/A18/); assert.ok(!result.answer.includes('预算上限'));
 assert.match(result.notice!,/本地规则/); assert.ok(result.links.some(l=>l.href.startsWith('/library/')));
 const malicious=completeModelReply({choices:[{finish_reason:'stop',message:{content:JSON.stringify({answer:'只要999元',recommendations:[],followUpQuestions:[]})}}]},ctx('苹果16什么芯片'),'test-model');
 assert.equal(malicious.mode,'ai'); assert.ok(!malicious.answer.includes('999元'));
});

test('明确中文和k预算可理解，省略单位歧义与硬件参数不冒充金额',()=>{
 for(const [text,amount] of [['预算两千',2000],['预算改成两千五百',2500],['预算2k',2000],['预算2.5k手机',2500],['预算一万两千',12000]] as const) assert.deepEqual(parseBudgetChange(text),{kind:'absolute',amount},text);
 for(const text of ['预算两千五','预算一万二','预算2千5','预算2000到3000','预算四五千','预算一二千']) assert.equal(parseBudgetChange(text).kind,'unclear',text);
 for(const text of ['2K屏幕','最高120Hz','最多200克','16GB内存']) assert.notEqual(parseBudgetChange(text).kind,'absolute',text);
 const c=ctx('主要日常用手机',[{role:'user',content:'预算5000元'},{role:'user',content:'预算改成两千'}]);assert.equal(c.memory.budget,2000);
});

test('同名不同地区设备不能拼接，明确国行时选择国行记录',()=>{
 const ambiguous=ctx('一加13什么接口');assert.equal(ambiguous.task.intent,'variant-question');assert.equal(ambiguous.references.length,2);
 const cn=ctx('国行一加13什么接口');assert.equal(cn.references.length,1);assert.equal(cn.references[0].id,'reviewed-oneplus-13');
});
