import test from 'node:test';
import assert from 'node:assert/strict';
import {buildContext} from '../lib/ai/context';
import {completeModelReply} from '../lib/ai/reply';
import {developmentDiagnostics,type ValidationDiagnostic} from '../lib/ai/validation-diagnostics';
const context=buildContext({message:'预算3000手机主要打游戏推荐哪款',history:[],path:'/'});
test('局部校验日志保留原始全文、规则、机型及字段，其他模型内容保留',()=>{
 const raw='```json\n'+JSON.stringify({answer:'Xiaomi 14值得先了解。iPhone 99 Ultra尚未上市。保留这句一般建议。',recommendations:[{id:'xiaomi-14',reason:'已有参数',caution:'核价'},{id:'iphone-99-ultra',reason:'未知',caution:'待核实'}]})+'\n```';
 const records:ValidationDiagnostic[]=[];
 const result=completeModelReply({choices:[{finish_reason:'stop',message:{content:raw}}]},context,'deepseek-flash',{enabled:true,emit:record=>records.push(record)});
 assert.equal(result.mode,'ai');assert.match(result.answer,/保留这句一般建议/);assert.ok(!result.answer.includes('iPhone 99 Ultra'));assert.ok(records.length);assert.equal(records[0].rawReply,raw);assert.equal(records[0].rule,'UNKNOWN_MODEL');assert.deepEqual(records[0].fields,['recommendations.1.id']);assert.ok(records[0].products[0].includes('iphone-99-ultra'));
});

test('默认和生产来源不记录原始模型正文，失败仍不向访客返回诊断原文',()=>{
 assert.equal(developmentDiagnostics('true','https://max0220-22.github.io').enabled,false);
 assert.equal(developmentDiagnostics('true','http://127.0.0.1:4174').enabled,true);
 let called=false;const raw='{"answer":"仅需2999元"}';const reply=completeModelReply({choices:[{finish_reason:'stop',message:{content:raw}}]},context,'deepseek-flash',{enabled:false,emit:()=>{called=true;}});
 assert.equal(called,false);assert.ok(!JSON.stringify(reply).includes(raw));
});
