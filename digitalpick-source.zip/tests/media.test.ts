import test from 'node:test';
import assert from 'node:assert/strict';
import { products } from '../lib/products';
import { officialProductMedia } from '../lib/official-product-media';
import { primaryMedia, galleryMedia } from '../lib/product-media';
import mediaReport from '../docs/official-media-report.json';
import expandedMedia from '../data/official-product-media.json';

test('已有主图保留官方来源，新增资料可明确使用无图占位', () => {
  const domains = ['www.apple.com.cn','cdsassets.apple.com','consumer.huawei.com','images.samsung.com','images.samsung.com.cn','i02.appmifile.com','www.oppo.com','image.oppo.com','wwwstatic.vivo.com.cn','cn-exstatic-vivofs.iqoo.com','in-exstatic-vivofs.vivo.com','www-file.honor.com','oasisstatics.oneplus.cn','oasis.opstatics.com','www.oneplus.com','msecfs.opposhop.cn','cdn.cnbj1.fds.api.mi-img.com','mishop-pc.cnbj1.mi-fds.com','res-shop.nubia.com','cdn-shop.redmagic.com'];
  for (const product of products) {
    const entry = officialProductMedia[product.id];
    if (!entry && product.specificationStatus==='partial') { assert.equal(primaryMedia(product.id),undefined);assert.deepEqual(galleryMedia(product.id),[]);continue; }
    assert.ok(entry, product.id);
    const url = new URL(entry.imageUrl);
    assert.equal(url.protocol, 'https:'); assert.ok(domains.includes(url.hostname), product.id);
    assert.match(entry.usageStatus, /授权未确认/); assert.match(entry.checkedAt, /^\d{4}-\d{2}-\d{2}$/);
    assert.equal(new URL(entry.officialPage).protocol,'https:');
    assert.equal(url.username,''); assert.equal(url.password,'');
    assert.equal(primaryMedia(product.id)?.src, entry.imageUrl);
    assert.equal(galleryMedia(product.id)[0].src, entry.imageUrl);
  }
});
test('标准版与 Pro 图片分开，附加实拍具有来源、许可与完整轮廓遮罩', () => {
  assert.notEqual(primaryMedia('vivo-x200')?.src, primaryMedia('vivo-x200-pro')?.src);
  assert.match(primaryMedia('iphone-18-pro')!.src, /iphone-18-pro-colors\.png$/);
  let total = 0;
  for (const product of products) for (const photo of galleryMedia(product.id).slice(1)) {
    total++; assert.ok(photo.clip); assert.ok(photo.sourceUrl.startsWith('https://commons.wikimedia.org/'));
    assert.match(photo.rights, /^CC/); assert.match(photo.notes, /未重绘/);
    const box = photo.clip.viewBox.split(' ').map(Number); assert.equal(box.length, 4); assert.ok(box.every(Number.isFinite));
  }
  assert.equal(total, 4);
});

test('official image coverage matches the catalog and every credit has a working product route',()=>{
 assert.equal(mediaReport.totalProducts,products.length);
 assert.equal(mediaReport.coveredProducts,Object.keys(officialProductMedia).length);
 assert.equal(mediaReport.newlyCovered,Object.keys(expandedMedia).length);
 assert.equal(mediaReport.items.length+mediaReport.missing.length,products.length);
 for(const row of mediaReport.items){
  assert.ok(products.some(p=>p.id===row.id),row.id);
  assert.equal(primaryMedia(row.id)?.src,row.imageUrl);
  assert.ok(row.width>=180&&row.height>=180,row.id);
 }
 for(const row of mediaReport.missing)assert.equal(primaryMedia(row.id),undefined,row.id);
});
test('SKU clean renders and size-specific iPad archives are preserved',()=>{
 for(const id of ['catalog-oneplus-pad-2-cn','catalog-oneplus-pad-2-pro-cn','catalog-oneplus-pad-3-pro-cn']){
  assert.match(primaryMedia(id)!.src,/\.png(?:\?|$)/);
  assert.ok(primaryMedia(id)!.sourceUrl.startsWith('https://www.opposhop.cn/'));
 }
 const small=primaryMedia('catalog-ipad-pro-11-m1')!,large=primaryMedia('catalog-ipad-pro-12-9-m1')!;
 assert.ok(small&&large);assert.notEqual(small.src,large.src);
 assert.match(small.src,/2021-ipad-pro-11-colors/);assert.match(large.src,/2021-ipad-pro-12-9-colors/);
});
