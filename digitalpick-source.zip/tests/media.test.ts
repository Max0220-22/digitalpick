import test from 'node:test';
import assert from 'node:assert/strict';
import { products } from '../lib/products';
import { officialProductMedia } from '../lib/official-product-media';
import { primaryMedia, galleryMedia } from '../lib/product-media';

test('每款产品主图均有独立的官方来源与明确版权状态', () => {
  const domains = ['www.apple.com.cn', 'cdsassets.apple.com', 'images.samsung.com', 'images.samsung.com.cn', 'i02.appmifile.com', 'www.oppo.com', 'wwwstatic.vivo.com.cn', 'www-file.honor.com', 'oasisstatics.oneplus.cn'];
  for (const product of products) {
    const entry = officialProductMedia[product.id];
    assert.ok(entry, product.id);
    const url = new URL(entry.imageUrl);
    assert.equal(url.protocol, 'https:'); assert.ok(domains.includes(url.hostname), product.id);
    assert.match(entry.usageStatus, /授权未确认/); assert.equal(entry.checkedAt, '2026-10-16');
    assert.equal(primaryMedia(product.id)?.src, entry.imageUrl);
    assert.equal(galleryMedia(product.id)[0].src, entry.imageUrl);
  }
});
test('标准版与 Pro 图片分开，附加实拍具有来源、许可与完整轮廓遮罩', () => {
  assert.notEqual(primaryMedia('vivo-x200')?.src, primaryMedia('vivo-x200-pro')?.src);
  assert.match(primaryMedia('iphone-18-pro')!.src, /iphone-18-pro-colors\.png$/);
  let total = 0;
  for (const product of products) for (const photo of galleryMedia(product.id).slice(1)) {
    total++; assert.ok(photo.clip); assert.ok(photo.sourceUrl.startsWith('https://commons.wikimedia.org/'));
    assert.match(photo.rights, /^CC/); assert.match(photo.notes, /未重绘/);
    const box = photo.clip.viewBox.split(' ').map(Number); assert.equal(box.length, 4); assert.ok(box.every(Number.isFinite));
  }
  assert.equal(total, 4);
});
