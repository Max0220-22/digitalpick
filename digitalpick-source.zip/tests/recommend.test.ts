import { ruleProducts as products } from './fixtures/rule-products';
import test from 'node:test';
import assert from 'node:assert/strict';
import { recommend, budgets, type Preferences } from '../lib/recommend';
import { uses, type Category, type PurchaseMode } from '../lib/products';
import { isStale, reliableSavings } from '../lib/prices';
import { summarize, checklist } from '../lib/checklist';
import { channels, safeChannelUrl } from '../lib/channels';
const now = new Date('2026-10-16T12:00:00+08:00');
const base: Preferences = { category: 'phone', maxBudget: 3000, mode: 'either', uses: ['日常使用'], brand: '', os: '', storage: 0, maxWeight: null, maxScreen: null };
test('预算、类别、购买方式的穷举组合均不突破硬性上限', () => {
 for (const category of ['phone', 'tablet', 'laptop'] as Category[]) for (const b of budgets) for (const mode of ['new', 'used', 'either'] as PurchaseMode[]) {
  const results = recommend({ ...base, category, maxBudget: b.max, mode, uses: [uses[category][0]] }, products, now);
  assert.ok(results.length <= 3);
  for (const r of results) { assert.equal(r.product.category, category); assert.ok(r.offer.price.max <= b.max); assert.ok(mode === 'either' || mode === r.offer.mode); assert.equal(r.score, r.breakdown.reduce((s, b) => s + b.score, 0)); assert.ok(r.score <= 100); }
 }
});
test('二手价格使用区间上限，最低价不能成为超预算入口', () => {
 assert.equal(recommend({ ...base, mode: 'used', maxBudget: 2000 }, products, now).length, 0);
 const result = recommend({ ...base, mode: 'used', maxBudget: 2500 }, products, now);
 assert.equal(result[0].product.id, 'xiaomi-14'); assert.equal(result[0].offer.price.max, 2500);
});
test('无价格产品不推荐，所有演示数据明确标识', () => {
 const results = recommend({ ...base, maxBudget: 100000 }, products, now);
 assert.ok(!results.some(r => r.product.id === 'iphone-13'));
 for (const p of products) for (const price of [p.newPrice, p.usedPrice]) if (price) { assert.equal(price.demo, true); assert.equal(price.source, null); }
});
test('系统、存储、重量、屏幕是硬限制；品牌偏好不能突破限制', () => {
 assert.equal(recommend({ ...base, os: 'Windows', category: 'laptop', uses: ['学习'], maxBudget: 100000 }, products, now).length, 0);
 assert.equal(recommend({ ...base, storage: 1024, maxBudget: 100000 }, products, now).length, 0);
 assert.equal(recommend({ ...base, maxWeight: 170, maxBudget: 100000 }, products, now).length, 0);
 assert.equal(recommend({ ...base, maxScreen: 6, maxBudget: 100000 }, products, now).length, 0);
 const results = recommend({ ...base, brand: 'Apple', maxBudget: 3000, mode: 'new' }, products, now);
 assert.equal(results[0].product.id, 'xiaomi-14');
});
test('用途不适合时不凑数推荐', () => {
 assert.equal(recommend({ ...base, category: 'laptop', maxBudget: 100000, uses: ['游戏'] }, products, now).length, 0);
 assert.equal(recommend({ ...base, uses: ['未配置的用途'] }, products, now).length, 0);
});
test('过期、无效日期、未来日期不参与预算推荐', () => {
 assert.equal(recommend(base, products, new Date('2026-11-17T12:00:00+08:00')).length, 0);
 const price = products[0].usedPrice!;
 assert.equal(isStale(price, now), false);
 assert.equal(isStale({ ...price, collectedAt: 'invalid' }, now), true);
 assert.equal(isStale({ ...price, collectedAt: '2026-12-31' }, now), true);
});
test('无效预算不返回推荐', () => { for (const maxBudget of [0, -1, NaN, Infinity]) assert.equal(recommend({ ...base, maxBudget }, products, now).length, 0); });
test('演示价格和缺失价格不计算差价', () => { for (const p of products) assert.equal(reliableSavings(p, now), null); });
test('可靠且同配置的有效报价才能计算保守参考差额', () => {
 const p = { ...products[0], newPrice: { ...products[0].newPrice!, demo: false, source: '官方测试来源' }, usedPrice: { ...products[0].usedPrice!, demo: false, source: '二手测试来源' } };
 assert.equal(reliableSavings(p, now)?.amount, 999);
});
test('渠道入口仅接受白名单 HTTPS 域名', () => {
 for (const c of channels) if (c.url) assert.ok(safeChannelUrl(c.url));
 for (const u of ['javascript:alert(1)', 'http://www.jd.com/', 'https://www.jd.com.evil.test/', 'https://evil.test/', 'https://user@www.jd.com/']) assert.equal(safeChannelUrl(u), null);
});
test('验机关键异常与未检查项分别统计，不把未查当通过', () => {
 const s = summarize(checklist.phone, { screen: 'pass', lock: 'issue' });
 assert.equal(s.passed.length, 1); assert.equal(s.issues.length, 1); assert.equal(s.pending.length, 8); assert.equal(s.criticalIssue, true);
});
test('非法价格范围和缺少来源的非演示报价不参与推荐', () => {
 for (const newPrice of [
  { ...products[1].newPrice!, min: -1, max: -1 },
  { ...products[1].newPrice!, min: 3000, max: 2000 },
  { ...products[1].newPrice!, min: NaN, max: 2000 },
  { ...products[1].newPrice!, demo: false, source: null },
 ]) assert.equal(recommend({ ...base, mode: 'new' }, [{ ...products[1], newPrice }], now).length, 0);
});
