import test from 'node:test';
import assert from 'node:assert/strict';
import { companionReducer, initialCompanionState, normalizePointer } from '../lib/companion/state';
import { localGuide, contextBubble } from '../lib/companion/guide';

test('精灵与聊天共享唯一状态：打开、输入、思考、关闭', () => {
  const opened = companionReducer(initialCompanionState, { type: 'open', prompt: '3000元手机' });
  assert.equal(opened.open, true); assert.equal(opened.phase, 'greeting'); assert.equal(opened.draft, '3000元手机');
  const input = companionReducer(opened, { type: 'input', value: '二手' });
  assert.equal(input.phase, 'listening');
  const thinking = companionReducer(input, { type: 'phase', phase: 'thinking' });
  assert.equal(thinking.phase, 'thinking');
  const closed = companionReducer(thinking, { type: 'close' });
  assert.equal(closed.open, false); assert.equal(closed.phase, 'idle'); assert.equal(closed.draft, '二手');
});
test('输入长度上限和暂停动态状态', () => {
  const state = companionReducer(initialCompanionState, { type: 'input', value: 'x'.repeat(900) });
  assert.equal(state.draft.length, 800);
  assert.equal(companionReducer(state, { type: 'motion', enabled: false }).motion, false);
});
test('鼠标和触控坐标保持在安全范围', () => {
  assert.deepEqual(normalizePointer(50, 50, 100, 100), { x: 0, y: 0 });
  assert.deepEqual(normalizePointer(999, -100, 100, 100), { x: 1, y: 1 });
  assert.deepEqual(normalizePointer(10, 10, 0, 0), { x: 0, y: 0 });
});
test('本地导览只生成内部工具链接，不伪造 AI 及真实价格', () => {
  const reply = localGuide('预算3000元，二手安卓手机', {}, '/');
  assert.deepEqual(reply.memory, { budget: 3000, category: 'phone', mode: 'used', os: 'Android' });
  const href = reply.links[0].href;
  assert.ok(href.startsWith('/recommend/?')); assert.ok(href.includes('budget=3000')); assert.ok(href.includes('mode=used'));
  assert.match(reply.text, /本地规则/); assert.match(reply.text, /演示数据/);
});
test('同一会话的新预算覆盖旧预算，增加预算保留其他条件', () => {
  const a = localGuide('预算3000元的二手安卓手机', {}, '/');
  const b = localGuide('预算提高500元呢', a.memory, '/');
  assert.equal(b.memory.budget, 3500); assert.equal(b.memory.mode, 'used'); assert.equal(b.memory.os, 'Android');
  const c = localGuide('预算改成2000元', b.memory, '/');
  assert.equal(c.memory.budget, 2000);
});
test('路由上下文只接受产品库中存在的 ID', () => {
  assert.match(contextBubble('/products/iphone-15/').label, /iPhone 15/);
  assert.ok(!contextBubble('/products/fake-999/').label.includes('fake'));
  const reply = localGuide('这款适合谁', {}, '/products/fake-999/');
  assert.equal(reply.productId, undefined);
});
test('Root 与保值相关问题说明数据边界，不编造可解锁或残值结论', () => {
  const reply = localGuide('想Root，转卖保值吗', {}, '/');
  assert.match(reply.text, /具体型号/); assert.match(reply.text, /当前演示库不能/);
  assert.equal(reply.productId, undefined);
});
test('不知道原预算时，不把加价金额误认为新预算', () => {
  const reply = localGuide('预算提高500元', {}, '/');
  assert.equal(reply.memory.budget, undefined); assert.match(reply.text, /原来的预算/);
});
