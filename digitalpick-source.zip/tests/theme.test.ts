import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import { readFileSync } from 'node:fs';
import { Group, Mesh, PerspectiveCamera, SphereGeometry, MeshBasicMaterial } from 'three';
import { createThemeTimeline, resolveTheme, themeBootstrap, THEME_DURATION, claimSkyHint, bindThemeScheduler, sampleTheme, readingPalette, sceneDaylight } from '../lib/theme';
import { createModelPicker, isModelTap } from '../lib/companion/model-hit';
function clock(initial: 'dark' | 'light' = 'dark') {
 let now = 0, id = 0; const queue = new Map<number, (time: number) => void>(); const paints: number[] = [];
 const timeline = createThemeTimeline(initial, { now: () => now, request: callback => { queue.set(++id, callback); return id; }, cancel: token => { queue.delete(token); }, paint: value => paints.push(value.daylight), start: () => {}, finish: () => {} });
 return { timeline, paints, queue, step(time: number) { now = time; const callbacks = [...queue.values()]; queue.clear(); callbacks.forEach(callback => callback(time)); } };
}
test('首次主题遵循系统，显式偏好优先；损坏的存储值不改变系统判断', () => {
 assert.equal(resolveTheme(null, false), 'light'); assert.equal(resolveTheme(null, true), 'dark'); assert.equal(resolveTheme('dark', false), 'dark'); assert.equal(resolveTheme('light', true), 'light'); assert.equal(resolveTheme('bad-value', false), 'light');
});
test('1.6秒日出只有一条时间轴，重复触发不会反向或叠加', () => {
 const c = clock(); assert.equal(c.timeline.start('light'), true); assert.equal(c.timeline.start('dark'), false); assert.equal(c.timeline.start('light'), false); assert.equal(c.timeline.state.sequence, 1);
 c.step(600); assert.equal(c.timeline.state.daylight, .5); assert.equal(c.timeline.state.busy, true); assert.equal(c.queue.size, 1);
 c.step(THEME_DURATION); assert.equal(c.timeline.state.daylight, 1); assert.equal(c.timeline.state.busy, false); assert.equal(c.queue.size, 0);
 assert.ok(c.paints.every((value, i, a) => !i || value >= a[i - 1]));
 assert.equal(c.timeline.start('dark'), true); c.step(2200); assert.equal(c.timeline.state.daylight, .5); c.step(3200); assert.equal(c.timeline.state.daylight, 0);
});
test('减少动态直接切换终态，不排动画帧；中途启用时可立即结束', () => {
 const c = clock(); assert.equal(c.timeline.start('light', true), true); assert.equal(c.timeline.state.daylight, 1); assert.equal(c.timeline.state.duration, 0); assert.equal(c.queue.size, 0); assert.equal(c.timeline.state.busy, false);
 c.timeline.start('dark'); c.step(400); c.timeline.finish(); assert.equal(c.timeline.state.daylight, 0); assert.equal(c.queue.size, 0);
});
test('首屏脚本在localStorage不可用时仍跟随系统，并在绘制前设置天空和配色', () => {
 for (const [stored, systemDark, blocked, expected] of [[null,false,false,'light'],[null,true,true,'dark'],['light',true,false,'light'],['dark',false,false,'dark']] as const) {
  const classes = new Set<string>(), css = new Map<string,string>(), root = { classList: { toggle: (name: string, enabled: boolean) => enabled ? classes.add(name) : classes.delete(name) }, dataset: {} as Record<string,string>, style: { colorScheme:'', setProperty: (key: string, value: string) => css.set(key,value) } };
  vm.runInNewContext(themeBootstrap, { localStorage: { getItem() { if (blocked) throw Error('denied'); return stored; } }, matchMedia: () => ({ matches: systemDark }), document: { documentElement: root } });
  assert.equal(root.dataset.theme, expected); assert.equal(classes.has('dark'), expected === 'dark'); assert.equal(css.get('--daylight'), expected === 'dark' ? '0' : '1');
 }
});
test('真实Raycaster仅命中模型及小幅外扩范围，舞台空白不触发', () => {
 const model = new Group(), geometry = new SphereGeometry(1), material = new MeshBasicMaterial(); model.add(new Mesh(geometry,material));
 const camera = new PerspectiveCamera(45,1,.1,100); camera.position.set(0,0,6); camera.lookAt(0,0,0);
 const pick = createModelPicker(model,camera), rect = {left:0,top:0,width:200,height:200};
 assert.equal(pick(100,100,rect),true); assert.equal(pick(195,10,rect),false); assert.equal(pick(-2,100,rect),false); assert.equal(pick(100,100,{...rect,width:0}),false);
 assert.equal(pick(156,100,rect),false); assert.equal(pick(156,100,rect,true),true);
 model.position.x = 3; assert.equal(pick(100,100,rect,true),false);
 geometry.dispose(); material.dispose();
});
test('轻微点按可触发，拖动和触屏滚动不会当成模型点击', () => {
 assert.equal(isModelTap({x:100,y:100},{x:104,y:105}),true); assert.equal(isModelTap({x:100,y:100},{x:100,y:130}),false);
});

test('首次主页提示只认领一次，新挂载与刷新沿用同一存储标记', () => {
 const values = new Map<string,string>(), storage = { getItem: (key:string) => values.get(key) || null, setItem: (key:string,value:string) => { values.set(key,value); } };
 assert.equal(claimSkyHint(storage),true); assert.equal(claimSkyHint(storage),false); assert.equal(claimSkyHint({...storage}),false);
});

test('原生帧调度器保留宿主调用上下文，过渡结束能取消帧并释放锁', () => {
 let cancelled = 0;
 const host = { performance: { now: () => 0 }, requestAnimationFrame() { assert.equal(this, host); return 42; }, cancelAnimationFrame(id: number) { assert.equal(this, host); cancelled = id; } };
 const timeline = createThemeTimeline('dark', { ...bindThemeScheduler(host), paint() {}, start() {}, finish() {} });
 timeline.start('light'); timeline.finish(); assert.equal(cancelled,42); assert.equal(timeline.state.busy,false); assert.equal(timeline.state.daylight,1);
});

test('日间正文和次级文字在浅色面板及最深天蓝底上满足4.5:1', () => {
 const css = readFileSync(new URL('../app/dawn.css', import.meta.url),'utf8');
 const day = css.match(/:root\{([^}]+)\}/)![1];
 const color = (name:string) => day.match(new RegExp('--'+name+':#([a-f0-9]{6})'))![1];
 const luminance = (hex:string) => { const c = hex.match(/../g)!.map(n=>parseInt(n,16)/255).map(n=>n<=.04045?n/12.92:((n+.055)/1.055)**2.4); return c[0]*.2126+c[1]*.7152+c[2]*.0722; };
 for (const [foreground,background] of [[color('foreground'),'ffffff'],[color('muted'),'ffffff'],[color('muted'),'83bdeb']]) { const values=[luminance(foreground),luminance(background)].sort((a,b)=>b-a); assert.ok((values[0]+.05)/(values[1]+.05)>=4.5); }
});


test('日出分镜严格遵循200/400/800ms三个入点，日落镜像且不残留屏息遮罩', () => {
 const at = (ms:number) => sampleTheme('dark','light',ms/THEME_DURATION);
 assert.deepEqual([at(200).daylight,at(400).lighting,at(800).ui],[0,0,0]);
 assert.equal(at(200).breath,.05); assert.equal(at(600).daylight,.5); assert.equal(at(800).lighting,.5); assert.equal(at(1200).ui,.5);
 assert.equal(at(1000).daylight,1); assert.equal(at(1200).lighting,1); assert.equal(at(1600).ui,1); assert.equal(at(1600).breath,0);
 for(let t=0;t<=1600;t+=20){ const sunrise=at(t), sunset=sampleTheme('light','dark',t/1600); for(const channel of ['daylight','lighting','ui'] as const)assert.ok(Math.abs(sunrise[channel]+sunset[channel]-1)<1e-10); assert.ok(sunrise.breath>=0&&sunrise.breath<=.05); }
});
test('过渡每一毫秒的阅读表面与正文对比度均达到4.5:1', () => {
 for(let t=0;t<=1600;t++){const palette=readingPalette(sampleTheme('dark','light',t/1600).ui);const contrast=palette.darkInk?(palette.luminance+.05)/.05:1.05/(palette.luminance+.05);assert.ok(contrast>=4.5,`at ${t}ms: ${contrast}`);}
});
test('四轮完整往返没有残留进度、重复动画或未释放的锁',()=>{
 const c=clock(); let time=0;
 for(let i=0;i<4;i++)for(const target of ['light','dark'] as const){assert.equal(c.timeline.start(target),true);assert.equal(c.timeline.start(target==='light'?'dark':'light'),false);time+=1600;c.step(time);assert.equal(c.timeline.state.busy,false);assert.equal(c.queue.size,0);assert.equal(c.timeline.state.breath,0);assert.equal(c.timeline.state.ui,+(target==='light'));}
 assert.equal(c.timeline.state.sequence,8);
});


test('曝光包络避免天空提前到终态，且日落与日出对称无残留',()=>{
 for(let ms=0;ms<=1600;ms+=10){const a=sampleTheme('dark','light',ms/1600),b=sampleTheme('light','dark',ms/1600);assert.ok(Math.abs(sceneDaylight(a)+sceneDaylight(b)-1)<1e-10);assert.ok(Math.abs(sceneDaylight(a)-a.ui)<=.25);}
 assert.ok(sceneDaylight(sampleTheme('light','dark',1000/1600))>.5);
 assert.equal(sceneDaylight(sampleTheme('dark','light',1)),1);assert.equal(sceneDaylight(sampleTheme('light','dark',1)),0);
});
