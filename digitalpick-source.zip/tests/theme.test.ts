import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import { readFileSync } from 'node:fs';
import { Group, Mesh, PerspectiveCamera, SphereGeometry, BoxGeometry, CylinderGeometry, MeshBasicMaterial, Vector3 } from 'three';
import { createElement } from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import { MascotFallback } from '../components/companion/fallback';
import { createThemeTimeline, resolveTheme, themeBootstrap, THEME_DURATION, claimSkyHint, bindThemeScheduler, sampleTheme, readingPalette, sceneDaylight, themeEase, sunlightVisibility } from '../lib/theme';
import { createModelPicker, isModelTap, isModelActionTap } from '../lib/companion/model-hit';
function clock(initial: 'dark' | 'light' = 'dark') {
 let now = 0, id = 0; const queue = new Map<number, (time: number) => void>(); const paints: number[] = [];
 const timeline = createThemeTimeline(initial, { now: () => now, request: callback => { queue.set(++id, callback); return id; }, cancel: token => { queue.delete(token); }, paint: value => paints.push(value.daylight), start: () => {}, finish: () => {} });
 return { timeline, paints, queue, step(time: number) { now = time; const callbacks = [...queue.values()]; queue.clear(); callbacks.forEach(callback => callback(time)); } };
}
test('首次主题遵循系统，显式偏好优先；损坏的存储值不改变系统判断', () => {
 assert.equal(resolveTheme(null, false), 'light'); assert.equal(resolveTheme(null, true), 'dark'); assert.equal(resolveTheme('dark', false), 'dark'); assert.equal(resolveTheme('light', true), 'light'); assert.equal(resolveTheme('bad-value', false), 'light');
});
test('1.6秒日出只有一条时间轴，重复触发不会反向或叠加', () => {
 const c = clock(); assert.equal(c.timeline.start('light'), true); assert.equal(c.timeline.start('dark'), false); assert.equal(c.timeline.start('light'), false); assert.equal(c.timeline.state.sequence, 1);
 c.step(800); assert.equal(c.timeline.state.daylight, .5); assert.equal(c.timeline.state.busy, true); assert.equal(c.queue.size, 1);
 c.step(THEME_DURATION); assert.equal(c.timeline.state.daylight, 1); assert.equal(c.timeline.state.busy, false); assert.equal(c.queue.size, 0);
 assert.ok(c.paints.every((value, i, a) => !i || value >= a[i - 1]));
 assert.equal(c.timeline.start('dark'), true); c.step(2400); assert.equal(c.timeline.state.daylight, .5); c.step(3200); assert.equal(c.timeline.state.daylight, 0);
});
test('减少动态直接切换终态，不排动画帧；中途启用时可立即结束', () => {
 const c = clock(); assert.equal(c.timeline.start('light', true), true); assert.equal(c.timeline.state.daylight, 1); assert.equal(c.timeline.state.duration, 0); assert.equal(c.queue.size, 0); assert.equal(c.timeline.state.busy, false);
 c.timeline.start('dark'); c.step(400); c.timeline.finish(); assert.equal(c.timeline.state.daylight, 0); assert.equal(c.queue.size, 0);
});
test('首屏脚本在localStorage不可用时仍跟随系统，并在绘制前设置天空和配色', () => {
 for (const [stored, systemDark, blocked, expected] of [[null,false,false,'light'],[null,true,true,'dark'],['light',true,false,'light'],['dark',false,false,'dark']] as const) {
  const classes = new Set<string>(), css = new Map<string,string>(), root = { classList: { toggle: (name: string, enabled: boolean) => enabled ? classes.add(name) : classes.delete(name) }, dataset: {} as Record<string,string>, style: { colorScheme:'', setProperty: (key: string, value: string) => css.set(key,value) } };
  vm.runInNewContext(themeBootstrap, { localStorage: { getItem() { if (blocked) throw Error('denied'); return stored; } }, matchMedia: () => ({ matches: systemDark }), document: { documentElement: root } });
  assert.equal(root.dataset.theme, expected); assert.equal(classes.has('dark'), expected === 'dark'); assert.equal(css.get('--daylight'), expected === 'dark' ? '0' : '1');
 }
});
function pickFixture() {
 const model = new Group(), head = new Group(), button = new Group(), material = new MeshBasicMaterial();
 head.position.set(0,.65,0); head.userData.companionAction='chat'; head.add(new Mesh(new SphereGeometry(.5,24,16),material));
 const torso = new Mesh(new BoxGeometry(.8,.7,.5),material); torso.position.set(0,-.6,0);
 button.position.set(0,-.55,.3); button.userData.companionAction='theme';
 const face = new Mesh(new CylinderGeometry(.165,.165,.04,32),material); face.rotation.x=Math.PI/2; button.add(face);
 const arm = new Mesh(new SphereGeometry(.16),material); arm.position.set(-.7,-.6,0);
 model.add(head,torso,button,arm);
 const camera = new PerspectiveCamera(45,1,.1,100); camera.position.set(0,0,6); camera.lookAt(0,0,0); camera.updateMatrixWorld();
 const rect={left:30,top:20,width:400,height:400}, pick=createModelPicker(model,camera);
 const screen=(object:Group|Mesh,local=new Vector3())=>{model.updateWorldMatrix(true,true);const p=object.localToWorld(local).project(camera);return {x:rect.left+(p.x+1)*rect.width/2,y:rect.top+(1-p.y)*rect.height/2};};
 const at=(object:Group|Mesh,local?:Vector3)=>{const p=screen(object,local);return pick(p.x,p.y,rect);};
 const dispose=()=>{model.traverse(o=>{if(o instanceof Mesh)o.geometry.dispose();});material.dispose();};
 return {model,head,button,torso,arm,camera,rect,pick,at,screen,dispose};
}
test('真实Raycaster区分头部聊天和胸前按钮；躯干、手臂、包围盒内空气均无动作',()=>{
 const f=pickFixture();
 assert.equal(f.at(f.head),'chat'); assert.equal(f.at(f.button),'theme');
 assert.equal(f.at(f.torso,new Vector3(.3,0,0)),null); assert.equal(f.at(f.arm),null);
 assert.equal(f.at(f.model,new Vector3(.4,-.08,0)),null);
 assert.equal(f.pick(31,21,f.rect),null); assert.equal(f.pick(0,100,f.rect),null);
 assert.equal(f.pick(230,220,{...f.rect,width:0}),null);
 // A point just outside the visible circular button cannot borrow the old touch padding.
 assert.equal(f.at(f.button,new Vector3(.19,0,0)),null);
 f.dispose();
});
test('头和按钮热区随移动、旋转及转头实时跟随，旧位置失效',()=>{
 const f=pickFixture(), old=f.screen(f.button);
 f.model.position.set(1.1,.2,.5); f.model.rotation.set(.08,.3,.1); f.head.rotation.set(.1,-.35,.12);
 assert.equal(f.at(f.head),'chat'); assert.equal(f.at(f.button),'theme');
 assert.equal(f.pick(old.x,old.y,f.rect),null);
 f.model.position.x=-1; f.model.rotation.y=-.25; f.head.rotation.y=.4;
 assert.equal(f.at(f.head),'chat'); assert.equal(f.at(f.button),'theme'); f.dispose();
});
test('最近可见表面遮挡按钮时不能隔着身体点击；隐藏头部不形成热区',()=>{
 const f=pickFixture(), cover=new Mesh(new BoxGeometry(.4,.4,.1),new MeshBasicMaterial()); cover.position.set(0,-.55,.6); f.model.add(cover);
 assert.equal(f.at(f.button),null); cover.visible=false; assert.equal(f.at(f.button),'theme');
 f.head.visible=false; assert.equal(f.at(f.head),null); cover.geometry.dispose(); (cover.material as MeshBasicMaterial).dispose(); f.dispose();
});
test('同部位按下抬起才触发；从空气进入、跨部位或拖动返回均拒绝',()=>{
 const start={x:100,y:100,action:'theme' as const};
 assert.equal(isModelActionTap(start,{...start,x:103}),true);
 assert.equal(isModelActionTap({...start,action:null},start),false);
 assert.equal(isModelActionTap(start,{...start,action:'chat'}),false);
 assert.equal(isModelActionTap(start,{...start,action:null}),false);
 assert.equal(isModelActionTap(start,{...start,y:120}),false);
 assert.equal(isModelActionTap(start,start,true),false);
});
test('2D形象在头部及胸前各有独立按钮；装饰用途不嵌入交互按钮',()=>{
 const plain=renderToStaticMarkup(createElement(MascotFallback)); assert.equal((plain.match(/<button/g)||[]).length,0);
 const html=renderToStaticMarkup(createElement(MascotFallback,{onChat:()=>{},onTheme:()=>true,themeBusy:true}));
 assert.equal((html.match(/<button/g)||[]).length,2);
 assert.match(html,/<div class="fallback-head">[\s\S]*?class="fallback-head-action"/);
 assert.match(html,/<div class="fallback-body"><button[^>]*class="fallback-core fallback-core-action"/);
 assert.match(html,/aria-label="点小派的头打开对话"/); assert.match(html,/disabled=""/);
});
test('轻微点按可触发，拖动和触屏滚动不会当成模型点击', () => {
 assert.equal(isModelTap({x:100,y:100},{x:104,y:105}),true); assert.equal(isModelTap({x:100,y:100},{x:100,y:130}),false);
});

test('首次主页提示只认领一次，新挂载与刷新沿用同一存储标记', () => {
 const values = new Map<string,string>(), storage = { getItem: (key:string) => values.get(key) || null, setItem: (key:string,value:string) => { values.set(key,value); } };
 assert.equal(claimSkyHint(storage),true); assert.equal(claimSkyHint(storage),false); assert.equal(claimSkyHint({...storage}),false);
});

test('原生帧调度器保留宿主调用上下文，过渡结束能取消帧并释放锁', () => {
 let cancelled = 0;
 const host = { performance: { now: () => 0 }, requestAnimationFrame() { assert.equal(this, host); return 42; }, cancelAnimationFrame(id: number) { assert.equal(this, host); cancelled = id; } };
 const timeline = createThemeTimeline('dark', { ...bindThemeScheduler(host), paint() {}, start() {}, finish() {} });
 timeline.start('light'); timeline.finish(); assert.equal(cancelled,42); assert.equal(timeline.state.busy,false); assert.equal(timeline.state.daylight,1);
});

test('日间正文和次级文字在浅色面板及最深天蓝底上满足4.5:1', () => {
 const css = readFileSync(new URL('../app/dawn.css', import.meta.url),'utf8');
 const day = css.match(/:root\{([^}]+)\}/)![1];
 const color = (name:string) => day.match(new RegExp('--'+name+':#([a-f0-9]{6})'))![1];
 const luminance = (hex:string) => { const c = hex.match(/../g)!.map(n=>parseInt(n,16)/255).map(n=>n<=.04045?n/12.92:((n+.055)/1.055)**2.4); return c[0]*.2126+c[1]*.7152+c[2]*.0722; };
 for (const [foreground,background] of [[color('foreground'),'ffffff'],[color('muted'),'ffffff'],[color('muted'),'83bdeb']]) { const values=[luminance(foreground),luminance(background)].sort((a,b)=>b-a); assert.ok((values[0]+.05)/(values[1]+.05)>=4.5); }
});


test('天空、光照、UI使用相同进度，双向对称，没有屏息闪色', () => {
 for(let ms=0;ms<=1600;ms+=10) {
  const a=sampleTheme('dark','light',ms/1600), b=sampleTheme('light','dark',ms/1600);
  assert.equal(a.daylight,a.lighting); assert.equal(a.daylight,a.ui); assert.equal(a.breath,0);
  assert.ok(Math.abs(a.daylight+b.daylight-1)<1e-10);
  assert.equal(sceneDaylight(a),a.daylight);
 }
});
test('过渡每一毫秒的阅读表面与正文对比度均达到4.5:1', () => {
 for(let t=0;t<=1600;t++){const palette=readingPalette(sampleTheme('dark','light',t/1600).ui);const contrast=palette.darkInk?(palette.luminance+.05)/.05:1.05/(palette.luminance+.05);assert.ok(contrast>=4.5,`at ${t}ms: ${contrast}`);}
});
test('四轮完整往返没有残留进度、重复动画或未释放的锁',()=>{
 const c=clock(); let time=0;
 for(let i=0;i<4;i++)for(const target of ['light','dark'] as const){assert.equal(c.timeline.start(target),true);assert.equal(c.timeline.start(target==='light'?'dark':'light'),false);time+=1600;c.step(time);assert.equal(c.timeline.state.busy,false);assert.equal(c.queue.size,0);assert.equal(c.timeline.state.breath,0);assert.equal(c.timeline.state.ui,+(target==='light'));}
 assert.equal(c.timeline.state.sequence,8);
});


test('曝光包络避免天空提前到终态，且日落与日出对称无残留',()=>{
 for(let ms=0;ms<=1600;ms+=10){const a=sampleTheme('dark','light',ms/1600),b=sampleTheme('light','dark',ms/1600);assert.ok(Math.abs(sceneDaylight(a)+sceneDaylight(b)-1)<1e-10);assert.ok(Math.abs(sceneDaylight(a)-a.ui)<=.25);}
 assert.ok(sceneDaylight(sampleTheme('light','dark',1000/1600))<.5);
 assert.equal(sceneDaylight(sampleTheme('dark','light',1)),1);assert.equal(sceneDaylight(sampleTheme('light','dark',1)),0);
});

test('CSS和rAF共享ease-in-out：端点一致、连续单调且正反向互补',()=>{
 assert.equal(themeEase(0),0);assert.equal(themeEase(.5),.5);assert.equal(themeEase(1),1);
 let previous=0;
 for(let ms=1;ms<=1600;ms++){const p=themeEase(ms/1600);assert.ok(p>=previous);assert.ok(p-previous<.002);assert.ok(Math.abs(p+themeEase(1-ms/1600)-1)<1e-6);previous=p;}
});
test('太阳和晨光始终不晚于天空退场，终态没有残留',()=>{
 for(let ms=0;ms<=1600;ms++){const sky=sampleTheme('light','dark',ms/1600).daylight,sun=sunlightVisibility(sky);assert.ok(sun<=sky);assert.ok(sun>=0);}
 assert.equal(sunlightVisibility(0),0);assert.equal(sunlightVisibility(1),1);assert.equal(sunlightVisibility(.5),.25);
});
