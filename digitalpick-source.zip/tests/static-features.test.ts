import test from 'node:test';
import assert from 'node:assert/strict';
import { createWishlistStore, parseWishlist, WISHLIST_KEY, WISHLIST_LIMIT } from '../lib/wishlist';
import { recommendationText, shareDisclaimer } from '../lib/recommendation-share';
import { products } from '../lib/products';
import { filterGlossary, glossary, faqs } from '../lib/beginner-content';
import type { Preferences } from '../lib/recommend';
const known = new Set(['a', 'b', 'c']);
function memoryStorage(initial: string | null = null) {
 let raw = initial; return { getItem: (key: string) => { assert.equal(key, WISHLIST_KEY); return raw; }, setItem: (key: string, value: string) => { assert.equal(key, WISHLIST_KEY); raw = value; } };
}
test('收藏校验损坏、非数组、未知和重复 ID，不执行不可信内容', () => {
 for (const raw of [null, '{broken', 'null', '{}', '"a"']) assert.deepEqual(parseWishlist(raw, known), []);
 assert.deepEqual(parseWishlist('["a","a",null,7,"unknown","b","<script>"]', known), ['a', 'b']);
});
test('收藏持久化、刷新恢复、移除以及外部存储同步', () => {
 const storage = memoryStorage(); const store = createWishlistStore(known, () => storage);
 assert.equal(store.getServerSnapshot().ready, false); store.refresh(); store.toggle('a'); store.toggle('b');
 assert.deepEqual(store.getSnapshot().ids, ['a', 'b']);
 const reloaded = createWishlistStore(known, () => storage); reloaded.refresh(); assert.deepEqual(reloaded.getSnapshot().ids, ['a', 'b']);
 reloaded.toggle('a'); store.refresh(); assert.deepEqual(store.getSnapshot().ids, ['b']);
 storage.setItem(WISHLIST_KEY, '[]'); store.refresh(); assert.deepEqual(store.getSnapshot().ids, []);
});
test('收藏禁用或额度不足时保留本次页面状态，明确报告不能持久化', () => {
 const broken = createWishlistStore(known, () => { throw Error('SecurityError'); }); broken.refresh(); broken.toggle('a'); broken.toggle('b');
 assert.equal(broken.getSnapshot().error, true); assert.deepEqual(broken.getSnapshot().ids, ['a', 'b']); broken.toggle('a'); assert.deepEqual(broken.getSnapshot().ids, ['b']);
 const quota = createWishlistStore(known, () => ({ getItem: () => '[]', setItem: () => { throw Error('QuotaExceededError'); } }));
 quota.toggle('a'); quota.toggle('b'); assert.deepEqual(quota.getSnapshot().ids, ['a', 'b']); assert.equal(quota.getSnapshot().error, true);
});
test('收藏读取无写操作、限制数量、通知订阅者并允许取消订阅', () => {
 let writes = 0, updates = 0; const ids = new Set(Array.from({ length: 220 }, (_, i) => `id-${i}`));
 const store = createWishlistStore(ids, () => ({ getItem: () => JSON.stringify([...ids]), setItem: () => { writes++; } }));
 const stop = store.subscribe(() => updates++); store.refresh(); assert.equal(writes, 0); assert.equal(store.getSnapshot().ids.length, WISHLIST_LIMIT);
 store.toggle('id-219'); assert.equal(writes, 0); assert.equal(updates, 1); stop(); store.toggle('id-0'); assert.equal(updates, 1);
});
test('推荐文本是微信友好的纯文本，去重、过滤未知 ID，保留核价与免责标签', () => {
 const product = products.find(p => p.id === 'iphone-15') || products[0];
 const text = recommendationText({ items: [{ id: product.id, reason: '日常使用\n先核价', caution: '确认成色' }, { id: product.id }, { id: 'invented-phone' }] });
 assert.ok(text.includes(product.name)); assert.ok(text.includes(shareDisclaimer)); assert.ok(text.includes('非实时价格')); assert.ok(text.includes('核价备选：尚未通过实时购买预算审核'));
 assert.ok(text.includes('参数更新：')); assert.equal((text.match(/1\. /g) || []).length, 1); assert.ok(!text.includes('invented-phone')); assert.ok(!text.includes('<table')); assert.ok(!text.includes('\r')); assert.ok(!text.includes('\\n'));
});
test('空结果分享条件清单，不虚构机型、可购买价格或库存', () => {
 const preferences: Preferences = { category: 'phone', maxBudget: 2000, reserveBudget: 100, mode: 'used', uses: ['游戏性能'], brand: '', os: '', storage: 0, maxWeight: null, maxScreen: null };
 const text = recommendationText({ items: [], preferences, scope: 'verified' });
 for (const part of ['¥2,000', '预留 ¥100', '二手', '游戏性能', '没有通过全部条件审核', shareDisclaimer]) assert.ok(text.includes(part));
 assert.ok(!text.includes('1. ')); assert.ok(!text.includes('到手价：'));
});
test('有依据的价格保持类型、配置、地区和日期，缺失价格不补造', () => {
 const priced = products.find(p => p.id === 'iphone-15') || products[0]; const text = recommendationText({ items: [{ id: priced.id }] });
 assert.ok(text.includes('价格资料：')); assert.ok(text.includes('二手资料：')); assert.ok(text.includes('官网起价、历史价和模型估算不可混用'));
});
test('FAQ 和术语数量及 ID 正确，搜索支持中文、大小写、空输入和空结果', () => {
 assert.ok(faqs.length >= 10 && faqs.length <= 12); assert.equal(new Set(faqs.map(f => f.id)).size, faqs.length);
 assert.ok(glossary.length >= 20); assert.equal(new Set(glossary.map(g => g.id)).size, glossary.length);
 assert.equal(filterGlossary('  sOc ')[0].id, 'soc'); assert.ok(filterGlossary('刷新率').some(t => t.id === 'refresh')); assert.equal(filterGlossary('').length, glossary.length); assert.equal(filterGlossary('unfindableterm').length, 0);
 for (const faq of faqs) assert.ok(faq.answer.split('。').filter(Boolean).length >= 2);
});
