import test from 'node:test';
import assert from 'node:assert/strict';
import { renderToStaticMarkup } from 'react-dom/server';
import { createElement } from 'react';
import { buildSecondhandLink, secondhandSearch, priceCheckSteps } from '../lib/secondhand';
import { SecondhandLink } from '../components/secondhand-link';
import { products } from '../lib/products';
import { channels } from '../lib/channels';
test('闲鱼关键词完整编码，特殊字符不产生额外参数',()=>{
 const value=buildSecondhandLink('一加','13','16+512');
 assert.equal(value,'https://www.goofish.com/search?q='+encodeURIComponent('一加 13 16+512'));
 const url=new URL(buildSecondhandLink('A&B','X/#?','16+512'));
 assert.equal(url.origin,'https://www.goofish.com');assert.equal(url.searchParams.get('q'),'A&B X/#? 16+512');assert.equal([...url.searchParams].length,1);assert.equal(url.hash,'');
});
test('设备搜索不重复品牌，不编造未知容量',()=>{
 const url=new URL(secondhandSearch({brand:'Xiaomi',name:'Xiaomi 14',ram:12,storage:256}));assert.equal(url.searchParams.get('q'),'Xiaomi 14 12+256');
 assert.equal(new URL(secondhandSearch({brand:'Apple',name:'iPad',ram:null,storage:null})).searchParams.get('q'),'Apple iPad ');
});
test('外跳安全属性、价格说明及单闲鱼二手渠道',()=>{
 const markup=renderToStaticMarkup(createElement(SecondhandLink,{product:products[0]}));
 assert.ok(markup.includes('target="_blank"'));assert.ok(markup.includes('rel="noopener"'));assert.ok(markup.includes('实时价格以平台页面为准'));assert.ok(markup.includes('闲鱼实时价'));
 assert.deepEqual(channels.filter(c=>c.group==='二手交易').map(c=>c.id),['goofish']);
});

test('核价三步搜索词与现有闲鱼链接逐字一致，附检查项与卖家问句',()=>{
 for(const product of products){
  const steps=priceCheckSteps(product);assert.equal(steps.length,3);assert.equal(steps[0].text,new URL(secondhandSearch(product)).searchParams.get('q'));
  for(const text of ['配置','成色','是否原装'])assert.ok(steps[1].text.includes(text));assert.ok(steps[2].text.includes(product.name));assert.ok(steps[2].text.endsWith('？'));
 }
 const html=renderToStaticMarkup(createElement(SecondhandLink,{product:products[0]}));assert.ok(html.includes('<details'));assert.ok(html.includes('核价三步'));assert.ok(html.includes('非实时价格，购买前请核实'));
});
