import test from 'node:test';
import assert from 'node:assert/strict';
import {buildContext} from '../lib/ai/context';
import {catalogCoverage,expansionRecords} from '../lib/catalog-expanded';
const context=(message:string,history:{role:'user'|'assistant';content:string}[]=[])=>buildContext({message,history,path:'/'});
test('详细规格保留同型号芯片与内存绑定，短问继续使用已核对资料',()=>{
 const first=context('国行Mate80 Pro处理器怎么选');
 assert.equal(first.references.length,1);
 assert.match(first.references[0].facts.processor!,/9030\s*Pro.*16\s*GB/s);
 assert.match(first.references[0].facts.processor!,/9030（12\s*GB/s);
 const follow=context('16GB版呢',[{role:'user',content:'国行Mate80 Pro处理器怎么选'}]);
 assert.deepEqual(follow.references.map(r=>r.id),first.references.map(r=>r.id));
 const undisclosed=context('国行Mate70用什么处理器');
 assert.equal(undisclosed.references.length,1);
 assert.ok(!undisclosed.references[0].facts.processor,'官网未列芯片的型号不能从相邻代际自动补写');
});
test('折叠机标准版资料不会自动套用典藏版电池和容量',()=>{
 const ctx=context('国行Mate X7电池多大');
 assert.equal(ctx.references.length,1);
 assert.match(ctx.references[0].facts.battery!,/5525/);
 assert.doesNotMatch(ctx.references[0].facts.battery!,/5600/);
 assert.match(ctx.references[0].facts.configuration!,/标准版12GB/);
});
test('新增海外笔记本按明确地区检索，国行缺失内存不借用英国配置',()=>{
 const uk=context('英国版红魔16 Pro的内存');
 assert.equal(uk.references.length,1);assert.match(uk.references[0].region,/^英国/);
 assert.match(uk.references[0].facts.ram!,/16GB/);
 const cn=context('国行红魔16 Pro的内存');
 assert.equal(cn.references.length,1);assert.match(cn.references[0].region,/^中国大陆/);
 assert.ok(!cn.references[0].facts.ram);
 const indonesia=context('印度尼西亚版MateBook D16配置');
 assert.ok(indonesia.references.length);
 assert.ok(indonesia.references.every(r=>/^(?:印尼|印度尼西亚)/.test(r.region)));
});
test('采集参数不混入网页代码、凭据或错误的耳机来源',()=>{
 for(const entry of catalogCoverage)for(const url of entry.sourceUrls)assert.doesNotMatch(url,/\/vivotws3\//);
 for(const r of expansionRecords){
  for(const value of Object.values(r.facts))if(value)assert.doesNotMatch(value,/<\/?(?:script|div|span)\b|createElementVNode|__v_is/);
  for(const source of [r.sourceUrl,...(r.sourceUrls||[])]){
   const url=new URL(source);assert.equal(url.protocol,'https:');assert.equal(url.username,'');assert.equal(url.password,'');
  }
 }
 for(const name of ['vivo S10','vivo S10 Pro']){
  const r=expansionRecords.find(r=>r.name===name);assert.ok(r,name);
  assert.doesNotMatch(r.sourceUrl,/tws/i);
  assert.ok(Object.values(r.facts).filter(Boolean).length>=5,name);
 }
});
test('Pro+后缀不会退化成Pro，也不会混用不同快充和电池规格',()=>{
 const pro=context('国行红魔8 Pro电池和充电');
 const plus=context('国行红魔8 Pro+电池和充电');
 assert.equal(pro.references.length,1);assert.equal(plus.references.length,1);
 assert.notEqual(pro.references[0].id,plus.references[0].id);
 assert.match(pro.references[0].facts.battery!,/6000/);
 assert.match(pro.references[0].facts.charging!,/80W/);
 assert.match(plus.references[0].facts.battery!,/5000/);
 assert.match(plus.references[0].facts.charging!,/165W/);
 const source=plus.payload.referenceContext.devices[0].source;
 assert.ok(source.urls.includes(plus.references[0].sourceUrl));
 assert.equal(source.checkedAt,'2026-10-18');

 const history=[{role:'user' as const,content:'iPhone 16\u7eed\u822a\u600e\u4e48\u6837'}];
 for(const message of ['\u7ea2\u9b54 12 Pro\u7eed\u822a\u5462','\u7ea2\u9b54 8 Ultra\u7eed\u822a\u5462']){
  const result=context(message,history);
  assert.deepEqual(result.references,[]);
  assert.equal(result.task.intent,'unknown-device');
  assert.equal(result.payload.referenceContext.inheritedFromUserHistory,false);
 }
});
