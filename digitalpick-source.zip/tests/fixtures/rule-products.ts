import { products as realProducts, type Price } from '../../lib/products';
// Synthetic prices belong only to tests, never the public catalog or AI context.
const values:Record<string,[number,number,number]>={'iphone-15':[4199,2600,3200],'xiaomi-14':[2999,1900,2500],'ipad-air-m2':[5299,3200,3900],'xiaomi-pad-6':[1499,800,999],'macbook-air-m2':[6299,3600,4500],'macbook-pro-m3':[9999,6500,7800]};
const demo=(min:number,max=min):Price=>({min,max,demo:true,source:null,collectedAt:'2026-10-16'});
export const ruleProducts=realProducts.map(p=>{const v=values[p.id];return v?{...p,newPrice:demo(v[0]),usedPrice:demo(v[1],v[2])}:{...p,newPrice:null,usedPrice:null};});
