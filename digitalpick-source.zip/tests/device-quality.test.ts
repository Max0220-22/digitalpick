import test from 'node:test';
import assert from 'node:assert/strict';
import {prefersLightweight,prefersHeroFallback} from '../lib/companion/quality';
test('手机和低资源默认轻量，普通桌面保留3D',()=>{
 for(const profile of [{width:390},{width:767},{width:1024,coarse:true},{width:1440,saveData:true},{width:1440,cores:2},{width:1440,memory:2}])assert.equal(prefersLightweight(profile),true);
 assert.equal(prefersLightweight({width:1440,cores:8,memory:8}),false);assert.equal(prefersLightweight({width:800,cores:4}),false);
});

test('普通手机Hero保留3D，浮动小派仍可轻量；只为资源约束提供2D',()=>{assert.equal(prefersHeroFallback({width:390,coarse:true,cores:8,memory:4}),false);assert.equal(prefersHeroFallback({width:320,cores:4}),false);assert.equal(prefersHeroFallback({width:390,saveData:true}),true);assert.equal(prefersHeroFallback({width:390,cores:2}),true);});
