import test from 'node:test';
import assert from 'node:assert/strict';
import {prefersLightweight} from '../lib/companion/quality';
test('手机和低资源默认轻量，普通桌面保留3D',()=>{
 for(const profile of [{width:390},{width:767},{width:1024,coarse:true},{width:1440,saveData:true},{width:1440,cores:2},{width:1440,memory:2}])assert.equal(prefersLightweight(profile),true);
 assert.equal(prefersLightweight({width:1440,cores:8,memory:8}),false);assert.equal(prefersLightweight({width:800,cores:4}),false);
});
