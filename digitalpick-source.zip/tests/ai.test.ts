import test from 'node:test';
import assert from 'node:assert/strict';
import { DatabaseSync } from 'node:sqlite';
import { reserveQuota } from '../lib/ai/quota';
import { validateModelReply, requestSchema } from '../lib/ai/schema';
import { buildContext } from '../lib/ai/context';
const reply = { answer: '先看系统与日常用途，再确认设备来源。', followUpQuestions: ['主要用来做什么？'], recommendations: [] };
const day = new Date('2026-10-16T03:00:00Z');
const limits = { dailyCalls: 4, userDaily: 2, dailyTokens: 1000, minuteCalls: 2 };
test('AI output rejects unknown IDs, duplicate IDs, money claims and arbitrary URLs', () => {
  assert.deepEqual(validateModelReply(reply, []), reply);
  assert.throws(() => validateModelReply({ ...reply, answer: '只要2999元' }, []));
  assert.throws(() => validateModelReply({ ...reply, answer: 'https://evil.example' }, []));
  const rec = { id: 'fake-phone', reason: '更轻', caution: '缺少报价' };
  assert.throws(() => validateModelReply({ ...reply, recommendations: [rec] }, ['iphone-15']));
  assert.throws(() => validateModelReply({ ...reply, recommendations: [rec, rec] }, ['fake-phone']));
});
test('AI candidate pool excludes every demo or missing quotation under a hard budget', () => {
  const context = buildContext(requestSchema.parse({ message: '3000元买什么手机，只考虑二手？', history: [] }));
  assert.equal(context.memory.budget, 3000); assert.equal(context.memory.mode, 'used');
  assert.equal(context.candidates.length, 0);
});
test('latest user constraints override earlier budget and purchase mode', () => {
  const context = buildContext(requestSchema.parse({ message: '预算2000元，只买全新手机', history: [{ role: 'user', content: '预算3000元，二手手机' }] }));
  assert.equal(context.memory.budget, 2000); assert.equal(context.memory.mode, 'new');
});
test('unparsed lower budget cannot reuse the previous higher ceiling', () => {
  const context = buildContext(requestSchema.parse({ message: '预算改成两千，只考虑全新，不买二手', history: [{ role: 'user', content: '预算5000元，二手手机' }] }));
  assert.equal(context.memory.budget, undefined); assert.equal(context.memory.mode, 'new');
  assert.equal(context.candidates.length, 0); assert.equal(context.guide.links[0].href, '/recommend/');
});
test('request bounds reject excess history and oversized input', () => {
  assert.equal(requestSchema.safeParse({ message: 'x'.repeat(801) }).success, false);
  assert.equal(requestSchema.safeParse({ message: '你好', history: Array(9).fill({ role: 'user', content: '你好' }) }).success, false);
});
test('durable reservations enforce per-user and global limits before calls', () => {
  const db = new DatabaseSync(':memory:');
  reserveQuota(db, 'a', 100, limits, day); reserveQuota(db, 'a', 100, limits, day);
  assert.throws(() => reserveQuota(db, 'a', 100, limits, day), /USER_LIMIT/);
  reserveQuota(db, 'b', 100, limits, day); reserveQuota(db, 'b', 100, limits, day);
  assert.throws(() => reserveQuota(db, 'c', 100, limits, day), /GLOBAL_LIMIT/);
  db.close();
});
test('token reservations fail closed and UTC rollover starts a new budget', () => {
  const db = new DatabaseSync(':memory:');
  reserveQuota(db, 'a', 950, limits, day);
  assert.throws(() => reserveQuota(db, 'b', 100, limits, day), /GLOBAL_LIMIT/);
  reserveQuota(db, 'a', 100, limits, new Date('2026-10-17T00:00:00Z'));
  db.close();
});
