import test from 'node:test';
import assert from 'node:assert/strict';
import { DatabaseSync } from 'node:sqlite';
import { reserveQuota } from '../lib/ai/quota';
import { validateModelReply, requestSchema } from '../lib/ai/schema';
import { buildContext } from '../lib/ai/context';
const reply = { answer: '先看系统与日常用途，再确认设备来源。', followUpQuestions: ['主要用来做什么？'], recommendations: [] };
const day = new Date('2026-10-16T03:00:00Z');
const limits = { dailyCalls: 4, userDaily: 2, dailyTokens: 1000, minuteCalls: 2 };
test('输出信封宽容格式和表达，仅局部移除未知或重复ID',()=>{
 assert.deepEqual(validateModelReply(reply,[]),reply);
 const rec={id:'fake-phone',reason:'更轻',caution:'缺少报价'};
 assert.deepEqual(validateModelReply({...reply,recommendations:[rec]},['iphone-15']).recommendations,[]);
 assert.equal(validateModelReply({...reply,recommendations:[rec,rec]},['fake-phone']).recommendations.length,1);
 assert.equal(validateModelReply('**先看需求**，预算3000元左右。',[]).answer,'**先看需求**，预算3000元左右。');
});

test('AI candidate pool excludes every demo or missing quotation under a hard budget', () => {
  const context = buildContext(requestSchema.parse({ message: '3000元买什么手机，只考虑二手？', history: [] }));
  assert.equal(context.memory.budget, 3000); assert.equal(context.memory.mode, 'used');
  assert.equal(context.candidates.length, 0);
});
test('latest user constraints override earlier budget and purchase mode', () => {
  const context = buildContext(requestSchema.parse({ message: '预算2000元，只买全新手机', history: [{ role: 'user', content: '预算3000元，二手手机' }] }));
  assert.equal(context.memory.budget, 2000); assert.equal(context.memory.mode, 'new');
});
test('unparsed lower budget cannot reuse the previous higher ceiling', () => {
  const context = buildContext(requestSchema.parse({ message: '预算降一档，只考虑全新，不买二手', history: [{ role: 'user', content: '预算5000元，二手手机' }] }));
  assert.equal(context.memory.budget, undefined); assert.equal(context.memory.mode, 'new');
  assert.equal(context.candidates.length, 0); assert.equal(context.guide.links[0].href, '/recommend/');
});
test('request bounds reject excess history and oversized input', () => {
  assert.equal(requestSchema.safeParse({ message: 'x'.repeat(801) }).success, false);
  assert.equal(requestSchema.safeParse({ message: '你好', history: Array(9).fill({ role: 'user', content: '你好' }) }).success, false);
});
test('durable reservations enforce per-user and global limits before calls', () => {
  const db = new DatabaseSync(':memory:');
  reserveQuota(db, 'a', 100, limits, day); reserveQuota(db, 'a', 100, limits, day);
  assert.throws(() => reserveQuota(db, 'a', 100, limits, day), /USER_LIMIT/);
  reserveQuota(db, 'b', 100, limits, day); reserveQuota(db, 'b', 100, limits, day);
  assert.throws(() => reserveQuota(db, 'c', 100, limits, day), /GLOBAL_LIMIT/);
  db.close();
});
test('token reservations fail closed and UTC rollover starts a new budget', () => {
  const db = new DatabaseSync(':memory:');
  reserveQuota(db, 'a', 950, limits, day);
  assert.throws(() => reserveQuota(db, 'b', 100, limits, day), /GLOBAL_LIMIT/);
  reserveQuota(db, 'a', 100, limits, new Date('2026-10-17T00:00:00Z'));
  db.close();
});

test('信封层不再用句式或货币正则整条否决，报价展示单独处理',()=>{
 for(const answer of ['预算3000元左右，可以先看参数。','按你的预算3000元上下，可以先核价。'])assert.equal(validateModelReply({answer},[]).answer,answer);
});
