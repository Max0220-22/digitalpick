# 官方产品图核对与使用边界

核对日期：2026-10-16。当前24款设备的主图均记录官方来源，优先采用透明产品图；旧款使用官方历史机型资料。本站不把下架机型称为官方仍在售，也不从图片推导报价、容量、地区配置或库存。

## 当前方式

- 源码只保存品牌公开图片地址与出处，没有打包官方位图、抓取商城价格、绕过访问限制或搬运官方旋转视频。客户端直接向对应品牌 CDN 请求图片，设置 no-referrer；失败时显示可理解的占位提示。
- 官方出处已核对，不代表开放授权。`usageStatus` 逐条保留“公开再分发授权未确认”；当前适用于本地设计预览，公开发布前应确认品牌使用许可或替换为自有授权素材。Apple 的要求见[第三方商标与版权指引](https://www.apple.com/legal/intellectual-property/guidelinesfor3rdparties.html)。远程嵌入同样不是版权许可。
- 苹果商城 iPhone 17 图片 CDN 本次返回非图片响应，因此采用 Apple 官方机型识别页的同型号配色图；没有换域代理或下载来绕过限制。三星 S24 / S25 图来自标准版官方商城条目，S24 为欧洲版，对应资料库的欧洲版配置。
- iPad Air 13英寸 M2 使用官方机型识别页“13 英寸 iPad Air (M2)”小节内的 spring-2024-3.png，避免仅凭11英寸文件名判断机型。iPhone 18 Pro 使用标准 Pro 的官方机型识别配色图，不拿 Pro Max 代替。
- 旧本地 Commons 素材保留在源码与许可清单中，产品主图不再使用门店照片。补充视图只展示4张无遮挡照片：iPhone X正面、背面，iPhone 14 / 15背面；原片SVG轮廓遮罩隐藏背景，未重绘摄像头、标识或补齐遮挡部位。CC BY-SA 4.0 作者、原片链接与许可仍在 `/sources/` 展示。
- imagegen 抠图试样未采用；最终展示使用原始照片像素与代码轮廓遮罩。不会把生成改画的细节当成设备证据。
- 主图为平面图像。放大、视差与切换不是官方360模型，网页没有伪造旋转序列帧。

## 记录

| 设备 | 图像类别 | 官方出处 | 原始图像 |
| --- | --- | --- | --- |
| iPhone 15 | 官方归档图 | [Apple](https://support.apple.com/zh-cn/108044) | [品牌 CDN](https://cdsassets.apple.com/live/7WUAS350/images/iphone/fall-2023-iphone-colors-iphone-15.png) |
| Xiaomi 14 | 官方外观图 | [Xiaomi](https://www.mi.com/sg/product/xiaomi-14/specs/) | [品牌 CDN](https://i02.appmifile.com/431_item_sg/22/10/2024/260e2d3ba3e4d7995022c27eecbf61df.png) |
| iPhone 13 | 官方归档图 | [Apple](https://support.apple.com/zh-cn/108044) | [品牌 CDN](https://cdsassets.apple.com/live/7WUAS350/images/iphone/2022-spring-iphone13-colors.png) |
| iPad Air 13″ | 官方归档图 | [Apple](https://support.apple.com/zh-cn/108043) | [品牌 CDN](https://cdsassets.apple.com/live/7WUAS350/images/ipad/spring-2024-3.png) |
| Xiaomi Pad 6 | 官方外观图 | [Xiaomi](https://www.mi.com/global/product/xiaomi-pad-6/) | [品牌 CDN](https://i02.appmifile.com/896_operatorx_operatorx_opx/31/08/2023/777129f39f90fe8479cf5489f9a1e509.png) |
| MacBook Air 13″ | 官方归档图 | [Apple](https://support.apple.com/zh-cn/111867) | [品牌 CDN](https://cdsassets.apple.com/live/SZLF0YNV/images/sp/111867_SP869-2022-macbook-air-m2-colors.png) |
| MacBook Pro 14″ | 官方归档图 | [Apple](https://support.apple.com/) | [品牌 CDN](https://cdsassets.apple.com/live/7WUAS350/images/tech-specs/macbook-pro-14-inch-m3-pro-or-m3.png) |
| iPhone X | 官方归档图 | [Apple](https://support.apple.com/zh-cn/111864) | [品牌 CDN](https://cdsassets.apple.com/live/SZLF0YNV/images/sp/111864_iphonex.png) |
| iPhone XS | 官方归档图 | [Apple](https://support.apple.com/zh-cn/108044) | [品牌 CDN](https://cdsassets.apple.com/live/7WUAS350/images/iphone/iphone-xs-colors.jpg) |
| iPhone XR | 官方归档图 | [Apple](https://support.apple.com/zh-cn/108044) | [品牌 CDN](https://cdsassets.apple.com/live/7WUAS350/images/iphone/iphone-xr/identify-iphone-xr-colors.jpg) |
| iPhone 11 | 官方归档图 | [Apple](https://support.apple.com/zh-cn/108044) | [品牌 CDN](https://cdsassets.apple.com/live/7WUAS350/images/iphone/identify-iphone-11-colors.jpg) |
| iPhone 12 | 官方归档图 | [Apple](https://support.apple.com/zh-cn/108044) | [品牌 CDN](https://cdsassets.apple.com/live/7WUAS350/images/iphone/2021-iphone12-colors.png) |
| iPhone 14 | 官方归档图 | [Apple](https://support.apple.com/zh-cn/111850) | [品牌 CDN](https://cdsassets.apple.com/live/SZLF0YNV/images/sp/111850_iphone-14_1.png) |
| iPhone 16 | 官方归档图 | [Apple](https://support.apple.com/zh-cn/108044) | [品牌 CDN](https://cdsassets.apple.com/live/7WUAS350/images/iphone/iphone-16-colors.png) |
| iPhone 17 | 官方外观图 | [Apple](https://support.apple.com/zh-cn/108044) | [品牌 CDN](https://cdsassets.apple.com/live/7WUAS350/images/iphone/iphone-17-colors.png) |
| iPhone 18 Pro | 官方外观图 | [Apple](https://support.apple.com/zh-cn/108044) | [品牌 CDN](https://cdsassets.apple.com/live/7WUAS350/images/iphone/iphone-18-pro-colors.png) |
| Xiaomi 15 | 官方外观图 | [Xiaomi](https://www.mi.com/hk/product/xiaomi-15/specs/) | [品牌 CDN](https://i02.appmifile.com/177_item_hk/21/02/2025/41edfda5883e4899d5cf226baa6e7134.png) |
| Samsung Galaxy S24 | 官方商城图 | [Samsung](https://www.samsung.com/es/smartphones/galaxy-s24/buy/) | [品牌 CDN](https://images.samsung.com/is/image/samsung/p6pim/es/2401/gallery/es-galaxy-s24-sm-s921bzvdeub-539409937) |
| Samsung Galaxy S25 | 官方商城图 | [Samsung](https://www.samsung.com.cn/smartphones/galaxy-s25/buy/) | [品牌 CDN](https://images.samsung.com.cn/is/image/samsung/p6pim/cn/2501/gallery/cn-galaxy-s25-532487-sm-s9310zsgchc-544568956) |
| OPPO Find X8 | 官方外观图 | [OPPO](https://www.oppo.com/cn/smartphones/series-find-x/find-x8/specs/) | [品牌 CDN](https://www.oppo.com/content/dam/oppo/common/mkt/v2-2/find-x8-series-cn/oppo-find-x8/product/1548-720-v2.png) |
| vivo X200 | 官方外观图 | [vivo](https://www.vivo.com.cn/vivo/param/x200) | [品牌 CDN](https://wwwstatic.vivo.com.cn/vivoportal/files/image/detail/20241008/8f19bf0f1ed8498a6b05143be7ff876b.png) |
| vivo X200 Pro | 官方外观图 | [vivo](https://www.vivo.com.cn/vivo/param/x200pro) | [品牌 CDN](https://wwwstatic.vivo.com.cn/vivoportal/files/image/detail/20241008/f3008e12d583428111100e63366bd467.png) |
| 荣耀 Magic7 Pro | 官方外观图 | [HONOR](https://www.honor.com/cn/phones/honor-magic7-pro/) | [品牌 CDN](https://www-file.honor.com/content/dam/honor/common/product-list/product-series/honor-magic7-pro/honor-magic7-pro-id-gary-back.png) |
| 一加 13 | 官方外观图 | [OnePlus](https://www.oneplus.com/cn/13/specs) | [品牌 CDN](https://oasisstatics.oneplus.cn/content/dam/oasis/page/2024/global/product/dodge/white-050214.png) |
