# 详细参数补充记录（2026-10-18）

## 本轮结果

更新 237 条正式产品资料，新增 1936 个非空参数字段、补强 176 个原有字段。仅型号/没有基础参数的正式记录由169条降至18条。

当前正式产品库492条型号/地区版本：手机339、平板90、笔记本63；用户原清单520项：446确认、18纠正、56暂未确认。新增笔记本记录保留地区/显卡配置区别，不作为重复独立家族宣传。

非空字段数只统计已整理的信息，不代表所有设备参数齐全。部分华为旧款只补了官方支持清单里的容量组合，仍缺屏幕、电池或芯片。字段为空与官网未披露、旧页不可读分别在资料备注说明。

## 资料范围

| 数据文件 | 更新记录 | 新增字段 | 补强字段 | 仍仅型号 |
| --- | ---: | ---: | ---: | ---: |
| china-phones.json | 158 | 1364 | 125 | 16 |
| apple-samsung-phones.json | 2 | 13 | 1 | 0 |
| tablets.json | 29 | 119 | 25 | 1 |
| laptops.json | 48 | 440 | 25 | 1 |

数据维护仍在data/catalog-expansion/四个JSON文件；机器可读的逐条字段与来源索引见[spec-enrichment-report.json](spec-enrichment-report.json)。不保存本次抓取的整页HTML或远端脚本，也不在运行时爬取。

## 重要版本边界

- 华为26款中国官网规格已按页面核对；Mate80 Pro的12GB/16GB芯片绑定、MateX6及X7标准/典藏电池区别保留。官方未列处理器的页面不会自动补芯片。
- Xiaomi Pad9三款等动态参数从官网实际引用的型号专属静态内容读取；不把网站导航中的其它机型参数带进来。
- vivo S10/S10Pro原错误耳机来源已从设备及清单引用中清理，并按官方同页区分RAM、后摄和NFC。
- 三星W23/W24依中国官网型号接口读取；W23只写已披露的核心/主频，不套用Fold芯片名称。
- 红魔8/9的Pro与Pro+采用中国官网独立列；英国RTX4060游戏本与国行RTX4070记录分开。旧7S Pro对比表芯片后缀不明确，未补写芯片。
- 日本Redmi Note11明确为骁龙680、4GB+64GB版本，不作为中国大陆同名5G版参数。
- 旧华为笔记本的可读取规格涉及西班牙、墨西哥、印尼等地区，地区标签以实际来源开头，不冒充国行。
- Apple未在技术页披露的手机/平板RAM继续留空；官方档案后续修订的容量或适配器配置注明以所列地区/时期为准。

## 同步与验证

补充来源同时进入产品详情、参数资料页及小派的服务端事实上下文。核对/导入日期为本次整理日期，来源未单独给出发布日期时显示未提供，不把整理时间冒充官网发布时间。

修复Pro+加号被丢弃以及“红魔8 Pro”误匹配iQOO8Pro的问题；新增地区筛选避免印度尼西亚误匹配印度，并支持本轮海外笔记本的明确国家查询。

103项测试通过，前端/Worker TypeScript通过；GitHub Pages静态构建516个HTML、20286条本地引用检查通过。手机390px参数表无横向溢出、浏览器无新增控制台错误。原有推荐、代理额度、安全校验与3D功能保留。此轮未调用真实付费模型。

## 仍仅确认型号的记录

以下18条仍缺基础参数；其他设备也可能缺个别字段，不能将其余记录视为“全参数已完成”。

| 型号 | 地区 | 资料入口 |
| --- | --- | --- |
| 一加平板 Pro | 中国大陆 | [官方资料](https://www.oneplus.com/cn/store) |
| HUAWEI Mate 50 RS 保时捷设计 | 中国大陆 | [官方资料](https://consumer.huawei.com/cn/support/phones/porsche-design-mate50-rs.html) |
| HUAWEI P60 Art | 中国大陆 | [官方资料](https://consumer.huawei.com/cn/support/phones/p60-art.html) |
| HUAWEI Mate X2 5G版 | 中国大陆 | [官方资料](https://consumer.huawei.com/cn/support/phones/mate-x2.html) |
| HUAWEI Mate X5 | 中国大陆 | [官方资料](https://consumer.huawei.com/cn/support/phones/mate-x5.html) |
| HUAWEI nova 9 Pro | 中国大陆 | [官方资料](https://consumer.huawei.com/cn/support/phones/nova9-pro.html) |
| HUAWEI nova 11 Ultra | 中国大陆 | [官方资料](https://consumer.huawei.com/cn/support/phones/nova11-ultra.html) |
| HUAWEI nova 13 | 中国大陆 | [官方资料](https://consumer.huawei.com/cn/support/phones/nova13.html) |
| HUAWEI nova 13 Pro | 中国大陆 | [官方资料](https://consumer.huawei.com/cn/support/phones/nova13-pro.html) |
| 一加 Ace 2 Pro | 中国大陆 | [官方资料](https://www.oneplus.com/cn/ace-2-pro-launch) |
| 红魔6 | 中国大陆 | [官方资料](https://m.redmagic.com/active/nonguaranteedprice.html?isinapk=1) |
| 红魔6R | 中国大陆 | [官方资料](https://m.redmagic.com/active/nonguaranteedprice.html?isinapk=1) |
| 红魔6S Pro | 中国大陆 | [官方资料](https://m.redmagic.com/active/nonguaranteedprice.html?isinapk=1) |
| 红魔7 | 中国大陆 | [官方资料](https://m.redmagic.com/active/nonguaranteedprice.html?isinapk=1) |
| 红魔7 Pro | 中国大陆 | [官方资料](https://m.redmagic.com/active/nonguaranteedprice.html?isinapk=1) |
| 红魔7S | 中国大陆 | [官方资料](https://m.redmagic.com/active/nonguaranteedprice.html?isinapk=1) |
| 红魔10 Pro | 中国大陆 | [官方资料](https://m.redmagic.com/active/nonguaranteedprice.html?isinapk=1) |
| Redmi Book Pro 14 2023 | 中国大陆 | [官方资料](https://pc.mi.com/xiaomishare_help) |

后续补充须继续按原ID更新；只有取得对应型号和地区的可信资料才添加字段，不补猜测价格或测试结论。
