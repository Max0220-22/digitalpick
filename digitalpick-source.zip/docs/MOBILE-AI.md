# 手机微信 AI 连接修复

日期：2026-10-17（北京时间）。

## 原因和证据

网站前端是 GitHub Pages，AI 是独立 Cloudflare Worker，访问域名不同。用户在手机微信打开原 `digitalpick-ai.digitalpick.workers.dev/health` 失败，本机 curl 也复现12秒超时；之前电脑 Safari 可以连接。这确认了客户端到原接口入口存在网络可达性差异，不能据此断言微信不支持 DeepSeek 或所有地区都封锁某个域名。

原前端另有缺陷：只在挂载时请求一次会话，8秒失败后不恢复，始终停在本地规则导览。

## 修复

新增 Pages 入口 `https://digitalpick-gateway.pages.dev`，在 Cloudflare 内部通过 Service Binding 转发至原 `digitalpick-ai`。用户最新反馈确认手机微信能看到新入口健康检查的 `ok:true`。GitHub 的 `AI_PROXY_URL` 改为这个入口，网站地址保持 `https://max0220-22.github.io/digitalpick/`。

前端连接超时调整为15秒，加入“重新连接 AI”；网络 online、页面重新可见或重新打开聊天时可恢复。连接请求合并，自动重连至少间隔15秒，429遵守服务端等待时间。只重试不计费的会话GET，不自动重发模型POST，不改变模型调用额度。网络、超时、服务关闭、来源拒绝、会话异常分别提示。

所有模型密钥仍只在原 Worker Secret，持久化额度仍由同一个 Durable Object 管理。入口未添加模型 Secret，也未复制或重建生产额度数据。

## 验证

82项测试、前端与Worker TypeScript均通过；Worker仅显式检查自身入口及实际导入依赖，避免混入浏览器专用类型；静态构建45个HTML页、1802个本地引用通过；真实workerd内部Service Binding、健康检查、来源拒绝通过。新线上入口健康检查200、预检204、会话GET200且enabled=true；未知来源403、伪造会话401。390×844手机布局中错误说明、重连按钮和输入栏均可见。此次修复未额外调用收费模型。

Cloudflare官方说明：Service Binding请求在内部调用，不经公网：https://developers.cloudflare.com/pages/functions/wrangler-configuration/#service-bindings 。免费默认域名的可达性仍取决于用户网络；若未来变化，应再做手机端健康检查，不能用关闭鉴权或把Key放到浏览器来修复。
