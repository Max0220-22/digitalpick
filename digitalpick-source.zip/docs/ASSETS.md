# 当前图像展示方式（星河版本）

主图已改为24款官方远程图，出处与版权状态见 [官方图像说明](OFFICIAL-MEDIA.md)。下面22张本地素材清单保留完整作者及许可记录；当前产品补充视图只展示4张无遮挡照片，使用SVG原片轮廓遮罩去背景。不是所有本地素材仍在页面展示。官方来源与开放许可分别管理，不将来源核实表述为已获再分发授权。

---

# 产品摄影与展示素材台账

核对日期：2026-10-16。

## 当前分发范围

`lib/catalog-assets.ts` 记录20款设备的本地外观图及作者、原始文件页面、许可链接、转换说明和品牌官方参数入口。`phoneCatalog` 另含20款手机的参数资料：Apple 从 iPhone X（2017）逐代覆盖至 iPhone 17，并补入经官方核实的 iPhone 18 Pro；Android 为2023–2025年间发布的精选主流机型，暂非全部型号及全部配置。

图片来自 Wikimedia Commons 文件持有人明确发布的 CC BY、CC BY-SA 或 CC0 许可，并非品牌官方授权给 DigitalPick 的摄影。参数来自品牌官方网站，图片颜色、地区版本、展示容量可能与页面默认配置不同；商品信息以所选配置和品牌规格为准。

没有可分发图片的机型应显示“暂无已授权照片”及官方外观入口，不使用通用绘图冒充具体机型。iPhone 18 Pro、vivo X200 标准版目前只有官方资料入口。照片中的历史价签、成色标签、包装和配件是拍摄场景，不能作为当前报价、库存、成色保证或标配说明。

## 使用与维护

- 本地WebP以最长边960px、quality82生成，不裁剪设备。保留源文件页许可，格式转换不改变许可要求。
- 署名包含作者名、原文件链接、许可名与链接、变更说明；页面应提供可见的图片来源入口。CC BY-SA 图像及其图像改编继续遵守同一许可；网站代码不会因此整体改为该许可。
- iPhone 12、Galaxy S24、Galaxy S25 使用文件作者发布的设备外观图，标注“授权外观图”，不宣称是品牌发布会摄影或 DigitalPick 实拍。
- MacBook Air M2 原文件贡献者已模糊屏幕内容，显示效果不代表真实系统UI；署名同时列入原摄影作者与该处理贡献者。
- 商标归相应品牌所有；素材作者、品牌与本网站无授权合作或背书关系。若未来获得品牌正式摄影授权，可在保留来源记录后替换图片。
- 原始JPG/PNG属于本次下载的临时生成物，优化后已移出public，仅分发WebP以控制页面体积。文件页可下载原始照片。

## 分发文件与许可

| 设备 / 文件 | 作者 | 原始文件 | 许可 | 处理说明 |
| --- | --- | --- | --- | --- |
| iphone-x · `/products/iphone-x-front.webp` | Gregory Varnum | [Wikimedia文件页](https://commons.wikimedia.org/wiki/File:Apple_iPhone_X_-_front_(8121).jpg) | [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0) | 按最长边960px缩放并转换WebP；未裁剪设备。 |
| iphone-x · `/products/iphone-x-back.webp` | Gregory Varnum | [Wikimedia文件页](https://commons.wikimedia.org/wiki/File:Apple_iPhone_X_-_back_(8111).jpg) | [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0) | 按最长边960px缩放并转换WebP；未裁剪设备。 |
| iphone-xs · `/products/iphone-xs.webp` | FASTILY | [Wikimedia文件页](https://commons.wikimedia.org/wiki/File:IPhone_XS_1_2018-11-02.jpg) | [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0) | 按最长边960px缩放并转换WebP；未裁剪设备。 |
| iphone-xr · `/products/iphone-xr.webp` | Asdaiang14453 | [Wikimedia文件页](https://commons.wikimedia.org/wiki/File:IPhone_XR.jpg) | [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0) | 按最长边960px缩放并转换WebP；未裁剪设备。 |
| iphone-11 · `/products/iphone-11.webp` | Ahmadkurdi44 | [Wikimedia文件页](https://commons.wikimedia.org/wiki/File:IPhone_11_RED.jpg) | [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0) | 按最长边960px缩放并转换WebP；未裁剪设备。 |
| iphone-12 · `/products/iphone-12.webp` | Raphaël Poupon | [Wikimedia文件页](https://commons.wikimedia.org/wiki/File:Iphone-12-product--red.png) | [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0) | 按最长边960px缩放并转换WebP；未裁剪设备。 |
| iphone-13 · `/products/iphone-13.webp` | 茅野ふたば | [Wikimedia文件页](https://commons.wikimedia.org/wiki/File:IPhone_13_White_256g.jpg) | [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0) | 按最长边960px缩放并转换WebP；未裁剪设备。 |
| iphone-14 · `/products/iphone-14.webp` | Hajoon0102 | [Wikimedia文件页](https://commons.wikimedia.org/wiki/File:IPhone_14_Product_Red.jpg) | [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0) | 按最长边960px缩放并转换WebP；未裁剪设备。 |
| iphone-15 · `/products/iphone-15.webp` | ThePhotoGraphIc | [Wikimedia文件页](https://commons.wikimedia.org/wiki/File:Back_of_iPhone_15.jpg) | [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0) | 按最长边960px缩放并转换WebP；未裁剪设备。 |
| iphone-16 · `/products/iphone-16.webp` | Padgriffin | [Wikimedia文件页](https://commons.wikimedia.org/wiki/File:IPhone_16_Ultramarine_Rear.png) | [CC BY 4.0](https://creativecommons.org/licenses/by/4.0) | 按最长边960px缩放并转换WebP；未裁剪设备。 |
| iphone-17 · `/products/iphone-17.webp` | Ahmad Ali Karim | [Wikimedia文件页](https://commons.wikimedia.org/wiki/File:Sage_iPhone_17_(cropped).jpg) | [CC0](https://creativecommons.org/publicdomain/zero/1.0/deed.en) | 按最长边960px缩放并转换WebP；未裁剪设备。 |
| xiaomi-14 · `/products/xiaomi-14.webp` | 茅野ふたば | [Wikimedia文件页](https://commons.wikimedia.org/wiki/File:Xiaomi_14_rear_(July_10,_2026).jpg) | [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0) | 按最长边960px缩放并转换WebP；未裁剪设备。 |
| xiaomi-15 · `/products/xiaomi-15.webp` | 茅野ふたば | [Wikimedia文件页](https://commons.wikimedia.org/wiki/File:Xiaomi_15_(1).jpg) | [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0) | 按最长边960px缩放并转换WebP；未裁剪设备。 |
| xiaomi-15 · `/products/xiaomi-15-front-2.webp` | 茅野ふたば | [Wikimedia文件页](https://commons.wikimedia.org/wiki/File:Xiaomi_15_(2).jpg) | [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0) | 按最长边960px缩放并转换WebP；未裁剪设备。 |
| galaxy-s24 · `/products/galaxy-s24.webp` | Eleanor Chin | [Wikimedia文件页](https://commons.wikimedia.org/wiki/File:S24_Onyx_Black.png) | [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0) | 按最长边960px缩放并转换WebP；未裁剪设备。 |
| galaxy-s25 · `/products/galaxy-s25.webp` | Mandy Harper | [Wikimedia文件页](https://commons.wikimedia.org/wiki/File:Galaxy_S25_Black.png) | [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0) | 按最长边960px缩放并转换WebP；未裁剪设备。 |
| oppo-find-x8 · `/products/oppo-find-x8.webp` | メイド理世 | [Wikimedia文件页](https://commons.wikimedia.org/wiki/File:Back_view_of_OPPO_Find_X8_(November_1,_2024).jpg) | [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0) | 按最长边960px缩放并转换WebP；未裁剪设备。 |
| vivo-x200-pro · `/products/vivo-x200-pro.webp` | X-SHLIED | [Wikimedia文件页](https://commons.wikimedia.org/wiki/File:Vivo_X200_Pro_blue.png) | [CC BY 4.0](https://creativecommons.org/licenses/by/4.0) | 按最长边960px缩放并转换WebP；未裁剪设备。 |
| honor-magic7-pro · `/products/honor-magic7-pro.webp` | 茅野ふたば | [Wikimedia文件页](https://commons.wikimedia.org/wiki/File:Honor_Magic_7_Pro_(May_1,_2025).jpg) | [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0) | 按最长边960px缩放并转换WebP；未裁剪设备。 |
| oneplus-13 · `/products/oneplus-13.webp` | Maksdroider | [Wikimedia文件页](https://commons.wikimedia.org/wiki/File:OnePlus_13_back.jpg) | [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0) | 按最长边960px缩放并转换WebP；未裁剪设备。 |
| ipad-air-m2 · `/products/ipad-air-m2.webp` | Kyu3a | [Wikimedia文件页](https://commons.wikimedia.org/wiki/File:M2_iPad_Air_13inti.jpg) | [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0) | 按最长边960px缩放并转换WebP；未裁剪设备。 |
| macbook-air-m2 · `/products/macbook-air-m2.webp` | KKPCW（Kyu3）；屏幕模糊处理：DFlhb | [Wikimedia文件页](https://commons.wikimedia.org/wiki/File:M2_Macbook_Air_Starlight_model.jpg) | [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0) | 按最长边960px缩放并转换WebP；未裁剪设备。原文件已由作者处理屏幕背景。 |

## 官方素材核对结论

已查阅 [Apple 第三方商标与版权指引](https://www.apple.com/legal/intellectual-property/guidelinesfor3rdparties.html)。该指引明确要求使用 Apple 所有或许可的产品照片前取得书面许可。Apple Newsroom 的“下载图片”按钮并不构成本站已取得再分发权的证明，因此未直接复制 Apple 官网产品摄影、宣传视频或360动画。

[小米媒体资料入口](https://www.mi.com/global/about/mediakit/) 提供媒体联络信息，未找到可直接适用于本站的开放图片许可。[Samsung Mobile Press](https://www.samsungmobilepress.com/media-assets) 提供新闻媒体素材库，未核实到本项目可再分发旋转视频的明确条款。OPPO、vivo、荣耀及一加官网同样只作为官方外观及参数链接。未从电商或社交平台抓取商品图。

## 官方演示参考入口

下列只链接品牌原站，可观看当前可用的产品展示；不承诺每页都有旋转动画，也不将其包装成本站拥有的360资产。官网内容可更新，独立视频、序列帧、三维模型需要单独核对授权再引入。

- [Apple 活动](https://www.apple.com/apple-events/)、[iPhone 18 Pro 官方展示](https://www.apple.com.cn/iphone-18-pro/)
- [Xiaomi 15 官方展示](https://www.mi.com/hk/product/xiaomi-15/)
- [Samsung Galaxy S25 官方展示](https://www.samsung.com.cn/smartphones/galaxy-s25/)
- [OPPO Find X8 官方展示](https://www.oppo.com/cn/smartphones/series-find-x/find-x8/)
- [vivo X200 Pro 官方展示](https://www.vivo.com.cn/vivo/x200pro/)
- [荣耀 Magic7 Pro 官方展示](https://www.honor.com/cn/phones/honor-magic7-pro/)
- [一加 13 官方展示](https://www.oneplus.com/cn/13)

本站若在照片上做鼠标视差或角度切换，只代表照片交互，不应标注为“官方360模型”。iPhone X 提供独立正面、背面照片；小米15的两张都是正面不同视角，不能标成背面。

## 参数录入规则

`phoneCatalog` 仅保存品牌可核对的机型、发布年份、处理器、内存、存储、屏幕、重量、系统家族与配置。Apple 参数页未公布的RAM保持null。新旧价格全部null；没有把历史首发建议价当作今天的市场报价。续航、相机细节或当前系统支持范围未统一整理的字段，应明确“请核对官方规格”，不从图片推断。欧洲版Galaxy S24处理器与国行不同，当前记录明确标注地区。vivo X200 Pro蓝色为228g；223g是黑色，不混用。

### 两款无图机型的核验记录

- **iPhone 18 Pro**：2026-10-16实际读取 [Apple 2026年9月官方发布稿](https://www.apple.com/newsroom/2026/09/apple-debuts-iphone-18-pro-and-iphone-18-pro-max/) 及 [Apple 中国大陆官方规格](https://www.apple.com.cn/iphone-18-pro/specs/)。规格页分别列明256GB起步、211g、6.3英寸2622×1206 OLED、最高120Hz和A20 Pro；这些数值来自已打开的官方页面，没有按上代参数推演。尚无核实为本站可分发的外观摄影，图片字段留空，RAM仍为null。
- **vivo X200 标准版**：核对 [vivo中国大陆产品参数](https://www.vivo.com.cn/vivo/param/x200) 与 [vivo香港官方参数](https://www.vivo.com/hk/zh/products/param/x200?id=9250)：天玑9400、6.67英寸屏，黑色197g、其他部分颜色202g。当前配置明确选辰夜黑。X200 Pro宝石蓝照片没有映射给标准版，两者分别建档。
