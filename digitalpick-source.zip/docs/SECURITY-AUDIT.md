# 部署安全检查

日期：2026-10-17；检查对象为本机 未域 ELVORA 项目、当前生成的静态资源与最终源码包。本文件不包含密钥明文。

## 密钥与历史

- DeepSeek Key 曾由维护者粘贴在本次聊天中，存在暴露风险。**上线前撤销旧 Key、创建新 Key，只通过 Cloudflare Secret 输入。** 不要把新值发回聊天。
- 本机 `.env.local` 是忽略文件，权限 600；没有将它复制到 Worker 配置、静态构建目录或源码分发包。本轮未替用户轮换、删除或停用凭据。
- `npm run check:secrets` 检查源码、公开资源及生成产物，匹配常见模型 / GitHub token 格式，并私下对照本机 API / 会话 Secret 的完整值；输出仅包含文件路径，不打印值。
- 当前项目根目录没有 `.git`。因此无法检查任何本地历史提交，也无法证明以前没有上传过密钥；本轮没有可核验的远端历史。扫描脚本在以后有仓库时会检查 `git rev-list --all` 可达提交。
- 扫描不覆盖远端仓库、聊天、截图文字 OCR、无法访问的历史、reflog / 悬空对象、平台日志或已分享的旧文件。ZIP 另做了解包内容检查；扫描结果不等于不存在任何类型的秘密。
- 本机 Node standalone 输出可能包含环境文件，所以仅分发排除构建缓存的源码包；不能直接打包整个 `.next`。

若密钥曾进入 Git，先撤销密钥，再按 [GitHub 删除敏感数据流程](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/removing-sensitive-data-from-a-repository) 处理。删除当前文件、改成私有或重写历史均无法让已泄露的 Key 恢复安全。

## 修复后的边界

- API Key / 签名 Secret 由 Worker 服务端读取，前端只知道公开代理地址与短期匿名会话。
- 固定 DeepSeek HTTPS 上游，禁止重定向；用户不能指定上游 URL、模型、system 角色或额度。
- 精确 CORS 白名单、JSON 类型检查、流式请求体上限、800 字 / 8 条历史、35 秒超时与中止处理。
- HMAC 会话、按日变化的 IP 摘要、每分钟 / 每日限制、全站次数和 token 预留。
- 单个 SQLite Durable Object 事务统一预留，跨 Worker 实例 / 重启持久；存储失败返回 503。日期索引减少旧数据清理的扫描。
- 上游错误不透传敏感原文，不自动重试；回复需通过 JSON、产品 ID、价格与链接约束。
- Worker 观测日志默认关闭，代码不记录对话正文。供应商及平台仍按各自政策处理数据。
- GitHub Actions 仅接收公开 Worker URL，不接收模型 Key 或 Cloudflare 管理 Token。静态构建不加载根目录的环境文件。

匿名限流不是身份认证。Origin 可被非浏览器伪造，新建会话可绕过单会话计数，IP 可共享或变动；全站额度仍限制本站此实例的每日调用。多个 namespace / 另建部署不共享额度，不应通过重建资源重置计数。本项目不是通用付费 API 转发服务。

## 验证与未验证

已通过 Worker 边界 / 错误 / 配额测试、真实本地 workerd 的 SQLite 并发与重启验证、浏览器跨端口聊天验证、静态路径与资源检查。具体命令与数量见 [验证记录](VERIFICATION.md)。

浏览器与 Worker 集成使用明确标注的模拟模型响应；本轮未发送真实付费推理请求，未发布 GitHub Pages / Cloudflare 公网资源，未验证真实账号余额、云端 CPU、微信网络及平台侧日志。旧的真实调用记录不能替代本轮云端验证。

完整配置及上线检查：[免费部署步骤](FREE-DEPLOYMENT.md)。
