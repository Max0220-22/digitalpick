# 设备参数素材库与小派检索（2026-10-17）

## 本次结果与边界

- 可浏览资料 1,812 条：37 条已核对字段资料（既有24条 + 新核对13条），1,775条待核验配置素材。不是1,812个独立机型。
- 待核验配置：手机699、平板84、笔记本992。来源品牌标签共32个，可能包含上游解析不规范标签，不宣称32个已认证品牌。
- 手机按上游年份收录2021—2025，另保留2017—2020部分Apple；年份精度仅到年，2021年滚动五年边界无法确认。部分2026新品由官方记录补入。
- 所有992条笔记本缺发布日期，不把采集年份冒充发布年份。完整覆盖标志固定为false，详见lib/library/import-report.json。
- 未添加图片，删除全部来源售价、评分；不把发布价、海外价格或待核验参数用于预算推荐。

## 来源审查

1. Mobiles Dataset (2025), Abdul Malik, Kaggle v1，API元数据许可证Apache-2.0，原始更新时间2025-02-18。固定HF镜像commit：82da805626c6693541daada6c4a50fedb4d21e87；CSV原始sha256见public/library-licenses/NOTICE.txt。原始930条，排除范围外135条、完全重复12条，保留783条手机/平板配置。
2. abhinavflac/laptops-specs-dataset，commit 79f2b96d4382598eb31f230e278b01a18b117176；processed CSV共992条。LICENSE是MIT，README另称数据CC0，两项如实保留。印度市场配置、CPU/GPU解析、保修信息均未逐条核验。
3. 13条补充官方资料逐条保留页面、地区、事实字段与日期，包括iQOO 13印度版、OnePlus 13美国版、小米Pad7菲律宾版、iPad Air 11 M3/M4、iPad Pro11 M4、MatePad11.5(2025)拉脱维亚版、小米17国际版、Galaxy S26系列新加坡版、MacBook Air13/15 M5。
4. 没有导入GSMArena镜像。即使抓取器代码标MIT，原站条款限制资料再发布；抽查JSON还发现Type/Video等同名字段被覆盖，不能称作完整规格。未运行任何抓取器、绕过限制或使用仓库中外泄的第三方凭据。
5. Wikidata CC0批量查询超时，没有虚报为已导入。

## 数据分层

- data/library-sources/*.csv：去价格与评分的固定快照；不在构建时联网。
- scripts/import-device-library.py：Python标准库离线导入器，确定性ID、去重、年份筛选、字段上限、已知冲突标记。
- lib/library/archive.json：所有待核验字段，review=pending；不被Worker导入，不进入AI上下文。
- lib/library/reviewed.ts与reviewed-additions.json：仅事实字段，保留容量组合、地区及标称测试条件。既有示例价和用途评分不进入这部分。
- lib/library/sources.ts、import-report.json和public/library-licenses/：许可、修订、缺口与原始/清洗后哈希。
- /library/：搜索、类别/品牌/年份/状态筛选，30条一页，详情与来源深链接，默认已核对字段。待核验详情明确警告，不提供AI解释按钮。

## 小派升级

没有更换或训练DeepSeek模型权重，继续使用deepseek-v4-pro。升级的是应用检索、输入理解和对话策略：

- 检索只扫描37条核对资料，最多提供3条，不整库塞进模型。
- 中文别名与iPhone家族简写；Pro/Ultra等变体不能回退到标准版。
- 简短追问从最近用户提到的机型继承；新型号覆盖旧机型，明确换话题时清除继承。助手历史不是设备事实来源。
- 同名地区版本保持分离，国行/美版明确时筛选地区，不合并硬件参数。
- 参数、比较、知识和购买咨询分别安排回应任务。参数问题不用先填预算；比较不得缺实测却编帧率或续航排名。
- “预算两千”“预算2k”“预算2.5k”可解析；“两千五”“一万二”“四五千”与预算区间仍需澄清；2K屏幕、120Hz、内存和重量不当成金额。
- 价格与购买候选仍走已有硬预算/可靠报价规则。新参数资料不是预算合格候选。
- 模型格式不合格时按本轮核对参数接续，明确标成本地规则，不重试收费请求。
- 免费会话GET增加knowledgeVersion=library-20261017-v1，供发布验收；不会返回API Key。

## 验证与维护

- npm run typecheck && npm run typecheck:worker && npm test：92项行为测试，包括现有82项和新增10项；本地阶段不调用真实模型；线上验收单独执行并报告。
- npm run build:pages && npm run check:pages：静态导出，路径前缀/digitalpick；本次构建47个HTML、1964个本地引用。
- npm run check:worker:local：实际workerd、跨域、并发限流及额度重启持久化，模拟模型。
- npm run check:secrets；独立扫描发布源码ZIP。完整Git历史不是本次重新审计范围。
- 离线重建：python3 scripts/import-device-library.py。会更新archive与报告；如改变事实审核状态，应先核对具体地区和配置，补来源，再加入reviewed-additions.json，不能直接把pending批量改为reviewed。
- 修改后分别部署Worker和GitHub Pages。模型Secret和额度数据保留，无需新账号或密钥。

## 仍缺什么

没有找到可免费合法复用且覆盖近五年所有品牌、所有配置与参数的全量源。手机来源多数停留2025年前，2026、国行差异、笔记本日期与冷门品牌仍需补录。这个缺口不能用未经核验的大量记录冒充完成，也不能通过给模型更长提示词解决。
