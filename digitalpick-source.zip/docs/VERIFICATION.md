# 当前版本验证：小派多轮对话修复（2026-10-17）

- 前端 / Worker类型检查、74项测试通过。新增14项围绕截图两轮、金额误拦截、游戏与短答、错误接续和历史边界。
- Node生产构建44个HTML / 1747条引用；Pages生产构建45个HTML / 1802条引用，路径检查通过。
- Worker dry-run与真实本地workerd额度并发 / 重启测试复测通过；重启后的Node预览44个路由、404、响应头及API输入边界HTTP检查通过。
- 390px浏览器复现“预算2000，打游戏 → 王者荣耀 → 不接受”；模拟不合规回复被明确标成“本地整理”，预算与游戏保留；第三轮链接为只考虑全新。
- 320 / 390px无整页横向溢出；无浏览器error，既有Three.Clock弃用warn仍存在。
- 未训练模型、未新增真实付费推理、未发布云端。截图采用模拟上游，不能当成真实模型质量评测。
- [修复说明](CONVERSATION.md) · [浏览器截图](screenshots/dialog-recovery-mobile.png)。

以下为历史验证记录。

---

# 当前版本验证：GitHub Pages + Cloudflare Worker（2026-10-17）

本轮保留页面与推荐功能，新增免费托管目标；下方为本轮实际检查结果，后续章节属于历史记录。

| 检查 | 结果 |
| --- | --- |
| `npm run typecheck` | 通过 |
| `npm run typecheck:worker` | 通过 |
| `npm test` | 60 项通过，0 失败 |
| `npm run build && npm run check:site` | Node 版通过，44 个 HTML、1747 条内部引用无失效路径；原 API 仍是动态路由 |
| `npm run build:pages && npm run check:pages` | 通过，45 个 HTML、1802 条内部链接 / 资源引用无失效路径 |
| `wrangler deploy --dry-run` | 正式 Worker 打包与绑定检查通过，未部署云端 |
| `npm run check:worker:local` | 真实本地 workerd + SQLite：10 个并发请求只放行 2 个，重启后仍拒绝超额；日期索引加入后复测通过 |
| 静态服务器 HTTP 检查 | 45 个 HTML 均返回 200；未知路径返回 404；Worker health 正常 |
| `npm run check:secrets` | 源码与生成资源未发现受支持的凭据模式或本机实际凭据值；无本地 Git 历史可查 |
| npm 安装安全审计 | 0 vulnerabilities（安装时结果，不代表长期安全保证） |

静态构建验证使用 `/digitalpick` 仓库子路径，公开 AI 地址为本地模拟 Worker。**当前 `out-pages` 是 localhost 联调产物，不能直接发布**；GitHub 工作流使用正式配置重新构建。

浏览器验证：

- 320 / 390 / 768 / 1440px 首页无整页横向溢出，星河和角色两个 Canvas 存在；未改写原有 3D 与动画实现。
- 390px 聊天抽屉完成跨端口状态查询、匿名 Bearer 会话与问答返回，条件链接正确带 `/digitalpick/`。
- 回复明确标注“本地接口模拟验证”，没有把模拟结果描述为真实 DeepSeek 推理。本轮没有付费模型请求。
- 首页表单搜索 iPhone X 跳转带前缀的产品库；购买方式 Radix 菜单可选二手，再恢复完整库；无报价设备不会混入演示报价筛选结果。
- iPhone X 详情可刷新；实拍 SVG 的图片路径为带前缀的本地 WebP；素材说明和下一步链接正确。
- 手机五步问答完成：5000 总预算、只考虑二手、日常使用、无额外硬配置，得到两款演示结果，购买方案上限不超预算；缺价 / 过期 / 能力不足仍排除。
- 验机屏幕通过、账号锁异常，摘要为 1 / 1 / 8 并提示暂停交易；刷新后保留，测试记录已通过页面确认清理。
- 查看控制台未发现 error；存在既有 R3F / Three `THREE.Clock` 弃用 warn，未隐藏它。
- 未进行实体手机、微信内浏览器、Safari / Firefox 的新增实机验收，也未验证云端 CPU / 免费限额或公网线路。

新增 Worker 测试覆盖：精确 CORS 与预检、无效 / 过期签名、未配置状态、请求体 / 历史 / 长度、共享规则、模型产品 ID / 金额 / 外链拒绝、上游错误、超时且不退额度、无自动重试、会话 / IP / 全站 / token 额度、UTC 切换和存储故障停止调用。

截图（本地静态版）：

- [390px 跨域模拟聊天](screenshots/free-worker-chat-mobile.png)
- [1440px 静态星河首页](screenshots/free-pages-home-desktop.png)

部署：[免费部署步骤](FREE-DEPLOYMENT.md)；密钥与 Git 历史范围：[安全检查](SECURITY-AUDIT.md)。源码包排除凭据、数据库、依赖与构建目录，并另行检查 ZIP 内容。此前在聊天中分享过的 Key 仍须轮换。

---

# 当前版本验证：研究来源与推荐规则 v2（2026-10-16）

- `npm run typecheck`、`npm test` **46项**、`npm run build` 全部通过。新增17项覆盖逐用途门槛、未知能力、主用途、预留、全新/二手取舍、AI同规则筛选及对话条件边界。
- 最终生产构建44个HTML，`npm run check:site` 检查1749个内部链接/资源引用，无失效路径。
- `node scripts/check-http.mjs` 实际访问最终standalone生产服务：44个预渲染路由、404、响应头与API输入边界通过。没有新增付费模型请求、训练或微调。
- 浏览器走通手机五步问答：预留等于总预算时“下一步”禁用；总预算5000、预留500、日常+续航、续航为主用途、更重低价时，显示2款演示结果。每款同时保留合格的全新/二手方案，上限加预留均不超预算。
- 实际操作主用途玻璃菜单，将日常切换为续航；结果正确保留主用途与预留。URL预填的笔记本10000、预留500、游戏+学习+日常办公完整走通后无结果；展开排除说明，Air与Pro均因游戏低于3/5被排除。
- 结果页与研究页在320 / 390 / 768 / 1440px均无整页横向溢出。研究页共17张来源卡（10条YouTube简介、6条Reddit正文、1条未核实X线索）、6条编辑原则；修正桌面标题字号后重新构建并复查四档宽度。
- iPhone15详情展示同型号历史评测的公开简介、日期与限制，明确不适用于Pro/ProMax、当前二手成色或未经核实的配置。浏览器未发现error；R3F/Three的Clock弃用warn沿用此前记录。
- 独立只读复核确认：最多2000/预算降到2000覆盖旧预算；还需要续航保留游戏；主要拍照不误变为游戏；硬品牌未确认时阻止候选；180克正确解析；XS Max/X200 Ultra/16e不回退页面标准版；问答交接保留完整已确认条件。
- 研究使用原作者链接与社交原帖，范围见下方记录。YouTube完整字幕未取得；Google搜索页和X正文/互动量访问受限，没有核实全网最高赞排名。社交互动快照不计入任何推荐分；现有用途等级仍为旧编辑判断，未从简介编造新机分数。
- 当前所有数字报价仍为演示数值，正式AI没有可靠报价候选；用受控非演示测试样本验证共享规则，不将测试数据写入真实产品库。
- 本机预览用于验收后关闭；未发布公网。真实手机硬件、Safari/Firefox、Docker与Cloudflare适配未在本轮新增验收。
- 最终源码包排除环境文件、额度数据库、依赖与构建产物；前端与源码包扫描未发现本机实际密钥值。

生产截图：

- [桌面推荐结果](screenshots/recommendation-v2-desktop.png)
- [手机购买方案与完整预算](screenshots/recommendation-v2-mobile.png)
- [用途不足与排除原因](screenshots/recommendation-v2-empty.png)
- [推荐方法与研究来源](screenshots/research-methodology-desktop.png)

[推荐规则与维护](RECOMMENDATION.md) · [MKBHD研究范围](research/mkbhd-research.md) · [社交研究范围](research/social-research.md)

以下为历史版本记录。

---

# 当前版本验证：流动星河与液态玻璃（2026-10-16）

- `npm run typecheck`、`npm test` **29项**、`npm run build` 全部通过。
- 生产构建43个HTML，`npm run check:site` 检查1648个内部链接/资源引用，无失效路径。
- `node scripts/check-http.mjs` 实际请求本机 standalone 生产服务：43个预渲染路由、404、响应头与API输入边界通过。本轮没有发起付费模型调用。
- 320 / 390 / 768 / 1440px首页宽度检查通过，手机产品库与详情在320 / 390px无整页横向溢出。截图为生产版本；真实手机硬件和Safari / Firefox尚未实机验收。
- 生产浏览器确认3D渲染、设备焦点切换、点击脉冲计数增加、星河暂停/恢复；暂停时 `data-motion=still`，小派 `data-motion=off`。
- 手机尺寸鼠标指针拖动角色后没有打开聊天，显示轻触导览提示。小派2D模式时角色Canvas为0，星河Canvas仍为1；恢复后动态可运行。
- 手机购买方式玻璃菜单正确打开并选中“二手参考”，结果为6款有对应演示价的设备。折射绘制已裁切到控件边界，文字不被位移处理。
- 24款产品主图映射到已核对官方来源；最终24条图片URL全部HEAD 200且MIME为image/*，原始核验记录见 [official-media-check.json](official-media-check.json)。可用性不等于图片版权许可或商品库存。
- 4张无遮挡补充实拍使用原照片SVG轮廓遮罩去背景，原作者与CC许可保留。iPad Air图片核对到官方识别页13英寸M2小节；vivo标准版与Pro分别建档。
- 浏览器未发现渲染error；仍有R3F/Three上游Clock弃用warn。没有隐藏该提示。
- 本机Node生产服务与HTTP检查通过；没有云端部署，Docker与Cloudflare适配状态沿用部署说明。
- `.next/static`、`public/` 与源码ZIP扫描无实际密钥值，源码包排除环境文件与额度数据库。本机环境文件权限600。

生产截图：

- [桌面星河首页](screenshots/cosmos-home-desktop.png)
- [手机星河首页](screenshots/cosmos-home-mobile.png)
- [平板首页](screenshots/cosmos-home-tablet.png)
- [手机液态玻璃菜单](screenshots/cosmos-menu-mobile.png)
- [手机官方主图](screenshots/cosmos-product-mobile.png)
- [原片去背景实拍](screenshots/cosmos-photo-cutout-mobile.png)

官方图使用边界：[OFFICIAL-MEDIA.md](OFFICIAL-MEDIA.md)。以下为历史阶段记录，不代表本轮仍以门店实拍作为主图。

---

# 当前版本验证：深色首页与 DeepSeek（2026-10-16）

- `npm run typecheck` 通过，`npm test` **27 项通过**，`npm run build` 通过。
- 生产构建预渲染43个HTML，`npm run check:site` 核对1677个内部链接/资源引用，无失效路径。
- `node scripts/check-http.mjs` 实际请求本机 standalone 生产服务，43个预渲染路由、404、响应头、API错误格式/过大请求/跨站来源拒绝均通过；该检查不调用模型。
- DeepSeek官方 `/models` 实测账户可用 `deepseek-v4-pro`；开发版与 standalone 生产版各完成一次真实对话，均未用演示价给出“预算内可买”的推荐。没有自动付费重试。
- 前端 `.next/static`、`public/` 扫描无密钥值；本机环境文件权限600。源码包排除环境文件、`.data`、构建目录和依赖。
- 首页在320、390、768、1440px宽度检查无横向溢出；390px聊天抽屉宽390、高度底部为844，与视口匹配。真实手机键盘和硬件尚未实机测试。
- 实际操作品牌筛选、玻璃菜单选中、五步问答购买方式卡片、首页设备切换与方向键、iPhone X正背面照片切换、手机拖动不误开聊天。
- 24款资料设备、20款设备图像映射、22张本地WebP（约1.21MB）；缺图型号明确占位，来源与许可可见。没有重分发无许可官方旋转动画。
- AI额度测试涵盖全站、匿名会话、保守token预留、UTC跨日、错误JSON、未知与重复产品ID、金额与任意外链拒绝、旧预算覆盖保护。
- 上游R3F/Three仍可能产生 `THREE.Clock` 弃用提示，未出现渲染错误。没有屏蔽日志。Docker配置已提供，但未运行镜像验收；Cloudflare额度适配尚未实施。

当前截图：

- [桌面首页](screenshots/night-home-desktop.jpg)
- [手机首页](screenshots/night-home-mobile.jpg)
- [平板首页（已修复深色字号优先级）](screenshots/night-home-tablet.jpg)
- [手机玻璃菜单](screenshots/night-menu-mobile.jpg)
- [购买方式卡片](screenshots/night-purchase-choice-mobile.jpg)
- [手机真实AI对话](screenshots/night-ai-mobile.jpg)
- [iPhone X详情](screenshots/night-product-mobile.jpg)

下方保留前两阶段历史记录；其中纯静态 `out/`、20项测试或“AI待接入”等仅描述历史版本，不是当前部署方式。

---

# 验证记录

日期：2026-10-16。环境：macOS、Node.js 26.8.1、npm 11.19.0。浏览器测试使用本地生产静态导出预览，未访问部署账号或发布到公网。

## 自动检查

| 检查 | 结果 |
| --- | --- |
| `npm run typecheck` | 通过，无 TypeScript 错误 |
| `npm test` | 12 项通过，0 项失败 |
| `npm run build` | Webpack 生产构建通过，27 个生成任务完成 |
| `npm run check:export` | 26 个 HTML、744 个内部链接 / 资源引用，0 个失效路径 |
| npm 安装 / 锁文件同步时的安全审计 | 0 vulnerabilities |

核心测试覆盖 3 类设备 × 6 个预算 × 3 种购买方式组合；另外验证区间上限、缺失 / 过期 / 未来报价、硬配置、品牌软偏好、用途不足、非法价格、演示差价禁止、链接白名单及验机统计。

## 浏览器验证

- 320px：首页、产品列表、产品详情、问答、渠道、验机、文章列表 / 详情、对比、关于，共 10 类页面没有整页横向溢出。对比表保留容器内的横向滚动。
- 390px：实际查看浅色首页、深色产品列表、移动菜单、验机和推荐结果，布局正常。
- 768px：首页、产品列表、问答、MacBook 详情、渠道完成宽度检查；发现并修复首页装饰轨道造成的 7px 溢出，复查首页宽度为 768 / 768。
- 1440px：相同关键页面完成宽度检查，桌面首页完整截图留存。
- 问答：2000 元 / 二手手机 / 日常使用时明确无结果；改为 2500 元后只推荐价格上限为 2500 元的 Xiaomi 14，规则分 88，未超预算。
- 用途未选时“下一步”禁用，选择后可继续。
- 产品列表搜索 Xiaomi，手机分类显示 1 款设备。
- 验机：屏幕通过、账号锁异常，生成摘要为 1 通过 / 1 异常 / 8 未查；关键异常出现暂停交易提示。刷新后状态保留，随后清理测试记录。
- 对比：3 款后添加控件禁用，iPhone 15 切换二手显示演示区间，iPhone 13 显示“暂无可靠报价”。
- 实测页面控制台未发现 warn / error。

本记录不代表真实设备评测，不包含实体手机硬件测试或跨所有浏览器的兼容性认证。TXT 下载与剪贴板还受用户浏览器权限影响，复制失败时页面提供可手动复制的文本。

## 截图

- [桌面首页](./screenshots/home-desktop.jpg)
- [完整首页](./screenshots/home-full.jpg)
- [手机首页](./screenshots/home-mobile.jpg)
- [手机产品库 · 深色](./screenshots/products-mobile-dark.jpg)

## 小派 3D 首页版本增量验证

本轮优先实现与首页融合的精灵交互，云端 AI 未接入。

- TypeScript 与最终生产构建通过；总计 20 项逻辑测试通过。
- 最新导出检查：26 个 HTML、809 个内部链接 / 资源引用，0 失效路径。
- 320 / 390 / 768 / 1440px 首页宽度分别与视口一致，未出现整页横向溢出。
- 实际确认 Three.js Canvas 渲染，以及鼠标移动对应的头部朝向与 DOM 视差变化。
- 390px 小屏拖动后显示“轻触我，打开导览”，拖动未误开聊天。该项通过桌面浏览器的小屏指针模拟检查，仍建议补充真机触控试用。
- 轻量 2D 切换后 Canvas 数量为 0，仍可点击角色打开导览。
- 手机抽屉稳定展开时宽 390px，底部位于 844px 视口底端；关闭后恢复页面滚动。未进行实体手机软键盘测试。
- 快捷问题点击后消息数量仍为 0；点击发送才运行本地规则。
- 预算 3000 / 手机 / 二手 / Android 的本地条件成功传到原有选购问答 URL。
- 产品页上下文气泡在首次约 5 秒出现；点击后预填“这款设备适合谁？”，消息数量仍为 0。
- 检查过程中发现透明 WebGL 上叠加模糊滤镜会产生矩形绘制伪影，已移除对应卡片的 backdrop-filter 并复查截图。
- 本轮查看的浏览器记录没有渲染 error；存在 Three.js / R3F 上游 Clock 弃用 warn，详见精灵实现说明。

最新截图：

- [3D 桌面首页](./screenshots/companion-desktop.jpg)
- [3D 手机首页](./screenshots/companion-mobile.jpg)
- [手机导览窗口](./screenshots/companion-chat-mobile.jpg)
- [2D 降级形象](./screenshots/companion-fallback.jpg)

完整功能与后续模型接入边界：[小派实现说明](./COMPANION.md)。
