# 社交测评原帖研究记录

检索日期：2026-10-16。用途：发现真实购买需求、争议与待验证问题；**互动量不参与产品质量评分**。

## 检索范围与可验证性

实际执行了公开网络搜索，查询包括 `site:x.com/MKBHD/status review Likes`、`site:reddit.com/r/iphone iPhone 15 Pro review battery votes`、`site:reddit.com/r/apple M2 MacBook Air review votes`、`site:reddit.com/r/Android review S24 votes`。另尝试直接打开 Google 搜索页 `https://www.google.com/search?q=site%3Ax.com%2FMKBHD%2Fstatus+review+likes`，工具无法读取该页。因此本轮不能称为已读取 Google 原始排名，更不能称为找到全网点赞最高的测评推文。

X 搜索结果可以定位 MKBHD 原帖，但原页读取返回 403 / 登录页面，点赞、转发、浏览量均未核实。没有使用绕过登录的镜像、付费 API 或伪造互动量。Reddit 为补充社交来源，`score` 是平台显示的投票分数，不能当成 X 点赞数或独立购买者人数。下列分数均为工具可读页面/搜索索引的快照，可能滞后、波动，不能代表检索时实时值。

## 原帖样本

| ID | 平台、原始链接与作者 | 发布日期 | 互动指标与可见状态 | 内容可读性与使用限制 |
| --- | --- | --- | --- | --- |
| social-m2-air-config | [MKBHD M2 Air 评测讨论帖](https://www.reddit.com/r/apple/comments/w2e3v8/mkbhd_m2_macbook_air_review_more_than_a_refresh/)，发帖 u/mwest217，主要配置讨论 u/P_S_D | 2022-07-18；主要评论 07-19 | `reddit_score_snapshot:1195`（帖）；配置评论 `735`。搜索结果亲见，原页正文可读但原页指标不可见，`metricSeenOnOriginal:false` | 这是用户分享视频及原创讨论，不是 MKBHD 自己的 Reddit 测评。讨论配置相同时 Air 与 Pro 的价差、轻便与持续负载的取舍。涉及 2022 年美国官翻/新品及其他地区价格，不能写入今日人民币报价。 |
| social-15-pro-positive | [My review of 15 pro](https://www.reddit.com/r/iphone/comments/16wnmn4/my_review_of_15_pro/)，u/InferiorArrears | 2023-10-01 | `reddit_score_snapshot:133`，搜索结果亲见；`metricSeenOnOriginal:false` | 原页正文可读。作者由 12 Pro 升级，自述续航、温度体验较好，也报告 Wi-Fi 问题。单人、非受控测试；地区、系统版本未知，网络/旧机电池条件有争议，不能推广成所有 15 Pro 的续航结论。 |
| social-15-pro-negative | [My iPhone 15 pro battery is trash](https://www.reddit.com/r/iPhone15Pro/comments/16x7etn/my_iphone_15_pro_battery_is_trash/)，作者已删除，`author:null` | 2023-10-01 | `reddit_score_snapshot:113`，搜索结果亲见；`metricSeenOnOriginal:false` | 原帖正文仍可读，仅报告一天续航不足。系统、地区、信号、电池健康、应用负载未提供。与上一条构成相反体验样本，不是故障率调查。评论包含 Pro / Pro Max / Plus，不能混成同一型号样本。 |
| social-15-pro-version | [My experience so far with 15 Pro and addressing concerns](https://www.reddit.com/r/iPhone15Pro/comments/1776cox/my_experience_so_far_with_15_pro_and_addressing/)，u/FoundationOpening513 | 2023-10-13 | `reddit_score_snapshot:83`，搜索结果亲见；`metricSeenOnOriginal:false` | 原页正文及反驳可读。明确普通 Pro、iOS 17.0.3，来自 XS Max。作者对长时间续航的表达受到充电次数与亮屏统计质疑。只提取“版本与使用条件要明确”，不采纳小时数，也不采纳其对他人体验的否定。 |
| social-compact-dimensions | [The End of the 6.1-Inch Era](https://uk.reddit.com/r/iphone/comments/1ofg2hc/the_end_of_the_61inch_era/)，u/S_Karmakar；尺寸讨论 u/squirrelist | 2025-10-25 | 原页快照亲见 `reddit_score_snapshot:208`、`upvote_ratio_snapshot:0.77`、`comments_snapshot:122`；`metricSeenOnOriginal:true`。搜索索引显示 205，差异保留，不择高宣传 | 原页正文与评论可读。关注小屏/单手握持，评论指出屏幕对角线不等于机身宽度。具体尺寸须另查品牌规格，不采纳帖子中的未来机型预测。取舍是手感需求，非大屏产品质量差。 |
| social-s24-migration | [S24 is an amazing phone (iPhone lifer)](https://www.reddit.com/r/samsung/comments/1hjkdqi/s24_is_an_amazing_phone_iphone_lifer/)，u/Boullionaire | 2024-12-21 | `reddit_score_snapshot:197`，搜索结果亲见；`metricSeenOnOriginal:false` | 原页正文可读。首次转 Samsung，提到迁移与键盘适应。新品短期感受，具体 S24 区域 SoC / 系统版本 / 运营商条件未知。可转成“迁移成本/常用软件”问题，不可给全部三星机型加分。 |

以上 6 条原始社交讨论均记录检索日期为 2026-10-16。发布日期来自原页精确日期或搜索索引的明确日期；索引相对“几年前”不作为推算依据。没有独立验证发帖者购机凭据、照片真实性或测试过程。研究是小样本定性阅读，既非系统性抽样也非民意调查。

### X 访问受限样本

[Marques Brownlee 转发自己的 M2 MacBook Air 视频](https://x.com/MKBHD/status/1549380247962935303)：作者 MKBHD，标题索引可读；`publishedAt:null`（本轮未核实原页日期）、`likes:null`、`reposts:null`、`views:null`、`metricSeenOnOriginal:false`。检索日期 2026-10-16。仅作为官方视频线索，不据此归纳视频完整观点，不入产品证据评分。

## 适合推荐引擎的改进

1. **先确认上下文。** 续航区分 Wi-Fi / 移动网络、信号、导航/拍照/视频/游戏、系统版本、是否新机初始化、充电限制、电池健康。不同条件的 SOT 不平均，不转成可跨品牌比较的续航分。
2. **配置、地区和成色必须对应。** 比较同内存/存储、同市场可买的配置；展示官翻、第三方翻新、个人二手的区别。2022 年美区评论价格不成为 2026 年中国报价。未知可靠价格仍不确认符合硬预算。
3. **让小屏需求更准确。** 现有屏幕尺寸筛选可以保留，但推荐解释同时提醒重量、机身宽度和保护壳对握持的影响。缺宽度数据不从屏幕尺寸推算。建议到店握持。
4. **询问当前设备与换机原因。** 旧机电池衰减与新机比较会放大提升感；如果当前设备已经满足软件/安全支持和性能需求，可建议换电池或暂缓购买，不能把年度升级当成默认答案。
5. **系统迁移成本是需求，不是品牌分。** 常用软件、数据迁移、配件兼容和学习成本由用户选择；需具体功能验证，不用单帖口碑替代兼容性证据。
6. **证据与热度分开。** 数据结构记录来源、原帖/评测种类、观察还是推论、发布时间、核验时间、适用型号/配置/地区/版本、限制、冲突与是否已被后续更新替代。社交证据只生成关注点或复查提醒，不直接改变 `useScores`、性能分、可靠性分或品牌排名。

当证据相反时，解释应写“该体验在不同用户/条件下有分歧，请核对自己的使用场景”，不能写“网上都说好/差”。发布时只使用必要的中文概括与原始链接，避免复制原帖正文、用户头像或截取私密信息。
