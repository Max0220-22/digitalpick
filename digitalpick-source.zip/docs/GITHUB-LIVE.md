# DigitalPick 正式上线记录

日期：2026-10-17（北京时间）。

- 网站：https://max0220-22.github.io/digitalpick/
- 源码：https://github.com/Max0220-22/digitalpick
- AI 代理：https://digitalpick-ai.digitalpick.workers.dev
- 架构：GitHub Pages 静态前端 + Cloudflare Worker + SQLite Durable Object。
- 未购买域名或开通付费托管；免费子域名和平台免费额度适用平台条款，DeepSeek 模型调用另计费。

## 验证结果

GitHub Actions 完整构建和 Pages 发布成功。公网直接访问首页、选购、产品库、iPhone 15 详情、验机、购买渠道、文章页均返回 HTTP 200；Safari 确认星河、3D 小派和聊天可打开。76 项本机测试通过，Worker TypeScript 检查通过。

线上首次验收发现 workerd 不支持 `redirect: "error"`。已在真实 workerd 用无凭据 HEAD 请求复现错误，`manual` 返回官方 API 的 401，随后修复为 `manual` 并拒绝所有非成功响应，不跟随跳转、不向其他域名转发凭据。修复发布版本：607d5d48-e6f8-4372-9ba7-b6ac9b723508。

经用户批准，修复后进行了两次模型请求：第一轮“预算2000，打游戏”得到真实 DeepSeek 回复；第二轮“王者荣耀”触发资料校验，明确转为本地整理，保留预算、游戏和下一问。未为资料校验失败自动重试模型。产品报价仍是演示数据，AI 不提供未经验证的预算内商品承诺。截图见 `screenshots/live-home.png` 和 `screenshots/live-chat.png`。

## 当前配置和维护

Cloudflare 中 `AI_API_KEY` 与 `AI_SESSION_SECRET` 均为加密 Secret；误建的明文变量已删除。`AI_ENABLED=true`，允许来源只有 `https://max0220-22.github.io`。GitHub Actions Variable `AI_PROXY_URL` 只包含公开 Worker 地址，不包含密钥。

每日全站最多30次、每会话10次、每IP20次，每IP每分钟6次；另有每会话分钟限制及全站每日180000的保守token预留。失败也保留预留，UTC跨日（北京时间08:00）重置。持久化额度不会因发布或进程重启清空。调用费以 DeepSeek 账单为准。

本地 `wrangler.toml` 默认关闭 AI，避免新部署意外计费。更新已上线代理时，确认保留两个 Secrets，使用 `npm exec -- wrangler deploy --var AI_ENABLED:true`。普通 `npm run deploy:worker` 会按安全默认值关闭在线 AI。

当前仓库通过浏览器上传完整 `digitalpick-source.zip`，Actions 解压后构建。修改本地源码后应重新生成不含 .env、.dev.vars、密钥、缓存、依赖、数据库和构建产物的源码包，再上传覆盖同名文件；不要只修改压缩包外的不存在的源码目录。

密钥曾被发到聊天中，建议在试用后轮换，再通过 Wrangler 隐藏输入更新 Cloudflare Secret；不要再次粘贴到聊天或 GitHub。轮换不需要重建静态前端。
