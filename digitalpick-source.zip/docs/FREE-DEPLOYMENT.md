# 免费部署：GitHub Pages + Cloudflare Workers

核验日期：2026-10-17。源码已经适配此架构；尚未在你的 Cloudflare / GitHub 账号创建资源或发布公网版本。

## 为什么原来不能部署

现有项目是 Next.js App Router + React + TypeScript + Tailwind，首页、小派和星河使用 Three.js / R3F。默认构建为 `output: "standalone"`，需要 Node 服务。`app/api/assistant/route.ts` 使用 Node 内置 SQLite 在本机持久磁盘预留额度，聊天请求写死同源接口。GitHub Pages 只能提供静态文件，无法执行该 API；Worker 也不能直接使用这一份本机 SQLite 文件。

现在保留原有 Node 版本，增加独立静态构建和 Web API 版 Worker，无需迁移框架或重写页面：

```mermaid
flowchart LR
  A[朋友的浏览器] --> B[GitHub Pages 静态页面与 3D 小派]
  A -->|HTTPS + 签名会话| C[Cloudflare Worker]
  C -->|事务预留额度| D[SQLite Durable Object]
  C -->|服务端 Secret| E[DeepSeek 官方 API]
```

`build:pages` 只在隔离目录中排除 Node API，原文件没有删除。Worker 与网页共用输入校验、推荐规则、研究上下文及回复审核。无可靠非演示价格时仍不会生成预算内可买的虚假推荐。

## 费用与域名

| 项目 | 方案与费用 |
| --- | --- |
| 前端 | GitHub Free 的公开仓库可使用 Pages；平台分配 `用户名.github.io/仓库名/` 地址，无需购买域名 |
| AI 代理 | Workers Free 免费额度内为 0；使用平台分配的 `workers.dev` 地址 |
| 持久计数 | Workers Free 支持 SQLite Durable Objects，本项目已使用这种类型 |
| DeepSeek | 仍按实际输入 / 输出 token 计费，托管免费不代表模型免费 |
| 自定义域名 | 可选，不属于本方案必要开支 |

当前官方限额：Worker Free 每日 100,000 请求、每次 10ms CPU；SQLite Durable Objects Free 每日 100,000 请求、500 万行读取、10 万行写入，总存储 5GB。多服务共享账号额度；触及免费限额时相关操作会失败，本项目额度服务失败会停止模型调用。IO 等待与 CPU 时间不同，云端 CPU 消耗还需上线后观察。不要为了部署切换到付费计划或扩大额度。

以上不是永久服务承诺，政策可能变化。依据：[GitHub Pages 创建说明](https://docs.github.com/en/pages/getting-started-with-github-pages/creating-a-github-pages-site)、[Worker 限额](https://developers.cloudflare.com/workers/platform/limits/)、[Durable Objects 计费](https://developers.cloudflare.com/durable-objects/platform/pricing/)、[DeepSeek 计费](https://api-docs.deepseek.com/quick_start/pricing/)。

## 1. 准备源码和新密钥

本机项目在 `/Users/a123/Desktop/网站`。推荐 Node.js 24 LTS，先运行：

```bash
npm ci
npm run typecheck
npm run typecheck:worker
npm test
npm run check:secrets
```

你此前在聊天里贴过 DeepSeek Key，**上线前必须去 DeepSeek 控制台撤销旧 Key，并创建新 Key**。不要再次粘贴到聊天、代码、终端命令参数或 GitHub 前端变量。当前检查未发现它进入源码 / 静态包，但不能因此认定旧 Key 安全。完整边界见 [安全检查](SECURITY-AUDIT.md)。

本机环境文件、数据库、构建缓存均被忽略。不要上传整个工作目录、`.next/standalone` 或旧 `out/`，也不要把环境文件放进源码 ZIP。

## 2. 部署 Cloudflare Worker

先由你在 Cloudflare 注册 / 登录并选择 Workers Free；账号条款、验证码与授权需你本人完成。不需要购买服务器或添加域名。

```bash
npm exec -- wrangler login
```

编辑根目录 `wrangler.toml`：

```toml
name = "digitalpick-ai"
# 保留文件中原有 main、compatibility_date、bindings、migrations 等设置

[vars]
AI_ENABLED = "false"
AI_MODEL = "deepseek-flash"
ALLOWED_ORIGINS = "https://你的GitHub用户名.github.io"
AI_DAILY_CALL_LIMIT = "30"
AI_USER_DAILY_LIMIT = "10"
AI_DAILY_TOKEN_LIMIT = "180000"
AI_IP_DAILY_LIMIT = "20"
AI_IP_MINUTE_LIMIT = "6"
AI_USER_MINUTE_LIMIT = "3"
```

这里只是需要修改的片段，不是完整文件。`ALLOWED_ORIGINS` 必须是最终网页的 **origin**，不带 `/digitalpick/` 路径、不带结尾斜杠。多个明确 origin 用英文逗号隔开；不允许通配符。自定义域名时填该域名。默认占位域名必须替换。

先以 AI 关闭状态部署，创建 Worker 和 SQLite Durable Object：

```bash
npm run deploy:worker
```

保存命令返回的实际地址，例如 `https://digitalpick-ai.你的子域.workers.dev`。本文示例地址不能直接使用。

随后通过交互输入新 Key：

```bash
npm exec -- wrangler secret put AI_API_KEY
```

在提示符里输入轮换后的 Key。不要把值写在命令后面。生成并直接传入随机会话签名 Secret，不显示明文：

```bash
node -e "process.stdout.write(require('node:crypto').randomBytes(32).toString('hex'))" | npm exec -- wrangler secret put AI_SESSION_SECRET
```

确认两项 Secret 已存在，再把 `wrangler.toml` 中 `AI_ENABLED` 改为 `"true"`，执行：

```bash
npm run deploy:worker
```

普通变量可公开，两个 Secret 只能保留在 Cloudflare 服务端。Worker 不需要 `AI_BASE_URL` 或 `AI_QUOTA_PATH`；上游地址固定为 DeepSeek 官方 HTTPS API。不要提交 `.dev.vars`。

不要改动 `AI_QUOTA` 绑定、`AIQuota` 类名、原有 `v1` migration，或代码内 `digitalpick-global-quota-v1` 对象标识来“刷新额度”。同一个 Worker / namespace 的普通更新会保留计数；删除资源或另建 namespace 会产生新额度存储。存储不可用时会返回 503，不绕过额度直连 DeepSeek。

紧急停用：将 `AI_ENABLED="false"` 后重新部署；规则、产品库和验机仍可用。

## 3. 发布 GitHub Pages

在 GitHub 创建一个空的 **公开** 仓库，例如 `digitalpick`。GitHub Free 下私有仓库不适用这里的免费 Pages 路线。公开前确认资料和素材的使用边界，勿把凭据上传。

当前目录没有 `.git`，以下初始化命令只适用于这一状态；如果以后已有仓库，不要重复初始化或覆盖远端：

```bash
git init -b main
git add .
git status --short
npm run check:secrets
git diff --cached --name-only
git commit -m "Add 未域 ELVORA static frontend and secure AI Worker"
git remote add origin https://github.com/你的GitHub用户名/digitalpick.git
git push -u origin main
```

提交前确认列表没有 `.env.local`、`.dev.vars`、`.data/`、`.next/`、`.deploy/`、`out-pages/`、旧 `out/`、ZIP、`node_modules/`。若某文件曾被跟踪，单靠 `.gitignore` 不会移除历史；先轮换凭据，再按 GitHub 官方流程处理泄露历史，不要盲目强制推送。

GitHub 设置：

1. 仓库 **Settings → Pages → Build and deployment → Source** 选 **GitHub Actions**。
2. **Settings → Secrets and variables → Actions → Variables → New repository variable**：
   - 名称 `AI_PROXY_URL`
   - 值为刚得到的 Worker HTTPS 地址，不能是 API Key。
3. **Actions → Publish DigitalPick frontend → Run workflow**，选择 `main`。如果首个 push 在设置前失败，设置好后重新运行即可。
4. 等待 `build`、`deploy` 成功，在部署结果或 Pages 设置页打开真实站点地址。

仓库已包含 `.github/workflows/pages.yml`，不需要上传 `out-pages` 到分支。流程自动执行安装、类型检查、74 项测试、密钥扫描、静态构建与路径检查，再发布产物。`actions/configure-pages` 自动确定仓库路径和 SEO 地址：

| 仓库 | 典型公开地址 | 构建 basePath |
| --- | --- | --- |
| `digitalpick` | `https://用户名.github.io/digitalpick/` | `/digitalpick` |
| `用户名.github.io` | `https://用户名.github.io/` | 空 |

原生图片、SVG 实拍遮罩、首页搜索和文章链接已处理该路径。不要手动在 Next Link 中再拼一次仓库名前缀。

GitHub Actions 不需要任何 DeepSeek Secret，也无需 Cloudflare 管理 Token；Worker 在本机用 Wrangler 独立发布。更新 Worker / 共享推荐数据后须重新执行 `deploy:worker`，推送 GitHub 仅更新前端。

## 4. 环境变量位置

| 名称 | 放在哪里 | 是否公开 |
| --- | --- | --- |
| `AI_API_KEY` | Cloudflare Worker Secret | 否 |
| `AI_SESSION_SECRET` | Cloudflare Worker Secret，至少 32 字符 | 否 |
| `AI_ENABLED`、`AI_MODEL`、额度 | `wrangler.toml` 的 vars | 是 |
| `ALLOWED_ORIGINS` | Worker vars，最终网页 origin | 是 |
| `AI_PROXY_URL` | GitHub 仓库 Actions **Variable** | 是，仅 Worker URL |
| `NEXT_PUBLIC_AI_PROXY_URL` | 工作流把上项传给构建 | 是 |
| `NEXT_PUBLIC_BASE_PATH`、`NEXT_PUBLIC_SITE_URL` | 工作流自动提供 | 是 |

所有 `NEXT_PUBLIC_*` 都会进入浏览器。构建脚本拒绝明显命名为公开 API Key / Token / Secret 的变量，但仍须检查配置值。静态构建不复制本机环境文件，并移除传给子构建进程的 AI / Cloudflare 服务端变量。

## 5. 上线验证

先验证 Worker，不产生模型费用：

```bash
curl -i https://你的Worker地址/health
curl -i -H 'Origin: https://你的GitHub用户名.github.io' \
  https://你的Worker地址/api/assistant/
curl -i -X OPTIONS \
  -H 'Origin: https://你的GitHub用户名.github.io' \
  -H 'Access-Control-Request-Method: POST' \
  -H 'Access-Control-Request-Headers: content-type,authorization' \
  https://你的Worker地址/api/assistant/
```

预期健康检查 200；状态接口 `enabled:true`，返回短期 `sessionToken`，**不会返回模型 Key**；预检 204 且 `Access-Control-Allow-Origin` 为准确的网页 origin。未知 origin / 无 Origin 的 AI 请求为 403。状态查询只扣初始化频率，不扣模型调用次数。

再打开 GitHub Pages 实际页面：

- 首页星河、小派、暂停 / 2D 模式、聊天抽屉正常；手机导航可展开。
- 浏览器 Network 的聊天 GET / OPTIONS / POST 均请求 Worker，POST 携带匿名 Bearer 会话；前端不含 DeepSeek Key。
- 发送一条不含私人信息的问题，确认真实 DeepSeek 回复。**这一步才会产生模型费用**；本次本机验证使用模拟上游，未替你执行此步骤。
- 聊天生成的工具链接带正确仓库前缀。刷新某个产品详情、文章页面仍正常。
- 搜索、购买方式菜单、五步问答、对比和验机摘要可用；缺价 / 演示标记保留。
- 用微信向自己发送实际站点地址，再用手机网络和 Wi-Fi 试用；大陆到 `github.io` / `workers.dev` / 图片 CDN 的可达性受网络影响，本机测试无法保证微信内可用。
- 停用 AI 时页面仍可用；错误、超时、限额均显示提示。不要循环发送真实问题测试限流，使用下面的本地模拟测试。

## 6. 限流、安全和隐私

| 约束 | 默认值 |
| --- | --- |
| 全站每日模型调用 | 30 |
| 全站每日保守预留 token | 180,000 |
| 单匿名会话每日 / 每分钟 | 10 / 3 |
| 同 IP 每日 / 每分钟 | 20 / 6 |
| 同 IP 初始化会话 | 每分钟 20 |
| 输入 / 最近历史 / 请求体 | 800 字 / 8 条 / 16KB |
| 输出 / 上游响应体 | 最多 1600 token / 64KB |
| 服务端 / 前端超时 | 35 秒 / 40 秒 |

日期按 UTC 更新（北京时间 08:00）。先在单个持久 Durable Object 的 SQLite 事务中统一预留，再请求模型；并发请求和服务重启不会重置计数。失败、取消和超时也不退回预留；没有自动付费重试。token 预留是按完整上游请求 UTF-8 字节加输出上限做的保守估计，不是精确账单或人民币封顶承诺，DeepSeek 后台余额也应自行监控。

会话是一天有效的 HMAC 签名随机凭证，只在页面内存中保存；跨域不依赖第三方 Cookie。IP 使用每日变化的服务端 HMAC 摘要，不保存原始 IP。计数表没有聊天正文，旧日期记录在下一次正常预留时清理。Worker 默认未启用 observability 日志，代码不打印密钥或对话正文。

CORS 防止其他网页直接读取接口，但不是登录或机器人防火墙，非浏览器可以伪造 Origin。匿名用户可新建会话，因此另加 IP 与全站硬额度；校园网共享 IP 也会共享 IP 限额。若被攻击耗尽免费资源，AI 会暂时停用，前端独立继续服务。必要时再增加 Turnstile 等验证，不假装已经实现完整防刷。

用户点击发送后，问题与最近历史会转交 DeepSeek。不要输入账号密码、密钥、IMEI 或私人资料。供应商和托管平台的数据处理政策仍适用。

## 7. 本地运行与无费用联调

原 Node 版保持：

```bash
npm run dev
# 或 npm run build && npm start
```

无费用的 Worker 验证（真实本地 workerd + SQLite，模拟模型响应）：

```bash
npm run check:worker:local
```

该脚本自动验证预检、10 个并发请求只放行 2 个，以及重启后仍拒绝超额，随后清理自建临时状态。不会调用 DeepSeek。

浏览器分离联调，终端 A：

```bash
WRANGLER_SEND_METRICS=false CLOUDFLARE_LOAD_DEV_VARS_FROM_DOT_ENV=false \
npm exec -- wrangler dev --local --ip 127.0.0.1 --port 8788 \
  --config wrangler.local-test.toml --persist-to .deploy/browser-qa-state \
  --var AI_DAILY_CALL_LIMIT:30
```

终端 B：

```bash
NEXT_PUBLIC_BASE_PATH=/digitalpick \
NEXT_PUBLIC_SITE_URL=http://127.0.0.1:4173/digitalpick \
NEXT_PUBLIC_AI_PROXY_URL=http://127.0.0.1:8788 \
npm run build:pages
npm run check:pages
npm run preview:pages
```

打开 `http://127.0.0.1:4173/digitalpick/`。模型名显示 `local-proxy-fixture`，回答明确写“本地接口模拟验证”。**不要部署 `wrangler.local-test.toml` 或 fixture；不要把本地 localhost 版 `out-pages` 发布到公网。** GitHub 工作流会使用正式配置重新构建。

若需要用真实 Key 在本地验证 Worker，将 `worker/.dev.vars.example` 复制到根目录 `.dev.vars`，由你填写新 Key、随机 Secret、`AI_ENABLED=true` 和本机 origin，再运行 `npm run dev:worker`。这是可产生费用的真实请求，默认生产配置是关闭状态。

## 8. 故障排查与替代平台

| 现象 | 检查 |
| --- | --- |
| 构建要求 AI_PROXY_URL | 设置 GitHub Actions 仓库 Variable，再重跑工作流；不是 Secret Key |
| CSS / 图片 / 文章链接 404 | Pages Source 选 Actions，使用流程产物；不要上传旧 out；确认仓库地址 / 自定义域名与 configure-pages 输出一致 |
| Worker 403 | ALLOWED_ORIGINS 只填网页 origin，无仓库路径，重新部署 |
| 状态 enabled:false | AI_ENABLED=true，两个 Secrets 已存在，签名 Secret 至少 32 字符 |
| 401 | 匿名会话已过期，刷新网页；不要误把 sessionToken 当模型 Key |
| 429 | 频率或每日额度已满；等窗口结束，不能删 namespace 绕过上限 |
| 502 | 检查 DeepSeek 模型、余额、凭据或网络；不自动重试。模型内容校验失败会明确转本地整理 |
| 503 | 检查 DO 绑定、SQLite migration、免费限额；存储失败会停止付费调用 |
| 504 | 上游超过 35 秒；基础工具继续可用 |
| Actions 成功但微信打不开 | 使用实际公网地址测试网络；没有保证境内可达性，不能靠改前端解决所有线路问题 |

当前框架已可按优先方案导出，无需改用 Vercel 或 OpenNext。可替代为 Cloudflare Pages 托管同一静态前端：构建命令 `npm run build:pages && npm run check:pages`，输出 `out-pages`，`NEXT_PUBLIC_BASE_PATH` 设为空，填写正式 SITE_URL / AI_PROXY_URL，并更新 Worker origin。静态 Pages 仍连接同一个 Worker，不在静态站中放 Key。

Vercel 亦可评估静态前端 + 当前 Worker；若改成 Vercel Node API，不能把现有本机 SQLite 存储直接放进临时函数文件系统。这里未实现该部署路线，也不需要它来完成免费方案。平台账号权限、免费政策和网络可达性应在选择时重新核对。

新文件主要位于 `worker/`、`wrangler.toml`、`scripts/*pages.mjs`、`scripts/check-worker-local.mjs`、`scripts/check-secrets.mjs`、`lib/deployment.ts`、`.github/workflows/pages.yml`；原页面、3D 与 Node API 保留。验证范围见 [验证记录](VERIFICATION.md)。


维护者隔离验收使用独立 Secret 与限额，不占访客额度；配置与安全边界见 [部署说明](../DEPLOYMENT.md#访客体验与维护者验收)。请勿把专用测试 Secret 设为 NEXT_PUBLIC 变量。
