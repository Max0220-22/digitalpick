# Windows 桌面兼容性自检（2026-10-17）

反馈：Chrome / Edge 上样式正常，但精灵不动、AI 显示本地导览；目前没有朋友电脑的实际诊断结果，不能断定是 Windows 系统缺陷。

## 已核实

- 正式部署配置为 /digitalpick，AI 使用 https://digitalpick-gateway.pages.dev/api/assistant/。
- 正式 AI 健康接口返回 200；带正式网站 Origin 的免费会话 GET 返回 enabled=true、会话令牌和精确匹配的 CORS 响应。未保存或打印令牌。
- Mac 上 Chromium 内核浏览器打开正式首页，可创建 3D 场景并建立 AI 会话。此次未发起付费模型调用，也没有在真实 Windows 设备上验证。
- Three.js 当前版本要求 WebGL 2（https://threejs.org/docs/pages/WebGLRenderer.html）。GPU 驱动、图形加速、远程桌面和组织策略是候选因素，尚未在反馈设备确认。
- 系统 prefers-reduced-motion、网站暂停按钮、后台页面、45 秒休眠都会影响动态；AI 连通性独立于 WebGL。

## 修复

- 动画活跃状态按页面可见性判断，不再额外依赖 document.hasFocus()。仍遵循后台暂停和系统减少动态效果设置。
- 3D 创建前明确显示加载；Canvas 创建后才报告 3D。渲染或模块错误被边界捕获后，向外提供失败状态，首页提示当前 2D 并提供重试。
- 在线 AI 失败后，浏览器重新获得焦点也可触发免费 GET 恢复。继续保留 15 秒间隔、请求合并、429 等待；不会自动重试收费 POST。
- 新增 /diagnostics/：显示实际场景启动结果、动画原因、浏览器类别、页面来源、AI 状态分类及入口。诊断结果仅展示于当前页面，不上传浏览器信息、不读取或展示模型密钥、会话令牌、聊天记录。
- 首页、页脚和离线聊天提供自检入口。静态部署保留 /digitalpick 前缀。

## 让朋友验证

1. 在出现故障的电脑打开 https://max0220-22.github.io/digitalpick/diagnostics/?v=desktop-20261017 。
2. 等待 AI 连接完成，记录 3D 渲染、动画状态和 AI 状态码；可截图回报。connected 只证明会话链路可用，不证明模型生成成功。
3. 若 network/timeout，换热点和无痕窗口对照，判断网络或扩展因素；不能从 fetch 错误独断 DNS、CORS 或地区封锁。
4. 若 3D 失败，更新浏览器、检查图形加速和显卡驱动；若提示系统减少动态效果，检查 Windows 动画设置。
5. 旧页使用 Ctrl+F5 强制刷新。不要通过关闭安全防护或取消接口限流解决。

## 验证范围

前端与 Worker 类型检查、现有 82 项测试、静态导出和资源路径检查；本地 Chromium 场景创建/重试、首页暂停与 2D 切换、移动布局，以及发布后的免费会话连通性。具体执行结果由本次交付消息报告。
