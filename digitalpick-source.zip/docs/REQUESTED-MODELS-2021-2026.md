> 用户提供的待核验清单，不代表所有条目均已确认存在或发布。逐项结果见网站 /products/coverage/。

# 近5年（2021–2026）主流设备型号清单（手机/平板/笔记本）

> 品牌：苹果、华为、三星、OPPO、vivo、小米、一加、iQOO、红魔

---

## 苹果 Apple

### 手机

- **iPhone 13 系列**：iPhone 13、iPhone 13 mini、iPhone 13 Pro、iPhone 13 Pro Max
- **iPhone 14 系列**：iPhone 14、iPhone 14 Plus、iPhone 14 Pro、iPhone 14 Pro Max
- **iPhone 15 系列**：iPhone 15、iPhone 15 Plus、iPhone 15 Pro、iPhone 15 Pro Max
- **iPhone 16 系列**：iPhone 16、iPhone 16 Plus、iPhone 16 Pro、iPhone 16 Pro Max
- **iPhone 17 系列**：iPhone 17、iPhone 17 Plus、iPhone 17 Pro、iPhone 17 Pro Max、iPhone 17e

### 平板

- iPad 9（2021）、iPad 10（2022）、iPad（A16，2025）
- iPad Air 5（M1，2022）、iPad Air 6（M2，2024）、iPad Air M4（2026）
- iPad Pro 2021（M1）、iPad Pro 2022（M2）、iPad Pro 2024（M4）、iPad Pro 2025（M5）
- iPad mini 6、iPad mini 7

### 笔记本

- MacBook Air M1（2021）、MacBook Air M2、MacBook Air M3、MacBook Air M5
- MacBook Pro 14 M1 Pro、MacBook Pro 16 M1 Pro
- MacBook Pro 14 M2、MacBook Pro 16 M2
- MacBook Pro 14 M3、MacBook Pro 16 M3
- MacBook Pro 14 M4、MacBook Pro 16 M4
- MacBook Neo（2026）

---

## 华为 HUAWEI

### 手机

- **Mate 50 系列**：Mate 50、Mate 50 Pro、Mate 50 RS 非凡大师
- **Mate 60 系列**：Mate 60、Mate 60 Pro、Mate 60 Pro+、Mate 60 RS 非凡大师
- **Mate 70 系列**：Mate 70、Mate 70 Pro、Mate 70 Pro+、Mate 70 RS 非凡大师
- **Mate 80 系列**：Mate 80、Mate 80 Pro、Mate 80 Pro Max、Mate 80 RS 非凡大师
- **P50 系列**：P50、P50 Pro
- **P60 系列**：P60、P60 Pro、P60 Art
- **Pura 70 系列**：Pura 70、Pura 70 Pro、Pura 70 Pro+、Pura 70 Ultra
- **Pura 80 系列**：Pura 80、Pura 80 Pro、Pura 80 Pro+、Pura 80 Ultra
- **Pura 90 系列**：Pura 90、Pura 90 Pro、Pura 90 Pro Max
- **折叠屏 Mate X 系列**：Mate X2、Mate Xs 2、Mate X3、Mate X5、Mate X6、Mate X7
- **nova 9 系列**：nova 9、nova 9 Pro
- **nova 10 系列**：nova 10、nova 10 Pro
- **nova 11 系列**：nova 11、nova 11 Pro、nova 11 Ultra
- **nova 12 系列**：nova 12、nova 12 Pro、nova 12 Ultra
- **nova 13 系列**：nova 13、nova 13 Pro、nova 13 Ultra
- **nova 14 系列**：nova 14、nova 14 Pro、nova 14 Ultra
- **nova 15 系列**：nova 15、nova 15 Pro、nova 15 Ultra
- **nova 16 系列**：nova 16、nova 16 Pro、nova 16 Ultra

### 平板

- MatePad Pro 10.8（2021）、MatePad Pro 12.6（2021）
- MatePad Pro 11（2022）、MatePad Pro 12.6（2022）
- MatePad Air、MatePad 11.5
- MatePad Pro 13.2、MatePad Mini
- MatePad Pro 12 英寸（2026）、MatePad Pro Max

### 笔记本

- MateBook X Pro 2022、MateBook X Pro 2023、MateBook X Pro 2024、MateBook X Pro 2025
- MateBook 14s、MateBook 16s
- MateBook 14 2023、MateBook 14 2024、MateBook 14 2025
- MateBook D14 2022、D14 2023、D14 2024、D14 2025
- MateBook D16 2022、D16 2023、D16 2024、D16 2025
- MateBook 16 2022、MateBook 16 2023
- MateBook Fold 非凡大师、MateBook Pro S

---

## 三星 SAMSUNG

### 手机

- **Galaxy S21 系列**：Galaxy S21、S21+、S21 Ultra
- **Galaxy S22 系列**：Galaxy S22、S22+、S22 Ultra
- **Galaxy S23 系列**：Galaxy S23、S23+、S23 Ultra
- **Galaxy S24 系列**：Galaxy S24、S24+、S24 Ultra
- **Galaxy S25 系列**：Galaxy S25、S25+、S25 Ultra
- **Galaxy S26 系列**：Galaxy S26、S26+、S26 Ultra
- **Galaxy Z Fold 系列**：Z Fold3、Z Fold4、Z Fold5、Z Fold6、Z Fold7、Z Fold8、Z Fold8 Ultra
- **Galaxy Z Flip 系列**：Z Flip3、Z Flip4、Z Flip5、Z Flip6、Z Flip7、Z Flip8
- **心系天下 W 系列**：Galaxy W23、W24、W25、W26

### 平板

- Galaxy Tab S7 FE、Tab S8、Tab S8+、Tab S8 Ultra
- Tab S9、Tab S9+、Tab S9 Ultra
- Tab S10、Tab S10+、Tab S10 Ultra
- Tab S11、Tab S11 Ultra
- Tab S12、Tab S12+、Tab S12 Ultra

### 笔记本

- Galaxy Book 2、Galaxy Book2 Pro、Galaxy Book2 Pro 360
- Galaxy Book3、Book3 Pro、Book3 Ultra、Book3 360
- Galaxy Book4、Book4 Pro、Book4 Ultra、Book4 360
- Galaxy Book5、Book5 Pro、Book5 Ultra
- Galaxy Book6、Book6 Pro、Book6 Ultra

---

## OPPO

### 手机

- **Find X3 系列**：Find X3、Find X3 Pro
- **Find X5 系列**：Find X5、Find X5 Pro
- **Find X6 系列**：Find X6、Find X6 Pro
- **Find X7 系列**：Find X7、Find X7 Ultra
- **Find X8 系列**：Find X8、Find X8 Ultra
- **Find N 折叠屏系列**：Find N、Find N2、Find N2 Flip、Find N3、Find N3 Flip、Find N5
- **Reno7 系列**：Reno7、Reno7 Pro
- **Reno8 系列**：Reno8、Reno8 Pro、Reno8 Pro+
- **Reno9 系列**：Reno9、Reno9 Pro、Reno9 Pro+
- **Reno10 系列**：Reno10、Reno10 Pro、Reno10 Pro+
- **Reno11 系列**：Reno11、Reno11 Pro、Reno11 Ultra
- **Reno12 系列**：Reno12、Reno12 Pro、Reno12 Ultra
- **Reno13 系列**：Reno13、Reno13 Pro、Reno13 Ultra

### 平板

- OPPO Pad、OPPO Pad Air、OPPO Pad 2、OPPO Pad 3、OPPO Pad 3 Pro

### 笔记本

- OPPO Book、OPPO Book Air、OPPO Book 2、OPPO Book 3、OPPO Book Pro

---

## vivo

### 手机

- **X70 系列**：X70、X70 Pro、X70 Pro+
- **X80 系列**：X80、X80 Pro
- **X90 系列**：X90、X90 Pro、X90 Pro+
- **X100 系列**：X100、X100 Pro、X100 Ultra
- **X200 系列**：X200、X200 Pro、X200 Ultra
- **X300 系列**：X300、X300 Pro、X300 Ultra
- **X500 系列**：X500、X500 Pro、X500 Pro Max
- **X Fold 系列**：X Fold、X Fold+、X Fold2、X Fold3、X Fold5、X Fold6
- **X Flip 系列**：X Flip、X Flip2、X Flip3
- **S10 系列**：S10、S10 Pro
- **S12 系列**：S12、S12 Pro
- **S15 系列**：S15、S15 Pro
- **S16 系列**：S16、S16 Pro
- **S17 系列**：S17、S17 Pro
- **S18 系列**：S18、S18 Pro
- **S19 系列**：S19、S19 Pro
- **S20 系列**：S20、S20 Pro

### 平板

- vivo Pad、vivo Pad Air、vivo Pad2、vivo Pad3、vivo Pad5、vivo Pad6、vivo Pad6 Pro

### 笔记本

- vivo Book、vivo Book Air、vivo Book 2、vivo Book Pro

---

## 小米 Xiaomi

### 手机

- **小米 12 系列**：小米12、小米12X、小米12 Pro、小米12S、小米12S Pro、小米12S Ultra
- **小米 13 系列**：小米13、小米13 Pro、小米13 Ultra
- **小米 14 系列**：小米14、小米14 Pro、小米14 Ultra
- **小米 15 系列**：小米15、小米15 Pro、小米15 Ultra
- **小米 16 系列**：小米16、小米16 Pro、小米16 Ultra
- **小米 17 系列**：小米17、小米17 Pro、小米17 Max、小米17 Ultra
- **MIX Fold 系列**：小米MIX Fold2、MIX Fold3、MIX Fold4、MIX Fold5、小米18 Fold
- **Redmi K50 系列**：Redmi K50、K50 Pro、K50 Ultra
- **Redmi K60 系列**：Redmi K60、K60 Pro、K60 Ultra
- **Redmi K70 系列**：Redmi K70、K70E、K70 Pro、K70 Ultra
- **Redmi K80 系列**：Redmi K80、K80 Pro、K80 Ultra
- **Redmi Note 11 系列**：Redmi Note11、Note11 Pro、Note11 Pro+
- **Redmi Note 12 系列**：Redmi Note12、Note12 Pro、Note12 Pro+
- **Redmi Note 13 系列**：Redmi Note13、Note13 Pro、Note13 Pro+
- **Redmi Note 14 系列**：Redmi Note14、Note14 Pro、Note14 Pro+
- **Redmi Note 15 系列**：Redmi Note15、Note15 Pro、Note15 Pro+
- **Redmi Note 16 系列**：Redmi Note16、Note16 Pro、Note16 Pro+
- **Redmi Note 17 系列**：Redmi Note17、Note17 Pro、Note17 Pro+

### 平板

- 小米平板5、小米平板5 Pro、小米平板5 Pro 12.4
- 小米平板6、小米平板6 Pro、小米平板6 Max
- 小米平板7、小米平板7 Pro、小米平板7 Ultra
- 小米平板8
- 小米平板9、小米平板9 Pro、小米平板9 Pro Max
- Redmi Pad、Redmi Pad SE、Redmi Pad 2、Redmi K Pad

### 笔记本

- Xiaomi Book Pro 14 2022、Xiaomi Book Pro 14 2023、Xiaomi Book Pro 14 2024、Xiaomi Book Pro 14 2025
- Xiaomi Book Pro 16 2022、Xiaomi Book Pro 16 2023
- RedmiBook Pro 14 2022、Pro 14 2023、Pro 14 2024、Pro 14 2025、Pro 14 2026
- RedmiBook Pro 16 2022、Pro 16 2023、Pro 16 2024、Pro 16 2025、Pro 16 2026
- RedmiBook 14 2022、14 2023、14 2024、14 2025、14 2026
- RedmiBook 16 2022、16 2023、16 2024、16 2025、16 2026

---

## 一加 OnePlus

### 手机

- **一加 9 系列**：一加9、一加9 Pro、一加9R
- **一加 10 Pro**
- **一加 11**
- **一加 12**
- **一加 13 系列**：一加13、一加13R
- **一加 15 系列**：一加15、一加15R、一加15T
- **一加 16**
- **一加 Ace 系列**：一加Ace、一加Ace 2、一加Ace 2V、一加Ace 3、一加Ace 3V、一加Ace 5、一加Ace 5至尊版、一加Ace 6、一加Ace 6至尊版
- **一加 Ace Pro 系列**：一加Ace Pro、一加Ace 2 Pro、一加Ace 3 Pro、一加Ace 5 Pro
- **一加 Turbo 系列**：一加Turbo、一加Turbo 6X、一加Turbo 6X Pro

### 平板

- 一加平板Pro、一加平板2、一加平板2 Pro、一加平板3、一加平板3 Pro、一加平板4、OnePlus Pad Go 2

### 笔记本

- 一加Book、一加Book Pro、一加Book Air

---

## iQOO

### 手机

- **iQOO 8 系列**：iQOO 8、iQOO 8 Pro
- **iQOO 9 系列**：iQOO 9、iQOO 9 Pro
- **iQOO 10 系列**：iQOO 10、iQOO 10 Pro
- **iQOO 11 系列**：iQOO 11、iQOO 11 Pro、iQOO 11S
- **iQOO 12 系列**：iQOO 12、iQOO 12 Pro
- **iQOO 13 系列**：iQOO 13、iQOO 13 Pro
- **iQOO 15 系列**：iQOO 15、iQOO 15 Pro、iQOO 15 Ultra、iQOO 15T
- **iQOO 16**
- **iQOO Neo5 系列**：iQOO Neo5、Neo5 SE
- **iQOO Neo6 系列**：iQOO Neo6、Neo6 SE
- **iQOO Neo7 系列**：iQOO Neo7、Neo7 SE、Neo7竞速版
- **iQOO Neo8 系列**：iQOO Neo8、Neo8 Pro
- **iQOO Neo9 系列**：iQOO Neo9、Neo9S Pro、Neo9 Pro
- **iQOO Neo10 系列**：iQOO Neo10、Neo10 Pro
- **iQOO Neo11 系列**：iQOO Neo11、Neo11至尊版
- **iQOO Z 系列**：iQOO Z5、Z6、Z7、Z8、Z9、Z11、Z11i、Z11S、Z11 Turbo

### 平板

- iQOO Pad、iQOO Pad2、iQOO Pad5 Pro、iQOO Pad6 Pro、iQOO Pad Ultra

### 笔记本

- iQOO Book、iQOO Book Pro

---

## 红魔 RedMagic

### 手机

- **红魔 6 系列**：红魔6、红魔6R、红魔6S Pro
- **红魔 7 系列**：红魔7、红魔7 Pro、红魔7S、红魔7S Pro
- **红魔 8 系列**：红魔8、红魔8 Pro、红魔8 Pro+
- **红魔 9 系列**：红魔9、红魔9 Pro、红魔9 Pro+
- **红魔 10 系列**：红魔10、红魔10 Pro、红魔10 Pro+

### 平板

- 红魔电竞平板、红魔电竞平板Pro、红魔平板3 Pro、红魔5 Pro

### 笔记本

- 红魔游戏本、红魔16 Pro游戏本、红魔17 Pro游戏本

---

*整理时间：2026-10-17*
