# 交互参考与开源许可

本轮在 GitHub 核对了以下项目（2026-10-16）：

- [Radix Primitives](https://github.com/radix-ui/primitives)，MIT。通过 npm 固定安装 `@radix-ui/react-select@2.3.8`，用于选中态、完整键盘导航、焦点恢复、菜单定位、滚动与触控交互。许可证随 npm 包保留，另复制到本目录的 licenses 文件夹。
- [rdev/liquid-glass-react](https://github.com/rdev/liquid-glass-react)，MIT。研究其边缘高光、轻微弹性与玻璃层次。项目说明 Safari / Firefox 仅部分支持折射效果；因此本项目没有安装该库或复制模板代码，第一版采用原创 CSS，本轮增加自有 SVG 背景位移、透光边缘、指针高光和弹性按压；未安装或复制该库模板。
- [Radix Select 官方文档](https://www.radix-ui.com/primitives/docs/components/select)。遵循 Trigger / Portal / Content / Viewport / Item 的可访问结构。

`components/ui/select.tsx` 是项目自有封装。`app/refinements.css` 是自有视觉样式，不是 Apple 官方 Liquid Glass 的移植或官方组件。菜单文字始终保持清晰，低性能设备不依赖实时折射；减少动态效果时关闭菜单缩放动画。

精灵为原创实时几何模型。产品摄影角度切换与视差交互不构成真实 360° 重建，也不冒充品牌发布会动画。

## 星河版本

核对 [Apple HIG Materials](https://developer.apple.com/design/human-interface-guidelines/materials) 与 [WWDC25 Meet Liquid Glass](https://developer.apple.com/videos/play/wwdc2025/219/) 的分层、透镜边缘、触碰亮光与弹性反馈思路。网页实现保留清晰文字，主要将玻璃用于导航与操作层，内容卡片保持稳定。`app/cosmos.css` 与 `components/ui/liquid-effects.tsx` 为本项目实现，不能等同原生iOS26材质；未承诺跨浏览器逐像素一致。

星河、小派与控件响应同一次指针输入：星尘避让与回聚、波环、局部短距离飞行、玻璃高光扩散。没有相机手势采集、外部粒子视频或额外付费依赖。
