import { DurableObject } from 'cloudflare:workers';
import { createAssistantHandler } from './handler';
import { QuotaError, reserve } from './quota';
import type { WorkerEnv } from './types';
/** One persistent actor holds the global and per-session/IP budgets in a single transaction. */
export class AIQuota extends DurableObject<WorkerEnv> {
  constructor(ctx: DurableObjectState, env: WorkerEnv) {
    super(ctx, env);
    ctx.storage.sql.exec('CREATE TABLE IF NOT EXISTS quota (bucket TEXT PRIMARY KEY, calls INTEGER NOT NULL, tokens INTEGER NOT NULL, day TEXT NOT NULL)');
    ctx.storage.sql.exec('CREATE INDEX IF NOT EXISTS quota_day ON quota(day)');
  }
  async fetch(request: Request) {
    try {
      if (request.method !== 'POST' || new URL(request.url).pathname !== '/reserve') return new Response(null, { status: 404 });
      const input = await request.json() as Parameters<typeof reserve>[1];
      const usage=this.ctx.storage.transactionSync(() => reserve({
        read: key => this.ctx.storage.sql.exec<{ calls: number; tokens: number }>('SELECT calls,tokens FROM quota WHERE bucket=?', key).toArray()[0],
        increment: (key, tokens, day) => { this.ctx.storage.sql.exec('INSERT INTO quota(bucket,calls,tokens,day) VALUES(?,1,?,?) ON CONFLICT(bucket) DO UPDATE SET calls=calls+1,tokens=tokens+excluded.tokens', key, tokens, day); },
        prune: day => { this.ctx.storage.sql.exec('DELETE FROM quota WHERE day < ?', day); },
      }, input, this.env));
      return Response.json({ok:true,usage});
    } catch (cause) {
      return cause instanceof QuotaError ? Response.json({code:cause.code,retryAfter:cause.retryAfter,period:cause.period},{status:cause.code==='DUPLICATE_REQUEST'?409:429}) : Response.json({ error: 'Quota unavailable' }, { status: 503 });
    }
  }
}
export default { fetch: createAssistantHandler() };
