import { requestSchema } from '../lib/ai/schema';
import { completeModelReply } from '../lib/ai/reply';
import { buildContext, systemPrompt } from '../lib/ai/context';
import { allowedOrigin, hmac, issueSession, readBounded, verifySession } from './security';
import type { Reservation } from './quota';
import type { WorkerEnv } from './types';

interface Dependencies { fetchImpl?: typeof fetch; now?: () => number; timeoutMs?: number }
/** Web APIs only. No Next runtime, local files, database paths, or browser model credentials. */
export function createAssistantHandler(dependencies: Dependencies = {}) {
  const fetchImpl = dependencies.fetchImpl || fetch, now = dependencies.now || Date.now, timeoutMs = dependencies.timeoutMs || 35000;
  return async function handle(request: Request, env: WorkerEnv): Promise<Response> {
    const path = new URL(request.url).pathname;
    if (path === '/health' && ['GET', 'HEAD'].includes(request.method)) return new Response(request.method === 'HEAD' ? null : '{"ok":true}', { headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' } });
    const origin = allowedOrigin(request.headers.get('origin'), env.ALLOWED_ORIGINS);
    const headers: Record<string, string> = { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', 'Vary': 'Origin', 'X-Content-Type-Options': 'nosniff', ...(origin ? { 'Access-Control-Allow-Origin': origin } : {}) };
    const respond = (body: unknown, status = 200, extra = {}) => Response.json(body, { status, headers: { ...headers, ...extra } });
    const error = (message: string, status: number, retryAfter?: number) => respond({ error: message }, status, retryAfter ? { 'Retry-After': String(retryAfter) } : {});
    if (!['/api/assistant', '/api/assistant/'].includes(path)) return error('接口不存在。', 404);
    if (!origin) return error('请从已授权的网站发起对话。', 403);
    if (request.method === 'OPTIONS') {
      if (!['GET', 'POST'].includes(request.headers.get('access-control-request-method') || '')) return error('不支持的请求方式。', 405);
      const requested = (request.headers.get('access-control-request-headers') || '').toLowerCase().split(',').map(h => h.trim()).filter(Boolean);
      if (requested.some(h => !['authorization', 'content-type'].includes(h))) return error('不支持的请求头。', 403);
      return new Response(null, { status: 204, headers: { ...headers, 'Access-Control-Allow-Methods': 'GET, POST, OPTIONS', 'Access-Control-Allow-Headers': 'Content-Type, Authorization', 'Access-Control-Max-Age': '600' } });
    }
    if (!['GET', 'POST'].includes(request.method)) return error('不支持的请求方式。', 405);
    const configured = env.AI_ENABLED === 'true' && !!env.AI_API_KEY && (env.AI_SESSION_SECRET?.length || 0) >= 32;
    if (!configured) return request.method === 'GET' ? respond({ enabled: false, model: null, sessionToken: null }) : error('AI 暂未启用，规则选购和验机清单仍可使用。', 503);
    const model = env.AI_MODEL || 'deepseek-v4-pro', secret = env.AI_SESSION_SECRET!;
    const ip = await hmac(secret, `ip:${new Date(now()).toISOString().slice(0, 10)}:${request.headers.get('cf-connecting-ip') || 'unknown'}`);
    async function reserveQuota(input: Omit<Reservation, 'ip'>) {
      if (!env.AI_QUOTA) return error('AI 额度服务暂不可用，请稍后再试。', 503);
      try {
        const stub = env.AI_QUOTA.get(env.AI_QUOTA.idFromName('digitalpick-global-quota-v1'));
        const result = await stub.fetch(new Request('https://quota.internal/reserve', { method: 'POST', body: JSON.stringify({ ...input, ip }) }));
        if (result.status === 429) {
          const data = await result.json() as { code?: string; retryAfter?: number };
          return error(data.code === 'GLOBAL_LIMIT' ? '今日 AI 体验额度已用完，规则选购和产品库仍可使用。' : '对话过于频繁或已达今日限额，请稍后再聊。', 429, Number.isInteger(data.retryAfter) && data.retryAfter! > 0 ? data.retryAfter : 60);
        }
        if (!result.ok) return error('AI 额度服务暂不可用，请稍后再试。', 503);
      } catch { return error('AI 额度服务暂不可用，请稍后再试。', 503); }
      return null;
    }
    if (request.method === 'GET') {
      const blocked = await reserveQuota({ kind: 'session' }); if (blocked) return blocked;
      return respond({ enabled: true, model, knowledgeVersion:'specs-20261018-v2', sessionToken: (await issueSession(secret, now())).token });
    }
    const token = request.headers.get('authorization')?.match(/^Bearer (\S+)$/)?.[1] || '';
    const user = await verifySession(secret, token, now());
    if (!user) return error('咨询会话已失效，请刷新页面后重试。', 401);
    if (!request.headers.get('content-type')?.toLowerCase().startsWith('application/json')) return error('请求格式不正确。', 415);
    let input;
    try { input = requestSchema.parse(JSON.parse(await readBounded(request, 16000))); }
    catch (cause) { return error(cause instanceof Error && cause.message === 'TOO_LARGE' ? '对话内容过长，请重新开始。' : '请输入800字以内的问题，或重新开始对话。', cause instanceof Error && cause.message === 'TOO_LARGE' ? 413 : 400); }
    const context = buildContext(input), body = JSON.stringify({ model, messages: [{ role: 'system', content: systemPrompt }, ...input.history, { role: 'user', content: JSON.stringify({ question: input.message, data: context.payload }) }], thinking: { type: 'disabled' }, response_format: { type: 'json_object' }, max_tokens: 1600, stream: false });
    if (request.signal.aborted) return error('咨询已取消。', 408);
    const blocked = await reserveQuota({ kind: 'call', user, tokens: new TextEncoder().encode(body).byteLength + 1600 }); if (blocked) return blocked;
    const abort = new AbortController(); let timedOut = false;
    const cancel = () => abort.abort(); request.signal.addEventListener('abort', cancel, { once: true });
    const timer = setTimeout(() => { timedOut = true; abort.abort(); }, timeoutMs);
    let stage: 'connect' | 'read' | 'parse' = 'connect';
    try {
      const upstream = await fetchImpl('https://api.deepseek.com/chat/completions', { method: 'POST', headers: { Authorization: `Bearer ${env.AI_API_KEY}`, 'Content-Type': 'application/json' }, body, signal: abort.signal, redirect: 'manual' });
      if (!upstream.ok) return error(upstream.status === 401 || upstream.status === 402 ? 'AI 服务凭据或余额待检查，请联系站点维护者。' : 'AI 服务暂时繁忙，请稍后重试。', 502);
      stage = 'read';
      const raw = await readBounded(upstream, 64000);
      stage = 'parse';
      const data = JSON.parse(raw);
      return respond(completeModelReply(data, context, model));
    } catch {
      // Fixed diagnostics only: never expose exception text, upstream bodies or credentials.
      const code = timedOut ? 'UPSTREAM_TIMEOUT' : request.signal.aborted ? 'REQUEST_CANCELLED' : stage === 'connect' ? 'UPSTREAM_CONNECTION' : stage === 'read' ? 'UPSTREAM_READ' : 'UPSTREAM_FORMAT';
      const message = timedOut ? '这次回复超时了，请稍后重试。' : request.signal.aborted ? '咨询已取消。' : stage === 'connect' ? 'AI 代理暂时连接不上 DeepSeek，请稍后重试。' : stage === 'read' ? 'DeepSeek 回复传输中断或超过大小限制，请稍后重试。' : 'DeepSeek 返回了无法读取的数据格式，请联系站点维护者。';
      return respond({ error: message, code }, timedOut ? 504 : request.signal.aborted ? 408 : 502);
    }
    finally { clearTimeout(timer); request.signal.removeEventListener('abort', cancel); }
  };
}
