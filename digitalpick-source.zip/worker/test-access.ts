import {hmac} from './security';
export const TEST_ACCESS_HEADER='x-elvora-test-access';
const lifetime=15*60*1000;
/** Only server-side tooling holding a dedicated secret can issue a session/origin-bound test grant. */
export async function issueTestAccess(secret:string,session:string,origin:string,now=Date.now()){
 if(secret.length<32)throw new Error('TEST_SECRET_TOO_SHORT');
 const expires=now+lifetime,nonce=crypto.randomUUID().replaceAll('-','');
 const value=`${expires}.${nonce}`;
 return `${value}.${await hmac(secret,`elvora-test-v1\n${origin}\n${session}\n${value}`)}`;
}
export async function verifyTestAccess(secret:string|undefined,grant:string,session:string,origin:string,now=Date.now()){
 if(!secret||secret.length<32||grant.length>160)return false;
 const [expires,nonce,signature,extra]=grant.split('.');
 if(extra!==undefined||!/^\d{13}$/.test(expires||'')||!/^[a-f0-9]{32}$/.test(nonce||'')||!/^[a-f0-9]{64}$/.test(signature||'')||Number(expires)<=now||Number(expires)>now+lifetime)return false;
 const key=await crypto.subtle.importKey('raw',new TextEncoder().encode(secret),{name:'HMAC',hash:'SHA-256'},false,['verify']);
 return crypto.subtle.verify('HMAC',key,Uint8Array.from(signature.match(/../g)!,s=>parseInt(s,16)),new TextEncoder().encode(`elvora-test-v1\n${origin}\n${session}\n${expires}.${nonce}`));
}
