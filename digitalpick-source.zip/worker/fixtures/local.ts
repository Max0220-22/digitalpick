// Local verification only: no model request leaves this fixture.
export { AIQuota } from '../index';
import { createAssistantHandler } from '../handler';
const handle = createAssistantHandler({ fetchImpl: async (_url, init) => {
  const request = JSON.parse(String(init?.body));
  const question = JSON.parse(request.messages.at(-1).content).question as string;
  // Deliberately unsafe fixture output verifies local recovery for the reported two-turn conversation.
  const reply = question === '王者荣耀'
    ? { answer: '这款手机只要999元', followUpQuestions: [], recommendations: [] }
    : { answer: '这是本地接口模拟验证。预算与用途已记录，未调用真实模型。', followUpQuestions: question.includes('打游戏') ? ['常玩的游戏是哪一款？'] : ['你更在意续航还是拍照？'], recommendations: [] };
  return Response.json({ choices: [{ finish_reason: 'stop', message: { content: JSON.stringify(reply) } }] });
} });
export default { fetch: handle };
