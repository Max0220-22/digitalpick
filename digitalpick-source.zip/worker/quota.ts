import type { WorkerEnv } from './types';
export interface Bucket { calls: number; tokens: number }
export interface QuotaStore { read(key: string): Bucket | undefined; increment(key: string, tokens: number, day: string): void; prune(day: string): void }
export interface Reservation { kind: 'session' | 'call'; ip: string; user?: string; tokens?: number }
export class QuotaError extends Error {
  constructor(public code: 'GLOBAL_LIMIT' | 'USER_LIMIT' | 'IP_LIMIT', public retryAfter: number) { super(code); }
}
function limit(value: string | undefined, fallback: number, maximum: number) { const n = Number(value); return Number.isInteger(n) && n > 0 ? Math.min(n, maximum) : fallback; }
/** The caller must wrap all reads and writes in one storage transaction. */
export function reserve(store: QuotaStore, input: Reservation, env: WorkerEnv, now = new Date()) {
  if (!/^[a-f0-9]{64}$/.test(input.ip) || !['session', 'call'].includes(input.kind)) throw new Error('INVALID_RESERVATION');
  const day = now.toISOString().slice(0, 10), minute = now.toISOString().slice(0, 16);
  const minuteWait = Math.max(1, 60 - now.getUTCSeconds());
  const dayWait = Math.max(1, Math.ceil((Date.parse(`${day}T00:00:00Z`) + 86400000 - now.getTime()) / 1000));
  const count = (key: string) => store.read(key) || { calls: 0, tokens: 0 };
  if (input.kind === 'session') {
    const key = `s:${minute}:${input.ip}`;
    if (count(key).calls >= 20) throw new QuotaError('IP_LIMIT', minuteWait);
    store.increment(key, 0, day); store.prune(day); return;
  }
  if (!/^[a-f0-9]{32}$/.test(input.user || '') || !Number.isInteger(input.tokens) || input.tokens! < 1 || input.tokens! > 100000) throw new Error('INVALID_RESERVATION');
  const g = `g:${day}`, u = `u:${day}:${input.user}`, ip = `i:${day}:${input.ip}`, m = `m:${minute}:${input.user}`, im = `p:${minute}:${input.ip}`;
  if (count(g).calls >= limit(env.AI_DAILY_CALL_LIMIT, 30, 200) || count(g).tokens + input.tokens! > limit(env.AI_DAILY_TOKEN_LIMIT, 180000, 1000000)) throw new QuotaError('GLOBAL_LIMIT', dayWait);
  if (count(u).calls >= limit(env.AI_USER_DAILY_LIMIT, 10, 50)) throw new QuotaError('USER_LIMIT', dayWait);
  if (count(ip).calls >= limit(env.AI_IP_DAILY_LIMIT, 20, 100)) throw new QuotaError('IP_LIMIT', dayWait);
  if (count(m).calls >= 3) throw new QuotaError('USER_LIMIT', minuteWait);
  if (count(im).calls >= limit(env.AI_IP_MINUTE_LIMIT, 6, 30)) throw new QuotaError('IP_LIMIT', minuteWait);
  for (const key of [g, u, ip, m, im]) store.increment(key, input.tokens!, day);
  store.prune(day);
}
