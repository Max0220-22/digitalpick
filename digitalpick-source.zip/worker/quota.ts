import type { WorkerEnv } from './types';
import {publicLimits,testAiLimits} from '../lib/ai/limits';
export interface Bucket { calls: number; tokens: number }
export interface QuotaStore { read(key: string): Bucket | undefined; increment(key: string, tokens: number, day: string): void; prune(day: string): void }
export interface Reservation { kind: 'session' | 'call'; ip: string; user?: string; tokens?: number; scope?: 'public'|'test'; requestId?:string }
export class QuotaError extends Error {
  constructor(public code: 'GLOBAL_LIMIT' | 'USER_LIMIT' | 'IP_LIMIT'|'DUPLICATE_REQUEST', public retryAfter: number, public period:'day'|'minute'='minute') { super(code); }
}
function limit(value: string | undefined, fallback: number, maximum: number) { const n = Number(value); return Number.isInteger(n) && n > 0 ? Math.min(n, maximum) : fallback; }
/** The caller must wrap all reads and writes in one storage transaction. */
export function reserve(store: QuotaStore, input: Reservation, env: WorkerEnv, now = new Date()) {
  if (!/^[a-f0-9]{64}$/.test(input.ip) || !['session', 'call'].includes(input.kind) || (input.scope!==undefined&&!['public','test'].includes(input.scope))) throw new Error('INVALID_RESERVATION');
  if(input.requestId!==undefined&&!/^[a-f0-9-]{36}$/.test(input.requestId))throw new Error('INVALID_REQUEST_ID');
  const day = now.toISOString().slice(0, 10), minute = now.toISOString().slice(0, 16);
  const minuteWait = Math.max(1, 60 - now.getUTCSeconds());
  const dayWait = Math.max(1, Math.ceil((Date.parse(`${day}T00:00:00Z`) + 86400000 - now.getTime()) / 1000));
  const count = (key: string) => store.read(key) || { calls: 0, tokens: 0 };
  if (input.kind === 'session') {
    const key = `s:${minute}:${input.ip}`;
    if (count(key).calls >= 20) throw new QuotaError('IP_LIMIT', minuteWait);
    store.increment(key, 0, day); store.prune(day); return;
  }
  if (!/^[a-f0-9]{32}$/.test(input.user || '') || !Number.isInteger(input.tokens) || input.tokens! < 1 || input.tokens! > 100000) throw new Error('INVALID_RESERVATION');
  const testing=input.scope==='test',prefix=testing?'t:':'',configured=publicLimits(env as unknown as Record<string,string|undefined>);
  const requestKey=input.requestId?`${prefix}r:${day}:${input.user}:${input.requestId}`:null;
  if(requestKey&&count(requestKey).calls)throw new QuotaError('DUPLICATE_REQUEST',1);
  const g = `${prefix}g:${day}`, u = `${prefix}u:${day}:${input.user}`, ip = `${prefix}i:${day}:${input.ip}`, m = `${prefix}m:${minute}:${input.user}`, im = `${prefix}p:${minute}:${input.ip}`;
  const daily=testing?limit(env.AI_TEST_DAILY_CALL_LIMIT,testAiLimits.dailyCalls,100):configured.dailyCalls;
  const tokens=testing?limit(env.AI_TEST_DAILY_TOKEN_LIMIT,testAiLimits.dailyTokens,8_000_000):configured.dailyTokens;
  const burst=testing?limit(env.AI_TEST_MINUTE_LIMIT,testAiLimits.minuteCalls,30):configured.userMinute;
  if (count(g).calls >= daily || count(g).tokens + input.tokens! > tokens) throw new QuotaError('GLOBAL_LIMIT',dayWait,'day');
  if (count(u).calls >= (testing?daily:configured.userDaily)) throw new QuotaError('USER_LIMIT',dayWait,'day');
  if (count(ip).calls >= (testing?daily:configured.ipDaily)) throw new QuotaError('IP_LIMIT',dayWait,'day');
  if (count(m).calls >= burst) throw new QuotaError('USER_LIMIT', minuteWait);
  if (count(im).calls >= (testing?burst:configured.ipMinute)) throw new QuotaError('IP_LIMIT', minuteWait);
  for (const key of [g, u, ip, m, im]) store.increment(key, input.tokens!, day);
  if(requestKey)store.increment(requestKey,0,day);
  store.prune(day);
  return {used:count(g).calls,limit:daily};
}
