export interface WorkerEnv {
  AI_ENABLED?: string;
  AI_API_KEY?: string;
  AI_SESSION_SECRET?: string;
  AI_MODEL?: string;
  AI_TIMING_LOGS?: string;
  AI_DEBUG_QUOTA?:string;
  AI_TEST_SECRET?: string;
  AI_TEST_DAILY_CALL_LIMIT?: string;
  AI_TEST_DAILY_TOKEN_LIMIT?: string;
  AI_TEST_MINUTE_LIMIT?: string;
  AI_USER_MINUTE_LIMIT?: string;
  ALLOWED_ORIGINS?: string;
  AI_DAILY_CALL_LIMIT?: string;
  AI_USER_DAILY_LIMIT?: string;
  AI_DAILY_TOKEN_LIMIT?: string;
  AI_IP_DAILY_LIMIT?: string;
  AI_IP_MINUTE_LIMIT?: string;
  AI_QUOTA: {
    idFromName(name: string): unknown;
    get(id: unknown): { fetch(request: Request): Promise<Response> };
  };
}
