const encoder = new TextEncoder();
export async function hmac(secret: string, text: string) {
  const key = await crypto.subtle.importKey('raw', encoder.encode(secret), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']);
  const signed = await crypto.subtle.sign('HMAC', key, encoder.encode(text));
  return [...new Uint8Array(signed)].map(b => b.toString(16).padStart(2, '0')).join('');
}
function randomId() { return [...crypto.getRandomValues(new Uint8Array(16))].map(b => b.toString(16).padStart(2, '0')).join(''); }
export async function issueSession(secret: string, now: number) {
  const user = randomId(), expires = now + 86400000;
  const value = `${user}.${expires}`;
  return { token: `${value}.${await hmac(secret, value)}`, expiresAt: expires };
}
export async function verifySession(secret: string, token: string, now: number): Promise<string | null> {
  if (token.length > 160) return null;
  const [user, expires, signature, extra] = token.split('.');
  if (extra !== undefined || !/^[a-f0-9]{32}$/.test(user || '') || !/^\d{13}$/.test(expires || '') || !/^[a-f0-9]{64}$/.test(signature || '') || Number(expires) <= now || Number(expires) > now + 86400000) return null;
  const key = await crypto.subtle.importKey('raw', encoder.encode(secret), { name: 'HMAC', hash: 'SHA-256' }, false, ['verify']);
  const bytes = Uint8Array.from(signature.match(/../g)!, s => parseInt(s, 16));
  return await crypto.subtle.verify('HMAC', key, bytes, encoder.encode(`${user}.${expires}`)) ? user : null;
}
export function allowedOrigin(raw: string | null, setting: string | undefined) {
  if (!raw || raw === 'null') return null;
  return (setting || '').split(',').map(s => s.trim()).filter(Boolean).some(value => {
    try { const url = new URL(value); return !url.username && !url.password && !url.search && !url.hash && url.pathname === '/' && (url.protocol === 'https:' || (url.protocol === 'http:' && ['localhost', '127.0.0.1', '[::1]'].includes(url.hostname))) && url.origin === raw; } catch { return false; }
  }) ? raw : null;
}
export async function readBounded(request: Request | Response, maximum: number) {
  const claimed = Number(request.headers.get('content-length'));
  if (claimed > maximum) throw new Error('TOO_LARGE');
  const reader = request.body?.getReader(); if (!reader) return '';
  const parts: Uint8Array[] = []; let size = 0;
  try {
    for (;;) { const part = await reader.read(); if (part.done) break; size += part.value.byteLength; if (size > maximum) { await reader.cancel(); throw new Error('TOO_LARGE'); } parts.push(part.value); }
  } finally { reader.releaseLock(); }
  const bytes = new Uint8Array(size); let offset = 0;
  for (const part of parts) { bytes.set(part, offset); offset += part.byteLength; }
  return new TextDecoder('utf-8', { fatal: true, ignoreBOM: false }).decode(bytes);
}
