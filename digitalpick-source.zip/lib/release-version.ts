/** Public build metadata only. No credentials, host paths, or runtime user data. */
export function createReleaseVersion(now:Date,revision?:string) {
 const date=new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Shanghai',year:'numeric',month:'2-digit',day:'2-digit'}).format(now);
 const suffix=revision&&/^[a-f0-9]{7,40}$/i.test(revision)?revision.slice(0,7):now.toISOString().replace(/[-:.TZ]/g,'');
 return {date,id:`diagnostics-2-${suffix}`};
}
export const diagnosticRelease={date:process.env.NEXT_PUBLIC_RELEASE_DATE||'开发构建',id:process.env.NEXT_PUBLIC_RELEASE_ID||'diagnostics-2-dev'};
export const diagnosticVersion=`${diagnosticRelease.date} · ${diagnosticRelease.id}`;
