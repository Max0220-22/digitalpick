import { DatabaseSync } from 'node:sqlite';
import { mkdirSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import {publicLimits} from './limits';

export interface QuotaLimits { dailyCalls: number; userDaily: number; dailyTokens: number; minuteCalls: number }
export function reserveQuota(db: DatabaseSync, user: string, tokens: number, limits: QuotaLimits, now = new Date()) {
  const day = now.toISOString().slice(0, 10), minute = now.toISOString().slice(0, 16);
  db.exec('CREATE TABLE IF NOT EXISTS quota (bucket TEXT PRIMARY KEY, calls INTEGER NOT NULL, tokens INTEGER NOT NULL)');
  db.exec('BEGIN IMMEDIATE');
  try {
    const read = (key: string) => db.prepare('SELECT calls,tokens FROM quota WHERE bucket=?').get(key) as { calls: number; tokens: number } | undefined;
    const global = read(`g:${day}`), personal = read(`u:${day}:${user}`), burst = read(`m:${minute}:${user}`);
    if ((global?.calls || 0) >= limits.dailyCalls || (global?.tokens || 0) + tokens > limits.dailyTokens) throw new Error('GLOBAL_LIMIT');
    if ((personal?.calls || 0) >= limits.userDaily || (burst?.calls || 0) >= limits.minuteCalls) throw new Error('USER_LIMIT');
    const upsert = db.prepare('INSERT INTO quota(bucket,calls,tokens) VALUES(?,1,?) ON CONFLICT(bucket) DO UPDATE SET calls=calls+1,tokens=tokens+excluded.tokens');
    for (const key of [`g:${day}`, `u:${day}:${user}`, `m:${minute}:${user}`]) upsert.run(key, tokens);
    // Counts are reserved before network calls and not refunded on failure or cancellation.
    db.prepare('DELETE FROM quota WHERE substr(bucket,3,10) < ?').run(day);
    db.exec('COMMIT');
  } catch (error) { db.exec('ROLLBACK'); throw error; }
}
export function withQuota(user: string, tokens: number) {
  const path = resolve(process.env.AI_QUOTA_PATH || '.data/ai-quota.sqlite');
  mkdirSync(dirname(path), { recursive: true, mode: 0o700 });
  const db = new DatabaseSync(path);
  try {
    db.exec('PRAGMA busy_timeout=3000');
    const limits=publicLimits(process.env);
    reserveQuota(db,user,tokens,{dailyCalls:limits.dailyCalls,userDaily:limits.userDaily,dailyTokens:limits.dailyTokens,minuteCalls:limits.userMinute});
  } finally { db.close(); }
}
