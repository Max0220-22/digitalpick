import type {AssistantReply} from './schema';
import type {ValidationIssue,ValidationReview} from './validation-report';
import {chatReplyNotice} from './presentation';
import {diagnosticVersion} from '../release-version';
export const validationHistoryKey='elvora.validation-history.v1';
export const validationHistoryEvent='elvora:validation-history';
export const validationHistoryLimit=50;
type StoragePort=Pick<Storage,'getItem'|'setItem'|'removeItem'>;
export interface ValidationHistoryEntry {
 id:string;time:string;version:string;question:string;outcome:ValidationReview['outcome'];issues:ValidationIssue[];
 final:{mode:AssistantReply['mode'];model:string|null;answer:string;notice:string|null;recommendations:{id:string;name:string;reason:string;caution:string}[];followUpQuestions:string[]};
}
function browserStorage():StoragePort|null {try{return typeof window==='undefined'?null:window.localStorage;}catch{return null;}}
function isEntry(value:unknown):value is ValidationHistoryEntry {
 if(!value||typeof value!=='object')return false;const v=value as ValidationHistoryEntry;
 return typeof v.id==='string'&&typeof v.time==='string'&&Number.isFinite(Date.parse(v.time))&&typeof v.question==='string'&&typeof v.version==='string'&&['adjusted','rejected'].includes(v.outcome)&&Array.isArray(v.issues)&&v.issues.every(i=>i&&typeof i.rule==='string'&&typeof i.reason==='string'&&typeof i.category==='string'&&Array.isArray(i.products)&&i.products.every(p=>typeof p==='string')&&Array.isArray(i.fields)&&i.fields.every(p=>typeof p==='string'))&&!!v.final&&typeof v.final.answer==='string'&&['ai','guide'].includes(v.final.mode)&&Array.isArray(v.final.recommendations)&&v.final.recommendations.every(r=>r&&typeof r.name==='string'&&typeof r.reason==='string'&&typeof r.caution==='string')&&Array.isArray(v.final.followUpQuestions);
}
export function readValidationHistory(storage=browserStorage()):{entries:ValidationHistoryEntry[];available:boolean} {
 if(!storage)return {entries:[],available:false};
 try{const raw=storage.getItem(validationHistoryKey),parsed=raw?JSON.parse(raw):[];return {entries:Array.isArray(parsed)?parsed.filter(isEntry).slice(0,validationHistoryLimit):[],available:true};}catch{return {entries:[],available:false};}
}
export function rememberValidationReply(question:string,reply:AssistantReply,names:(id:string)=>string=(id=>id),storage=browserStorage(),now=new Date()):boolean {
 if(!reply.validationReview?.issues.length)return true;
 if(!storage)return false;
 const entry:ValidationHistoryEntry={id:crypto.randomUUID(),time:now.toISOString(),version:diagnosticVersion,question,outcome:reply.validationReview.outcome,issues:reply.validationReview.issues,final:{mode:reply.mode,model:reply.model,answer:reply.answer,notice:chatReplyNotice(reply),recommendations:reply.recommendations.map(rec=>({...rec,name:names(rec.id)})),followUpQuestions:reply.followUpQuestions}};
 try{const previous=readValidationHistory(storage).entries;storage.setItem(validationHistoryKey,JSON.stringify([entry,...previous].slice(0,validationHistoryLimit)));if(typeof window!=='undefined')window.dispatchEvent(new Event(validationHistoryEvent));return true;}catch{return false;}
}
export function clearValidationHistory(storage=browserStorage()):boolean {try{if(!storage)return false;storage.removeItem(validationHistoryKey);if(typeof window!=='undefined')window.dispatchEvent(new Event(validationHistoryEvent));return true;}catch{return false;}}
export const validationCategoryLabels:Record<ValidationIssue['category'],string>={model:'机型 / 版本',score:'需求规则分',price:'价格 / 库存口径',budget:'预算条件',parameter:'参数资料',response:'回复结构 / 完整性'};
