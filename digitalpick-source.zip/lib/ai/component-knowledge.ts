/** Manufacturer architecture facts, checked 2026-10-23; not comparative device benchmarks. */
const chips = [
 { match: /(?:骁龙|snapdragon)\s*8\s*elite(?!\s*(?:gen|第|[+＋]|\d))/i, name: '骁龙 8 Elite', fact: 'CPU 使用高通自研 Oryon 架构，GPU 为 Adreno。', source: 'https://www.qualcomm.com/smartphones/products/8-series/snapdragon-8-elite-mobile-platform' },
 { match: /(?:天玑|dimensity)\s*9400(?![+＋eE\d])/, name: '天玑 9400', fact: 'CPU 采用 Arm Cortex-X925、Cortex-X4 和 Cortex-A720 全大核组合，GPU 为 Immortalis-G925。', source: 'https://www.mediatek.com/products/smartphones/mediatek-dimensity-9400' },
];
export function componentKnowledge(message: string) {
 return chips.filter(chip => chip.match.test(message)).map(({ name, fact, source }) => ({ name, fact, source, checkedAt: '2026-10-23', limitation: '架构不同不等于同条件实测排名；具体手机的散热、调度、游戏适配和电池会影响体验。' }));
}
export function componentGuide(message: string) {
 const facts = componentKnowledge(message);
 return facts.length ? '先看差异，不能仅凭芯片名断言哪台手机更好。'+facts.map(c => c.name+'：'+c.fact).join('\n\n')+'\n\n两者的 CPU 与 GPU 路线不同；游戏稳定性、发热和续航仍要比较具体手机在相同条件下的实测，不能把厂商各自对上一代的提升当作彼此差距。' : '芯片比较要分别看 CPU、GPU、功耗和具体手机的散热调度；不能仅凭型号数字判定胜负。当前本地资料没有这组芯片的已核对差异，可连接在线顾问继续解释，不需要先填预算。';
}
