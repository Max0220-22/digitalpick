import { type Preferences, type PurchasePriority } from '../recommend';
import { type Category } from '../products';
import { localGuide, type GuideMemory } from '../companion/guide';
import { parseBudgetChange, stripReserve } from '../companion/budget';
import { gamingPattern, suggestsPhone, updateGames } from './games';

const usePatterns: Record<Category, [string, RegExp][]> = {
  phone: [['游戏性能', gamingPattern], ['拍照摄影', /拍照|摄影|拍视频|录像|人像|长焦/], ['日常使用', /日常|聊天|社交/], ['续航', /续航|电池/], ['AI和系统可玩性', /\bAI\b|人工智能|本地模型|root|bootloader|刷机/i], ['小屏手感', /小屏|单手|手感/]],
  tablet: [['学习笔记', /学习|笔记|上课/], ['娱乐影音', /追剧|影音|娱乐|看视频/], ['绘画', /绘画|画画|插画/], ['轻办公', /轻办公|文档|表格/]],
  laptop: [['日常办公', /办公|文档|表格/], ['编程开发', /编程|开发|写代码/], ['游戏', gamingPattern], ['视频剪辑', /剪辑|视频创作/], ['学习', /学习|上课|大学/]],
};
const reserveClause = /(?:预留|另留|留出)(?:配件|维修|电池|软件|费用|预算|费|用)?\s*(?:是|为)?\s*(\d{1,6})\s*(?:元|块)?/g;
export const withoutReserveAmounts = stripReserve;
export function unparsedBudgetChange(text: string) { return parseBudgetChange(text).kind === 'unclear'; }
/** Intentionally bounded parser: unresolved hard requirements keep the candidate pool empty. */
export function preferencesForTurns(messages: string[]) {
  let memory: GuideMemory = {}, selected: string[] = [], primaryUse = '', reserveBudget = 0, storage = 0;
  let maxWeight: number | null = null, maxScreen: number | null = null;
  let priority: PurchasePriority = 'balanced';
  const unresolved = new Set<string>(); let budgetUnclear = false, categoryInferred = false; let games: string[] = [];
  for (const message of messages) {
    const before = memory.category;
    memory = localGuide(withoutReserveAmounts(message), memory, '/').memory;
    games = updateGames(games, message);
    if (/手机|安卓|iphone|平板|ipad|电脑|笔记本|macbook/i.test(message)) categoryInferred = false;
    if (!memory.category && suggestsPhone(message)) { memory.category = 'phone'; categoryInferred = true; }
    if (unparsedBudgetChange(message)) { delete memory.budget; budgetUnclear = true; }
    else if (parseBudgetChange(message).kind !== 'none') budgetUnclear = !memory.budget;
    if (memory.category !== before) { selected = []; primaryUse = ''; storage = 0; maxWeight = null; maxScreen = null; const reserveUnclear = unresolved.has('reserve'); unresolved.clear(); if (reserveUnclear) unresolved.add('reserve'); }
    const category = memory.category;
    if (!category) continue;
    const positive = message.replace(/(?:不玩|不打|不要|不需要|不考虑|不做|不用)(?:任何|什么)?(?:游戏|拍照|摄影|剪辑|绘画|AI|刷机|编程)/gi, '');
    const matched = usePatterns[category].filter(([, pattern]) => pattern.test(positive)).map(([use, pattern]) => ({ use, position: positive.search(pattern) })).sort((a, b) => a.position - b.position).map(a => a.use);
    if (matched.length) { selected = /改成|改为|只要|只需|仅需|不需要其他/.test(message) ? matched : [...new Set([...selected, ...matched])]; primaryUse = selected.includes(primaryUse) ? primaryUse : selected[0]; }
    for (const [use, pattern] of usePatterns[category]) if (!(games.length && (use === '游戏性能' || use === '游戏')) && new RegExp(`(?:不玩|不打|不要|不需要|不考虑|不做|不用).{0,3}(?:${pattern.source})`, 'i').test(message)) selected = selected.filter(u => u !== use);
    if (!selected.includes(primaryUse)) primaryUse = selected[0] || '';
    const mostImportant = message.match(/(?:最重要|优先|主要)(?:是|考虑|用来|用途是)?([^，,。；;]{0,15})/i)?.[1]?.split(/也|还|兼顾|同时/)[0];
    if (mostImportant) { const match = usePatterns[category].filter(([use, pattern]) => selected.includes(use) && pattern.test(mostImportant)).sort((a, b) => mostImportant.search(a[1]) - mostImportant.search(b[1]))[0]; if (match) primaryUse = match[0]; }
    const reserve = [...message.matchAll(reserveClause)].at(-1)?.[1];
    if (reserve !== undefined) { reserveBudget = Number(reserve); unresolved.delete('reserve'); }
    else if (/预留|另留|留出/.test(message)) unresolved.add('reserve');
    if (/不(?:用|必|需要)预留/.test(message)) { reserveBudget = 0; unresolved.delete('reserve'); }
    const amount = message.match(/(?:存储|容量|至少|最低)?\s*(\d{2,4}|1|2)\s*(TB|GB|T|G)(?!\s*内存)/i);
    if (amount && !/内存|RAM/i.test(message)) { storage = Number(amount[1]) * (/^T/i.test(amount[2]) ? 1024 : 1); unresolved.delete('storage'); }
    else if (/存储|容量/.test(message)) unresolved.add('storage');
    if (/内存|RAM|高刷|刷新率|长焦|防水|解锁|必须.*(?:软件|接口|功能)|只(?:买|要).*Pro/i.test(message)) unresolved.add('capability');
    if (/(?:只买|只要|只考虑|仅考虑|不要|不买|排除|不考虑).{0,8}(?:苹果|Apple|小米|Xiaomi|三星|Samsung|荣耀|HONOR|一加|OnePlus|OPPO|vivo|华为|Huawei|索尼|Sony)/i.test(message)) unresolved.add('hard-brand');
    const weight = message.match(/(\d{2,4})\s*(?:克|g)(?:以内|以下|为止)/) || message.match(/(?:不能超过|不超过|不重于|最多)\s*(\d{2,4})\s*(?:克|g)/);
    if (weight) { maxWeight = Number(weight[1]); unresolved.delete('weight'); }
    else if (/重量|轻于|重于|(?:不能超过|不超过).{0,6}(?:克|g)/.test(message)) unresolved.add('weight');
    const screen = message.match(/(\d{1,2}(?:\.\d+)?)\s*(?:英寸|寸)(?:以内|以下)/) || message.match(/(?:不能超过|不超过|最多)\s*(\d{1,2}(?:\.\d+)?)\s*(?:英寸|寸)/);
    if (screen) { maxScreen = Number(screen[1]); unresolved.delete('screen'); }
    else if (/屏幕.{0,8}(?:以内|以下|不超过)|不超过.{0,6}(?:英寸|寸)/.test(message)) unresolved.add('screen');
    if (/(?:只(?:用|要|考虑)|系统(?:是|要)?|必须|需要)\s*Windows|Windows\s*(?:电脑|系统)/i.test(message)) memory.os = 'Windows';
    if (/macOS/i.test(message) && !/不(?:要|用|考虑).{0,3}macOS/i.test(message)) memory.os = 'macOS';
    if (/iPadOS/i.test(message) && !/不(?:要|用|考虑).{0,3}iPadOS/i.test(message)) memory.os = 'iPadOS';
    if (/(?:不要|不买|排除|不考虑).{0,3}(?:苹果|iOS|Android|安卓|Windows|macOS)/i.test(message)) unresolved.add('excluded-system');
    if (/更重省心|少折腾|优先售后/.test(message)) priority = 'peace-of-mind';
    if (/更重低价|价格优先|便宜优先/.test(message)) priority = 'price';
    if (/均衡考虑/.test(message)) priority = 'balanced';
  }
  const preferences: Preferences | null = memory.category && memory.budget ? { category: memory.category, maxBudget: memory.budget, mode: memory.mode || 'either', uses: selected, primaryUse, brand: '', os: memory.os || '', storage, maxWeight, maxScreen, reserveBudget, purchasePriority: priority } : null;
  return { memory, preferences, uses: selected, primaryUse, games, categoryInferred, budgetUnclear, needsClarification: unresolved.size > 0 || !selected.length, unresolvedRequirements: [...unresolved] };
}
