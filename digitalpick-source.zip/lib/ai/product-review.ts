import type {buildContext} from './context';
import type {ModelReply} from './schema';
import type {Product} from '../products';
import {normalizedDeviceName} from './retrieval';
import type {ValidationIssue} from './validation-report';
import {logValidationFailure,ReplyValidationError,type ValidationDiagnostics} from './validation-diagnostics';
type Context=ReturnType<typeof buildContext>;
const cache=new WeakMap<Product[],{product:Product;aliases:string[]}[]>();
function indexFor(dataset:Product[]){
 let entries=cache.get(dataset);if(!entries){entries=dataset.map(product=>({product,aliases:[...new Set([product.id,product.name,product.brand+' '+product.name,...(product.aliases||[])].map(normalizedDeviceName).flatMap(name=>[name,name.replace(/^samsunggalaxy/,'samsung')]).filter(s=>s.length>=3))]}));cache.set(dataset,entries);}return entries;
}
const familyNames=/(?:iPhone\s*(?:\d{1,2}|X[SR]?|SE)(?:[\s-]*(?:Pro|Max|Plus|mini|Ultra))*(?:\s*\([^\n)]*\))?|iPad(?:[\s-]*(?:Air|mini|Pro))?(?:[\s-]*(?:\d{1,2}(?:\.\d)?|M\d|A\d{2}))*(?:\s*英寸)?|MacBook\s*(?:Air|Pro)(?:[\s-]*(?:\d{1,2}|M\d))*(?:\s*英寸)?(?:\s*\([^\n)]*\))?|(?:Xiaomi|小米|Redmi|红米|OnePlus|一加|iQOO|vivo|OPPO|realme|Pixel|荣耀|HONOR|华为|HUAWEI|Galaxy|Samsung|三星)(?:[\s-]*(?:Galaxy|MatePad|Mate|Nova|Pad|Note|Book|平板|Magic|Find|Reno|Neo|GT|K|X|S|Z|A|V|Y|P|折叠|Turbo))*[\s-]*\d{1,4}[A-Z]?(?:[\s-]*(?:Pro|Max|Plus|Ultra|mini|SE|FE|Lite|Turbo))*)/gi;
function containsAlias(text:string,alias:string){
 let at=text.indexOf(alias);while(at>=0){const before=text.slice(0,at),after=text.slice(at+alias.length);if(!/[a-z0-9]$/.test(before)&&! /^(?:pro|max|plus|mini|ultra|lite|fe|[a-z0-9])/.test(after))return true;at=text.indexOf(alias,at+1);}return false;
}
export function reviewProductReply(reply:ModelReply,value:unknown,context:Context,rawReply:string,diagnostics:ValidationDiagnostics={}){
 const entries=indexFor(context.dataset),preferred=[...context.candidates,...context.advisory.map(s=>s.product)];
 const resolve=(text:string)=>{const normalized=normalizedDeviceName(text),found=entries.filter(e=>e.aliases.includes(normalized));return preferred.find(p=>found.some(e=>e.product.id===p.id))||found[0]?.product;};
 const knownIn=(text:string)=>{const normalized=normalizedDeviceName(text),found=entries.filter(e=>e.aliases.some(alias=>containsAlias(normalized,alias))).map(e=>e.product);for(const token of text.matchAll(familyNames)){const product=resolve(token[0]);if(product&&!found.some(p=>p.id===product.id))found.push(product);}return found;};
 let adjusted=false;
 const record=(rule:string,field:string,model?:string,detail?:Pick<ValidationIssue,'category'|'reason'>)=>{adjusted=true;logValidationFailure(rawReply,new ReplyValidationError(rule,[field],model?[model]:[],detail),diagnostics);};
 const object=value&&typeof value==='object'?value as Record<string,unknown>:{};
 const rawCards=Array.isArray(object.recommendations)?object.recommendations:[];
 const cards:ModelReply['recommendations']=[];
 const unknownNames:string[]=[];
 const scores=new Map<string,number>([...context.advisory.map(s=>[s.product.id,s.score] as [string,number]),...context.payload.candidates.map(s=>[s.id,s.ruleScore] as [string,number])]);
 for(const [i,item] of rawCards.entries()){
  if(!item||typeof item!=='object')continue;
  const rec=item as Record<string,unknown>,name=[rec.id,rec.name,rec.model,rec.productName].filter((v):v is string=>typeof v==='string');
  const product=name.map(resolve).find(Boolean);
  if(!product){record('UNKNOWN_MODEL',`recommendations.${i}.id`,name.join(' / '));unknownNames.push(...name.filter(n=>n.length>=3));continue;}
  if(cards.some(c=>c.id===product.id)){record('DUPLICATE_MODEL',`recommendations.${i}.id`,product.name);continue;}
  if(rec.score!==undefined||rec.ruleScore!==undefined){const supplied=Number(rec.score??rec.ruleScore);if(supplied!==scores.get(product.id))record('SCORE_MISMATCH',`recommendations.${i}.score`,product.name,{category:'score',reason:`模型给出 ${supplied} 分，${scores.has(product.id)?'本站同条件规则分为 '+scores.get(product.id)+' 分':'当前条件下没有可核对的本站规则分'}，已按现有规则处理该分数。`});}
  cards.push({id:product.id,reason:typeof rec.reason==='string'?rec.reason:`${product.processor}；具体适配以参数与使用场景为准。`,caution:typeof rec.caution==='string'?rec.caution:'非实时价格，购买前请核实配置、机况和来源。'});
 }
 const editText=(text:string,field:string,subject?:Product)=>{
  // Clauses keep independent valid recommendations even when a neighbouring model is unknown.
  const wholeKnown=knownIn(text);
  const pieces=text.split(/(?<=[。！？；;，,\n])/u);
  return pieces.map(piece=>{
   const identified=knownIn(piece),known=identified.length?identified:subject?[subject]:wholeKnown.length===1?wholeKnown:[];
   const unknown=[...unknownNames.filter(name=>piece.toLowerCase().includes(name.toLowerCase())),...[...piece.matchAll(familyNames)].map(m=>m[0]).filter(name=>!resolve(name)&&![...known,...wholeKnown].some(p=>normalizedDeviceName(p.name).startsWith(normalizedDeviceName(name))))];
   if(unknown.length){
    return piece.split(/(?<=[，,])/u).filter(clause=>{const bad=unknown.find(name=>clause.toLowerCase().includes(name.toLowerCase()));if(bad){record('UNKNOWN_MODEL',field,bad);return false;}return true;}).join('');
   }
   let edited=piece;
   // Only rule/100-point score claims: frame rates, capacities and 5-point use grades are untouched.
   if(known.length===1){const product=known[0],score=scores.get(product.id);
    edited=edited.replace(/(?:(?:规则|匹配|需求|推荐|综合|总)?(?:评?分|得分)[：:\s]*)(\d+(?:\.\d+)?)(?:\s*\/\s*100|\s*分)?|(\d+(?:\.\d+)?)\s*\/\s*100|(?:^|(?<=[（(\s：:，,]))\b(\d+(?:\.\d+)?)\s*分(?!钟)/g,(match,a,b,c)=>{
     const claimed=Number(a||b||c);if(c&&claimed<=5&&/游戏|拍照|续航|适配/.test(piece))return match;if(score===undefined){record('UNAVAILABLE_SCORE',field,product.name);return '评分尚未核实';}if(claimed!==score){record('SCORE_MISMATCH',field,product.name,{category:'score',reason:`模型给出 ${claimed} 分，本站同条件规则分为 ${score} 分，已校对该分数。`});return `本站需求规则分 ${score}/100`;}return match;
    });
   }
   return edited;
  }).join('').trim();
 };
 const answer=editText(reply.answer,'answer',cards.length===1?resolve(cards[0].id):undefined);
 for(const card of cards){const product=context.dataset.find(p=>p.id===card.id)!;card.reason=editText(card.reason,'recommendations.reason',product);card.caution=editText(card.caution,'recommendations.caution',product);if(!preferred.some(p=>p.id===card.id))card.caution+=' 该机型未确认符合本次预算或用途，仅作参数参考。';const score=scores.get(card.id);if(score!==undefined&&rawCards.some((r:any)=>resolve(String(r?.id||r?.name||''))?.id===card.id&&(r.score!==undefined||r.ruleScore!==undefined)))card.reason=card.reason.replace(/[。；;，,]+$/,'')+`；本站需求规则分 ${score}/100。`;}
 // Plain text/Markdown may not include a card envelope. Resolve names without rejecting its format.
 if(!cards.length&&answer)for(const product of knownIn(answer).slice(0,3))cards.push({id:product.id,reason:`${product.processor}；${product.pros[0]||'可查看资料库参数与来源'}。`,caution:'资料库参考，非实时价格；是否满足预算与具体用途仍需核实。'});
 return {reply:{...reply,answer,recommendations:cards.slice(0,3)},adjusted};
}
