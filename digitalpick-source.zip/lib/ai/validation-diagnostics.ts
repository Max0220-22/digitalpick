export interface ValidationDiagnostic {rawReply:string;rule:string;fields:string[];products:string[]}
export interface ValidationDiagnostics {enabled?:boolean;emit?:(entry:ValidationDiagnostic)=>void}
export class ReplyValidationError extends Error {
 constructor(rule:string,public fields:string[]=[],public products:string[]=[]){super(rule);this.name='ReplyValidationError';}
}
/** Explicit local-development opt-in only. No diagnostic data is attached to a visitor response. */
export function developmentDiagnostics(enabled:string|undefined,origin:string|null):ValidationDiagnostics {
 return {enabled:enabled==='true'&&!!origin&&/^http:\/\/(?:localhost|127\.0\.0\.1)(?::\d+)?$/.test(origin)};
}
export function logValidationFailure(rawReply:string,cause:unknown,options:ValidationDiagnostics={}){
 if(!options.enabled)return;
 const error=cause as {message?:string;issues?:{path:(string|number)[];message:string}[];fields?:string[];products?:string[]};
 const entry:ValidationDiagnostic={rawReply,rule:error.issues?'RESPONSE_SCHEMA':error.message||'INVALID_FORMAT',fields:error.issues?.map(issue=>issue.path.join('.')+': '+issue.message)||(error.fields?.length?error.fields:['choices.0.message.content']),products:error.products||[]};
 (options.emit||((record:ValidationDiagnostic)=>console.debug('[assistant:validation]',record)))(entry);
}
