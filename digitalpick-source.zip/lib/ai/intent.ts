import { parseBudgetChange } from '../companion/budget';
import { mentionedGames } from './games';
type Turn = { role: 'user' | 'assistant'; content: string };
const device = /手机|平板|电脑|笔记本|耳机|iphone|ipad|macbook/i;
const shopping = /预算|推荐|选购|想买|要买|买什么|买一|购买|怎么选|怎么挑|换一|换个/;
const information = /哪个好|哪个更|区别|对比|比较|怎么样|什么是|是什么意思|有什么|怎么(?:验|检查|迁移)|验机|账号锁|激活锁|能不能|能否/;
export const impossibleRequest = (text: string) => /穿越(?:时空|时间)|时光(?:机|旅行)|回到过去|瞬间移动|永动机|无限续航/.test(text);
export const componentQuestion = (text: string) => /骁龙|snapdragon|天玑|dimensity|芯片|处理器|CPU|GPU/i.test(text) && /哪个好|哪个更|区别|对比|比较|怎么样|什么是|怎么选|差别|性能|架构/i.test(text);
function startsPurchase(text: string) {
 if (impossibleRequest(text) || componentQuestion(text) || information.test(text)) return false;
 const budget = parseBudgetChange(text).kind !== 'none';
 return (device.test(text) && (shopping.test(text) || budget)) || (budget && /预算|打游戏|游戏|买|左右|以内/.test(text));
}
/** Classify this turn before inheriting shopping conditions. A stored budget is not intent. */
export function purchaseIntent(message: string, history: Turn[] = []) {
 if (impossibleRequest(message) || componentQuestion(message) || information.test(message)) return false;
 if (startsPurchase(message)) return true;
 const hasPurchase = history.some(t => t.role === 'user' && startsPurchase(t.content));
 if (!hasPurchase) return false;
 // Short answers may complete the ongoing questionnaire, but greetings/new questions cannot.
 const preference = /二手|全新|新机|手机|平板|电脑|笔记本|日常|拍照|续航|学习|编程|办公|游戏|存储|内存|屏幕|苹果|安卓|小米|红米|三星|华为|荣耀|一加|vivo|oppo|容量/i.test(message);
 return parseBudgetChange(message).kind !== 'none' || mentionedGames(message).length > 0 ||
  preference && /^(?:只买|只要|只考虑|只接受|不要|不买|不考虑|不接受|不能接受|不想要|接受|可以接受|能接受|也接受|也考虑|改成|换成|全新|二手|新机|还要|主要|更在意|更重视|日常|拍照|续航|学习|编程|办公|游戏|我指的是|我说的是|是手机|是平板|是电脑|存储至少|内存至少|屏幕最多)/.test(message) ||
  /^(?:手机|平板|电脑|笔记本)(?:[。！!，,]?|方向|为主)$/.test(message);
}
