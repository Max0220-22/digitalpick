import { products, type Product } from '../products';
import { analyzeRecommendations, preferenceHref, type Preferences } from '../recommend';
import { pricingSummary } from '../price-reference';
import { buildContext } from './context';
import { safeGuideReply } from './reply';
import {isGreeting,greetingAnswer} from './greeting';
import { retrieveDeviceReferences } from './retrieval';
import { matchingProduct } from './product-match';
import { preferencesForTurns } from './preferences';
import { conversationUserTurns } from './conversation';
import type { AssistantReply, requestSchema } from './schema';
import type { z } from 'zod';
import type { LocalFallbackReason } from '../companion/quota-fallback';
type Input = z.infer<typeof requestSchema>;
function devicesFor(input: Input, dataset: Product[]) {
 const references = retrieveDeviceReferences(input).devices;
 const matched = references.map(d => dataset.find(p => p.id === (d.productId || d.id)) || matchingProduct(d.name, '/', dataset)).filter((p): p is Product => !!p);
 const direct = matchingProduct(input.message, input.path, dataset);
 return [...new Map([...matched, ...(direct ? [direct] : [])].map(p=>[p.id,p])).values()].slice(0,3);
}
/** Only called by a local/degraded branch; the normal model request and scoring weights stay intact. */
export function localQuotaReply(input: Input, reason: LocalFallbackReason, dataset = products, now = new Date()): AssistantReply {
 const wrap = (answer: string, links: AssistantReply['links'] = []): AssistantReply => ({ answer, links, recommendations:[], followUpQuestions:[], model:null, mode:'guide', budgetQualified:false, fallbackReason:reason });
 if(isGreeting(input.message))return {...wrap(greetingAnswer,[{label:'开始数码选购',href:'/recommend/'}]),localReason:'greeting'};
 let context=buildContext(input,dataset,now);
 // A missing category must not turn a useful local budget/game question into empty methodology.
 // This provisional assumption is displayed, never saved as a user-confirmed preference.
 if(context.task.intent==='purchase-advice'&&context.memory.budget&&!context.memory.category){
  context=buildContext({...input,message:'手机，'+input.message},dataset,now);
  context.payload.conversation.categoryInferred=true;
 }
 const decision = preferencesForTurns(conversationUserTurns(input.history, input.message));
 const why = /为什么|为啥|为何|凭什么/.test(input.message) && /推|选中|选了/.test(input.message);
 const comparison = /选哪个|选哪款|选哪台|哪个好|哪个更|和.*选|还是|对比|比较|取舍/.test(input.message);
 let devices = devicesFor(input,dataset);
 // Names may come from the last recommendation; constraints only come from user turns.
 const direct= comparison ? retrieveDeviceReferences({...input,history:[]}) : null;
 if (comparison && devices.length < 2 && !devicesFor({...input,history:[]},dataset).length && !direct?.unknownModel) {
  for (const turn of input.history.slice(-8).reverse()) {
   const snippets=turn.role==='assistant'?turn.content.split(/[；;。\n]/):[turn.content];
   const previous=[...new Map(snippets.flatMap(message=>devicesFor({...input,message,history:[]},dataset)).map(p=>[p.id,p])).values()];
   if (previous.length >= 2) { devices=previous;break; }
  }
 }
 if ((why || comparison) && devices.length) {
  const category=devices[0].category, defaultUse={phone:'日常使用',tablet:'娱乐影音',laptop:'日常办公'}[category];
  const prefs: Preferences = {category,maxBudget:decision.memory.budget || 3000,mode:decision.memory.mode || 'either',brand:'',os:decision.memory.os || '',storage:0,maxWeight:null,maxScreen:null,...(decision.preferences || {}),uses:decision.uses.length?decision.uses:[defaultUse],primaryUse:decision.primaryUse || decision.uses[0] || defaultUse};
  const missing=[!decision.memory.budget?'预算3000元':'',!decision.uses.length?defaultUse:'',!decision.memory.mode?'全新二手均可':''].filter(Boolean);
  const known=[decision.memory.budget?`预算${decision.memory.budget}元`:'',decision.memory.category?{phone:'手机',tablet:'平板',laptop:'笔记本电脑'}[decision.memory.category]:'',...decision.uses,decision.memory.mode?{new:'只考虑全新',used:'只考虑二手',either:'全新二手均可'}[decision.memory.mode]:''].filter(Boolean);
  const assumptions=(known.length?`沿用已知条件：${known.join('，')}。`:'')+(missing.length ? `尚缺${why?'原问卷中的部分':'部分'}条件，以下仅补用“${missing.join('、')}”演示同一套规则，不代表你当时的得分。` : `以${prefs.primaryUse}为主用途，按同一套规则核算。`);
  const blocked=decision.budgetUnclear || decision.unresolvedRequirements.length>0;
  const audit = blocked ? null : analyzeRecommendations(prefs,dataset,now,{pricePolicy:'reference-guidance'});
  if (why) {
   const target=devices[0], result=audit?.recommendations.find(result=>result.product.id===target.id);
   if (!result) return wrap(`${target.name} 的推荐要结合具体条件解释。${assumptions}\n\n${blocked?'你还有未确认的预算或硬要求，不能伪造分数。':audit?.exclusions.find(e=>e.productId===target.id)?.reason || '这组条件下它没有进入前三，不能把它说成已入选。'}\n\n补充原问卷条件后，可以按相同规则重新核算。`,[{label:'核对完整问卷条件',href:preferenceHref(prefs)},{label:target.name+' 参数',href:`/products/${target.id}/`}]);
   return wrap(`${target.name} 在这组条件下为 ${result.score}/100 分。${assumptions}\n\n`+result.breakdown.map(b=>`${b.label}：${b.score}/${b.max}。${b.reason}`).join('\n\n')+`\n\n依据是本站规则 v2.1，${result.offer.evidence?.estimated?'基于估算价，非实时价格，购买前请核实':'基于同配置有效报价，购买前仍须核价'}；不是模型评分、实测跑分或可购买承诺。`,[{label:'查看同条件问卷评分',href:preferenceHref(prefs)},{label:'查看 '+target.name,href:`/products/${target.id}/`}]);
  }
  if (devices.length < 2) return wrap('我只识别到一款设备，不能拿上一款或相近变体补齐对比。请补充另一款完整型号；已识别的参数可先查看。',devices.map(p=>({label:p.name,href:`/products/${p.id}/`})));
  const pair=devices.slice(0,2), ranked=blocked?[]:analyzeRecommendations(prefs,pair,now,{pricePolicy:'reference-guidance'}).recommendations;
  const choice=ranked[0];
  const summary=pair.map(p=>`${p.name}：\n芯片：${p.processor}\n屏幕：${p.screen}\n电池/标称续航：${p.battery}\n重量：${p.weight===null?'尚未核实':p.weight+'g'}\n价格口径：${pricingSummary(p,'new')}；二手 ${pricingSummary(p,'used')}。`).join('\n\n');
  const tilt=choice?`在上述条件下，本地规则更倾向 ${choice.product.name}（${choice.score}/100）。这只是用途与购买取舍倾向，不是实测性能排名，也不保证预算内可买。`:'这组条件缺少适配或价格依据，不能宣布一款全面胜出。';
  return wrap(`${assumptions}\n\n${summary}\n\n${tilt}系统、机况和售后仍需分别核对；标称容量不等于真实续航，不同价格口径不能当成即时差价。`,pair.map(p=>({label:p.name+' 参数与来源',href:`/products/${p.id}/`})));
 }
 if (why || comparison) return wrap('还没有识别到可核对的完整型号，不能编造评分或拿相近机型代替。请写出具体机型，我可以用资料库解释参数、价格口径和规则依据。',[{label:'查找具体机型',href:'/products/'}]);
 if (context.task.intent === 'purchase-advice') return {...safeGuideReply(context,'LOCAL_GUIDE'),fallbackReason:reason};
 if (context.task.intent === 'component-comparison' || context.task.intent === 'impossible-request' || context.references.length || /验机|电池|内存|存储|渠道|root|bootloader/i.test(input.message)) return {...safeGuideReply(context,'LOCAL_GUIDE'),fallbackReason:reason};
 return wrap('我是小派，主要帮你选数码、比较设备和检查二手机况，暂时不能处理这类与数码无关的请求。你可以告诉我预算和用途，或发两款设备让我帮你比较。',[{label:'开始数码选购',href:'/recommend/'}]);
}
