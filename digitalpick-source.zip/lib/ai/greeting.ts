export function isGreeting(message:string){
 const greeting=message.trim().toLowerCase().replace(/[\s，,。.!！?？、~～]/g,'');
 return /^(?:小派)?(?:你好|您好|嗨|哈喽|早上好|早安|中午好|下午好|晚上好|hello|hi|hey|谢谢|感谢)(?:小派)?$/.test(greeting);
}
export const greetingAnswer='嗨，我是小派，你的数码选购伙伴。告诉我预算和用途，或发两款设备，我可以帮你比较。';
