/** Durations only: no questions, replies, tokens or credentials in timing telemetry. */
export function createRequestTiming(clock:()=>number=()=>performance.now()) {
 const started=clock(), stages:Record<string,number>={};
 const elapsed=(start:number)=>Math.max(0,Math.round((clock()-start)*10)/10);
 return {
  async measure<T>(name:string,work:()=>Promise<T>):Promise<T>{const start=clock();try{return await work();}finally{stages[name]=elapsed(start);}},
  sync<T>(name:string,work:()=>T):T{const start=clock();try{return work();}finally{stages[name]=elapsed(start);}},
  snapshot(){return {...stages,'dp-total':elapsed(started)};},
  header(){return Object.entries({...stages,'dp-total':elapsed(started)}).filter(([key,value])=>/^[a-z-]+$/.test(key)&&Number.isFinite(value)).map(([key,value])=>`${key};dur=${value}`).join(', ');},
 };
}
