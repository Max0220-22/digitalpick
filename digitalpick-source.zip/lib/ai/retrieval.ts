import { reviewedDevices } from '../library/reviewed';
import { factLabels, type FactKey, type LibraryDevice } from '../library/types';

export function normalizedDeviceName(text: string) {
 return text.normalize('NFKC').toLowerCase().replace(/苹果/g,'iphone').replace(/小米平板/g,'xiaomipad').replace(/小米/g,'xiaomi').replace(/红米/g,'redmi').replace(/一加/g,'oneplus').replace(/三星/g,'samsung').replace(/华为/g,'huawei').replace(/荣耀/g,'honor').replace(/爱酷/g,'iqoo').replace(/(\d)\+/g,'$1plus').replace(/英寸|标准版/g,'').replace(/[^a-z0-9\u4e00-\u9fff]/g,'');
}
function aliases(device: LibraryDevice) {
 const full=normalizedDeviceName(device.name), brand=normalizedDeviceName(device.brand);
 return [...new Set([full,normalizedDeviceName(device.brand+device.name),full.startsWith(brand)?full.slice(brand.length):'',...device.aliases.map(normalizedDeviceName)].filter(a=>a.length>=3))];
}
function explicitMatches(text: string, dataset: LibraryDevice[]) {
 let normalized=normalizedDeviceName(text);
 // Only expand an unambiguous iPhone family shorthand, not arbitrary numbers or budgets.
 if (/iphone\d/.test(normalized)) normalized=normalized.replace(/(和|与|还是|对比|vs)(\d{1,2})(promax|pro|plus|mini)?(?=哪个好|怎么样|哪个|比较|对比|好|$)/g,'$1iphone$2$3');
 return dataset.flatMap(device=>{
  if(device.review!=='reviewed') return [];
  let best=-1;
  for(const alias of aliases(device)) {
   let at=normalized.indexOf(alias);
   while(at>=0) {
    const before=normalized.slice(0,at), after=normalized.slice(at+alias.length);
    const capacity=/^\d{2,4}(?:gb|g|tb|t)(?:[^a-z]|$)/.test(after);
    const suffix=/^(?:pro|max|plus|mini|ultra|lite|fe|se|m\d|[a-z0-9])/.test(after)&&!capacity;
    const negated=/(?:不看|不考虑|不买|排除|不是|别看|不要)[a-z0-9]{0,3}$/.test(before);
    if(!/[a-z0-9]$/.test(before)&&!suffix&&!negated) { best=at;break; }
    at=normalized.indexOf(alias,at+1);
   }
  }
  return best<0?[]:[{device,at:best}];
 }).sort((a,b)=>a.at-b.at||b.device.name.length-a.device.name.length).map(r=>r.device);
}
const namesModel=(text:string)=>/(?:iphone|ipad|macbook|xiaomi|redmi|samsung|galaxy|oneplus|iqoo|huawei|honor|matepad|pixel|oppo|vivo|realme|thinkpad|surface)[a-z0-9]*\d/.test(normalizedDeviceName(text));
export function deviceFamily(device:LibraryDevice) {
 const brand=normalizedDeviceName(device.brand);let name=normalizedDeviceName(device.name);
 if(name.startsWith(brand))name=name.slice(brand.length);
 return name.replace(/^galaxy/,'');
}
function selectRegion(text:string,devices:LibraryDevice[]) {
 const requested=/国行|中国大陆|国内版/.test(text)?/中国大陆|国行/:/美版|美国版|美国/.test(text)?/美国/:/印度版|印度/.test(text)?/印度/:/加拿大版|加拿大/.test(text)?/加拿大/:/新加坡版|新加坡/.test(text)?/新加坡/:/菲律宾版|菲律宾/.test(text)?/菲律宾/:/国际版|全球版/.test(text)?/国际|全球/:null;
 const matched=requested?devices.filter(d=>requested.test(d.region.split(/[，；;。]/)[0])):devices;
 const unique=matched.filter((d,i)=>matched.findIndex(other=>deviceFamily(other)===deviceFamily(d)&&other.region===d.region)===i);
 return {devices:unique.slice(0,3),unknownModel:!!requested&&!unique.length};
}
export function retrieveDeviceReferences(input:{message:string;history:{role:'user'|'assistant';content:string}[];path:string},dataset=reviewedDevices) {
 const direct=explicitMatches(input.message,dataset);
 if(direct.length) return {...selectRegion(input.message,direct),inherited:false};
 if(namesModel(input.message)) return {devices:[],inherited:false,unknownModel:true};
 if(/换个话题|换个问题|重新选|不聊|不看.*了|改看(?:手机|平板|电脑)|换成(?:手机|平板|电脑)/.test(input.message)) return {devices:[],inherited:false,unknownModel:false};
 const url=new URL(input.path,'https://digitalpick.invalid');
 const page=dataset.find(d=>d.review==='reviewed'&&(d.id===url.searchParams.get('device')||(d.productId&&url.pathname.replace(/\/$/,'')===`/products/${d.productId}`)));
 const continuation=/续航|电池|屏幕|拍照|相机|芯片|处理器|内存|存储|重量|多重|参数|哪个好|哪个更|那款|这款|这两|它|能玩|游戏|系统|接口|手写笔|适合|散热|发热|呢|相比|区别|推荐哪/.test(input.message);
 if(continuation) {
  for(const turn of input.history.filter(t=>t.role==='user').slice().reverse()) {
   const found=explicitMatches(turn.content,dataset);
   if(found.length) return {...selectRegion(turn.content,found),inherited:true};
   if(namesModel(turn.content)) break;
  }
 }
 return {devices:page?[page]:[],inherited:!!page,unknownModel:false};
}
export function referenceTask(message:string,devices:LibraryDevice[],unknownModel=false) {
 const knowledge=/是什么意思|什么是|区别是什么|内存和存储|RAM和|UFS|验机|怎么检查|账号锁|激活锁/.test(message);
 const sameFamily=devices.length>1&&new Set(devices.map(deviceFamily)).size===1;
 const intent=sameFamily?'variant-question':devices.length>1?'comparison':devices.length?'device-question':unknownModel?'unknown-device':knowledge?'knowledge':'purchase-advice';
 return {intent, requiresPrice:intent==='purchase-advice', instruction:intent==='variant-question'?'检索到同名设备的不同地区版本。不要把参数拼接为同一台；先指出具体版本差异，必要时只追问地区版本，不先问预算。':intent==='comparison'?'先给有依据的条件式取舍，再比较2到3个与本轮相关的参数。地区或配置不一致需指出；缺实测不能宣布性能赢家。不要要求先填预算或品牌。':intent==='device-question'?'直接回答这个型号的当前问题；短句承接上一轮设备。只使用检索到的已核对字段，缺字段直说未整理，不把标称容量转成实测续航。不因没有报价阻止参数解释。':intent==='unknown-device'?'这一型号或变体尚未有已核对资料。不要拿标准版代替Pro/Ultra，也不要沿用上一轮设备。请用一句话说明缺口，至多问完整型号和地区版本。':intent==='knowledge'?'先解释概念或操作，不要求填写预算和品牌；按提供的知识卡回答。':'先接住预算和用途，说明最影响选择的取舍，至多追问一项。缺可靠报价时简短说明，不反复用缺数据替代回答。'};
}
export function referencePayload(devices:LibraryDevice[]) {
 return devices.filter(d=>d.review==='reviewed').slice(0,3).map(d=>({ id:d.id,name:d.name,category:d.category,year:d.year,region:d.region,configuration:d.facts.configuration||null,facts:Object.fromEntries(Object.entries(d.facts).filter(([,v])=>v)),source:{url:d.sourceUrl,checkedAt:d.importedAt},limitations:d.notes,role:'参数事实资料；不是通过预算和用途审核的购买候选' }));
}
export function relevantFacts(message:string,device:LibraryDevice) {
 const keys:FactKey[]=/续航|电池|充电/.test(message)?['battery','charging']: /内存|存储|容量|RAM|GB|TB/i.test(message)?['ram','storage','configuration']: /屏幕|高刷|刷新/.test(message)?['display','displayResolution']: /重量|多重|手感/.test(message)?['weight','dimensions']: /拍照|相机|摄影/.test(message)?['rearCamera','frontCamera']: /芯片|处理器|性能|游戏|能玩/.test(message)?['processor','gpu','ram']: /手写笔|画画|绘画/.test(message)?['stylus','display']:['processor','display','ram'];
 return keys.filter(k=>!!device.facts[k]).map(k=>`${factLabels[k]}：${device.facts[k]}`).slice(0,3);
}
