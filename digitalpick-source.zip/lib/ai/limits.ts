/** Defaults mirror the deployed public limits; operators configure values in Wrangler/env. */
export const publicAiLimits={dailyCalls:30,userDaily:10,userMinute:3,ipDaily:20,ipMinute:6,dailyTokens:180_000} as const;
export const testAiLimits={dailyCalls:40,minuteCalls:20,dailyTokens:2_000_000} as const;
const settings={dailyCalls:['AI_DAILY_CALL_LIMIT',200],userDaily:['AI_USER_DAILY_LIMIT',50],userMinute:['AI_USER_MINUTE_LIMIT',30],ipDaily:['AI_IP_DAILY_LIMIT',500],ipMinute:['AI_IP_MINUTE_LIMIT',60],dailyTokens:['AI_DAILY_TOKEN_LIMIT',20_000_000]} as const;
export function publicLimits(env:Record<string,string|undefined>){
 return Object.fromEntries(Object.entries(settings).map(([key,[name,max]])=>{const value=Number(env[name]);return[key,Number.isInteger(value)&&value>0?Math.min(value,max):publicAiLimits[key as keyof typeof publicAiLimits]];})) as Record<keyof typeof publicAiLimits,number>;
}
