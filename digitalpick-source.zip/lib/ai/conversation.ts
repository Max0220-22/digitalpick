import type { preferencesForTurns } from './preferences';
import { normalizeFollowUpAnswer } from '../companion/chat-history';
import { mentionedGames, gamingPattern } from './games';

type Decision = ReturnType<typeof preferencesForTurns>;
export function conversationPlan(decision: Decision, latest: string, hasCandidates: boolean) {
  const { memory, games, categoryInferred } = decision;
  const isGaming = games.length > 0 || decision.uses.some(use => use === '游戏' || use === '游戏性能') || gamingPattern.test(latest);
  const informational = /怎么(?:验|检查|看电池)|验机|账号锁|维修记录|是什么意思|基础知识/.test(latest);
  const known = [
    memory.budget ? `预算上限${memory.budget}元` : '',
    memory.category ? ({ phone: '手机', tablet: '平板', laptop: '笔记本电脑' }[memory.category]) : '',
    games.length ? `主要玩《${games.join('》《')}》` : decision.uses.length ? `用途：${decision.uses.join('、')}` : isGaming ? '主要打游戏' : '',
    memory.mode ? ({ new: '只考虑全新', used: '只考虑二手', either: '全新、二手都可以' }[memory.mode]) : '',
  ].filter(Boolean);
  let nextQuestion: string | null = null, questionKey: string | null = null;
  if (!informational) {
    if (!memory.category) { questionKey = 'category'; nextQuestion = '这次想选手机、平板，还是笔记本电脑？'; }
    else if (!memory.budget) { questionKey = 'budget'; nextQuestion = '这次的总预算上限是多少？'; }
    else if (!decision.uses.length && !games.length && !isGaming) { questionKey = 'use'; nextQuestion = '这台设备主要用来做什么？'; }
    else if (decision.unresolvedRequirements.length) { questionKey = 'requirement'; nextQuestion = '你提到的额外硬要求，哪一项是必须满足的？'; }
    else if (!memory.mode) { questionKey = 'mode'; nextQuestion = '更倾向全新，还是也接受二手？'; }
    else if (isGaming && !games.length) { questionKey = 'game'; nextQuestion = '最常玩的游戏是哪一款？'; }
    else if (!hasCandidates) { questionKey = 'model'; nextQuestion = '有正在考虑的具体型号吗？我可以继续帮你核对资料。'; }
  }
  return {
    known, games, isGaming, categoryInferred, nextQuestion, questionKey,
    latestGames: mentionedGames(latest),
    responseGoal: mentionedGames(latest).length ? '用户正在补充游戏名，接上既有预算和用途；不要重新开始问诊。' : '先回应本轮问题，再用已有条件推进。',
    assumptions: categoryInferred ? ['用户未明确设备类型，暂按手机方向；说明这是可纠正的假设。'] : [],
    missingEvidence: hasCandidates ? [] : ['当前没有同时满足可信报价与用途条件的购买候选；不是用户的问题。'],
  };
}
export type ConversationPlan = ReturnType<typeof conversationPlan>;

export function repeatsKnownQuestion(text: string, plan: ConversationPlan) {
  const questions = text.split(/[。！!\n]/).filter(part => /[?？]/.test(part));
  return questions.some(question =>
    (plan.known.some(s => s.startsWith('预算上限')) && /预算.{0,8}(?:多少|几千|几百)|(?:多少|几千).{0,6}预算/.test(question)) ||
    (plan.games.length > 0 && /(?:常玩|主要玩|玩|打)(?:的)?(?:游戏)?(?:具体)?(?:是|有)?(?:什么|哪些|哪(?:一|几)?款)|游戏(?:具体)?(?:是|有)?(?:什么|哪些|哪(?:一|几)?款)|(?:什么|哪些|哪(?:一|几)?款)(?:手机)?游戏/.test(question)) ||
    (plan.known.some(s => /只考虑|都可以/.test(s)) && /全新.{0,8}二手|二手.{0,8}全新/.test(question)));
}

export function conversationUserTurns(history: { role: 'user' | 'assistant'; content: string }[], message: string) {
  const turns: string[] = []; let previous = '';
  for (const turn of [...history, { role: 'user', content: message }]) {
    if (turn.role === 'assistant') previous = turn.content;
    else { turns.push(normalizeFollowUpAnswer(turn.content, previous)); previous = ''; }
  }
  return turns;
}
