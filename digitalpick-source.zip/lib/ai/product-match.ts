import { products, type Product } from '../products';
export function matchingProduct(message: string, path: string, dataset = products): Product | undefined {
  const normalized = message.toLowerCase().replace(/[\s‐‑–—-]+/g, '');
  const matches = dataset.filter(p => {
    const name = p.name.toLowerCase().replace(/[\s‐‑–—-]+/g, '');
    let index = normalized.indexOf(name);
    while (index >= 0) {
      const before = normalized.slice(Math.max(0, index - 1), index), after = normalized.slice(index + name.length);
      if (!/[a-z0-9]/.test(before) && !/^(?:[a-z0-9]|pro|max|plus|mini|ultra|fe|s\d)/.test(after)) return true;
      index = normalized.indexOf(name, index + 1);
    }
    return false;
  }).sort((a, b) => b.name.length - a.name.length);
  if (matches.length === 1) return matches[0];
  if (matches.length > 1) return undefined;
  // An explicitly named unlisted variant must not silently fall back to the page's standard model.
  if (/(?:iphone|ipad|macbook|galaxy|xiaomi|redmi|pixel|oneplus|vivo|oppo|honor|huawei|thinkpad|surface|小米|红米|三星|荣耀|华为|一加|苹果).{0,16}?(?:\d|\b[xs]\b|xs|xr)/i.test(message)) return undefined;
  return dataset.find(p => path.split('?')[0].replace(/\/$/, '') === `/products/${p.id}`);
}
