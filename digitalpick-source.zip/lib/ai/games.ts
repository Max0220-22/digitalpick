// Names identify the user's workload. They do not imply tested frame rates or device compatibility.
const games = [
  ['王者荣耀', /王者(?:荣耀)?/i],
  ['和平精英', /和平精英/],
  ['原神', /原神/],
  ['崩坏：星穹铁道', /(?:崩坏[：:]?)?星穹铁道|星铁/],
  ['金铲铲之战', /金铲铲(?:之战)?/],
  ['英雄联盟手游', /英雄联盟手游|LOL手游/i],
  ['无畏契约', /无畏契约|valorant/i],
  ['黑神话：悟空', /黑神话[：:]?悟空/],
  ['三角洲行动', /三角洲行动/],
] as const;
export const gamingPattern = /游戏|手游|王者(?:荣耀)?|和平精英|原神|星穹铁道|星铁|金铲铲|英雄联盟手游|LOL手游|无畏契约|valorant|黑神话|三角洲行动/i;
export function mentionedGames(text: string) {
  return games.filter(([, pattern]) => pattern.test(text)).map(([name]) => name as string);
}
export function updateGames(previous: string[], text: string) {
  let result = /不(?:玩|打)(?:任何)?游戏|不玩了|不打了/.test(text) ? [] : [...previous];
  if (/只玩|改玩/.test(text)) result = [];
  for (const [name, pattern] of games) {
    const negative = new RegExp(`(?:不玩|不打|不考虑|不需要)(?:再|了|这款)?(?:${pattern.source})`, 'gi');
    if (negative.test(text)) result = result.filter(value => value !== name);
    const positive = text.replace(negative, '');
    if (pattern.test(positive) && !result.includes(name)) result.push(name);
  }
  return result;
}
export function suggestsPhone(text: string) {
  const positive = text.replace(/(?:不玩|不打)(?:王者(?:荣耀)?|和平精英|金铲铲(?:之战)?|英雄联盟手游|LOL手游)/gi, '');
  return /王者(?:荣耀)?|和平精英|金铲铲(?:之战)?|英雄联盟手游|LOL手游/i.test(positive);
}
