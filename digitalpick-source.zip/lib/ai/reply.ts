import type { buildContext } from './context';
import { repeatsKnownQuestion } from './conversation';
import { validateModelReply, type AssistantReply } from './schema';
type Context = ReturnType<typeof buildContext>;

/** A failure is recovered with disclosed local guidance, never a fabricated model answer or another paid call. */
export function safeGuideReply(context: Context): AssistantReply {
  const plan = context.payload.conversation;
  const paragraphs = [plan.known.length ? `已记住：${plan.known.join('；')}。` : '我会接着你已有的信息继续整理。'];
  if (plan.categoryInferred) paragraphs.push('我先按手机方向帮你看；如果你指的是平板或电脑，可以直接纠正。');
  if (plan.isGaming) paragraphs.push('围绕游戏，先核对当前版本下的帧率稳定性、发热和电池状态；没有同条件实测时，不承诺具体帧数。');
  if (!context.candidates.length) paragraphs.push('目前资料库缺少满足条件的可靠报价或适配依据，暂时不能确认预算内可买的具体机型。');
  return {
    answer: paragraphs.join('\n\n'), followUpQuestions: plan.nextQuestion ? [plan.nextQuestion] : [], recommendations: [],
    mode: 'guide', model: null, budgetQualified: !!context.memory.budget, links: context.guide.links,
    notice: '本次模型回复未通过检查，已由本地规则接续整理；没有再次调用模型。',
  };
}
export function completeModelReply(data: unknown, context: Context, model: string): AssistantReply {
  try {
    const result = data as { choices?: { finish_reason?: string; message?: { content?: unknown } }[] };
    const choice = result?.choices?.[0];
    if (choice?.finish_reason !== 'stop' || typeof choice.message?.content !== 'string') throw new Error('INCOMPLETE');
    let content = choice.message.content.trim().replace(/^\uFEFF/, '');
    // Only unwrap a whole JSON fence; do not scrape an object out of arbitrary prose.
    const fence = content.match(/^```(?:json)?\s*\n?([\s\S]*?)\n?```$/i);
    if (fence) content = fence[1].trim();
    const reply = validateModelReply(JSON.parse(content), context.candidates.map(p => p.id), { budget: context.memory.budget });
    const plan = context.payload.conversation;
    if (repeatsKnownQuestion(reply.answer, plan)) throw new Error('REPEATED_QUESTION');
    const questions = reply.followUpQuestions.filter(q => !repeatsKnownQuestion(q, plan)).slice(0, 1);
    return { ...reply, followUpQuestions: questions, mode: 'ai', model, budgetQualified: !!context.memory.budget, links: context.guide.links };
  } catch { return safeGuideReply(context); }
}
