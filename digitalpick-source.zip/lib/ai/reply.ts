import type { buildContext } from './context';
import { referenceDisclosure } from './reference-suggestions';
import { repeatsKnownQuestion } from './conversation';
import { relevantFacts } from './retrieval';
import { componentGuide } from './component-knowledge';
import { validateModelReply, type AssistantReply } from './schema';
type Context = ReturnType<typeof buildContext>;

/** A failure is recovered with disclosed local guidance, never a fabricated model answer or another paid call. */
export function safeGuideReply(context: Context, validationCode = 'INVALID_FORMAT'): AssistantReply {
  const notice = validationCode === 'LOCAL_GUIDE' ? '本地规则参考，未调用云端模型。' : '这次由本地规则补充参考，在线回答暂未完成。';
  const plan = context.payload.conversation;
  if (context.task.intent !== 'purchase-advice') {
    const facts = context.references.map(device => {
      const values = relevantFacts(context.question, device);
      return `${device.name}（${device.region}）：${values.length ? values.join('；') : '这一问题对应的参数尚未整理。'}`;
    });
    const answer = context.task.intent === 'impossible-request' ? '目前没有这样的产品，手机还不能带人穿越时空。真有这功能，我也想先回去提醒自己早点备份照片。' : context.task.intent === 'component-comparison' ? componentGuide(context.question) : facts.length ? facts.join('\n\n') + (/续航|游戏|能玩|性能/.test(context.question) ? '\n\n这些是官方标称参数，缺少同条件实测时不能承诺游戏帧率或判断实际续航高低。' : '') : context.task.intent === 'unknown-device' ? '这款具体型号或地区版本还没有已核对参数，我不会拿标准版或上一款设备代替。' : /内存和存储|RAM和/.test(context.question) ? '内存（RAM）是设备运行应用时的临时工作空间；存储用来长期保存应用、照片和文件。买设备时需要分别核对，两者不能相互替代。' : /验机|避坑|账号锁|root|bootloader|保值|转卖|渠道|哪里买|购买链接|全新还是二手|清空|重新开始/i.test(context.question) ? context.guide.text : /你好|嗨|hello|谢谢/i.test(context.question) ? '嗨，我是小派。可以一起聊数码，也可以直接问你想了解的参数或使用问题。' : '在线顾问暂时无法完成这次解释，我不会拿旧预算或购买清单代替你的问题。可以稍后重试；具体设备参数也能在产品库查看。';
    return { answer, followUpQuestions: plan.nextQuestion ? [plan.nextQuestion] : [], recommendations: [], mode:'guide', model:null, budgetQualified:false, links:context.links, validationCode, notice };
  }
  const paragraphs: string[] = [context.memory.budget ? `按你的${context.memory.budget}元预算，先把参数、成色和实际报价一起比较。` : '先从用途和购买方式看起，预算可以接着补充。'];
  if (plan.categoryInferred) paragraphs.push('我先按手机方向帮你看；如果你指的是平板或电脑，可以直接纠正。');
  if (plan.isGaming) paragraphs.push((plan.games.length ? `主要玩《${plan.games.join('》《')}》的话，` : '围绕游戏，')+'先核对当前版本下的帧率稳定性、发热和电池状态；没有同条件实测时，不承诺具体帧数。');
  if (!context.candidates.length && !context.advisory.length) paragraphs.push('目前资料库缺少满足条件的可靠报价或适配依据，暂时不能确认预算内可买的具体机型。');
  if(context.advisory[0]?.assumedUse) paragraphs.push(`尚未说明用途，先按${context.advisory[0].assumedUse}给参考，补充后会重新匹配。`);
  const budgetContext=context.payload.recommendationBudgetContext;
  if(budgetContext && budgetContext.stage!=='original') paragraphs.push(budgetContext.message);
  if(context.advisory.length)paragraphs.push('可以先核价：'+context.advisory.slice(0,3).map(s=>`${s.product.name}（规则v2.1 ${s.score}分；${s.mode==='used'?'二手':'全新'}方向；${s.basis.startsWith('基于估算价')?'基于估算价':'有效报价参考'}）`).join('；')+'。'+referenceDisclosure);
  else if(context.candidates.length) paragraphs.push('按同配置有效报价和已确认条件，可先了解：'+context.candidates.slice(0,3).map(p=>p.name).join('、')+'；购买前仍须核价和确认售后。');
  return {
    answer: paragraphs.join('\n\n'), followUpQuestions: plan.nextQuestion ? [plan.nextQuestion] : [], recommendations: context.advisory.length ? context.advisory.slice(0,3).map(s=>({id:s.product.id,reason:`规则v2.1 ${s.score}分；${s.product.processor}；${s.basis}`,caution:s.overBudget ? `按参考区间上限加预留核算，仍超原预算¥${s.overBudget}，仅供提高预算前参考；具体配置、成色与实际报价需要核实。` : '具体配置、成色与实际报价需要核实，不保证预算内可买。'})) : context.candidates.slice(0,3).map(p=>({id:p.id,reason:p.processor,caution:'购买前核实同配置报价、来源和售后。'})),
    recommendationScope:context.advisory.length?'reference':context.candidates.length?'verified':undefined, mode: 'guide', model: null, budgetQualified: context.candidates.length>0, links: context.links,
    validationCode, notice,
  };
}
export function completeModelReply(data: unknown, context: Context, model: string): AssistantReply {
  try {
    const result = data as { choices?: { finish_reason?: string; message?: { content?: unknown } }[] };
    const choice = result?.choices?.[0];
    if (choice?.finish_reason !== 'stop' || typeof choice.message?.content !== 'string') throw new Error('INCOMPLETE');
    let content = choice.message.content.trim().replace(/^\uFEFF/, '');
    // Only unwrap a whole JSON fence; do not scrape an object out of arbitrary prose.
    const fence = content.match(/^```(?:json)?\s*\n?([\s\S]*?)\n?```$/i);
    if (fence) content = fence[1].trim();
    const purchase = context.task.intent === 'purchase-advice';
    let value: unknown;
    try { value = JSON.parse(content); } catch {
      // A complete plain answer is useful for informational turns; never scrape partial JSON.
      if (purchase || /^[{\[\x60]/.test(content) || /"answer"\s*:/.test(content)) throw new Error('INVALID_FORMAT');
      value = { answer: content };
    }
    if (!purchase && value && typeof value === 'object') {
      const info = value as Record<string, unknown>;
      value = { answer: info.answer, followUpQuestions: Array.isArray(info.followUpQuestions) ? info.followUpQuestions.filter(q => typeof q === 'string' && q.length > 0 && q.length <= 100).slice(0,1) : [], recommendations: [] };
    }
    const reply = validateModelReply(value, [...context.candidates.map(p => p.id),...context.advisory.map(s=>s.product.id)], { budget: purchase ? context.memory.budget : undefined });
    const plan = context.payload.conversation;
    if (context.task.intent === 'impossible-request' && !/没有|不存在|无法|不能|做不到|不可能|尚无|目前还没/.test(reply.answer)) throw new Error('UNSUPPORTED_CLAIM');
    const claims=[reply.answer,...reply.recommendations.flatMap(r=>[r.reason,r.caution])].join('。').replace(/(?:不|不能|无法|没法|未能)(?:保证|确保|承诺)[^。；\n]*/g,'');
    if(context.advisory.length&&/(?:保证|确保|承诺|肯定|一定).{0,8}(?:有货|买到|买得到|预算内)|库存充足|现货充足|都(?:在|符合).{0,4}预算/.test(claims))throw new Error('UNVERIFIED_PURCHASE_PROMISE');
    if (purchase && repeatsKnownQuestion(reply.answer, plan)) throw new Error('REPEATED_QUESTION');
    let questions = reply.followUpQuestions.filter(q => !repeatsKnownQuestion(q, plan)).slice(0, 1);
    const reference=reply.recommendations.some(rec=>context.advisory.some(s=>s.product.id===rec.id));
    if(reference&&!questions.length&&plan.nextQuestion&&!/[?？]/.test(reply.answer))questions=[plan.nextQuestion];
    let answer=reference&&!/非实时价格.*购买前.{0,3}核实/s.test(reply.answer)?reply.answer+'\n\n'+referenceDisclosure:reply.answer;
    if(reference && context.payload.recommendationBudgetContext?.stage!=='original' && context.payload.recommendationBudgetContext) answer+='\n\n'+context.payload.recommendationBudgetContext.message;
    return { ...reply, answer, followUpQuestions: questions, mode: 'ai', model, budgetQualified:context.candidates.length>0&&reply.recommendations.length>0, recommendationScope:reference?'reference':'verified', ...(reference?{notice:referenceDisclosure}:{}), links: context.links };
  } catch (cause) {
    const code=cause instanceof Error&&['UNSUPPORTED_CLAIM','INVALID_PRODUCT','REPEATED_QUESTION','INCOMPLETE','UNVERIFIED_PURCHASE_PROMISE'].includes(cause.message)?cause.message:'INVALID_FORMAT';
    console.info('[assistant] response fallback', { intent: context.task.intent, code });
    return safeGuideReply(context,code);
  }
}
