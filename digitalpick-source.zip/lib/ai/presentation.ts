import type {AssistantReply} from './schema';
import {referenceDisclosure} from './reference-suggestions';
export function chatReplyNotice(reply:Pick<AssistantReply,'mode'|'recommendationScope'|'notice'|'fallbackReason'|'fallbackDetail'|'reviewAdjusted'>){
 if(reply.mode==='guide'){
  const reason=reply.fallbackReason;
  const message=reason==='daily-quota'?'今日在线顾问额度已用完，已切换为本地整理。':reason==='model-failure'?(reply.fallbackDetail==='empty'?'模型未返回有效正文，已切换为本地整理。':reply.fallbackDetail==='incomplete'?'模型回复不完整，已切换为本地整理。':reply.fallbackDetail==='validation'?'模型回复未通过资料校验，已切换为本地整理。':reply.fallbackDetail==='timeout'?'模型回复超时，已切换为本地整理。':'模型调用失败，已切换为本地整理。'):reason==='limited'?'请求暂时达到频率限制，已切换为本地整理。':'在线顾问当前不可用，已切换为本地整理。';
  return message+'本地资料参考，非模型回答。';
 }
 return [reply.reviewAdjusted?'部分机型或分数已按本站资料校对，其余模型内容保留。':'',reply.recommendationScope==='reference'?referenceDisclosure:''].filter(Boolean).join('')||null;
}
