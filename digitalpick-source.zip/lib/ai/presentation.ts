import type { AssistantReply } from './schema';
import { referenceDisclosure } from './reference-suggestions';
export function chatReplyNotice(reply: Pick<AssistantReply, 'mode' | 'recommendationScope' | 'notice' | 'fallbackReason'>) {
 if (reply.mode === 'guide' && reply.fallbackReason) return reply.fallbackReason === 'daily-quota' ? 'AI 额度今天用完了，先用本地资料给你个参考。规则选购和产品库仍可使用。' : '在线顾问暂时达到限额，先用本地资料给你个参考。';
 if (reply.mode === 'guide') return '本地资料参考，非模型回答。';
 return reply.recommendationScope === 'reference' ? referenceDisclosure : null;
}
