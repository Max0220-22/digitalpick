import type { AssistantReply } from './schema';
import { referenceDisclosure } from './reference-suggestions';
export function chatReplyNotice(reply: Pick<AssistantReply, 'mode' | 'recommendationScope' | 'notice'>) {
 if (reply.mode === 'guide') return '本地资料参考，非模型回答。';
 return reply.recommendationScope === 'reference' ? referenceDisclosure : null;
}
