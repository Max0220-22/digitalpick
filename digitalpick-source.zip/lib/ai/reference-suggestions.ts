import type { Product } from '../products';
import type { preferencesForTurns } from './preferences';
import { analyzeRecommendations, type BudgetContext } from '../recommend';
export const referenceDisclosure = '基于资料库参考，非实时价格，购买前请核实；这是核价备选，不保证预算内可买或有库存。';
export interface ReferenceSuggestion {
 product: Product; mode: 'new'|'used'; basis: string; configuration: string; checkedAt: string; budgetVerified: false;
 score: number; assumedUse?: string; budgetContext: BudgetContext; overBudget: number;
}
/** Same v2.1 planning engine as the questionnaire; estimates never become verified purchase quotes. */
export function referenceSuggestions(decision: ReturnType<typeof preferencesForTurns>, dataset: Product[], now: Date): ReferenceSuggestion[] {
 const {memory,preferences}=decision;
 if (!memory.budget || !memory.category || decision.budgetUnclear || decision.unresolvedRequirements.length || !preferences) return [];
 // This is a disclosed provisional use, never stored as a user-confirmed preference.
 const assumedUse = decision.uses.length ? undefined : { phone: '日常使用', tablet: '娱乐影音', laptop: '日常办公' }[memory.category];
 const planning = assumedUse ? { ...preferences, uses: [assumedUse], primaryUse: assumedUse } : preferences;
 const audit = analyzeRecommendations(planning, dataset, now, { pricePolicy: 'reference-guidance' });
 if (audit.inputError || !audit.budgetContext) return [];
 return audit.recommendations.map(result => ({
  product: result.product, mode: result.offer.mode,
  basis: `${result.offer.evidence?.estimated ? '基于估算价' : '同配置有效报价'} · ${result.offer.evidence?.label || '报价'}；${result.offer.evidence?.note || '购买前核实配置、成色和实际报价。'}`,
  configuration: result.offer.evidence?.configuration || result.product.configuration,
  checkedAt: result.offer.evidence?.checkedAt || result.offer.price.collectedAt,
  budgetVerified: false, score: result.score, assumedUse, budgetContext: audit.budgetContext!,
  overBudget: Math.max(0, result.offer.totalCeiling - preferences.maxBudget),
 }));
}
