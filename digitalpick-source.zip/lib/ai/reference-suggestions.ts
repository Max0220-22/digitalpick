import type { Product } from '../products';
import type { preferencesForTurns } from './preferences';
import { pricingFor, usedPriceScenario } from '../price-reference';
export const referenceDisclosure = '基于资料库参考，非实时价格，购买前请核实；这是核价备选，不保证预算内可买或有库存。';
export interface ReferenceSuggestion { product: Product; mode: 'new'|'used'; basis: string; configuration: string; checkedAt: string; budgetVerified: false }
/** Discovery directions only. Does not create a quote, change rule scores, or enter the hard-budget engine. */
export function referenceSuggestions(decision: ReturnType<typeof preferencesForTurns>, dataset: Product[], now: Date): ReferenceSuggestion[] {
 const {memory,preferences}=decision;
 if (!memory.budget || !memory.category || decision.budgetUnclear || decision.unresolvedRequirements.length || !preferences) return [];
 const available=memory.budget-(preferences.reserveBudget||0);
 if(available<=0)return [];
 const rows: (ReferenceSuggestion & {priority:number})[]=[];
 for(const product of dataset){
  if(product.category!==memory.category || (product.year!==null&&product.year>now.getFullYear()) || !product.processor || /尚未|待核|未整理/.test(product.processor))continue;
  const android=/android|originos|coloros|miui|hyperos|澎湃/i.test(product.os);
  if(preferences.os && !(preferences.os==='Android'?android:product.os.toLowerCase().includes(preferences.os.toLowerCase())))continue;
  if((preferences.storage>0&&(product.storage===null||product.storage<preferences.storage))||(preferences.maxWeight!==null&&(product.weight===null||product.weight>preferences.maxWeight))||(preferences.maxScreen!==null&&(product.screenSize===null||product.screenSize>preferences.maxScreen)))continue;
  if(decision.uses.some(use=>Number.isFinite(product.useScores[use])&&product.useScores[use]<3))continue;
  const info=pricingFor(product.id),estimate=usedPriceScenario(product,now.toISOString().slice(0,10));
  const official=info.official;
  const officialDays=official?(now.getTime()-Date.parse(official.checkedAt+'T00:00:00+08:00'))/86400000:Infinity;
  if(memory.mode!=='used'&&official&&official.currency==='CNY'&&officialDays>=0&&officialDays<=30&&official.amount<=available){
   rows.push({product,mode:'new',basis:'官网非实时报价参考，配置和结算价待逐项核实',configuration:official.configuration,checkedAt:official.checkedAt,budgetVerified:false,priority:3000000+(product.year||0)*100+official.amount/available});
  }else if(memory.mode!=='new'&&estimate&&estimate.max<=available){
   rows.push({product,mode:'used',basis:'无市场样本的折旧情景估算，成色与真实卖家报价待核实',configuration:estimate.anchor.configuration,checkedAt:estimate.date,budgetVerified:false,priority:2000000+(product.year||0)*100+estimate.max/available});
  }else if(memory.mode!=='used'&&info.status!=='not-listed'&&!official){
   const historical=info.launch||info.msrp;
   if(historical&&historical.currency==='CNY'&&historical.amount<=available)rows.push({product,mode:'new',basis:info.launch?'历史首发参考，仅供核价方向，不证明今日在售':'官方建议价参考，未核实首发价或今日在售价',configuration:historical.configuration,checkedAt:historical.checkedAt,budgetVerified:false,priority:1000000+(product.year||0)*100+historical.amount/available});
  }
 }
 const seen=new Set<string>();
 return rows.sort((a,b)=>b.priority-a.priority||a.product.id.localeCompare(b.product.id)).filter(row=>{const key=row.product.name.toLowerCase().replace(/[^a-z0-9\u4e00-\u9fff+]/g,'');if(seen.has(key))return false;seen.add(key);return true;}).slice(0,6).map(({priority,...row})=>row);
}
