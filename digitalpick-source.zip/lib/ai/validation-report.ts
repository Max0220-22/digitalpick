/** Safe review summaries only. Raw model output remains in opt-in development logs. */
export type ValidationCategory = 'model'|'score'|'price'|'budget'|'parameter'|'response';
export interface ValidationIssue {rule:string;fields:string[];products:string[];category:ValidationCategory;reason:string}
export interface ValidationReview {outcome:'adjusted'|'rejected';issues:ValidationIssue[]}
export function validationIssue(rule:string,fields:string[],products:string[],detail?:Pick<ValidationIssue,'category'|'reason'>):ValidationIssue {
 const reasons:Record<string,[ValidationCategory,string]>={
  UNKNOWN_MODEL:['model','资料库未收录这个完整机型或版本，已移除对应机型/语句；没有用相近型号替代。'],
  DUPLICATE_MODEL:['model','同一机型重复出现，已合并重复推荐卡。'],
  SCORE_MISMATCH:['score','模型给出的分数与当前需求下的本站规则分不一致，已按本站规则校对。'],
  UNAVAILABLE_SCORE:['score','当前条件下没有可核对的本站规则分，已移除该分数。'],
  UNVERIFIED_RENDER_CONTENT:['response','该字段包含未经核实的展示内容，已按现有展示规则处理。'],
  RESPONSE_ENVELOPE_REPAIRED:['response','模型响应结构不完整，已提取可恢复的正文，其余有效内容保留。'],
  EMPTY_AFTER_PRODUCT_REVIEW:['response','移除未收录机型后没有剩余有效正文，最终改用本地资料参考。'],
  EMPTY_RESPONSE:['response','模型没有返回有效正文，最终改用本地资料参考；这不属于价格或参数不匹配。'],
  INCOMPLETE:['response','模型回复未完整结束，最终改用本地资料参考；这不属于预算不足。'],
 };
 const [category,reason]=reasons[rule]||['response','回复未通过现有处理规则，最终改用本地资料参考。'];
 return {rule,fields:fields.slice(0,8),products:products.slice(0,6).map(p=>p.slice(0,160)),category:detail?.category||category,reason:detail?.reason||reason};
}
