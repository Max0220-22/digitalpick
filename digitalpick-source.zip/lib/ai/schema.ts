import { z } from 'zod';
import type {ValidationReview} from './validation-report';
import {ReplyValidationError} from './validation-diagnostics';

export const requestSchema = z.object({
  message: z.string().trim().min(1).max(800),
  history: z.array(z.object({ role: z.enum(['user', 'assistant']), content: z.string().max(1600) })).max(8).default([]),
  requestId:z.string().uuid().optional(),
  path: z.string().max(160).regex(/^\/[a-zA-Z0-9/?=&_-]*$/).default('/'),
});
export const modelReplySchema = z.object({
  answer: z.string().trim().min(1).max(1600),
  followUpQuestions: z.array(z.string().min(1).max(100)).max(3).default([]),
  recommendations: z.array(z.object({ id: z.string().max(80), reason: z.string().min(1).max(180), caution: z.string().min(1).max(180) })).max(3).default([]),
});
export type ModelReply = z.infer<typeof modelReplySchema>;
export interface AssistantReply extends ModelReply { model: string | null; mode: 'ai' | 'guide'; notice?: string; budgetQualified: boolean; recommendationScope?: 'verified'|'reference'; validationCode?: string; fallbackReason?: 'daily-quota'|'limited'|'model-failure'|'other'; reviewAdjusted?:boolean; validationReview?:ValidationReview; fallbackDetail?:'timeout'|'network'|'validation'|'empty'|'incomplete'; links: { label: string; href: string }[] }

/** A tolerant envelope reader. Product facts are reviewed separately and repaired locally. */
export function validateModelReply(value:unknown,allowedIds:readonly string[],_options:{budget?:number}={}):ModelReply {
 const object=typeof value==='string'?{answer:value}:value&&typeof value==='object'?value as Record<string,unknown>:{};
 const answer=[object.answer,object.content,object.text,object.reply,object.message,object.response].find(v=>typeof v==='string') as string|undefined;
 if(!answer?.trim())throw new ReplyValidationError('EMPTY_RESPONSE',['answer']);
 const recommendations=Array.isArray(object.recommendations)?object.recommendations.flatMap(item=>{
  if(!item||typeof item!=='object')return [];
  const rec=item as Record<string,unknown>,id=typeof rec.id==='string'?rec.id:'';
  if(!allowedIds.includes(id))return [];
  return [{id,reason:typeof rec.reason==='string'?rec.reason:'可先核对资料库参数。',caution:typeof rec.caution==='string'?rec.caution:'非实时价格，购买前核实配置、成色和来源。'}];
 }).filter((rec,index,array)=>array.findIndex(other=>other.id===rec.id)===index).slice(0,3):[];
 return {answer:answer.trim(),followUpQuestions:Array.isArray(object.followUpQuestions)?object.followUpQuestions.filter((q):q is string=>typeof q==='string'&&!!q.trim()).slice(0,3):[],recommendations};
}
