import { z } from 'zod';

export const requestSchema = z.object({
  message: z.string().trim().min(1).max(800),
  history: z.array(z.object({ role: z.enum(['user', 'assistant']), content: z.string().max(1600) })).max(8).default([]),
  path: z.string().max(160).regex(/^\/[a-zA-Z0-9/?=&_-]*$/).default('/'),
});
export const modelReplySchema = z.object({
  answer: z.string().trim().min(1).max(1600),
  followUpQuestions: z.array(z.string().min(1).max(100)).max(3).default([]),
  recommendations: z.array(z.object({ id: z.string().max(80), reason: z.string().min(1).max(180), caution: z.string().min(1).max(180) })).max(3).default([]),
});
export type ModelReply = z.infer<typeof modelReplySchema>;
export interface AssistantReply extends ModelReply { model: string | null; mode: 'ai' | 'guide'; notice?: string; budgetQualified: boolean; links: { label: string; href: string }[] }

// Only a tightly labelled, exact user budget at the start of the answer may contain money. Quotations remain forbidden.
const moneyClaim = /[¥￥$]|\d[\d,.]*(?:\s*[-–到至]\s*\d[\d,.]*)?\s*(?:元|块钱|人民币|美元)|[一二三四五六七八九十百千万]+(?:元|块钱)|https?:\/\/|sk-[a-zA-Z0-9]{12,}/i;
function maskConfirmedBudget(answer: string, budget: number | undefined) {
  if (!Number.isInteger(budget) || !budget || budget <= 0) return answer;
  const amount = budget.toString(), formatted = budget.toLocaleString('en-US');
  const number = formatted === amount ? amount : `(?:${amount}|${formatted})`;
  const introduction = new RegExp(`^(?:(?:明白|好的|收到|了解|已记住)[，,。！!：:\\s]*)?(?:(?:你的|你这次的|这次的|本次的|总)?预算(?:上限)?)(?:是|为|有)?\\s*[¥￥]?\\s*${number}\\s*(?:元|块钱|人民币)(?:以内|以下)?(?=[，,。；;\\n]|$)`);
  return answer.replace(introduction, '[已确认预算]');
}
export function validateModelReply(value: unknown, allowedIds: readonly string[], options: { budget?: number } = {}): ModelReply {
  const parsed = modelReplySchema.parse(value);
  const ids = new Set<string>();
  for (const rec of parsed.recommendations) {
    if (!allowedIds.includes(rec.id) || ids.has(rec.id)) throw new Error('INVALID_PRODUCT');
    ids.add(rec.id);
  }
  if (moneyClaim.test(JSON.stringify({ ...parsed, answer: maskConfirmedBudget(parsed.answer, options.budget) }))) throw new Error('UNSUPPORTED_CLAIM');
  return parsed;
}
