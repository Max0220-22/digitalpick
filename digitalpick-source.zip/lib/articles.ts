import fs from 'node:fs';
import path from 'node:path';
export const articleCategories = ['二手手机避坑', '苹果设备选购', '安卓手机选购', '大学生电脑推荐', '数码产品保值率', '电池健康与维修', 'Root与Bootloader基础知识', 'AI手机与本地模型', '开箱之后'];
export const articles = [
 { slug: 'after-unboxing', title: '开箱之后：检查、激活与数据迁移', category: '开箱之后', excerpt: '先留证、再检查，确认激活与退货约定后，把旧设备的数据安全带过来。', minutes: 5, color: 'blue' },
 { slug: 'used-phone-basics', title: '第一次买二手手机，先问这 6 个问题', category: '二手手机避坑', excerpt: '来源、维修、账号和交易记录，比一句“几乎全新”更有用。', minutes: 4, color: 'blue' },
 { slug: 'student-laptop', title: '大学生选电脑，先看专业，再看参数', category: '大学生电脑推荐', excerpt: '把必用软件和携带需求列出来，预算才有明确的去处。', minutes: 4, color: 'purple' },
 { slug: 'battery-health', title: '电池健康度，能告诉你多少？', category: '电池健康与维修', excerpt: '百分比只是一条线索，还需要结合续航、发热和使用记录。', minutes: 3, color: 'green' },
 { slug: 'apple-ecosystem', title: '买苹果设备前，先确认这几件事', category: '苹果设备选购', excerpt: '先核对应用兼容性、配件和存储，再考虑生态协同。', minutes: 3, color: 'silver' },
 { slug: 'android-choices', title: '安卓手机怎么选？把需求拆成四件事', category: '安卓手机选购', excerpt: '处理器以外，屏幕、影像、系统和体积也值得认真比较。', minutes: 3, color: 'green' },
 { slug: 'resale-value', title: '保值率不是一个固定答案', category: '数码产品保值率', excerpt: '同一配置、同一成色、同一时间，才有讨论差价的前提。', minutes: 3, color: 'blue' },
 { slug: 'bootloader-basics', title: 'Root 与 Bootloader，先理解再动手', category: 'Root与Bootloader基础知识', excerpt: '系统可玩性背后，也有数据、更新与设备兼容性的取舍。', minutes: 4, color: 'purple' },
 { slug: 'local-ai-basics', title: '为了本地 AI 买设备，先问模型需要什么', category: 'AI手机与本地模型', excerpt: '先明确任务和模型需求，再判断内存、软件支持与使用成本。', minutes: 4, color: 'silver' },
];
export function getArticle(slug: string) { const article = articles.find(a => a.slug === slug); if (!article) return null; return { ...article, updatedAt: slug === 'after-unboxing' ? '2026-10-19' : '2026-10-16', content: fs.readFileSync(path.join(process.cwd(), 'content/articles', `${article.slug}.md`), 'utf8') }; }
