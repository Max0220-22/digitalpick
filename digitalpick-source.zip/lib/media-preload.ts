import { assetPath } from './deployment';
// Intent-driven, bounded warming only: never fetch every category on first render.
const warmed = new Set<string>();
export function preloadMedia(sources: (string | undefined)[]) {
  if (typeof window === 'undefined' || typeof Image === 'undefined') return;
  const connection = (navigator as Navigator & { connection?: { saveData?: boolean; effectiveType?: string } }).connection;
  if (connection?.saveData || /^(slow-2g|2g)$/.test(connection?.effectiveType || '')) return;
  for (const source of [...new Set(sources.filter((s): s is string => !!s))].slice(0,3)) {
    const src = assetPath(source);
    if (warmed.has(src) || warmed.size >= 32) continue;
    warmed.add(src);
    const image = new Image(); image.decoding = 'async'; image.referrerPolicy = 'no-referrer';
    image.onerror = () => warmed.delete(src); image.src = src;
  }
}
