import { isModelTap } from './state';
export { isModelTap } from './state';
import { Raycaster, Vector2, type Camera, type Object3D } from 'three';

export type ModelAction = 'chat' | 'theme';
type Point = { x: number; y: number };

/** Pick the nearest visible surface, then resolve its action on the moving model.
 * Never fill empty space with a whole-model bounding box or click through the torso.
 */
export function createModelPicker(model: Object3D, camera: Camera) {
 const ray = new Raycaster(), point = new Vector2();
 return (x: number, y: number, rect: { left: number; top: number; width: number; height: number }): ModelAction | null => {
  if (rect.width <= 0 || rect.height <= 0 || x < rect.left || y < rect.top || x > rect.left + rect.width || y > rect.top + rect.height) return null;
  point.set((x - rect.left) / rect.width * 2 - 1, -(y - rect.top) / rect.height * 2 + 1);
  camera.updateMatrixWorld(); model.updateWorldMatrix(true, true); ray.setFromCamera(point, camera);
  for (const hit of ray.intersectObject(model, true)) {
   let action: ModelAction | null = null, visible = true;
   for (let node: Object3D | null = hit.object; node; node = node.parent) {
    if (!node.visible) { visible = false; break; }
    const value = node.userData.companionAction;
    if (!action && (value === 'chat' || value === 'theme')) action = value;
    if (node === model) break;
   }
   if (visible) return action;
  }
  return null;
 };
}
/** A press must begin and finish on the same part; drags stay cancelled even after returning. */
export function isModelActionTap(start: Point & { action: ModelAction | null }, end: Point & { action: ModelAction | null }, dragged = false) {
 return !dragged && start.action !== null && start.action === end.action && isModelTap(start, end);
}
