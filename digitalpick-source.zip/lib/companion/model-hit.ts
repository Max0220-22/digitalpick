import { Box3, Raycaster, Vector2, Vector3, type Camera, type Object3D } from 'three';
/** Only the robot group is pickable. Orbits, floor and canvas whitespace are excluded. */
export function createModelPicker(model: Object3D, camera: Camera) {
 const ray = new Raycaster(), point = new Vector2(), bounds = new Box3(), intersection = new Vector3();
 return (x: number, y: number, rect: { left: number; top: number; width: number; height: number }, touch = false) => {
  if (rect.width <= 0 || rect.height <= 0 || x < rect.left || y < rect.top || x > rect.left + rect.width || y > rect.top + rect.height) return false;
  point.set((x - rect.left) / rect.width * 2 - 1, -(y - rect.top) / rect.height * 2 + 1);
  camera.updateMatrixWorld(); model.updateWorldMatrix(true, true); ray.setFromCamera(point, camera);
  if (ray.intersectObject(model, true).length) return true;
  // Modest world-space padding follows the moving model; it never covers the whole stage.
  bounds.setFromObject(model).expandByScalar(touch ? .18 : .08);
  return !!ray.ray.intersectBox(bounds, intersection);
 };
}
export function isModelTap(start: { x: number; y: number }, end: { x: number; y: number }) {
 return Math.hypot(start.x - end.x, start.y - end.y) <= 9;
}
