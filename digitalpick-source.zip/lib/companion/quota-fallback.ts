export type LocalFallbackReason = 'daily-quota' | 'limited';
export function quotaFallback(status: number, error: unknown, retryAfter: string | null, now = Date.now()) {
 if (status !== 429) return null;
 const seconds = retryAfter && /^\d+$/.test(retryAfter) ? Number(retryAfter) : 60;
 return { reason: /(?:今日|今天).*额度.*(?:用完|用尽|耗尽)/.test(typeof error === 'string' ? error : '') ? 'daily-quota' as const : 'limited' as const, until: now + Math.min(86400, Math.max(1, seconds)) * 1000 };
}
