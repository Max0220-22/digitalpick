export type LocalFallbackReason='daily-quota'|'limited'|'model-failure'|'other';
export function quotaFallback(status:number,error:unknown,retryAfter:string|null,now=Date.now(),code?:unknown){
 if(status!==429)return null;
 const seconds=retryAfter&&/^\d+$/.test(retryAfter)?Number(retryAfter):60;
 const daily=code==='AI_DAILY_QUOTA'||(code===undefined&&/(?:今日|今天).*额度.*(?:用完|用尽|耗尽)/.test(typeof error==='string'?error:''));
 return {reason:daily?'daily-quota' as const:'limited' as const,until:now+Math.min(86400,Math.max(1,seconds))*1000};
}
export function failureReason(status:number,code?:unknown):LocalFallbackReason{
 return status===502||status===504||typeof code==='string'&&/^UPSTREAM_|^MODEL_/.test(code)?'model-failure':'other';
}
