const digits: Record<string,number> = { 零:0,一:1,二:2,两:2,三:3,四:4,五:5,六:6,七:7,八:8,九:9 };
function monetaryNumber(value:string): number | null {
 const shorthand=value.match(/^(\d+(?:\.\d+)?)([kw千万])$/i);
 if(shorthand) { const amount=Number(shorthand[1])*(/k|千/i.test(shorthand[2])?1000:10000); return Number.isInteger(amount)?amount:null; }
 if(!/^[零一二两三四五六七八九十百千万]+$/.test(value)||!/[十百千万]/.test(value)||/[一二两三四五六七八九]{2}/.test(value)||(value.match(/万/g)||[]).length>1) return null;
 // “两千五” and “一万二” have ambiguous omitted units. Ask rather than invent a ceiling.
 if(/[百千万]/.test(value)&&/[一二两三四五六七八九]$/.test(value)&&!value.includes('零')&&!/十[一二两三四五六七八九]$/.test(value)) return null;
 let total=0,section=0,number=0,lastUnit=10000;
 for(const char of value) {
  if(char in digits) { number=digits[char];continue; }
  const unit=char==='十'?10:char==='百'?100:char==='千'?1000:10000;
  if(unit===10000) { total+=(section+number||1)*unit;section=0;number=0;lastUnit=10000; }
  else { if(unit>=lastUnit) return null;section+=(number||1)*unit;number=0;lastUnit=unit; }
 }
 const amount=total+section+number;return amount>0&&amount<=100000?amount:null;
}
function normalizeMoney(text:string) {
 const prefix='(?:总预算|预算|封顶|上限|最多|最高|提高|增加|降低|减少|加|减)(?:(?:是|为|有|改成|改为|改到|调整到|降低到|降到|提高到|升到|改|至|到|不超过|不能超过|预算))*';
 return text.replace(new RegExp('('+prefix+')([零一二两三四五六七八九十百千万]+|\\d+(?:\\.\\d+)?[kw千万])(?![零一二两三四五六七八九十百千万0-9]|屏幕|分辨率|像素|赫兹|帧|[hH][zZ])','gi'),(whole,lead:string,raw:string)=>{const amount=monetaryNumber(raw);return amount===null?whole:lead+amount;});
}
export function stripReserve(text: string) {
  return text.replace(/(?:预留|另留|留出)(?:配件|维修|电池|软件|费用|预算|费|用)?\s*(?:是|为)?\s*\d{1,6}\s*(?:元|块)?/g, '');
}
export type BudgetChange = { kind: 'none' | 'unclear' } | { kind: 'absolute' | 'relative'; amount: number };
/** This parser is shared by local guidance and AI: a numeric-looking phrase is not proof of a parsed ceiling. */
export function parseBudgetChange(text: string): BudgetChange {
  const compact = normalizeMoney(stripReserve(text).replace(/[,，\s]/g, ''));
  if (/(?:预算|上限|封顶).{0,8}\d+(?:元)?(?:到|至|[-–~～])(?:\d|[零一二两三四五六七八九])/.test(compact)) return { kind:'unclear' };
  const absolute = compact.match(/(?:总预算|预算|最高|上限|最多|封顶)(?:(?:是|为|有|改成|改为|改到|调整到|降低到|降到|提高到|升到|改|至|到|不超过|不能超过))*[¥￥]?(\d{1,6})(?![\d.])(?!(?:克|kg|g|英寸|寸|gb|tb|hz|fps|mah|wh|w|千|万|k|瓦|帧|赫兹))(?:元|块)?/i);
  const relative = compact.match(/(?:提高|增加|加|降低|减少|减)(?:预算)?(\d{1,6})(?![\d.])(?!(?:克|kg|g|英寸|寸|gb|tb|hz|fps|mah|wh|w|千|万|k|瓦|帧|赫兹))(?:元|块)?/i);
  if (absolute && relative) return { kind: 'unclear' };
  if (absolute) { const amount = Number(absolute[1]); return amount > 0 && amount <= 100000 ? { kind: 'absolute', amount } : { kind: 'unclear' }; }
  if (relative) { const amount = Number(relative[1]) * (/降低|减少|减/.test(relative[0]) ? -1 : 1); return amount !== 0 && Math.abs(amount) <= 100000 ? { kind: 'relative', amount } : { kind: 'unclear' }; }
  const buying = compact.match(/(?:^|[。；;])[¥￥]?(\d{3,6})(?:元|块)(?:以内|以下|左右)?(?:买|选|找)/) || compact.match(/(?:买|选|找).{0,5}?(\d{3,6})(?:元|块)(?:以内|以下|左右)?/);
  if (buying) { const amount = Number(buying[1]); return amount > 0 && amount <= 100000 ? { kind: 'absolute', amount } : { kind: 'unclear' }; }
  // A purchase amount can omit “预算/元”: “想买3000左右的手机”.
  // Require a device/purchase context, never treat bare model years or hardware units as money.
  const device = '(?:(?:全新|二手|安卓|苹果|游戏|学习|办公|轻薄))*(?:手机|平板|笔记本(?:电脑)?|电脑)';
  const casual = compact.match(new RegExp('(?:^|[^0-9.])([0-9]{3,6})(?:元|块)?(?:左右|上下|以内|以下)(?:的)?'+device,'i'))
    || compact.match(new RegExp('(?:买|选|找)(?:一?[台部个])?[¥￥]?([0-9]{3,6})(?:元|块)?(?:的)?'+device,'i'))
    || compact.match(new RegExp('(?:^|[。；;])[¥￥]?([0-9]{3,6})(?:元|块)?(?:买|选|找)(?:一?[台部个])?'+device,'i'));
  if (casual) {
    if (/\d+(?:元|块)?(?:到|至|[-–~～])\d+/.test(compact)) return { kind: 'unclear' };
    const before = compact.slice(0, (casual.index || 0) + casual[0].indexOf(casual[1])).slice(-8);
    if (!/电池|容量|像素|分辨率|型号|处理器|芯片|年份|发布/.test(before)) {
      const amount = Number(casual[1]);
      return amount > 0 && amount <= 100000 ? { kind: 'absolute', amount } : { kind: 'unclear' };
    }
  }
  if (/预算|封顶|上限|(?:最多|最高)(?!\d+(?:\.\d+)?(?:克|kg|g|英寸|寸|gb|tb|hz|fps|mah|wh|w|千|万|k|瓦|帧|赫兹))|[¥￥]|\d+(?:元|块)|(?:加|减)\d+(?!(?:克|kg|g|英寸|寸|gb|tb|hz|fps|mah|wh|w|千|万|k|瓦|帧|赫兹))/i.test(compact)) return { kind: 'unclear' };
  return { kind: 'none' };
}
