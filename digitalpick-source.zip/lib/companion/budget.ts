export function stripReserve(text: string) {
  return text.replace(/(?:预留|另留|留出)(?:配件|维修|电池|软件|费用|预算|费|用)?\s*(?:是|为)?\s*\d{1,6}\s*(?:元|块)?/g, '');
}
export type BudgetChange = { kind: 'none' | 'unclear' } | { kind: 'absolute' | 'relative'; amount: number };
/** This parser is shared by local guidance and AI: a numeric-looking phrase is not proof of a parsed ceiling. */
export function parseBudgetChange(text: string): BudgetChange {
  const compact = stripReserve(text).replace(/[,，\s]/g, '');
  const absolute = compact.match(/(?:总预算|预算|最高|上限|最多|封顶)(?:(?:是|为|有|改成|改为|改到|调整到|降低到|降到|提高到|升到|改|至|到|不超过|不能超过))*[¥￥]?(\d{1,6})(?![\d.])(?!(?:克|kg|g|英寸|寸|gb|tb))(?:元|块)?/i);
  const relative = compact.match(/(?:提高|增加|加|降低|减少|减)(?:预算)?(\d{1,6})(?![\d.])(?!(?:克|kg|g|英寸|寸|gb|tb))(?:元|块)?/i);
  if (absolute && relative) return { kind: 'unclear' };
  if (absolute) { const amount = Number(absolute[1]); return amount > 0 && amount <= 100000 ? { kind: 'absolute', amount } : { kind: 'unclear' }; }
  if (relative) { const amount = Number(relative[1]) * (/降低|减少|减/.test(relative[0]) ? -1 : 1); return amount !== 0 && Math.abs(amount) <= 100000 ? { kind: 'relative', amount } : { kind: 'unclear' }; }
  const buying = compact.match(/(?:^|[。；;])[¥￥]?(\d{3,6})(?:元|块)(?:以内|以下|左右)?(?:买|选|找)/) || compact.match(/(?:买|选|找).{0,5}?(\d{3,6})(?:元|块)(?:以内|以下|左右)?/);
  if (buying) { const amount = Number(buying[1]); return amount > 0 && amount <= 100000 ? { kind: 'absolute', amount } : { kind: 'unclear' }; }
  if (/预算|封顶|上限|(?:最多|最高)(?!\d+(?:\.\d+)?(?:克|kg|g|英寸|寸|gb|tb))|[¥￥]|\d+(?:元|块)|(?:加|减)\d+(?!(?:克|kg|g|英寸|寸|gb|tb))/i.test(compact)) return { kind: 'unclear' };
  return { kind: 'none' };
}
