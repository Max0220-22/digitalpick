export interface DeviceProfile { width:number; coarse?:boolean; cores?:number; memory?:number; saveData?:boolean }
/** Desktop visuals stay unchanged; phones, data saving and low-resource devices start in 2D. */
export function prefersLightweight(profile:DeviceProfile) {
 return profile.width<=767 || !!profile.saveData || (!!profile.coarse && profile.width<=1024) || (profile.cores!==undefined && profile.cores<=2) || (profile.memory!==undefined && profile.memory<=2);
}
