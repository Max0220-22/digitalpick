interface Entry { role: 'user' | 'assistant'; text: string; contextText?: string; error?: boolean; aiReply?: { followUpQuestions: string[] } }
export function normalizeFollowUpAnswer(message: string, previous: string) {
  const answer = message.trim().replace(/[。！!，,]+$/, '');
  const question = previous.match(/[^。！？!?\n]*[？?]/g)?.at(-1) || '';
  if (/接受.{0,4}二手|考虑.{0,4}二手|全新.{0,8}二手|二手.{0,8}全新/.test(question)) {
    if (/^(?:可以|可以的|接受|能接受|都可以|都行|也行|没问题|可以接受)$/.test(answer)) return '全新二手都可以';
    if (/^(?:不可以|不接受|不能接受|不行|不考虑|不想要)$/.test(answer)) return '只考虑全新，不接受二手';
  }
  if (/预算.{0,8}(?:多少|几千|几百)|多少钱/.test(question) && /^\d{3,6}(?:元|块)?$/.test(answer)) return '预算' + answer.replace(/(?:元|块)$/, '') + '元';
  return message;
}
/** Keep more actual user constraints in the existing 8-message / 16KB envelope. */
export function chatHistory(entries: Entry[]) {
  const users = entries.filter(entry => entry.role === 'user').slice(-7);
  const lastAssistant = entries.filter(entry => entry.role === 'assistant' && !entry.error).at(-1);
  const selected = new Set<Entry>(lastAssistant ? [...users, lastAssistant] : users);
  const history = entries.filter(entry => selected.has(entry)).map(entry => ({
    role: entry.role,
    content: entry.role === 'user' ? (entry.contextText || entry.text).slice(0, 800) : [entry.text.slice(0, 1400), ...(entry.aiReply?.followUpQuestions || [])].join('\n').slice(0, 1600),
  }));
  // Reserve space for the current 800-character question and JSON fields within the 16KB API limit.
  while (new TextEncoder().encode(JSON.stringify(history)).byteLength > 11000) history.shift();
  return history;
}
