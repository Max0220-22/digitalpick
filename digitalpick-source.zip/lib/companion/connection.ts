export interface AiConnectionState {
  ready: boolean; enabled: boolean; connecting: boolean;
  model: string | null; token: string | null; error: string | null;
  reason: 'network' | 'timeout' | 'limited' | 'disabled' | 'forbidden' | 'invalid' | null;
}
export const initialAiConnection: AiConnectionState = { ready: false, enabled: false, connecting: true, model: null, token: null, error: null, reason: null };
interface Options {
  endpoint: string; remote: boolean; onChange: (state: AiConnectionState) => void;
  fetchImpl?: typeof fetch; timeoutMs?: number; now?: () => number;
}
/** Reconnects only the free session GET. Never retries a model POST or stores credentials. */
export function createAssistantConnection(options: Options) {
  const fetchImpl = options.fetchImpl || fetch, now = options.now || Date.now;
  let disposed = false, pending: Promise<void> | null = null, abort: AbortController | null = null;
  let lastAttempt: number | null = null, retryAt = 0;
  const publish = (state: AiConnectionState) => { if (!disposed) options.onChange(state); };
  const failed = (reason: AiConnectionState['reason'], error: string) => publish({ ...initialAiConnection, ready: true, connecting: false, reason, error });
  return {
    connect(force = false): Promise<void> {
      if (disposed) return Promise.resolve();
      if (pending) return pending;
      if (now() < retryAt || (!force && lastAttempt !== null && now() - lastAttempt < 15000)) return Promise.resolve();
      lastAttempt = now(); abort = new AbortController(); const controller = abort;
      publish({ ...initialAiConnection });
      let timedOut = false;
      const timer = setTimeout(() => { timedOut = true; controller.abort(); }, options.timeoutMs ?? 15000);
      pending = (async () => {
        try {
          const response = await Promise.resolve().then(() => fetchImpl(options.endpoint, { signal: controller.signal, cache: 'no-store', credentials: options.remote ? 'omit' : 'same-origin' }));
          if (disposed) return;
          if (response.status === 429) {
            const raw = response.headers.get('retry-after');
            const seconds = raw && /^\d+$/.test(raw) ? Number(raw) : 60;
            retryAt = now() + Math.min(Math.max(seconds, 1), 86400) * 1000;
            failed('limited', 'AI 连接请求过于频繁，请稍后重试。'); return;
          }
          if (response.status === 403) { failed('forbidden', 'AI 服务尚未允许本站连接，请联系网站维护者。'); return; }
          if (!response.ok) { failed('network', 'AI 服务暂时无法连接，可以重新连接；本地选购工具仍可使用。'); return; }
          const value: unknown = await response.json();
          if (!value || typeof value !== 'object') { failed('invalid', 'AI 连接返回异常，请稍后重新连接。'); return; }
          const data = value as Record<string, unknown>;
          if (data.enabled !== true) { failed('disabled', '在线 AI 暂未启用，当前提供本地规则导览。'); return; }
          if (options.remote && (typeof data.sessionToken !== 'string' || !data.sessionToken)) { failed('invalid', 'AI 会话未建立，请重新连接。'); return; }
          retryAt = 0;
          publish({ ...initialAiConnection, ready: true, connecting: false, enabled: true, model: typeof data.model === 'string' ? data.model : null, token: typeof data.sessionToken === 'string' ? data.sessionToken : null });
        } catch {
          if (!disposed) failed(timedOut ? 'timeout' : 'network', timedOut ? 'AI 连接超时，可以重新连接。若在微信中持续失败，请尝试系统浏览器或切换网络。' : '当前网络无法连接 AI。可以重新连接，或在系统浏览器打开、切换网络后再试。');
        } finally { clearTimeout(timer); pending = null; if (abort === controller) abort = null; }
      })();
      return pending;
    },
    dispose() { disposed = true; abort?.abort(); },
  };
}
