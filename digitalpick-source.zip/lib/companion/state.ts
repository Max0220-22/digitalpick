export type CompanionMood = 'idle' | 'hover' | 'greeting' | 'listening' | 'thinking' | 'speaking' | 'success' | 'error' | 'sleeping';
export type DeviceFocus = 'phone' | 'tablet' | 'laptop';
export interface CompanionState {
  open: boolean;
  draft: string;
  phase: CompanionMood;
  focus: DeviceFocus;
  motion: boolean;
}
export type CompanionEvent =
  | { type: 'open'; prompt?: string }
  | { type: 'close' }
  | { type: 'input'; value: string }
  | { type: 'phase'; phase: CompanionMood }
  | { type: 'focus'; focus: DeviceFocus }
  | { type: 'motion'; enabled: boolean }
  | { type: 'reset' };
export const initialCompanionState: CompanionState = { open: false, draft: '', phase: 'idle', focus: 'phone', motion: true };
export function companionReducer(state: CompanionState, event: CompanionEvent): CompanionState {
  switch (event.type) {
    case 'open': return { ...state, open: true, draft: event.prompt ?? state.draft, phase: 'greeting' };
    case 'close': return { ...state, open: false, phase: 'idle' };
    case 'input': return { ...state, draft: event.value.slice(0, 800), phase: event.value ? 'listening' : 'idle' };
    case 'phase': return { ...state, phase: event.phase };
    case 'focus': return { ...state, focus: event.focus, phase: 'success' };
    case 'motion': return { ...state, motion: event.enabled };
    case 'reset': return { ...state, draft: '', phase: 'greeting' };
  }
}
export function normalizePointer(x: number, y: number, width: number, height: number) {
  if (width <= 0 || height <= 0) return { x: 0, y: 0 };
  return { x: Math.max(-1, Math.min(1, x / width * 2 - 1)), y: Math.max(-1, Math.min(1, 1 - y / height * 2)) };
}

/** Keep pointer tap checks independent of the deferred Three.js scene. */
export function isModelTap(start: {x:number;y:number}, end: {x:number;y:number}) {
 return Math.hypot(start.x - end.x, start.y - end.y) <= 9;
}
