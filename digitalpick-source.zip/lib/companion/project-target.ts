import { Vector3, type Camera, type Object3D } from 'three';
import type { createModelPicker } from './model-hit';
/** Project only the visible chest circle, never the character's enclosing rectangle. */
export function createChestProjection(button: Object3D, camera: Camera, pick: ReturnType<typeof createModelPicker>) {
 const center=new Vector3(), left=new Vector3(), right=new Vector3(), top=new Vector3(), bottom=new Vector3();
 return (width:number,height:number) => {
  if (width<=0 || height<=0) return null;
  camera.updateMatrixWorld();button.updateWorldMatrix(true,false);
  const project=(point:Vector3,x:number,y:number)=>button.localToWorld(point.set(x,y,.03)).project(camera);
  project(center,0,0);project(left,-.217,0);project(right,.217,0);project(top,0,.217);project(bottom,0,-.217);
  const x=(center.x+1)*width/2,y=(1-center.y)*height/2;
  if(center.z < -1 || center.z > 1 || pick(x,y,{left:0,top:0,width,height})!=='theme') return null;
  return {x,y,width:Math.abs(right.x-left.x)*width/2,height:Math.abs(top.y-bottom.y)*height/2};
 };
}
