import { getProduct, type Category, type PurchaseMode } from '@/lib/products';
import { parseBudgetChange } from './budget';
export interface GuideMemory { budget?: number; category?: Category; mode?: PurchaseMode; os?: string; reserveBudget?: number }
export interface GuideReply { text: string; links: { label: string; href: string }[]; memory: GuideMemory; productId?: string }
// This is a small, deterministic local guide. It never calls or impersonates a language model.
export function localGuide(input: string, previous: GuideMemory, path: string): GuideReply {
  const memory = { ...previous };
  const compact = input.replace(/[,，\s]/g, '');
  const reserve = compact.match(/(?:预留|另留|留出)(?:配件|维修|电池|软件|费用|预算|费|用)?(?:是|为)?(\d{1,6})(?:元|块)?/);
  if (reserve) memory.reserveBudget = Number(reserve[1]);
  const budgetChange = parseBudgetChange(input);
  if (budgetChange.kind === 'unclear') delete memory.budget;
  if (budgetChange.kind === 'relative' && !memory.budget) return { text: '我还不知道原来的预算上限。先告诉我一个具体金额，再一起调整。当前是本地规则导览，未调用云端模型。', links: [], memory };
  if (budgetChange.kind === 'relative' && memory.budget) {
    const next = memory.budget + budgetChange.amount;
    if (Number.isInteger(next) && next > 0 && next <= 100000) memory.budget = next; else delete memory.budget;
  } else if (budgetChange.kind === 'absolute') memory.budget = budgetChange.amount;
  const oldCategory = memory.category;
  if (/手机|安卓|iphone/i.test(input)) memory.category = 'phone';
  if (/平板|ipad/i.test(input)) memory.category = 'tablet';
  if (/电脑|笔记本|macbook/i.test(input)) memory.category = 'laptop';
  if (oldCategory && memory.category !== oldCategory) delete memory.os;
  if (/(?:只买|只要|只考虑|改成|不要二手|不买二手|不考虑二手).{0,3}全新|不要二手|不买二手|不考虑二手|不(?:能|可以)?接受二手|不想要二手|拒绝二手|二手.{0,3}(?:不接受|不考虑)/.test(input)) memory.mode = 'new';
  else if (/(?:只买|只要|只考虑|只接受|改成).{0,3}二手|不要全新|不买全新|不考虑全新/.test(input)) memory.mode = 'used';
  else if (/全新.{0,3}二手|二手.{0,3}全新|(?:也接受|也考虑|可以接受|能接受|接受|可以).{0,2}二手|二手也(?:可以|行)/.test(input)) memory.mode = 'either';
  else if (/二手/.test(input)) memory.mode = 'used';
  else if (/全新|新机/.test(input)) memory.mode = 'new';
  if (/(?:不买|不要|排除|不考虑)(?:苹果|iPhone|iOS)/i.test(input)) { if (memory.os === 'iOS') delete memory.os; }
  else if (/ios|苹果手机/i.test(input)) memory.os = 'iOS';
  if (/(?:不买|不要|排除|不考虑)(?:安卓|Android)/i.test(input)) { if (memory.os === 'Android') delete memory.os; }
  else if (/安卓|android/i.test(input)) memory.os = 'Android';
  const productId = path.match(/^\/products\/([^/]+)/)?.[1];
  const product = productId ? getProduct(productId) : undefined;
  if (/清空|重新开始/.test(input)) return { text: '可以。请使用右上角“重新开始”，清除本次会话的消息与条件。', links: [], memory };
  if (/验机|避坑|账号锁|电池/.test(input)) return { text: '买二手前，先确认型号、维修记录、电池和账号锁，再逐项检查。未完成检查不能当作通过；账号或组织管理限制没有解除时，应暂停交易。你可以直接打开分类清单。', links: [{ label: '打开二手验机清单', href: `/checklist/?category=${memory.category || 'phone'}` }], memory };
  if (/root|bootloader|解锁|保值|转卖/i.test(input)) return { text: 'Root / Bootloader 能力需要按具体型号、地区和当前品牌政策核实，不能只凭品牌推断。保值率还需要同配置、相近日期的真实价格数据，当前演示库不能给出可信结论。先看基础指南，再决定是否把这些条件设为必须满足。', links: [{ label: '了解 Root 与 Bootloader', href: '/guides/bootloader-basics/' }, { label: '了解保值率的数据前提', href: '/guides/resale-value/' }], memory };
  if (/比较|对比|纠结/.test(input)) return { text: '可以先将最多 3 款设备放在一起，分别切换全新或二手查看。当前只提供参数并列，不把不同条件的续航或跑分当成完全可比的数据。', links: [{ label: '打开产品对比', href: product ? `/compare/?add=${product.id}` : '/compare/' }], memory, productId: product?.id };
  if (/渠道|哪里买|购买链接/.test(input)) return { text: '购买渠道页提供核验过的官方平台入口和注意事项。没有可信商品直达链接时，只提供平台入口或搜索关键词，不编造库存和优惠。', links: [{ label: '查看购买渠道', href: product ? `/channels/?product=${product.id}` : '/channels/' }], memory };
  if (/全新还是二手|全新.*二手.*划算|二手.*全新.*划算/.test(input)) return { text: '更看重完整使用历史、保修和省心，可以先看正规渠道的全新设备。愿意认真验机并接受电池、成色及售后差异，再考虑二手。当前价格都是演示数值，不能据此判断真实差价。', links: [{ label: '比较两种购买方式', href: product ? `/products/${product.id}/#new-vs-used` : '/recommend/' }], memory };
  if (product && /这台|这款|当前|适合/.test(input)) return { text: `${product.name} 的示例配置是 ${product.configuration}。编辑列出的适合场景包括：${product.suitable.join('、')}。主要取舍：${product.cons.slice(0, 2).join('；')}。这只是产品库导览，具体兼容性与设备状况仍需核实。`, links: [{ label: '查看完整参数与来源', href: `/products/${product.id}/` }], memory, productId: product.id };
  const summary = [memory.budget ? `预算上限 ¥${memory.budget.toLocaleString('zh-CN')}` : '', memory.category ? ({ phone: '手机', tablet: '平板', laptop: '笔记本电脑' }[memory.category]) : '', memory.mode === 'used' ? '只考虑二手' : memory.mode === 'new' ? '只考虑全新' : '', memory.os || ''].filter(Boolean);
  const search = new URLSearchParams();
  if (memory.budget) search.set('budget', String(memory.budget));
  if (memory.category) search.set('category', memory.category);
  if (memory.mode) search.set('mode', memory.mode);
  if (memory.os) search.set('os', memory.os);
  if (memory.reserveBudget !== undefined) search.set('reserve', String(memory.reserveBudget));
  return { text: summary.length ? `本地规则已整理：${summary.join(' · ')}。可以带着这些条件进入选购问答，补充用途后再匹配。现阶段所有价格都是演示数据；我不会把它们当成市场行情进行正式购买推荐。` : '先告诉我大致预算，以及想选手机、平板还是电脑。我可以整理条件并带你进入选购问答，也可以打开二手验机、产品对比和购买渠道。当前为本地导览，尚未连接云端 AI。', links: [{ label: summary.length ? '带着这些条件开始选购' : '开始五步选购', href: `/recommend/${search.size ? `?${search}` : ''}` }], memory };
}
export function contextBubble(path: string) {
  const product = getProduct(path.match(/^\/products\/([^/]+)/)?.[1] || '');
  if (product) return { label: `想一起看看 ${product.name} 的取舍吗？`, prompt: '这款设备适合谁？' };
  if (path.startsWith('/checklist')) return { label: '买二手，还有哪些地方需要检查？', prompt: '二手设备怎么验机？' };
  if (path.startsWith('/compare')) return { label: '纠结两款设备？我们一起看清取舍。', prompt: '帮我比较两款设备。' };
  return { label: '不知道从哪选？和小派聊聊。', prompt: '我的预算是 3000 元，想选一台手机。' };
}
