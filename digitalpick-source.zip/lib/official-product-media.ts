/** Verified official origins. Remote references are not an open license or an inventory signal. */
export interface OfficialProductMedia {
  imageUrl: string; officialPage: string; owner: string;
  mediaType: '官方商城图' | '官方归档图' | '官方外观图';
  alt: string; notes: string; usageStatus: string; checkedAt: string;
}
export const officialProductMedia: Record<string, OfficialProductMedia> = {
  "iphone-x": {
    "imageUrl": "https://cdsassets.apple.com/live/SZLF0YNV/images/sp/111864_iphonex.png",
    "officialPage": "https://support.apple.com/zh-cn/111864",
    "owner": "Apple",
    "mediaType": "官方归档图",
    "alt": "iphone x 官方外观归档图",
    "notes": "官方历史机型资料；图片颜色与配置不代表在售商品。",
    "usageStatus": "品牌保留版权；公开再分发授权未确认",
    "checkedAt": "2026-10-16"
  },
  "iphone-xs": {
    "imageUrl": "https://cdsassets.apple.com/live/7WUAS350/images/iphone/iphone-xs-colors.jpg",
    "officialPage": "https://support.apple.com/zh-cn/108044",
    "owner": "Apple",
    "mediaType": "官方归档图",
    "alt": "iphone xs 官方配色及正面展示",
    "notes": "多配色归档图；不表示官方仍在售卖该机型。",
    "usageStatus": "品牌保留版权；公开再分发授权未确认",
    "checkedAt": "2026-10-16"
  },
  "iphone-xr": {
    "imageUrl": "https://cdsassets.apple.com/live/7WUAS350/images/iphone/iphone-xr/identify-iphone-xr-colors.jpg",
    "officialPage": "https://support.apple.com/zh-cn/108044",
    "owner": "Apple",
    "mediaType": "官方归档图",
    "alt": "iphone xr 官方配色及正面展示",
    "notes": "多配色归档图；不表示官方仍在售卖该机型。",
    "usageStatus": "品牌保留版权；公开再分发授权未确认",
    "checkedAt": "2026-10-16"
  },
  "iphone-12": {
    "imageUrl": "https://cdsassets.apple.com/live/7WUAS350/images/iphone/2021-iphone12-colors.png",
    "officialPage": "https://support.apple.com/zh-cn/108044",
    "owner": "Apple",
    "mediaType": "官方归档图",
    "alt": "iphone 12 官方配色及正面展示",
    "notes": "多配色归档图；不表示官方仍在售卖该机型。",
    "usageStatus": "品牌保留版权；公开再分发授权未确认",
    "checkedAt": "2026-10-16"
  },
  "iphone-13": {
    "imageUrl": "https://cdsassets.apple.com/live/7WUAS350/images/iphone/2022-spring-iphone13-colors.png",
    "officialPage": "https://support.apple.com/zh-cn/108044",
    "owner": "Apple",
    "mediaType": "官方归档图",
    "alt": "iphone 13 官方配色及正面展示",
    "notes": "多配色归档图；不表示官方仍在售卖该机型。",
    "usageStatus": "品牌保留版权；公开再分发授权未确认",
    "checkedAt": "2026-10-16"
  },
  "iphone-14": {
    "imageUrl": "https://cdsassets.apple.com/live/SZLF0YNV/images/sp/111850_iphone-14_1.png",
    "officialPage": "https://support.apple.com/zh-cn/111850",
    "owner": "Apple",
    "mediaType": "官方归档图",
    "alt": "iphone 14 官方外观归档图",
    "notes": "官方历史机型资料；图片颜色与配置不代表在售商品。",
    "usageStatus": "品牌保留版权；公开再分发授权未确认",
    "checkedAt": "2026-10-16"
  },
  "iphone-15": {
    "imageUrl": "https://cdsassets.apple.com/live/7WUAS350/images/iphone/fall-2023-iphone-colors-iphone-15.png",
    "officialPage": "https://support.apple.com/zh-cn/108044",
    "owner": "Apple",
    "mediaType": "官方归档图",
    "alt": "iphone 15 官方配色与正面展示",
    "notes": "官方机型识别页原始图；配色仅供外观参考。",
    "usageStatus": "品牌保留版权；公开再分发授权未确认",
    "checkedAt": "2026-10-16"
  },
  "iphone-16": {
    "imageUrl": "https://cdsassets.apple.com/live/7WUAS350/images/iphone/iphone-16-colors.png",
    "officialPage": "https://support.apple.com/zh-cn/108044",
    "owner": "Apple",
    "mediaType": "官方归档图",
    "alt": "iphone 16 官方配色与正面展示",
    "notes": "官方机型识别页原始图；配色仅供外观参考。",
    "usageStatus": "品牌保留版权；公开再分发授权未确认",
    "checkedAt": "2026-10-16"
  },
  "ipad-air-m2": {
    "imageUrl": "https://cdsassets.apple.com/live/7WUAS350/images/ipad/spring-2024-3.png",
    "officialPage": "https://support.apple.com/zh-cn/108043",
    "owner": "Apple",
    "mediaType": "官方归档图",
    "alt": "iPad Air 13 英寸 M2 官方配色与正面展示",
    "notes": "对应官方机型识别页 2024 年 13 英寸 M2 机型。",
    "usageStatus": "品牌保留版权；公开再分发授权未确认",
    "checkedAt": "2026-10-16"
  },
  "macbook-air-m2": {
    "imageUrl": "https://cdsassets.apple.com/live/SZLF0YNV/images/sp/111867_SP869-2022-macbook-air-m2-colors.png",
    "officialPage": "https://support.apple.com/zh-cn/111867",
    "owner": "Apple",
    "mediaType": "官方归档图",
    "alt": "macbook air m2 官方外观归档图",
    "notes": "官方历史机型资料；图片颜色与配置不代表在售商品。",
    "usageStatus": "品牌保留版权；公开再分发授权未确认",
    "checkedAt": "2026-10-16"
  },
  "macbook-pro-m3": {
    "imageUrl": "https://cdsassets.apple.com/live/7WUAS350/images/tech-specs/macbook-pro-14-inch-m3-pro-or-m3.png",
    "officialPage": "https://support.apple.com/",
    "owner": "Apple",
    "mediaType": "官方归档图",
    "alt": "macbook pro m3 官方外观归档图",
    "notes": "官方历史机型资料；图片颜色与配置不代表在售商品。",
    "usageStatus": "品牌保留版权；公开再分发授权未确认",
    "checkedAt": "2026-10-16"
  },
  "iphone-11": {
    "imageUrl": "https://cdsassets.apple.com/live/7WUAS350/images/iphone/identify-iphone-11-colors.jpg",
    "officialPage": "https://support.apple.com/zh-cn/108044",
    "owner": "Apple",
    "mediaType": "官方归档图",
    "alt": "iphone 11 官方配色及正面展示",
    "notes": "多配色归档图；不表示官方仍在售卖该机型。",
    "usageStatus": "品牌保留版权；公开再分发授权未确认",
    "checkedAt": "2026-10-16"
  },
  "iphone-17": {
    "imageUrl": "https://cdsassets.apple.com/live/7WUAS350/images/iphone/iphone-17-colors.png",
    "officialPage": "https://support.apple.com/zh-cn/108044",
    "owner": "Apple",
    "mediaType": "官方外观图",
    "alt": "iphone 17 官方配色与正面展示",
    "notes": "官方机型识别页原始图；配色仅供外观参考。",
    "usageStatus": "品牌保留版权；公开再分发授权未确认",
    "checkedAt": "2026-10-16"
  },
  "iphone-18-pro": {
    "imageUrl": "https://cdsassets.apple.com/live/7WUAS350/images/iphone/iphone-18-pro-colors.png",
    "officialPage": "https://support.apple.com/zh-cn/108044",
    "owner": "Apple",
    "mediaType": "官方外观图",
    "alt": "iPhone 18 Pro 标准 Pro 机型的官方配色与正面展示",
    "notes": "对应官方机型识别页 iPhone 18 Pro 小节，未以 Pro Max 图代替。",
    "usageStatus": "品牌保留版权；公开再分发授权未确认",
    "checkedAt": "2026-10-16"
  },
  "xiaomi-14": {
    "imageUrl": "https://i02.appmifile.com/431_item_sg/22/10/2024/260e2d3ba3e4d7995022c27eecbf61df.png",
    "officialPage": "https://www.mi.com/sg/product/xiaomi-14/specs/",
    "owner": "Xiaomi",
    "mediaType": "官方外观图",
    "alt": "xiaomi 14 品牌官网展示图",
    "notes": "官方地区页面素材，外观配色不代表当前库存或配置。",
    "usageStatus": "品牌保留版权；公开再分发授权未确认",
    "checkedAt": "2026-10-16"
  },
  "xiaomi-15": {
    "imageUrl": "https://i02.appmifile.com/177_item_hk/21/02/2025/41edfda5883e4899d5cf226baa6e7134.png",
    "officialPage": "https://www.mi.com/hk/product/xiaomi-15/specs/",
    "owner": "Xiaomi",
    "mediaType": "官方外观图",
    "alt": "xiaomi 15 品牌官网展示图",
    "notes": "官方地区页面素材，外观配色不代表当前库存或配置。",
    "usageStatus": "品牌保留版权；公开再分发授权未确认",
    "checkedAt": "2026-10-16"
  },
  "xiaomi-pad-6": {
    "imageUrl": "https://i02.appmifile.com/896_operatorx_operatorx_opx/31/08/2023/777129f39f90fe8479cf5489f9a1e509.png",
    "officialPage": "https://www.mi.com/global/product/xiaomi-pad-6/",
    "owner": "Xiaomi",
    "mediaType": "官方外观图",
    "alt": "xiaomi pad 6 品牌官网展示图",
    "notes": "官方地区页面素材，外观配色不代表当前库存或配置。",
    "usageStatus": "品牌保留版权；公开再分发授权未确认",
    "checkedAt": "2026-10-16"
  },
  "galaxy-s24": {
    "imageUrl": "https://images.samsung.com/is/image/samsung/p6pim/es/2401/gallery/es-galaxy-s24-sm-s921bzvdeub-539409937",
    "officialPage": "https://www.samsung.com/es/smartphones/galaxy-s24/buy/",
    "owner": "Samsung",
    "mediaType": "官方商城图",
    "alt": "galaxy s24 标准版官方商城展示",
    "notes": "S24 为西班牙商城图，对应本页欧洲版；S25 为中国大陆商城图。",
    "usageStatus": "品牌保留版权；公开再分发授权未确认",
    "checkedAt": "2026-10-16"
  },
  "galaxy-s25": {
    "imageUrl": "https://images.samsung.com.cn/is/image/samsung/p6pim/cn/2501/gallery/cn-galaxy-s25-532487-sm-s9310zsgchc-544568956",
    "officialPage": "https://www.samsung.com.cn/smartphones/galaxy-s25/buy/",
    "owner": "Samsung",
    "mediaType": "官方商城图",
    "alt": "galaxy s25 标准版官方商城展示",
    "notes": "S24 为西班牙商城图，对应本页欧洲版；S25 为中国大陆商城图。",
    "usageStatus": "品牌保留版权；公开再分发授权未确认",
    "checkedAt": "2026-10-16"
  },
  "oppo-find-x8": {
    "imageUrl": "https://www.oppo.com/content/dam/oppo/common/mkt/v2-2/find-x8-series-cn/oppo-find-x8/product/1548-720-v2.png",
    "officialPage": "https://www.oppo.com/cn/smartphones/series-find-x/find-x8/specs/",
    "owner": "OPPO",
    "mediaType": "官方外观图",
    "alt": "OPPO Find X8 官网配色展示",
    "notes": "标准版外观图，不以 Pro 图片替代。",
    "usageStatus": "品牌保留版权；公开再分发授权未确认",
    "checkedAt": "2026-10-16"
  },
  "vivo-x200": {
    "imageUrl": "https://wwwstatic.vivo.com.cn/vivoportal/files/image/detail/20241008/8f19bf0f1ed8498a6b05143be7ff876b.png",
    "officialPage": "https://www.vivo.com.cn/vivo/param/x200",
    "owner": "vivo",
    "mediaType": "官方外观图",
    "alt": "vivo x200 品牌官方配色展示",
    "notes": "标准版与 Pro 分别核对，未混用机型图片。",
    "usageStatus": "品牌保留版权；公开再分发授权未确认",
    "checkedAt": "2026-10-16"
  },
  "vivo-x200-pro": {
    "imageUrl": "https://wwwstatic.vivo.com.cn/vivoportal/files/image/detail/20241008/f3008e12d583428111100e63366bd467.png",
    "officialPage": "https://www.vivo.com.cn/vivo/param/x200pro",
    "owner": "vivo",
    "mediaType": "官方外观图",
    "alt": "vivo x200 pro 品牌官方配色展示",
    "notes": "标准版与 Pro 分别核对，未混用机型图片。",
    "usageStatus": "品牌保留版权；公开再分发授权未确认",
    "checkedAt": "2026-10-16"
  },
  "honor-magic7-pro": {
    "imageUrl": "https://www-file.honor.com/content/dam/honor/common/product-list/product-series/honor-magic7-pro/honor-magic7-pro-id-gary-back.png",
    "officialPage": "https://www.honor.com/cn/phones/honor-magic7-pro/",
    "owner": "HONOR",
    "mediaType": "官方外观图",
    "alt": "荣耀 Magic7 Pro 月影灰背面官方展示",
    "notes": "官方产品导航中的该机型原始图。",
    "usageStatus": "品牌保留版权；公开再分发授权未确认",
    "checkedAt": "2026-10-16"
  },
  "oneplus-13": {
    "imageUrl": "https://oasisstatics.oneplus.cn/content/dam/oasis/page/2024/global/product/dodge/white-050214.png",
    "officialPage": "https://www.oneplus.com/cn/13/specs",
    "owner": "OnePlus",
    "mediaType": "官方外观图",
    "alt": "一加 13 白露晨曦官方展示",
    "notes": "官方规格页配色图。",
    "usageStatus": "品牌保留版权；公开再分发授权未确认",
    "checkedAt": "2026-10-16"
  }
};
