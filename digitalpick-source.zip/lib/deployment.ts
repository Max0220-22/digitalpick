/** Public deployment settings only. Never put a model credential in NEXT_PUBLIC_* variables. */
export const basePath = process.env.NEXT_PUBLIC_BASE_PATH || '';
export const isStaticDeployment = process.env.NEXT_PUBLIC_DEPLOYMENT === 'static';
export const remoteAssistant = !!process.env.NEXT_PUBLIC_AI_PROXY_URL;
export function assetPath(path: string) { return path.startsWith('/') && !path.startsWith('//') ? `${basePath}${path}` : path; }
export function appPath(path: string) { return basePath && (path === basePath || path.startsWith(`${basePath}/`)) ? path.slice(basePath.length) || '/' : path; }
export function assistantEndpoint() {
  const configured = process.env.NEXT_PUBLIC_AI_PROXY_URL?.trim();
  if (!configured) return '/api/assistant/';
  const url = new URL(configured);
  if ((url.protocol !== 'https:' && !(url.protocol === 'http:' && ['localhost', '127.0.0.1', '[::1]'].includes(url.hostname))) || url.username || url.password || url.search || url.hash || !['/', '/api/assistant', '/api/assistant/'].includes(url.pathname)) throw new Error('AI proxy URL must be an HTTPS Worker origin or assistant endpoint.');
  return `${url.origin}/api/assistant/`;
}
