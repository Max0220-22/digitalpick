export const channels = [
 { id: 'apple', name: 'Apple 中国官网', initials: 'A', group: '官方渠道', type: 'Apple 全新设备与官方服务', url: 'https://www.apple.com.cn/', verified: true, pros: '配置和服务说明由品牌直接提供。', risk: '旧款未必仍在售，价格和发货信息以官网为准。', note: '选对地区版本，确认教育优惠资格与售后条款。' },
 { id: 'xiaomi', name: '小米官方商城', initials: 'mi', group: '官方渠道', type: '小米与 Redmi 全新产品', url: 'https://www.mi.com/shop', verified: true, pros: '便于核对官方配置、配件与服务。', risk: '不同版本及活动可能有不同限制。', note: '核对完整配置、开票主体和售后范围。' },
 { id: 'jd', name: '京东', initials: 'JD', group: '综合电商', type: '全新设备与配件', url: 'https://www.jd.com/', verified: true, pros: '便于在同平台对照不同商家的配置与服务。', risk: '自营、官方旗舰店与第三方店铺主体不同。', note: '确认店铺经营主体、发票和退换货条件。' },
 { id: 'tmall', name: '天猫', initials: 'T', group: '综合电商', type: '品牌旗舰店与授权店商品', url: 'https://www.tmall.com/', verified: true, pros: '可通过店铺资质了解经营主体。', risk: '店铺名称不等同于已核实的品牌授权。', note: '向品牌核实授权；确认配置、发票与售后主体。' },
 { id: 'taobao', name: '淘宝', initials: '淘', group: '综合电商', type: '全新设备、配件与部分二手商品', url: null, verified: false, pros: '商品种类较多，可按具体配置搜索。', risk: '商家和商品状态差异大，需逐项核对。', note: '本次未完成入口连通性核验，请使用官方 App 搜索关键词。' },
 { id: 'pdd', name: '拼多多', initials: '拼', group: '综合电商', type: '全新设备与配件', url: null, verified: false, pros: '便于按型号查找不同商品选项。', risk: '优惠条件、版本和服务可能不同。', note: '本次未完成入口连通性核验，请使用官方 App；不预设任何补贴或优惠券。' },
 { id: 'goofish', name: '闲鱼', initials: '鱼', group: '二手交易', type: '个人闲置与二手设备', url: 'https://www.goofish.com/', verified: true, pros: '可以直接询问实际使用情况与维修历史。', risk: '成色与来源依卖家披露，需自行验机。', note: '保留平台内沟通和交易记录，不进行站外转账。' },
];
const allowedHosts = new Set(['www.apple.com.cn', 'www.mi.com', 'www.jd.com', 'www.tmall.com', 'www.goofish.com']);
export function safeChannelUrl(value: string | null) { if (!value) return null; try { const url = new URL(value); return url.protocol === 'https:' && !url.username && !url.password && allowedHosts.has(url.hostname) ? url.href : null; } catch { return null; } }
