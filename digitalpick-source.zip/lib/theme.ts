export type Theme = 'dark' | 'light';
export const THEME_DURATION = 1500;
export const THEME_STORAGE = 'dp-theme';
export const SKY_HINT_STORAGE = 'dp-sky-hint-seen';
export function claimSkyHint(storage: Pick<Storage, 'getItem' | 'setItem'>) {
 try { if (storage.getItem(SKY_HINT_STORAGE)) return false; storage.setItem(SKY_HINT_STORAGE, '1'); } catch {}
 return true;
}
export function resolveTheme(stored: string | null, systemDark: boolean): Theme {
 return stored === 'dark' || stored === 'light' ? stored : systemDark ? 'dark' : 'light';
}
export interface ThemeFrame { daylight: number; from: Theme; to: Theme; startedAt: number; duration: number; sequence: number; busy: boolean }
export function bindThemeScheduler(host: { performance: { now(): number }; requestAnimationFrame(callback: (time: number) => void): number; cancelAnimationFrame(id: number): void }) {
 return { now: () => host.performance.now(), request: (callback: (time: number) => void) => host.requestAnimationFrame(callback), cancel: (id: number) => host.cancelAnimationFrame(id) };
}
interface TimelineClock { now: () => number; request: (callback: (time: number) => void) => number; cancel: (id: number) => void; paint: (state: ThemeFrame) => void; start: (state: ThemeFrame) => void; finish: (state: ThemeFrame) => void }
/** One clock drives the sky, lighting and pose. Repeated triggers are rejected synchronously. */
export function createThemeTimeline(initial: Theme, clock: TimelineClock) {
 const state: ThemeFrame = { daylight: initial === 'light' ? 1 : 0, from: initial, to: initial, startedAt: 0, duration: 0, sequence: 0, busy: false };
 let frame = 0;
 function finish() {
  clock.cancel(frame); frame = 0; state.daylight = state.to === 'light' ? 1 : 0; state.busy = false;
  clock.paint(state); clock.finish(state);
 }
 function tick(time: number) {
  const progress = Math.max(0, Math.min(1, (time - state.startedAt) / state.duration));
  const eased = progress * progress * (3 - 2 * progress);
  state.daylight = state.from === 'dark' ? eased : 1 - eased;
  if (progress === 1) { finish(); return; }
  clock.paint(state); frame = clock.request(tick);
 }
 return { state, start(next: Theme, immediate = false) {
  if (state.busy || state.to === next) return false;
  state.from = state.to; state.to = next; state.startedAt = clock.now(); state.duration = immediate ? 0 : THEME_DURATION; state.sequence++; state.busy = !immediate;
  clock.start(state);
  if (immediate) finish(); else { clock.paint(state); frame = clock.request(tick); }
  return true;
 }, finish, dispose() { clock.cancel(frame); } };
}
export const themeBootstrap = `(function(){var t=null;try{t=localStorage.getItem('dp-theme')}catch(e){}var d=t==='dark'||t==='light'?t==='dark':matchMedia('(prefers-color-scheme: dark)').matches;var r=document.documentElement;r.classList.toggle('dark',d);r.dataset.theme=d?'dark':'light';r.style.colorScheme=d?'dark':'light';r.style.setProperty('--daylight',d?'0':'1')})();`;
export const themeMessages = {
 light: ['天亮啦，早上好。', '把天空点亮，一起出发吧。', '晨光到了，今天也慢慢选。'],
 dark: ['天黑啦，我也要睡了。', '星河亮起来啦，晚安。', '月光就位，陪你慢慢看。'],
} as const;
