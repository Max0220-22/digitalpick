export type Theme = 'dark' | 'light';
export const THEME_DURATION = 1600;
export const THEME_STORAGE = 'dp-theme';
export const SKY_HINT_STORAGE = 'dp-sky-hint-seen';
export function claimSkyHint(storage: Pick<Storage, 'getItem' | 'setItem'>) {
 try { if (storage.getItem(SKY_HINT_STORAGE)) return false; storage.setItem(SKY_HINT_STORAGE, '1'); } catch {}
 return true;
}
export function resolveTheme(stored: string | null, systemDark: boolean): Theme {
 return stored === 'dark' || stored === 'light' ? stored : systemDark ? 'dark' : 'light';
}
export interface ThemeFrame { daylight: number; lighting: number; ui: number; breath: number; progress: number; from: Theme; to: Theme; startedAt: number; duration: number; sequence: number; busy: boolean }

/** CSS ease-in-out: cubic-bezier(.42,0,.58,1), shared by the rAF and CSS clocks. */
export function themeEase(value: number) {
 const x = Math.max(0, Math.min(1, value));
 if (x === 0 || x === 1 || x === .5) return x;
 let low=0, high=1, t=x;
 for(let i=0;i<24;i++) { t=(low+high)/2; const sample=3*(1-t)*(1-t)*t*.42+3*(1-t)*t*t*.58+t*t*t; if(sample<x)low=t;else high=t; }
 return 3*(1-t)*t*t+t*t*t;
}
export function sunlightVisibility(daylight: number) { return Math.max(0,Math.min(1,daylight)) ** 2; }
/** One symmetric playhead keeps the sky, lighting and UI synchronized. */
export function sampleTheme(from: Theme, to: Theme, progress: number) {
 const p = Math.max(0, Math.min(1, progress));
 const daylight = from === to ? +(to === 'light') : to === 'light' ? themeEase(p) : 1-themeEase(p);
 return { progress: p, daylight, lighting: daylight, ui: daylight, breath: 0 };
}
/** All sky layers use the same uninterrupted blend. */
export function sceneDaylight(frame: Pick<ThemeFrame,'daylight'|'ui'>) { return frame.daylight; }
export function readingPalette(progress: number) {
 const rgb = [8,17,31].map((night,i) => Math.round(night + ([244,249,255][i]-night)*progress));
 const linear = rgb.map(n => { const v=n/255; return v<=.04045?v/12.92:((v+.055)/1.055)**2.4; });
 const luminance = linear[0]*.2126+linear[1]*.7152+linear[2]*.0722;
 // Change ink polarity only at a measured contrast crossover. Never blend ink through gray.
 const darkInk = luminance >= .18;
 return { surface: `rgb(${rgb.join(' ')})`, ink: darkInk ? '#000000' : '#ffffff', darkInk, luminance };
}

export function bindThemeScheduler(host: { performance: { now(): number }; requestAnimationFrame(callback: (time: number) => void): number; cancelAnimationFrame(id: number): void }) {
 return { now: () => host.performance.now(), request: (callback: (time: number) => void) => host.requestAnimationFrame(callback), cancel: (id: number) => host.cancelAnimationFrame(id) };
}
interface TimelineClock { now: () => number; request: (callback: (time: number) => void) => number; cancel: (id: number) => void; paint: (state: ThemeFrame) => void; start: (state: ThemeFrame) => void; finish: (state: ThemeFrame) => void }
/** One clock drives the sky, lighting and pose. Repeated triggers are rejected synchronously. */
export function createThemeTimeline(initial: Theme, clock: TimelineClock) {
 const state: ThemeFrame = { ...sampleTheme(initial, initial, 1), from: initial, to: initial, startedAt: 0, duration: 0, sequence: 0, busy: false };
 let frame = 0;
 function finish() {
  clock.cancel(frame); frame = 0; Object.assign(state, sampleTheme(state.from, state.to, 1)); state.busy = false;
  clock.paint(state); clock.finish(state);
 }
 function tick(time: number) {
  const progress = Math.max(0, Math.min(1, (time - state.startedAt) / state.duration));
  Object.assign(state, sampleTheme(state.from, state.to, progress));
  if (progress === 1) { finish(); return; }
  clock.paint(state); frame = clock.request(tick);
 }
 return { state, start(next: Theme, immediate = false) {
  if (state.busy || state.to === next) return false;
  state.from = state.to; state.to = next; state.startedAt = clock.now(); state.duration = immediate ? 0 : THEME_DURATION; state.sequence++; state.busy = !immediate;
  Object.assign(state, sampleTheme(state.from, state.to, immediate ? 1 : 0));
  clock.start(state);
  if (immediate) finish(); else { clock.paint(state); frame = clock.request(tick); }
  return true;
 }, finish, dispose() { clock.cancel(frame); } };
}
export const themeBootstrap = `(function(){var t=null;try{t=localStorage.getItem('dp-theme')}catch(e){}var d=t==='dark'||t==='light'?t==='dark':matchMedia('(prefers-color-scheme: dark)').matches;var r=document.documentElement;r.classList.toggle('dark',d);r.dataset.theme=d?'dark':'light';r.dataset.themeDestination=r.dataset.theme;r.style.colorScheme=d?'dark':'light';r.style.setProperty('--daylight',d?'0':'1');r.style.setProperty('--scene-daylight',d?'0':'1');r.style.setProperty('--lighting',d?'0':'1');r.style.setProperty('--ui-daylight',d?'0':'1')})();`;
export const themeMessages = {
 light: ['天亮啦，早上好。', '把天空点亮，一起出发吧。', '晨光到了，今天也慢慢选。'],
 dark: ['天黑啦，我也要睡了。', '星河亮起来啦，晚安。', '月光就位，陪你慢慢看。'],
} as const;
