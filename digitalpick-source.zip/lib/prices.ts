import type { Price, Product, PurchaseMode } from './products';
import { money } from './utils';
export const PRICE_TTL_DAYS = 30;
export function isStale(price: Price, now = new Date()) { const at = Date.parse(`${price.collectedAt}T00:00:00+08:00`); return !Number.isFinite(at) || now.getTime() - at > PRICE_TTL_DAYS * 86400000 || at > now.getTime(); }
export function priceText(price: Price | null) { return price ? `${money(price.min)}${price.max !== price.min ? `–${money(price.max)}` : ''}` : '暂无可靠报价'; }
export function eligiblePrices(product: Product, mode: PurchaseMode, budget: number, now = new Date()) {
  return (['new', 'used'] as const).filter(m => mode === 'either' || mode === m).flatMap(m => {
    const price = m === 'new' ? product.newPrice : product.usedPrice;
    return price && (!price.kind || price.kind === 'quote') && price.budgetEligible !== false && (!price.currency || price.currency === 'CNY') && Number.isFinite(price.min) && Number.isFinite(price.max) && price.min > 0 && price.max >= price.min && (price.demo || !!price.source) && !isStale(price, now) && price.max <= budget ? [{ mode: m, price }] : [];
  });
}
export function reliableSavings(product: Product, now = new Date()): { amount: number; rate: number } | null {
  const a = product.newPrice, b = product.usedPrice;
  if (!a || !b || (a.kind && a.kind !== 'quote') || (b.kind && b.kind !== 'quote') || a.budgetEligible === false || b.budgetEligible === false || (a.currency && a.currency !== 'CNY') || (b.currency && b.currency !== 'CNY') || a.demo || b.demo || !a.source || !b.source || isStale(a, now) || isStale(b, now) || a.max !== a.min || b.max > a.min || a.min <= 0) return null;
  return { amount: a.min - b.max, rate: (a.min - b.max) / a.min * 100 };
}
