import priceData from '@/data/product-prices.json';
import type { Product } from './products';

export interface PriceReference {
 amount: number; currency: 'CNY'; region: string; configuration: string;
 scope: 'starting' | 'configuration'; kind: 'launch' | 'official-current' | 'official-msrp';
 sourceUrl: string; sourceLabel: string; checkedAt: string; publishedAt?: string;
 note?: string; evidenceUrl?: string; variants?: { configuration: string; amount: number }[];
}
export interface ProductPricing {
 status: 'listed' | 'not-listed' | 'unknown'; statusLabel: string; statusSource: string | null;
 checkedAt: string; launch: PriceReference | null; official: PriceReference | null;
 msrp: PriceReference | null; notes: string[];
}
export const productPricing = priceData as Record<string, ProductPricing>;
export const priceReferenceText = (price: PriceReference) => `¥${price.amount.toLocaleString('zh-CN')}${price.scope === 'starting' ? ' 起' : ''}`;
export function pricingFor(id: string): ProductPricing {
 return productPricing[id] || { status: 'unknown', statusLabel: '官网在售状态待核实', statusSource: null, checkedAt: '2026-10-19', launch: null, official: null, msrp: null, notes: [] };
}
// Editorial scenario model, not an observed market price or a platform appraisal.
export const estimatePolicy = {
 version: 'scenario-v1', date: '2026-10-19', condition: '功能正常、无进水/重大维修、无账号锁、普通成色；不含配件、平台保修或运费',
 phone: [[.55,.8],[.4,.65],[.28,.5],[.2,.4],[.14,.32],[.1,.25],[.07,.2],[.05,.16],[.04,.13],[.03,.1]],
 tablet: [[.55,.8],[.45,.7],[.35,.6],[.28,.5],[.2,.42],[.15,.35],[.1,.3],[.08,.25],[.06,.2],[.05,.16]],
 laptop: [[.55,.8],[.45,.72],[.35,.62],[.28,.52],[.22,.45],[.17,.38],[.13,.32],[.1,.27],[.08,.22],[.06,.18]],
} as const;
export function usedPriceScenario(product: Pick<Product,'id'|'category'|'year'|'name'>, date: string = estimatePolicy.date) {
 const pricing = pricingFor(product.id);
 if (pricing.status === 'listed' || /fold|flip|pocket|mate\s*x|折叠/i.test(product.name)) return null;
 // An MSRP is not silently treated as a launch price. No reliable launch anchor, no number.
 const anchor = pricing.launch;
 if (!anchor || anchor.currency !== 'CNY') return null;
 const year = anchor.publishedAt ? Number(anchor.publishedAt.slice(0,4)) : product.year;
 const currentYear = Number(date.slice(0,4));
 if (!year || year > currentYear || !Number.isInteger(currentYear)) return null;
 const age = currentYear - year;
 const band = estimatePolicy[product.category][Math.min(age,9)];
 const min = Math.floor(anchor.amount * band[0] / 50) * 50;
 const max = Math.ceil(anchor.amount * band[1] / 50) * 50;
 return { min, max, age, factors: band, anchor, date, policy: estimatePolicy.version, condition: estimatePolicy.condition, confidence: 'low' as const, marketSampleCount: 0, budgetEligible: false as const };
}
export function pricingSummary(product: Pick<Product,'id'|'category'|'year'|'name'>, mode: 'new'|'used') {
 const pricing = pricingFor(product.id);
 if (mode === 'used') { const estimate=usedPriceScenario(product); return estimate ? `¥${estimate.min.toLocaleString('zh-CN')}–¥${estimate.max.toLocaleString('zh-CN')}（折旧模型估算；无市场样本）` : '暂无有依据的二手估算'; }
 const quote=pricing.official||pricing.launch||pricing.msrp;
 return quote ? `${priceReferenceText(quote)}（${quote.kind==='official-current'?'官网参考':quote.kind==='launch'?'发售参考':'官方建议零售价'}；${quote.region}；${quote.configuration}）` : '暂无可靠价格记录';
}
