import type { Category } from '../products';
export const factLabels = {
  processor: '处理器', ram: '内存', storage: '存储配置', display: '屏幕', battery: '电池与标称续航',
  rearCamera: '后置摄像头', frontCamera: '前置摄像头', weight: '重量', os: '出厂系统 / 平台',
  gpu: '图形处理器', gpuMemory: '独立显存', cpuCores: 'CPU 核心数', cpuThreads: 'CPU 线程数',
  performanceCores: '性能核心', efficiencyCores: '能效核心', lowPowerCores: '低功耗能效核心',
  displayResolution: '屏幕分辨率', charging: '充电规格', connectivity: '接口与连接', stylus: '手写笔支持',
  dimensions: '机身尺寸', warranty: '来源地区保修', configuration: '配置范围',
} as const;
export type FactKey = keyof typeof factLabels;
export interface LibraryDevice {
  id: string; brand: string; name: string; category: Category; year: number | null;
  region: string; sourceId: string; sourceUrl: string; sourceUpdatedAt: string | null; importedAt: string;
  review: 'reviewed' | 'pending'; facts: Partial<Record<FactKey, string | null>>;
  aliases: string[]; productId?: string; notes: string[];
}
export interface LibrarySource { id: string; name: string; url: string; license: string; licensePath: string | null; revision: string; collectedAt: string | null; limitations: string[] }
