import { products } from '../products';
import additions from './reviewed-additions.json';
import type { LibraryDevice } from './types';
const present = (value: string) => /尚未|未单独|未披露|暂无/.test(value) ? null : value;
/** Only factual, sourced fields. Demo prices and editorial scores never enter this library. */
export const reviewedDevices: LibraryDevice[] = [
 ...products.map(p => ({
  id:'reviewed-'+p.id, productId:p.id, brand:p.brand, name:p.name, category:p.category, year:p.year,
  region:'既有配置资料；地区与配置见来源说明：'+p.source.label,
  sourceId:'official', sourceUrl:p.source.url, sourceUpdatedAt:p.updatedAt, importedAt:'2026-10-17', review:'reviewed' as const,
  aliases:[p.id.replace(/-/g,' ')],
  facts:{ processor:present(p.processor), ram:p.ram ? `${p.ram}GB（该配置）` : null, storage:`${p.storage}GB（该配置，不代表全部可选容量）`, display:present(p.screen), battery:present(p.battery), rearCamera:present(p.camera), weight:`${p.weight}g（该配置）`, os:p.os, configuration:p.configuration, ...(p.id==='iphone-16'?{ battery:'官方视频播放最长22小时；流媒体视频最长18小时；实验条件见 Apple，不能等同实际使用', rearCamera:'4800万主摄 + 1200万超广角（双摄）', frontCamera:'1200万像素', connectivity:'USB-C，USB 2（最高480Mb/s）' }:{} ) },
  notes:['既有单一配置参数，不能推断所有地区与容量版本相同。','没有可信现价或同条件测试时，不代表可在预算内买到，也不作帧率与续航承诺。'],
 })),
 ...additions as LibraryDevice[],
];
