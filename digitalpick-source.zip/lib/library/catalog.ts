import archive from './archive.json';
import { reviewedDevices } from './reviewed';
import type { LibraryDevice } from './types';
export const libraryDevices: LibraryDevice[] = [...reviewedDevices, ...archive as LibraryDevice[]];
export const libraryHref = (id: string) => `/library/?device=${encodeURIComponent(id)}`;
