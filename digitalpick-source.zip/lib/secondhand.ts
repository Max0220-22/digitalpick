import type { Product } from './products';
/** Search only: no tracking, invented listing, seller or price. */
export function buildSecondhandLink(brand: string, model: string, storage: string) {
 return 'https://www.goofish.com/search?q=' + encodeURIComponent(`${brand} ${model} ${storage}`);
}
export function secondhandSearch(product: Pick<Product, 'brand' | 'name' | 'storage' | 'ram'>) {
 const model = product.name.toLowerCase().startsWith(product.brand.toLowerCase()) ? product.name.slice(product.brand.length).trim() : product.name;
 const storage = product.storage ? `${product.ram ? product.ram + '+' : ''}${product.storage}` : '';
 return buildSecondhandLink(product.brand, model, storage);
}
