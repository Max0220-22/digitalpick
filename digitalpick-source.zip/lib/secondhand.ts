import type { Product } from './products';
type SearchProduct=Pick<Product,'brand'|'name'|'storage'|'ram'>;
/** Search only: no tracking, invented listing, seller or price. */
export function buildSecondhandLink(brand:string,model:string,storage:string) {
 return 'https://www.goofish.com/search?q='+encodeURIComponent(`${brand} ${model} ${storage}`);
}
export function secondhandKeywords(product:SearchProduct) {
 const model=product.name.toLowerCase().startsWith(product.brand.toLowerCase())?product.name.slice(product.brand.length).trim():product.name;
 const storage=product.storage?`${product.ram?product.ram+'+':''}${product.storage}`:'';
 return `${product.brand} ${model} ${storage}`;
}
export function secondhandSearch(product:SearchProduct) {
 return 'https://www.goofish.com/search?q='+encodeURIComponent(secondhandKeywords(product));
}
export function priceCheckSteps(product:SearchProduct) {
 return [
  {title:'搜什么',text:secondhandKeywords(product)},
  {title:'核哪三项',text:'配置：确认实际内存、存储与版本；成色：看磕碰、维修与功能；是否原装：核对屏幕、电池等部件的更换情况。搜索配置与参考价配置可能不同，请按实际配置重新核价。'},
  {title:'问卖家',text:`请确认这台${product.name}的实际内存和存储、磕碰与维修情况，以及屏幕、电池等部件是否更换；能否提供已遮挡个人信息的设备信息截图和功能演示？`},
 ];
}
