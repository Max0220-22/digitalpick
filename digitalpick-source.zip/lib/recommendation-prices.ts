import type { Price, Product, PurchaseMode } from './products';
import { eligiblePrices } from './prices';
import { pricingFor, usedPriceScenario, type PriceReference } from './price-reference';
export interface PriceEvidence {
 kind: 'quote' | 'official-reference' | 'launch-reference' | 'msrp-reference' | 'used-estimate';
 label: string; estimated: boolean; configuration: string; region: string;
 sourceLabel: string; sourceUrl: string | null; checkedAt: string; note: string;
}
export interface PlanningOffer { mode: 'new' | 'used'; price: Price; evidence: PriceEvidence }
function storageCapacity(configuration: string) {
 const amounts = [...configuration.matchAll(/(\d+(?:\.\d+)?)\s*(GB|TB|G|T)(?=\b|[+·（( /])/gi)].map(match => Number(match[1]) * (/^T/i.test(match[2]) ? 1024 : 1)).filter(value => value >= 32);
 return amounts.length ? Math.max(...amounts) : null;
}
function qualifiedReference(reference: PriceReference, minimumStorage: number): PriceReference | null {
 if (!minimumStorage) return reference;
 const variants = [reference, ...(reference.variants || []).map(variant => ({ ...reference, ...variant, scope: 'configuration' as const }))];
 return variants.filter(variant => (storageCapacity(variant.configuration) || 0) >= minimumStorage).sort((a, b) => a.amount - b.amount)[0] || null;
}
function validReference(reference: PriceReference | null, now: Date): reference is PriceReference {
 if (!reference || reference.currency !== 'CNY' || !Number.isFinite(reference.amount) || reference.amount <= 0) return false;
 const date = Date.parse(`${reference.checkedAt}T00:00:00+08:00`);
 try { const url = new URL(reference.sourceUrl); return url.protocol === 'https:' && !url.username && !url.password && Number.isFinite(date) && date <= now.getTime(); } catch { return false; }
}
/** Planning references never mutate Product prices or become budget-qualified purchase quotes. */
export function planningOffers(product: Product, mode: PurchaseMode, minimumStorage: number, now: Date): PlanningOffer[] {
 const validQuotes = eligiblePrices(product, mode, Number.MAX_SAFE_INTEGER, now).filter(offer => !offer.price.demo);
 const pricing = pricingFor(product.id); const result: PlanningOffer[] = [];
 for (const purchaseMode of ['new', 'used'] as const) {
  if (mode !== 'either' && mode !== purchaseMode) continue;
  const quote = validQuotes.find(offer => offer.mode === purchaseMode);
  if (quote) { result.push({ ...quote, evidence: { kind: 'quote', label: '同配置有效报价', estimated: false, configuration: product.configuration, region: product.region || '以报价来源为准', sourceLabel: quote.price.source || '报价来源', sourceUrl: /^https:\/\//.test(quote.price.source || '') ? quote.price.source : null, checkedAt: quote.price.collectedAt, note: '按报价区间上限核算，购买前仍须核实实际交易条件。' } }); continue; }
  if (purchaseMode === 'new') {
   const raw = [pricing.official, pricing.launch, pricing.msrp].find(reference => validReference(reference, now));
   const reference = raw && qualifiedReference(raw, minimumStorage);
   if (!reference || !validReference(reference, now)) continue;
   const label = reference.kind === 'official-current' ? '官网参考记录' : reference.kind === 'launch' ? '历史发售参考' : '官方建议零售价';
   result.push({ mode: 'new', price: { kind: reference.kind === 'launch' ? 'launch' : reference.kind === 'official-msrp' ? 'msrp' : 'estimate', min: reference.amount, max: reference.amount, demo: false, budgetEligible: false, currency: 'CNY', source: reference.sourceUrl, collectedAt: reference.checkedAt }, evidence: { kind: reference.kind === 'official-current' ? 'official-reference' : reference.kind === 'launch' ? 'launch-reference' : 'msrp-reference', estimated: true, label, configuration: reference.configuration, region: reference.region, sourceLabel: reference.sourceLabel, sourceUrl: reference.sourceUrl, checkedAt: reference.checkedAt, note: `${reference.scope === 'starting' ? '此金额是所列基础配置起价。' : ''}仅用于宽松预算规划，不是当前同配置可购买报价；不承诺仍有全新库存。` } });
  } else {
   const estimate = usedPriceScenario(product);
   if (!estimate || estimate.min <= 0 || !Number.isFinite(estimate.max) || estimate.max < estimate.min || !validReference(estimate.anchor, now) || (minimumStorage > 0 && (storageCapacity(estimate.anchor.configuration) || 0) < minimumStorage)) continue;
   result.push({ mode: 'used', price: { kind: 'estimate', min: estimate.min, max: estimate.max, demo: false, budgetEligible: false, currency: 'CNY', source: estimate.anchor.sourceUrl, collectedAt: estimate.date }, evidence: { kind: 'used-estimate', estimated: true, label: '二手折旧模型估算', configuration: estimate.anchor.configuration, region: estimate.anchor.region, sourceLabel: `模型锚点：${estimate.anchor.sourceLabel}`, sourceUrl: estimate.anchor.sourceUrl, checkedAt: estimate.date, note: `按估算区间上限核算；低置信度、无平台成交样本。前提：${estimate.condition}。` } });
  }
 }
 return result;
}
