/** Locally hosted, independently licensed device imagery. Never infer a quotation from a photographed price tag. */
export interface CatalogAsset {
  src: string; alt: string; author: string; sourceUrl: string;
  license: string; licenseUrl: string; changes: string; officialUrl: string;
  acquiredAt: string; label: string; views?: CatalogAsset[];
}
export const catalogAssets: Record<string, CatalogAsset> = {
  "iphone-x": {
    "src": "/products/iphone-x-front.webp",
    "alt": "iPhone X 深空灰色正面实拍",
    "author": "Gregory Varnum",
    "sourceUrl": "https://commons.wikimedia.org/wiki/File:Apple_iPhone_X_-_front_(8121).jpg",
    "license": "CC BY-SA 4.0",
    "licenseUrl": "https://creativecommons.org/licenses/by-sa/4.0",
    "changes": "按最长边960px缩放并转换WebP；未裁剪设备。",
    "officialUrl": "https://support.apple.com/zh-cn/111864",
    "acquiredAt": "2026-10-16",
    "label": "实物摄影",
    "views": [
      {
        "label": "背面",
        "src": "/products/iphone-x-back.webp",
        "alt": "iPhone X 深空灰色背面实拍",
        "author": "Gregory Varnum",
        "sourceUrl": "https://commons.wikimedia.org/wiki/File:Apple_iPhone_X_-_back_(8111).jpg",
        "license": "CC BY-SA 4.0",
        "licenseUrl": "https://creativecommons.org/licenses/by-sa/4.0",
        "changes": "按最长边960px缩放并转换WebP；未裁剪设备。",
        "officialUrl": "https://support.apple.com/zh-cn/111864",
        "acquiredAt": "2026-10-16"
      }
    ]
  },
  "iphone-xs": {
    "src": "/products/iphone-xs.webp",
    "alt": "iPhone XS 门店展台实拍，照片含其他展机",
    "author": "FASTILY",
    "sourceUrl": "https://commons.wikimedia.org/wiki/File:IPhone_XS_1_2018-11-02.jpg",
    "license": "CC BY-SA 4.0",
    "licenseUrl": "https://creativecommons.org/licenses/by-sa/4.0",
    "changes": "按最长边960px缩放并转换WebP；未裁剪设备。",
    "officialUrl": "https://support.apple.com/zh-cn/111881",
    "acquiredAt": "2026-10-16",
    "label": "实物摄影"
  },
  "iphone-xr": {
    "src": "/products/iphone-xr.webp",
    "alt": "蓝色 iPhone XR 背面实拍",
    "author": "Asdaiang14453",
    "sourceUrl": "https://commons.wikimedia.org/wiki/File:IPhone_XR.jpg",
    "license": "CC BY-SA 4.0",
    "licenseUrl": "https://creativecommons.org/licenses/by-sa/4.0",
    "changes": "按最长边960px缩放并转换WebP；未裁剪设备。",
    "officialUrl": "https://support.apple.com/zh-cn/111868",
    "acquiredAt": "2026-10-16",
    "label": "实物摄影"
  },
  "iphone-11": {
    "src": "/products/iphone-11.webp",
    "alt": "红色 iPhone 11 背面实拍",
    "author": "Ahmadkurdi44",
    "sourceUrl": "https://commons.wikimedia.org/wiki/File:IPhone_11_RED.jpg",
    "license": "CC BY-SA 4.0",
    "licenseUrl": "https://creativecommons.org/licenses/by-sa/4.0",
    "changes": "按最长边960px缩放并转换WebP；未裁剪设备。",
    "officialUrl": "https://support.apple.com/zh-cn/111865",
    "acquiredAt": "2026-10-16",
    "label": "实物摄影"
  },
  "iphone-12": {
    "src": "/products/iphone-12.webp",
    "alt": "红色 iPhone 12 正面外观图",
    "author": "Raphaël Poupon",
    "sourceUrl": "https://commons.wikimedia.org/wiki/File:Iphone-12-product--red.png",
    "license": "CC BY-SA 4.0",
    "licenseUrl": "https://creativecommons.org/licenses/by-sa/4.0",
    "changes": "按最长边960px缩放并转换WebP；未裁剪设备。",
    "officialUrl": "https://support.apple.com/zh-cn/111876",
    "acquiredAt": "2026-10-16",
    "label": "授权外观图"
  },
  "iphone-13": {
    "src": "/products/iphone-13.webp",
    "alt": "白色 iPhone 13 256GB 展机实拍，成色标签仅为照片内容",
    "author": "茅野ふたば",
    "sourceUrl": "https://commons.wikimedia.org/wiki/File:IPhone_13_White_256g.jpg",
    "license": "CC BY-SA 4.0",
    "licenseUrl": "https://creativecommons.org/licenses/by-sa/4.0",
    "changes": "按最长边960px缩放并转换WebP；未裁剪设备。",
    "officialUrl": "https://support.apple.com/zh-cn/111872",
    "acquiredAt": "2026-10-16",
    "label": "实物摄影"
  },
  "iphone-14": {
    "src": "/products/iphone-14.webp",
    "alt": "红色 iPhone 14 背面实拍",
    "author": "Hajoon0102",
    "sourceUrl": "https://commons.wikimedia.org/wiki/File:IPhone_14_Product_Red.jpg",
    "license": "CC BY-SA 4.0",
    "licenseUrl": "https://creativecommons.org/licenses/by-sa/4.0",
    "changes": "按最长边960px缩放并转换WebP；未裁剪设备。",
    "officialUrl": "https://support.apple.com/zh-cn/111850",
    "acquiredAt": "2026-10-16",
    "label": "实物摄影"
  },
  "iphone-15": {
    "src": "/products/iphone-15.webp",
    "alt": "黑色 iPhone 15 背面实拍",
    "author": "ThePhotoGraphIc",
    "sourceUrl": "https://commons.wikimedia.org/wiki/File:Back_of_iPhone_15.jpg",
    "license": "CC BY-SA 4.0",
    "licenseUrl": "https://creativecommons.org/licenses/by-sa/4.0",
    "changes": "按最长边960px缩放并转换WebP；未裁剪设备。",
    "officialUrl": "https://support.apple.com/zh-cn/111831",
    "acquiredAt": "2026-10-16",
    "label": "实物摄影"
  },
  "iphone-16": {
    "src": "/products/iphone-16.webp",
    "alt": "群青色 iPhone 16 背面实拍",
    "author": "Padgriffin",
    "sourceUrl": "https://commons.wikimedia.org/wiki/File:IPhone_16_Ultramarine_Rear.png",
    "license": "CC BY 4.0",
    "licenseUrl": "https://creativecommons.org/licenses/by/4.0",
    "changes": "按最长边960px缩放并转换WebP；未裁剪设备。",
    "officialUrl": "https://support.apple.com/zh-cn/121029",
    "acquiredAt": "2026-10-16",
    "label": "实物摄影"
  },
  "iphone-17": {
    "src": "/products/iphone-17.webp",
    "alt": "鼠尾草绿色 iPhone 17 背面实拍",
    "author": "Ahmad Ali Karim",
    "sourceUrl": "https://commons.wikimedia.org/wiki/File:Sage_iPhone_17_(cropped).jpg",
    "license": "CC0",
    "licenseUrl": "https://creativecommons.org/publicdomain/zero/1.0/deed.en",
    "changes": "按最长边960px缩放并转换WebP；未裁剪设备。",
    "officialUrl": "https://support.apple.com/zh-cn/125089",
    "acquiredAt": "2026-10-16",
    "label": "实物摄影"
  },
  "xiaomi-14": {
    "src": "/products/xiaomi-14.webp",
    "alt": "黑色 Xiaomi 14 背面展机实拍",
    "author": "茅野ふたば",
    "sourceUrl": "https://commons.wikimedia.org/wiki/File:Xiaomi_14_rear_(July_10,_2026).jpg",
    "license": "CC BY-SA 4.0",
    "licenseUrl": "https://creativecommons.org/licenses/by-sa/4.0",
    "changes": "按最长边960px缩放并转换WebP；未裁剪设备。",
    "officialUrl": "https://www.mi.com/sg/product/xiaomi-14/specs/",
    "acquiredAt": "2026-10-16",
    "label": "实物摄影"
  },
  "xiaomi-15": {
    "src": "/products/xiaomi-15.webp",
    "alt": "Xiaomi 15 正面展机实拍，照片价签为历史场景不构成报价",
    "author": "茅野ふたば",
    "sourceUrl": "https://commons.wikimedia.org/wiki/File:Xiaomi_15_(1).jpg",
    "license": "CC BY-SA 4.0",
    "licenseUrl": "https://creativecommons.org/licenses/by-sa/4.0",
    "changes": "按最长边960px缩放并转换WebP；未裁剪设备。",
    "officialUrl": "https://www.mi.com/hk/product/xiaomi-15/specs/",
    "acquiredAt": "2026-10-16",
    "label": "实物摄影",
    "views": [
      {
        "label": "正面 · 另一视角",
        "src": "/products/xiaomi-15-front-2.webp",
        "alt": "Xiaomi 15 正面另一视角实拍，照片价签为历史场景不构成报价",
        "author": "茅野ふたば",
        "sourceUrl": "https://commons.wikimedia.org/wiki/File:Xiaomi_15_(2).jpg",
        "license": "CC BY-SA 4.0",
        "licenseUrl": "https://creativecommons.org/licenses/by-sa/4.0",
        "changes": "按最长边960px缩放并转换WebP；未裁剪设备。",
        "officialUrl": "https://www.mi.com/hk/product/xiaomi-15/specs/",
        "acquiredAt": "2026-10-16"
      }
    ]
  },
  "galaxy-s24": {
    "src": "/products/galaxy-s24.webp",
    "alt": "Samsung Galaxy S24 正背面外观图",
    "author": "Eleanor Chin",
    "sourceUrl": "https://commons.wikimedia.org/wiki/File:S24_Onyx_Black.png",
    "license": "CC BY-SA 4.0",
    "licenseUrl": "https://creativecommons.org/licenses/by-sa/4.0",
    "changes": "按最长边960px缩放并转换WebP；未裁剪设备。",
    "officialUrl": "https://www.samsung.com/es/business/smartphones/galaxy-s/galaxy-s24-sm-s921bzkgeub/",
    "acquiredAt": "2026-10-16",
    "label": "授权外观图"
  },
  "galaxy-s25": {
    "src": "/products/galaxy-s25.webp",
    "alt": "Samsung Galaxy S25 黑色正面外观图",
    "author": "Mandy Harper",
    "sourceUrl": "https://commons.wikimedia.org/wiki/File:Galaxy_S25_Black.png",
    "license": "CC BY-SA 4.0",
    "licenseUrl": "https://creativecommons.org/licenses/by-sa/4.0",
    "changes": "按最长边960px缩放并转换WebP；未裁剪设备。",
    "officialUrl": "https://www.samsung.com.cn/smartphones/galaxy-s25/specs/",
    "acquiredAt": "2026-10-16",
    "label": "授权外观图"
  },
  "oppo-find-x8": {
    "src": "/products/oppo-find-x8.webp",
    "alt": "OPPO Find X8 背面展机实拍",
    "author": "メイド理世",
    "sourceUrl": "https://commons.wikimedia.org/wiki/File:Back_view_of_OPPO_Find_X8_(November_1,_2024).jpg",
    "license": "CC BY-SA 4.0",
    "licenseUrl": "https://creativecommons.org/licenses/by-sa/4.0",
    "changes": "按最长边960px缩放并转换WebP；未裁剪设备。",
    "officialUrl": "https://www.oppo.com/cn/smartphones/series-find-x/find-x8/specs/",
    "acquiredAt": "2026-10-16",
    "label": "实物摄影"
  },
  "vivo-x200-pro": {
    "src": "/products/vivo-x200-pro.webp",
    "alt": "vivo X200 Pro 宝石蓝背面展机实拍",
    "author": "X-SHLIED",
    "sourceUrl": "https://commons.wikimedia.org/wiki/File:Vivo_X200_Pro_blue.png",
    "license": "CC BY 4.0",
    "licenseUrl": "https://creativecommons.org/licenses/by/4.0",
    "changes": "按最长边960px缩放并转换WebP；未裁剪设备。",
    "officialUrl": "https://www.vivo.com.cn/vivo/param/x200pro",
    "acquiredAt": "2026-10-16",
    "label": "实物摄影"
  },
  "honor-magic7-pro": {
    "src": "/products/honor-magic7-pro.webp",
    "alt": "荣耀 Magic7 Pro 正面展机实拍，照片价签为历史场景不构成报价",
    "author": "茅野ふたば",
    "sourceUrl": "https://commons.wikimedia.org/wiki/File:Honor_Magic_7_Pro_(May_1,_2025).jpg",
    "license": "CC BY-SA 4.0",
    "licenseUrl": "https://creativecommons.org/licenses/by-sa/4.0",
    "changes": "按最长边960px缩放并转换WebP；未裁剪设备。",
    "officialUrl": "https://www.honor.com/cn/phones/honor-magic7-pro/spec/",
    "acquiredAt": "2026-10-16",
    "label": "实物摄影"
  },
  "oneplus-13": {
    "src": "/products/oneplus-13.webp",
    "alt": "一加 13 黑色背面展机实拍",
    "author": "Maksdroider",
    "sourceUrl": "https://commons.wikimedia.org/wiki/File:OnePlus_13_back.jpg",
    "license": "CC BY-SA 4.0",
    "licenseUrl": "https://creativecommons.org/licenses/by-sa/4.0",
    "changes": "按最长边960px缩放并转换WebP；未裁剪设备。",
    "officialUrl": "https://www.oneplus.com/cn/13/specs",
    "acquiredAt": "2026-10-16",
    "label": "实物摄影"
  },
  "ipad-air-m2": {
    "src": "/products/ipad-air-m2.webp",
    "alt": "iPad Air 13英寸 M2 展机实拍，键盘为另购配件",
    "author": "Kyu3a",
    "sourceUrl": "https://commons.wikimedia.org/wiki/File:M2_iPad_Air_13inti.jpg",
    "license": "CC BY-SA 4.0",
    "licenseUrl": "https://creativecommons.org/licenses/by-sa/4.0",
    "changes": "按最长边960px缩放并转换WebP；未裁剪设备。",
    "officialUrl": "https://support.apple.com/zh-cn/119893",
    "acquiredAt": "2026-10-16",
    "label": "实物摄影"
  },
  "macbook-air-m2": {
    "src": "/products/macbook-air-m2.webp",
    "alt": "MacBook Air 13.6英寸 M2 星光色实拍，原作者已模糊屏幕内容",
    "author": "KKPCW（Kyu3）；屏幕模糊处理：DFlhb",
    "sourceUrl": "https://commons.wikimedia.org/wiki/File:M2_Macbook_Air_Starlight_model.jpg",
    "license": "CC BY-SA 4.0",
    "licenseUrl": "https://creativecommons.org/licenses/by-sa/4.0",
    "changes": "按最长边960px缩放并转换WebP；未裁剪设备。原文件已由作者处理屏幕背景。",
    "officialUrl": "https://support.apple.com/zh-cn/111867",
    "acquiredAt": "2026-10-16",
    "label": "实物摄影"
  }
};

/** Manufacturer facts only. Apple does not publish RAM capacity in these specification pages; retain null.
 * No runtime performance claims, resale estimates or invented prices are attached to these catalogue entries.
 * Product editorial assessments are maintained separately from manufacturer specification facts. */
export interface CatalogPhone {
  id: string; brand: string; name: string; year: number; processor: string; ram: number | null;
  storage: number; screen: string; screenSize: number; weight: number; os: string; configuration: string;
  source: { label: string; url: string }; updatedAt: string; newPrice: null; usedPrice: null;
}
export const phoneCatalog: CatalogPhone[] = [
  {
    "id": "iphone-x",
    "brand": "Apple",
    "name": "iPhone X",
    "year": 2017,
    "processor": "Apple A11 仿生",
    "ram": null,
    "storage": 64,
    "screen": "5.8 英寸 OLED · 2436 × 1125",
    "screenSize": 5.8,
    "weight": 174,
    "os": "iOS",
    "configuration": "64GB · 标准版",
    "source": {
      "label": "Apple 官方技术规格",
      "url": "https://support.apple.com/zh-cn/111864"
    },
    "updatedAt": "2026-10-16",
    "newPrice": null,
    "usedPrice": null
  },
  {
    "id": "iphone-xs",
    "brand": "Apple",
    "name": "iPhone XS",
    "year": 2018,
    "processor": "Apple A12 仿生",
    "ram": null,
    "storage": 64,
    "screen": "5.8 英寸 OLED · 2436 × 1125",
    "screenSize": 5.8,
    "weight": 177,
    "os": "iOS",
    "configuration": "64GB · 标准版",
    "source": {
      "label": "Apple 官方技术规格",
      "url": "https://support.apple.com/zh-cn/111881"
    },
    "updatedAt": "2026-10-16",
    "newPrice": null,
    "usedPrice": null
  },
  {
    "id": "iphone-xr",
    "brand": "Apple",
    "name": "iPhone XR",
    "year": 2018,
    "processor": "Apple A12 仿生",
    "ram": null,
    "storage": 128,
    "screen": "6.1 英寸 LCD · 1792 × 828",
    "screenSize": 6.1,
    "weight": 194,
    "os": "iOS",
    "configuration": "128GB · 标准版",
    "source": {
      "label": "Apple 官方技术规格",
      "url": "https://support.apple.com/zh-cn/111868"
    },
    "updatedAt": "2026-10-16",
    "newPrice": null,
    "usedPrice": null
  },
  {
    "id": "iphone-11",
    "brand": "Apple",
    "name": "iPhone 11",
    "year": 2019,
    "processor": "Apple A13 仿生",
    "ram": null,
    "storage": 128,
    "screen": "6.1 英寸 LCD · 1792 × 828",
    "screenSize": 6.1,
    "weight": 194,
    "os": "iOS",
    "configuration": "128GB · 标准版",
    "source": {
      "label": "Apple 官方技术规格",
      "url": "https://support.apple.com/zh-cn/111865"
    },
    "updatedAt": "2026-10-16",
    "newPrice": null,
    "usedPrice": null
  },
  {
    "id": "iphone-12",
    "brand": "Apple",
    "name": "iPhone 12",
    "year": 2020,
    "processor": "Apple A14 仿生",
    "ram": null,
    "storage": 128,
    "screen": "6.1 英寸 OLED · 2532 × 1170",
    "screenSize": 6.1,
    "weight": 162,
    "os": "iOS",
    "configuration": "128GB · 标准版",
    "source": {
      "label": "Apple 官方技术规格",
      "url": "https://support.apple.com/zh-cn/111876"
    },
    "updatedAt": "2026-10-16",
    "newPrice": null,
    "usedPrice": null
  },
  {
    "id": "iphone-13",
    "brand": "Apple",
    "name": "iPhone 13",
    "year": 2021,
    "processor": "Apple A15 仿生",
    "ram": null,
    "storage": 128,
    "screen": "6.1 英寸 OLED · 2532 × 1170",
    "screenSize": 6.1,
    "weight": 173,
    "os": "iOS",
    "configuration": "128GB · 标准版",
    "source": {
      "label": "Apple 官方技术规格",
      "url": "https://support.apple.com/zh-cn/111872"
    },
    "updatedAt": "2026-10-16",
    "newPrice": null,
    "usedPrice": null
  },
  {
    "id": "iphone-14",
    "brand": "Apple",
    "name": "iPhone 14",
    "year": 2022,
    "processor": "Apple A15 仿生",
    "ram": null,
    "storage": 128,
    "screen": "6.1 英寸 OLED · 2532 × 1170",
    "screenSize": 6.1,
    "weight": 172,
    "os": "iOS",
    "configuration": "128GB · 标准版",
    "source": {
      "label": "Apple 官方技术规格",
      "url": "https://support.apple.com/zh-cn/111850"
    },
    "updatedAt": "2026-10-16",
    "newPrice": null,
    "usedPrice": null
  },
  {
    "id": "iphone-15",
    "brand": "Apple",
    "name": "iPhone 15",
    "year": 2023,
    "processor": "Apple A16 仿生",
    "ram": null,
    "storage": 128,
    "screen": "6.1 英寸 OLED · 2556 × 1179",
    "screenSize": 6.1,
    "weight": 171,
    "os": "iOS",
    "configuration": "128GB · 标准版",
    "source": {
      "label": "Apple 官方技术规格",
      "url": "https://support.apple.com/zh-cn/111831"
    },
    "updatedAt": "2026-10-16",
    "newPrice": null,
    "usedPrice": null
  },
  {
    "id": "iphone-16",
    "brand": "Apple",
    "name": "iPhone 16",
    "year": 2024,
    "processor": "Apple A18",
    "ram": null,
    "storage": 128,
    "screen": "6.1 英寸 OLED · 2556 × 1179",
    "screenSize": 6.1,
    "weight": 170,
    "os": "iOS",
    "configuration": "128GB · 标准版",
    "source": {
      "label": "Apple 官方技术规格",
      "url": "https://support.apple.com/zh-cn/121029"
    },
    "updatedAt": "2026-10-16",
    "newPrice": null,
    "usedPrice": null
  },
  {
    "id": "iphone-17",
    "brand": "Apple",
    "name": "iPhone 17",
    "year": 2025,
    "processor": "Apple A19",
    "ram": null,
    "storage": 256,
    "screen": "6.3 英寸 OLED · 2622 × 1206 · 最高120Hz",
    "screenSize": 6.3,
    "weight": 177,
    "os": "iOS",
    "configuration": "256GB · 标准版",
    "source": {
      "label": "Apple 官方技术规格",
      "url": "https://support.apple.com/zh-cn/125089"
    },
    "updatedAt": "2026-10-16",
    "newPrice": null,
    "usedPrice": null
  },
  {
    "id": "iphone-18-pro",
    "brand": "Apple",
    "name": "iPhone 18 Pro",
    "year": 2026,
    "processor": "Apple A20 Pro",
    "ram": null,
    "storage": 256,
    "screen": "6.3 英寸 OLED · 2622 × 1206 · 最高120Hz",
    "screenSize": 6.3,
    "weight": 211,
    "os": "iOS",
    "configuration": "256GB · 中国大陆版",
    "source": {
      "label": "Apple 中国大陆官方技术规格；尚未找到可分发摄影",
      "url": "https://www.apple.com.cn/iphone-18-pro/specs/"
    },
    "updatedAt": "2026-10-16",
    "newPrice": null,
    "usedPrice": null
  },
  {
    "id": "xiaomi-14",
    "brand": "Xiaomi",
    "name": "Xiaomi 14",
    "year": 2023,
    "processor": "骁龙 8 Gen 3",
    "ram": 12,
    "storage": 256,
    "screen": "6.36 英寸 AMOLED · 2670 × 1200 · 1–120Hz",
    "screenSize": 6.36,
    "weight": 193,
    "os": "Android",
    "configuration": "12GB + 256GB · 玻璃版",
    "source": {
      "label": "小米官方规格（新加坡版，核对地区版本）",
      "url": "https://www.mi.com/sg/product/xiaomi-14/specs/"
    },
    "updatedAt": "2026-10-16",
    "newPrice": null,
    "usedPrice": null
  },
  {
    "id": "xiaomi-15",
    "brand": "Xiaomi",
    "name": "Xiaomi 15",
    "year": 2024,
    "processor": "骁龙 8 至尊版",
    "ram": 12,
    "storage": 256,
    "screen": "6.36 英寸 AMOLED · 2670 × 1200 · 1–120Hz",
    "screenSize": 6.36,
    "weight": 191,
    "os": "Android",
    "configuration": "12GB + 256GB · 玻璃版",
    "source": {
      "label": "小米香港官方规格（电池等参数可能有地区差异）",
      "url": "https://www.mi.com/hk/product/xiaomi-15/specs/"
    },
    "updatedAt": "2026-10-16",
    "newPrice": null,
    "usedPrice": null
  },
  {
    "id": "galaxy-s24",
    "brand": "Samsung",
    "name": "Samsung Galaxy S24",
    "year": 2024,
    "processor": "Samsung Exynos 2400（欧洲版）",
    "ram": 8,
    "storage": 256,
    "screen": "6.2 英寸 AMOLED · 2340 × 1080 · 最高120Hz",
    "screenSize": 6.2,
    "weight": 167,
    "os": "Android",
    "configuration": "8GB + 256GB · 欧洲版 SM-S921B",
    "source": {
      "label": "三星西班牙官方规格（欧洲版；国行处理器不同）",
      "url": "https://www.samsung.com/es/business/smartphones/galaxy-s/galaxy-s24-sm-s921bzkgeub/"
    },
    "updatedAt": "2026-10-16",
    "newPrice": null,
    "usedPrice": null
  },
  {
    "id": "galaxy-s25",
    "brand": "Samsung",
    "name": "Samsung Galaxy S25",
    "year": 2025,
    "processor": "骁龙 8 至尊版移动平台（for Galaxy）",
    "ram": 12,
    "storage": 256,
    "screen": "6.2 英寸 AMOLED · 2340 × 1080 · 最高120Hz",
    "screenSize": 6.2,
    "weight": 162,
    "os": "Android",
    "configuration": "12GB + 256GB · 中国大陆版",
    "source": {
      "label": "三星中国大陆官方规格",
      "url": "https://www.samsung.com.cn/business/smartphones/galaxy-s/galaxy-s25-sm-s9310lbgchc/"
    },
    "updatedAt": "2026-10-16",
    "newPrice": null,
    "usedPrice": null
  },
  {
    "id": "oppo-find-x8",
    "brand": "OPPO",
    "name": "OPPO Find X8",
    "year": 2024,
    "processor": "联发科天玑 9400",
    "ram": 12,
    "storage": 256,
    "screen": "6.59 英寸 AMOLED · 2760 × 1256 · 最高120Hz",
    "screenSize": 6.59,
    "weight": 193,
    "os": "Android",
    "configuration": "12GB + 256GB · 中国大陆版",
    "source": {
      "label": "OPPO 中国大陆官方规格",
      "url": "https://www.oppo.com/cn/smartphones/series-find-x/find-x8/specs/"
    },
    "updatedAt": "2026-10-16",
    "newPrice": null,
    "usedPrice": null
  },
  {
    "id": "vivo-x200",
    "brand": "vivo",
    "name": "vivo X200",
    "year": 2024,
    "processor": "联发科天玑 9400",
    "ram": 12,
    "storage": 256,
    "screen": "6.67 英寸 AMOLED · 2800 × 1260 · 最高120Hz",
    "screenSize": 6.67,
    "weight": 197,
    "os": "Android",
    "configuration": "12GB + 256GB · 辰夜黑 · 中国大陆版",
    "source": {
      "label": "vivo 中国大陆官方规格；尚未找到可分发摄影",
      "url": "https://www.vivo.com.cn/vivo/param/x200"
    },
    "updatedAt": "2026-10-16",
    "newPrice": null,
    "usedPrice": null
  },
  {
    "id": "vivo-x200-pro",
    "brand": "vivo",
    "name": "vivo X200 Pro",
    "year": 2024,
    "processor": "联发科天玑 9400",
    "ram": 12,
    "storage": 256,
    "screen": "6.78 英寸 AMOLED · 2800 × 1260 · 最高120Hz",
    "screenSize": 6.78,
    "weight": 228,
    "os": "Android",
    "configuration": "12GB + 256GB · 宝石蓝 · 中国大陆版",
    "source": {
      "label": "vivo 中国大陆官方规格（蓝色228g，黑色223g）",
      "url": "https://www.vivo.com.cn/vivo/param/x200pro"
    },
    "updatedAt": "2026-10-16",
    "newPrice": null,
    "usedPrice": null
  },
  {
    "id": "honor-magic7-pro",
    "brand": "HONOR",
    "name": "荣耀 Magic7 Pro",
    "year": 2024,
    "processor": "骁龙 8 至尊版",
    "ram": 12,
    "storage": 256,
    "screen": "6.8 英寸 OLED · 2800 × 1280 · 最高120Hz",
    "screenSize": 6.8,
    "weight": 223,
    "os": "Android",
    "configuration": "12GB + 256GB · 中国大陆版",
    "source": {
      "label": "荣耀中国大陆官方规格（页面动态加载，购买时复核SKU）",
      "url": "https://www.honor.com/cn/phones/honor-magic7-pro/spec/"
    },
    "updatedAt": "2026-10-16",
    "newPrice": null,
    "usedPrice": null
  },
  {
    "id": "oneplus-13",
    "brand": "OnePlus",
    "name": "一加 13",
    "year": 2024,
    "processor": "骁龙 8 至尊版",
    "ram": 12,
    "storage": 256,
    "screen": "6.82 英寸 AMOLED · 3168 × 1440 · 1–120Hz",
    "screenSize": 6.82,
    "weight": 213,
    "os": "Android",
    "configuration": "12GB + 256GB · 玻璃版 · 中国大陆版",
    "source": {
      "label": "一加中国大陆官方规格（玻璃版213g，皮革版210g）",
      "url": "https://www.oneplus.com/cn/13/specs"
    },
    "updatedAt": "2026-10-16",
    "newPrice": null,
    "usedPrice": null
  }
];
