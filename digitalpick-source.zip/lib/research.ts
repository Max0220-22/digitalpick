/** Curated source notes, not training data, reviewer ratings, or an all-platform popularity ranking. */
export interface ResearchSource {
  id: string; title: string; creator: string; platform: 'YouTube' | 'Reddit' | 'X'; kind: 'review' | 'social';
  url: string; publishedAt: string | null; checkedAt: string; access: 'description' | 'post-body' | 'unavailable';
  productIds: string[]; configuration: string | null; region: string | null; softwareVersion: string | null;
  summary: string; limitations: string;
  engagement: { metric: string; value: number; visibility: string; recordedAt: string } | null;
}
export const researchSources: ResearchSource[] = [
  {
    "id": "M01",
    "title": "Apple iPhone X Unboxing!",
    "creator": "Marques Brownlee / MKBHD",
    "platform": "YouTube",
    "kind": "review",
    "url": "https://www.youtube.com/watch?v=l0DoQYGZt8M",
    "publishedAt": "2017-10-31",
    "checkedAt": "2026-10-16",
    "access": "description",
    "productIds": [
      "iphone-x"
    ],
    "configuration": null,
    "region": null,
    "softwareVersion": null,
    "summary": "开箱与早期印象，不能充当多年可靠性评测。",
    "limitations": "简介含 Apple 供机披露；未读完整字幕。",
    "engagement": null
  },
  {
    "id": "M02",
    "title": "iPhone X Revisited: Still Worth $1000?!",
    "creator": "Marques Brownlee / MKBHD",
    "platform": "YouTube",
    "kind": "review",
    "url": "https://www.youtube.com/watch?v=OJfOsoUYPts",
    "publishedAt": "2018-04-27",
    "checkedAt": "2026-10-16",
    "access": "description",
    "productIds": [
      "iphone-x"
    ],
    "configuration": null,
    "region": null,
    "softwareVersion": null,
    "summary": "约六个月后的回访，保留评测阶段与时间窗口。",
    "limitations": "未核实视频最后购买结论；历史美元语境不是当前行情。",
    "engagement": null
  },
  {
    "id": "M03",
    "title": "iPhone 13 Review: Lowkey Great!",
    "creator": "Marques Brownlee / MKBHD",
    "platform": "YouTube",
    "kind": "review",
    "url": "https://www.youtube.com/watch?v=g5ymJNLURRI",
    "publishedAt": "2021-09-27",
    "checkedAt": "2026-10-16",
    "access": "description",
    "productIds": [
      "iphone-13"
    ],
    "configuration": null,
    "region": null,
    "softwareVersion": null,
    "summary": "简介给出总体正面判断，但没有列明三个改善项目。",
    "limitations": "不从总体好评推导各项满分；供机披露可读，配置及地区未确认。",
    "engagement": null
  },
  {
    "id": "M04",
    "title": "Smartphone Awards 2021!",
    "creator": "Marques Brownlee / MKBHD",
    "platform": "YouTube",
    "kind": "review",
    "url": "https://www.youtube.com/watch?v=IDcyXtweHCw",
    "publishedAt": "2021-12-22",
    "checkedAt": "2026-10-16",
    "access": "description",
    "productIds": [],
    "configuration": null,
    "region": null,
    "softwareVersion": null,
    "summary": "章节分别设置尺寸、相机、电池、价值等类别。",
    "limitations": "仅核对类别，未导入得主、名次或数字评分。",
    "engagement": null
  },
  {
    "id": "M05",
    "title": "M2 MacBook Air Review: More Than a Refresh!",
    "creator": "Marques Brownlee / MKBHD",
    "platform": "YouTube",
    "kind": "review",
    "url": "https://www.youtube.com/watch?v=HeMIZC2rkMo",
    "publishedAt": "2022-07-18",
    "checkedAt": "2026-10-16",
    "access": "description",
    "productIds": [
      "macbook-air-m2"
    ],
    "configuration": null,
    "region": null,
    "softwareVersion": null,
    "summary": "简介同时强调机身薄与价格容易被低估。",
    "limitations": "不能据简介推导散热或SSD成绩；发布期价格、测试配置未核实。",
    "engagement": null
  },
  {
    "id": "M06",
    "title": "iPhone 15 Review: Welcome to the Club!",
    "creator": "Marques Brownlee / MKBHD",
    "platform": "YouTube",
    "kind": "review",
    "url": "https://www.youtube.com/watch?v=0X0Jm8QValY",
    "publishedAt": "2023-10-02",
    "checkedAt": "2026-10-16",
    "access": "description",
    "productIds": [
      "iphone-15"
    ],
    "configuration": null,
    "region": null,
    "softwareVersion": null,
    "summary": "简介认为缺少新意仍可以是好手机；章节讨论60Hz、接口、相机与续航。",
    "limitations": "未核实完整最终购买建议，不适用于Pro/Pro Max或当前二手成色。",
    "engagement": null
  },
  {
    "id": "M07",
    "title": "The Blind Smartphone Camera Test Winners!",
    "creator": "Marques Brownlee / MKBHD",
    "platform": "YouTube",
    "kind": "review",
    "url": "https://www.youtube.com/watch?v=VRoTOE3FqT0",
    "publishedAt": "2024-01-08",
    "checkedAt": "2026-10-16",
    "access": "description",
    "productIds": [],
    "configuration": null,
    "region": null,
    "softwareVersion": null,
    "summary": "原作者盲测结果作品，可核实投票项目入口。",
    "limitations": "官方完整协议和结果未读取；不导入胜者、票数或相机分。",
    "engagement": null
  },
  {
    "id": "M08",
    "title": "The Worst Product I've Ever Reviewed... For Now",
    "creator": "Marques Brownlee / MKBHD",
    "platform": "YouTube",
    "kind": "review",
    "url": "https://www.youtube.com/watch?v=TitZV6k8zfA",
    "publishedAt": "2024-04-14",
    "checkedAt": "2026-10-16",
    "access": "description",
    "productIds": [],
    "configuration": null,
    "region": null,
    "softwareVersion": null,
    "summary": "简介对当时的Humane AI Pin给出明确负面购买意见。",
    "limitations": "只适用于当时该设备，不能外推所有AI手机；未来潜力与已交付能力分开。",
    "engagement": null
  },
  {
    "id": "M09",
    "title": "5 Weird iPad Pro (M4) Decisions",
    "creator": "Marques Brownlee / MKBHD",
    "platform": "YouTube",
    "kind": "review",
    "url": "https://www.youtube.com/watch?v=PHcDrXeyguM",
    "publishedAt": "2024-05-21",
    "checkedAt": "2026-10-16",
    "access": "description",
    "productIds": [],
    "configuration": null,
    "region": null,
    "softwareVersion": null,
    "summary": "简介说明约两周体验，可确认评测窗口。",
    "limitations": "未核实五项具体意见，不能套用iPad Air M2。",
    "engagement": null
  },
  {
    "id": "M10",
    "title": "iPhone 16/16 Pro Review: Times Have Changed!",
    "creator": "Marques Brownlee / MKBHD",
    "platform": "YouTube",
    "kind": "review",
    "url": "https://www.youtube.com/watch?v=MRtg6A1f2Ko",
    "publishedAt": "2024-09-23",
    "checkedAt": "2026-10-16",
    "access": "description",
    "productIds": [],
    "configuration": null,
    "region": null,
    "softwareVersion": null,
    "summary": "简介将当时产品描述为尚未完成，章节包含购买建议。",
    "limitations": "标题含标准版与Pro，未读全文，不推断各地区今天的AI功能状态。",
    "engagement": null
  },
  {
    "id": "S01",
    "title": "M2 MacBook Air 配置与总成本讨论",
    "creator": "u/mwest217；配置评论 u/P_S_D",
    "platform": "Reddit",
    "kind": "social",
    "url": "https://www.reddit.com/r/apple/comments/w2e3v8/mkbhd_m2_macbook_air_review_more_than_a_refresh/",
    "publishedAt": "2022-07-18",
    "checkedAt": "2026-10-16",
    "access": "post-body",
    "productIds": [],
    "configuration": null,
    "region": null,
    "softwareVersion": null,
    "summary": "轻便和配置升级成本需要分别考虑，评论涉及不同地区历史价格。",
    "limitations": "2022年讨论；不是作者本人测评，不能套用当前16GB配置价格。",
    "engagement": {
      "metric": "Reddit 投票分数快照",
      "value": 1195,
      "visibility": "搜索索引快照",
      "recordedAt": "2026-10-16"
    }
  },
  {
    "id": "S02",
    "title": "My review of 15 pro",
    "creator": "u/InferiorArrears",
    "platform": "Reddit",
    "kind": "social",
    "url": "https://www.reddit.com/r/iphone/comments/16wnmn4/my_review_of_15_pro/",
    "publishedAt": "2023-10-01",
    "checkedAt": "2026-10-16",
    "access": "post-body",
    "productIds": [],
    "configuration": null,
    "region": null,
    "softwareVersion": null,
    "summary": "个人购后续航与温度体验较正面，也报告Wi-Fi问题。",
    "limitations": "单人观察，地区、系统和负载未确认；不用于标准版iPhone15。",
    "engagement": {
      "metric": "Reddit 投票分数快照",
      "value": 133,
      "visibility": "搜索索引快照",
      "recordedAt": "2026-10-16"
    }
  },
  {
    "id": "S03",
    "title": "My iPhone 15 pro battery is trash",
    "creator": "作者已删除",
    "platform": "Reddit",
    "kind": "social",
    "url": "https://www.reddit.com/r/iPhone15Pro/comments/16x7etn/my_iphone_15_pro_battery_is_trash/",
    "publishedAt": "2023-10-01",
    "checkedAt": "2026-10-16",
    "access": "post-body",
    "productIds": [],
    "configuration": null,
    "region": null,
    "softwareVersion": null,
    "summary": "个人自述一天续航不足，与同日另一用户形成相反体验。",
    "limitations": "信号、负载、版本和电池健康未知；不是故障率样本。",
    "engagement": {
      "metric": "Reddit 投票分数快照",
      "value": 113,
      "visibility": "搜索索引快照",
      "recordedAt": "2026-10-16"
    }
  },
  {
    "id": "S04",
    "title": "My experience so far with 15 Pro and addressing concerns",
    "creator": "u/FoundationOpening513",
    "platform": "Reddit",
    "kind": "social",
    "url": "https://www.reddit.com/r/iPhone15Pro/comments/1776cox/my_experience_so_far_with_15_pro_and_addressing/",
    "publishedAt": "2023-10-13",
    "checkedAt": "2026-10-16",
    "access": "post-body",
    "productIds": [],
    "configuration": null,
    "region": null,
    "softwareVersion": "iOS 17.0.3",
    "summary": "iOS17.0.3体验帖的续航表述受到统计方式质疑。",
    "limitations": "不采纳亮屏小时数；不得与其他充电/网络条件混算。",
    "engagement": {
      "metric": "Reddit 投票分数快照",
      "value": 83,
      "visibility": "搜索索引快照",
      "recordedAt": "2026-10-16"
    }
  },
  {
    "id": "S05",
    "title": "The End of the 6.1-Inch Era",
    "creator": "u/S_Karmakar",
    "platform": "Reddit",
    "kind": "social",
    "url": "https://uk.reddit.com/r/iphone/comments/1ofg2hc/the_end_of_the_61inch_era/",
    "publishedAt": "2025-10-25",
    "checkedAt": "2026-10-16",
    "access": "post-body",
    "productIds": [],
    "configuration": null,
    "region": null,
    "softwareVersion": null,
    "summary": "小屏用户关注单手握持，屏幕对角线不能代替机身宽度。",
    "limitations": "原页快照208分、索引205分；不采纳未来机型预测或推算机身宽度。",
    "engagement": {
      "metric": "Reddit 投票分数快照",
      "value": 208,
      "visibility": "原页快照",
      "recordedAt": "2026-10-16"
    }
  },
  {
    "id": "S06",
    "title": "S24 is an amazing phone (iPhone lifer)",
    "creator": "u/Boullionaire",
    "platform": "Reddit",
    "kind": "social",
    "url": "https://www.reddit.com/r/samsung/comments/1hjkdqi/s24_is_an_amazing_phone_iphone_lifer/",
    "publishedAt": "2024-12-21",
    "checkedAt": "2026-10-16",
    "access": "post-body",
    "productIds": [],
    "configuration": null,
    "region": null,
    "softwareVersion": null,
    "summary": "系统迁移、键盘习惯和数据迁移影响首次换平台体验。",
    "limitations": "地区SoC、系统及运营商未知；不可给欧洲版S24或所有三星机型加分。",
    "engagement": {
      "metric": "Reddit 投票分数快照",
      "value": 197,
      "visibility": "搜索索引快照",
      "recordedAt": "2026-10-16"
    }
  },
  {
    "id": "X01",
    "title": "MKBHD 分享 M2 MacBook Air 评测",
    "creator": "MKBHD",
    "platform": "X",
    "kind": "social",
    "url": "https://x.com/MKBHD/status/1549380247962935303",
    "publishedAt": null,
    "checkedAt": "2026-10-16",
    "access": "unavailable",
    "productIds": [],
    "configuration": null,
    "region": null,
    "softwareVersion": null,
    "summary": "可定位原帖，正文和互动数据未核实。",
    "limitations": "原页访问受限，仅保留发现线索，不作为产品结论。",
    "engagement": null
  }
];
export interface ResearchPrinciple { id: string; title: string; rule: string; sourceIds: string[] }
export const researchPrinciples: ResearchPrinciple[] = [
  { id: 'fit', title: '主需求不能被平均分盖住', rule: '各项主要用途先过门槛，再按用户主用途排序。60/40和各项权重是本站编辑规则，不是博主的公式。', sourceIds: ['M04', 'M06'] },
  { id: 'budget', title: '预算算完整，购买方式看取舍', rule: '按具体配置报价上限加用户预留费用审核，不默认低价二手更适合。未知配件、维修与订阅费用不编造。', sourceIds: ['M05', 'S01'] },
  { id: 'battery', title: '相反体验保留条件', rule: '不同版本、网络和电池状态的续航不平均；相反购后帖仅触发复查，不形成设备故障率。', sourceIds: ['S02', 'S03', 'S04'] },
  { id: 'camera', title: '拍照偏好不等于全能相机', rule: '照片、视频、夜景、人像、长焦分别确认；本轮未读到原始盲测协议与名次，因此不导入排名。', sourceIds: ['M07'] },
  { id: 'availability', title: '只认可已核实的当前能力', rule: 'AI、解锁与软件能力须核对型号、地区、语言和版本。未来承诺及营销标签不给默认奖励，历史批评也不永久扣分。', sourceIds: ['M08', 'M10'] },
  { id: 'workflow', title: '先确认工作流，再比较芯片', rule: '必要系统、软件与配件先核对。屏幕对角线不是机身宽度；换平台还要考虑软件与数据迁移。', sourceIds: ['M09', 'S05', 'S06'] },
];
export function historicalReferences(productId: string) { return researchSources.filter(s => s.kind === 'review' && s.access !== 'unavailable' && s.productIds.includes(productId)); }
export function researchContext(uses: string[]) {
  const ids = ['fit', 'budget', 'workflow', ...(/续航/.test(uses.join()) ? ['battery'] : []), ...(/拍照|摄影/.test(uses.join()) ? ['camera'] : []), ...(/AI|系统可玩性/.test(uses.join()) ? ['availability'] : [])];
  return researchPrinciples.filter(p => ids.includes(p.id)).map(p => ({ ...p, provenance: 'DigitalPick 编辑归纳，未由来源作者制定', sources: p.sourceIds.map(id => researchSources.find(s => s.id === id)!).map(s => ({ id: s.id, title: s.title, url: s.url, publishedAt: s.publishedAt, access: s.access, limitations: s.limitations })) }));
}
