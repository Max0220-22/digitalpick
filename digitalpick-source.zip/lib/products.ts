import { phoneCatalog } from './catalog-assets';
import { expandProducts, type CatalogFacts } from './catalog-expanded';
export type Category = 'phone' | 'tablet' | 'laptop';
export type PurchaseMode = 'new' | 'used' | 'either';
export interface Price { kind?: 'quote' | 'launch' | 'estimate' | 'msrp'; currency?: string; budgetEligible?: boolean; min: number; max: number; demo: boolean; source: string | null; collectedAt: string; }
export interface Product {
  id: string; brand: string; name: string; category: Category; year: number | null; tagline: string;
  processor: string; ram: number | null; storage: number | null; screen: string; screenSize: number | null;
  battery: string; camera: string; weight: number | null; os: string; configuration: string;
  pros: string[]; cons: string[]; suitable: string[]; unsuitable: string[];
  useScores: Record<string, number>; newPrice: Price | null; usedPrice: Price | null;
  source: { label: string; url: string }; updatedAt: string; color: string; featured?: boolean;
  region?: string; aliases?: string[]; catalogRecordIds?: string[]; facts?: CatalogFacts; referenceId?: string; catalogNotes?: string[]; sourceUrls?: string[]; specificationStatus?: 'partial' | 'reviewed';
}
export const categories: { id: Category; name: string; subtitle: string }[] = [
  { id: 'phone', name: '手机', subtitle: '掌心里的每一天' },
  { id: 'tablet', name: '平板', subtitle: '学习与灵感，不设限' },
  { id: 'laptop', name: '笔记本电脑', subtitle: '认真工作，也尽情创造' },
];
export const uses: Record<Category, string[]> = {
  phone: ['游戏性能', '拍照摄影', '日常使用', '续航', 'AI和系统可玩性', '小屏手感'],
  tablet: ['学习笔记', '娱乐影音', '绘画', '轻办公'],
  laptop: ['日常办公', '编程开发', '游戏', '视频剪辑', '学习'],
};
// Public products contain only purchase quotes; launch/MSRP/estimates are separate display references.
const demoProducts: Product[] = [
  {
    id: 'iphone-15', brand: 'Apple', name: 'iPhone 15', category: 'phone', year: 2023,
    tagline: '轻巧日常，记录生活。', processor: 'Apple A16 仿生', ram: null, storage: 128,
    screen: '6.1 英寸 OLED · 2556 × 1179', screenSize: 6.1, battery: '官方视频播放最长 20 小时；实际依使用而异',
    camera: '4800 万像素主摄 + 1200 万超广角', weight: 171, os: 'iOS', configuration: '128GB · 标准版',
    pros: ['171g 机身便于日常携带', 'USB-C 接口便于共用线材', '主摄适合日常照片与视频'],
    cons: ['屏幕不支持高刷新率', '无独立长焦镜头', '存储容量无法扩展'],
    suitable: ['日常记录与社交', '偏好 iOS 的轻度用户'], unsuitable: ['追求高刷的游戏玩家', '需要大容量本地素材库的人'],
    useScores: { '游戏性能': 3, '拍照摄影': 4, '日常使用': 5, '续航': 3, 'AI和系统可玩性': 1, '小屏手感': 5 },
    newPrice: null, usedPrice: null, source: { label: 'Apple 官方技术规格', url: 'https://support.apple.com/zh-cn/111831' },
    updatedAt: '2026-10-16', color: 'blue', featured: true,
  },
  {
    id: 'xiaomi-14', brand: 'Xiaomi', name: 'Xiaomi 14', category: 'phone', year: 2023,
    tagline: '小尺寸，也有大想法。', processor: '骁龙 8 Gen 3', ram: 12, storage: 256,
    screen: '6.36 英寸 AMOLED · 1–120Hz', screenSize: 6.36, battery: '4610mAh · 90W 有线充电（官方标称）',
    camera: '5000 万像素主摄、超广角与长焦', weight: 193, os: 'Android', configuration: '12GB + 256GB · 玻璃版',
    pros: ['高刷新率屏幕', '拥有独立长焦镜头', '机身相对紧凑'], cons: ['玻璃版重量 193g', '长时间重负载仍需关注温度', '系统功能因地区与版本而异'],
    suitable: ['喜欢 Android 的日常用户', '兼顾拍照与游戏的人'], unsuitable: ['必须使用 iOS 应用的人', '偏好特别轻薄机身的人'],
    useScores: { '游戏性能': 5, '拍照摄影': 5, '日常使用': 5, '续航': 4, 'AI和系统可玩性': 4, '小屏手感': 4 },
    newPrice: null, usedPrice: null, source: { label: '小米官方规格（新加坡版，购买时核对地区版本）', url: 'https://www.mi.com/sg/product/xiaomi-14/specs/' },
    updatedAt: '2026-10-16', color: 'green',
  },
  {
    id: 'iphone-13', brand: 'Apple', name: 'iPhone 13', category: 'phone', year: 2021,
    tagline: '熟悉的体验，先看清成色。', processor: 'Apple A15 仿生', ram: null, storage: 128,
    screen: '6.1 英寸 OLED · 2532 × 1170', screenSize: 6.1, battery: '官方视频播放最长 19 小时；旧机依电池状况而异',
    camera: '1200 万像素双摄', weight: 173, os: 'iOS', configuration: '128GB · 标准版',
    pros: ['173g 机身', '支持 Face ID', '日常应用场景覆盖广'], cons: ['Lightning 接口', '机龄较长，需检查电池与维修史', '屏幕不支持高刷新率'],
    suitable: ['已有 Lightning 配件的人'], unsuitable: ['追求新功能的人', '无法判断二手成色的人'],
    useScores: { '游戏性能': 2, '拍照摄影': 3, '日常使用': 4, '续航': 2, 'AI和系统可玩性': 1, '小屏手感': 5 },
    newPrice: null, usedPrice: null, source: { label: 'Apple 官方技术规格', url: 'https://support.apple.com/zh-cn/111872' },
    updatedAt: '2026-10-16', color: 'pink',
  },
  {
    id: 'ipad-air-m2', brand: 'Apple', name: 'iPad Air 13″', category: 'tablet', year: 2024,
    tagline: '让笔记和灵感，都有余地。', processor: 'Apple M2', ram: null, storage: 128,
    screen: '13 英寸 IPS · 2732 × 2048', screenSize: 13, battery: '官方无线网络浏览最长 10 小时；依使用而异',
    camera: '1200 万像素后置摄像头', weight: 617, os: 'iPadOS', configuration: 'M2 · 128GB · Wi-Fi',
    pros: ['大屏适合分屏阅读', '支持 Apple Pencil Pro', 'M2 芯片适合绘画与轻创作'],
    cons: ['617g 不适合长时间单手握持', '手写笔与键盘需另购', '不能替代所有桌面软件'],
    suitable: ['需要分屏笔记的学生', '有大屏绘画需求的人'], unsuitable: ['主要单手阅读的人', '需要完整桌面开发环境的人'],
    useScores: { '学习笔记': 5, '娱乐影音': 4, '绘画': 5, '轻办公': 4 },
    newPrice: null, usedPrice: null, source: { label: 'Apple 官方技术规格', url: 'https://support.apple.com/zh-cn/119893' },
    updatedAt: '2026-10-16', color: 'purple', featured: true,
  },
  {
    id: 'xiaomi-pad-6', brand: 'Xiaomi', name: 'Xiaomi Pad 6', category: 'tablet', year: 2023,
    tagline: '从课堂，轻松切换到片场。', processor: '骁龙 870', ram: 8, storage: 128,
    screen: '11 英寸 LCD · 2880 × 1800 · 144Hz', screenSize: 11, battery: '8840mAh · 33W 充电（官方标称）',
    camera: '1300 万像素后置摄像头', weight: 490, os: 'Android', configuration: '8GB + 128GB · Wi-Fi',
    pros: ['高刷新率大屏', '适合影音与阅读', '支持第二代小米灵感触控笔'], cons: ['手写笔需另购', '骁龙 870 不适合追求最新性能的人', '需核对软件更新与应用适配'],
    suitable: ['影音为主、兼顾笔记的人'], unsuitable: ['依赖 iPad 专属绘画软件的人', '重度桌面办公用户'],
    useScores: { '学习笔记': 4, '娱乐影音': 5, '绘画': 3, '轻办公': 3 },
    newPrice: null, usedPrice: null, source: { label: '小米官方产品介绍与参数', url: 'https://www.mi.com/xiaomi-pad-6' },
    updatedAt: '2026-10-16', color: 'silver',
  },
  {
    id: 'macbook-air-m2', brand: 'Apple', name: 'MacBook Air 13″', category: 'laptop', year: 2022,
    tagline: '轻一点，走得更远。', processor: 'Apple M2 · 8 核 CPU / 8 核 GPU', ram: 16, storage: 256,
    screen: '13.6 英寸 IPS · 2560 × 1664', screenSize: 13.6, battery: '52.6Wh；官方无线上网最长 15 小时',
    camera: '1080p FaceTime 摄像头', weight: 1240, os: 'macOS', configuration: 'M2 · 16GB + 256GB',
    pros: ['1.24kg 适合随身携带', '无风扇设计运行安静', '16GB 内存适合多任务学习与办公'],
    cons: ['接口数量有限', '内存与存储无法自行升级', '持续高负载需考虑无风扇设计'],
    suitable: ['移动办公与学习', '轻量编程开发'], unsuitable: ['依赖 Windows 专属软件的人', '大型游戏与持续重渲染用户'],
    useScores: { '日常办公': 5, '编程开发': 4, '游戏': 1, '视频剪辑': 3, '学习': 5 },
    newPrice: null, usedPrice: null, source: { label: 'Apple 官方技术规格', url: 'https://support.apple.com/zh-cn/111867' },
    updatedAt: '2026-10-16', color: 'midnight', featured: true,
  },
  {
    id: 'macbook-pro-m3', brand: 'Apple', name: 'MacBook Pro 14″', category: 'laptop', year: 2023,
    tagline: '为更认真的创作，留出空间。', processor: 'Apple M3 · 8 核 CPU / 10 核 GPU', ram: 16, storage: 512,
    screen: '14.2 英寸 Liquid Retina XDR · 120Hz', screenSize: 14.2, battery: '70Wh；官方无线上网最长 15 小时',
    camera: '1080p FaceTime 摄像头', weight: 1550, os: 'macOS', configuration: 'M3 · 16GB + 512GB',
    pros: ['支持高刷新率 XDR 显示', 'HDMI 与 SDXC 接口便于创作', '主动散热适合较长时间工作'],
    cons: ['1.55kg 高于 Air', '内存与存储无法自行升级', '游戏与专业软件需先确认兼容性'],
    suitable: ['视频创作与开发', '需要额外接口的人'], unsuitable: ['只做轻度文档的人', '必须使用 Windows 软件的人'],
    useScores: { '日常办公': 5, '编程开发': 5, '游戏': 2, '视频剪辑': 5, '学习': 4 },
    newPrice: null, usedPrice: null, source: { label: 'Apple 官方技术规格', url: 'https://support.apple.com/zh-cn/117735' },
    updatedAt: '2026-10-16', color: 'silver',
  },
];
// The expanded reference library has no invented prices or unreviewed suitability scores.
const legacyProducts: Product[] = [
  ...demoProducts,
  ...phoneCatalog.filter(phone => !demoProducts.some(p => p.id === phone.id)).map(phone => ({
    ...phone, category: 'phone' as const,
    tagline: phone.year <= 2020 ? '经典设计，先看清机龄与兼容性。' : '了解真实配置，再决定是否适合。',
    battery: '尚未单独整理，请查看下方品牌官方规格。',
    camera: '尚未单独整理，请查看下方品牌官方规格。',
    pros: [
      phone.weight <= 180 ? `${phone.weight}g 机身，相对便于携带` : `${phone.screenSize} 英寸屏幕，先确认是否适合你的手感`,
      /120Hz/.test(phone.screen) ? '官方规格支持最高 120Hz 刷新率' : `${phone.storage}GB 示例配置，便于核算容量需求`,
    ],
    cons: [
      phone.year <= 2020 ? '机龄较长，电池、维修记录与应用兼容性须逐项核实' : '不同地区、颜色与容量版本可能存在配置差异',
      '暂无可靠报价，当前不能确认预算匹配',
      '标称参数不能替代长时间性能与续航的实际测试',
    ],
    suitable: ['希望核对这一具体型号与配置的用户'],
    unsuitable: ['需要已核实现价或完整实测结论后立即下单的人'],
    useScores: {}, color: phone.os === 'iOS' ? 'blue' : 'green',
  })),
];
export const products: Product[] = expandProducts(legacyProducts);
export function getProduct(id: string) { return products.find(p => p.id === id); }
export const categoryName = (id: Category) => categories.find(c => c.id === id)!.name;
