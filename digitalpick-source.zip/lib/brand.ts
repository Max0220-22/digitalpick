export const BRAND_NAME = '未域 ELVORA';
export const HERO_OPENING = '世界很大，适合你的很小。';
export const BRAND_STORY = '未域相信，每个人都值得一台“刚好适合”的设备，而不是一台“别人说好”的设备。';
export const ENGLISH_SLOGAN = 'Not the priciest. Just the right one.';
