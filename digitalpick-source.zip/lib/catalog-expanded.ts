import tablets from '../data/catalog-expansion/tablets.json';
import phones from '../data/catalog-expansion/apple-samsung-phones.json';
import chinaPhones from '../data/catalog-expansion/china-phones.json';
import laptops from '../data/catalog-expansion/laptops.json';
import requestedModels from '../data/catalog-expansion/requested-models.json';
import priorReferences from './library/reviewed-additions.json';
import type { Category, Product } from './products';
import type { FactKey } from './library/types';
export type CatalogFacts = Partial<Record<FactKey,string | null>>;
export interface CatalogRecord {
 id:string; brand:string; name:string; category:Category; year:number|null; region:string;
 sourceUrl:string; sourceLabel:string; sourceUrls?:string[]; aliases:string[]; requestedNames:string[];
 facts:CatalogFacts; notes:string[]; referenceId?:string; updatedAt?:string;
}
export interface CoverageEntry { requestedName:string; status:'verified'|'corrected'|'unconfirmed'; recordIds:string[]; sourceUrls:string[]; note:string }
const additions = [tablets,phones,chinaPhones,laptops] as unknown as {records:CatalogRecord[];coverage:CoverageEntry[]}[];
export const rawCatalogCoverage = additions.flatMap(d=>d.coverage);
function requestedKey(brand:string,name:string,category:string) {
 let text=normalizeCatalogQuery(name);
 if(category!=='laptop')text=text.replace(/20\d\d/g,'');
  const prefixes=brand.includes('苹果')?['apple']:brand.includes('华为')?['huawei']:brand.includes('三星')?['samsung','galaxy']:brand.includes('小米')?['xiaomi']:brand.includes('一加')?['oneplus']:brand.includes('红魔')?['redmagic']:brand.toLowerCase()==='vivo'?['vivo']:brand==='iQOO'?['iqoo']:[normalizeCatalogQuery(brand)];
 for(const prefix of prefixes)if(text.startsWith(prefix))text=text.slice(prefix.length);
 return text;
}
// Normalize each source name once per scope, rather than during every requested-row search.
const coverageLookup=new Map<string,CoverageEntry>();
for(const scope of [...new Set(requestedModels.map(row=>row.brand+'|'+row.category))]) {
 const [brand,category]=scope.split('|');
 for(const entry of rawCatalogCoverage) {
  const key=scope+'|'+requestedKey(brand,entry.requestedName,category);
  if(!coverageLookup.has(key))coverageLookup.set(key,entry);
 }
}
const coverageEntryFor=(row:{brand:string;category:string;requestedName:string})=>coverageLookup.get(row.brand+'|'+row.category+'|'+requestedKey(row.brand,row.requestedName,row.category));
export const catalogCoverage = requestedModels.map(row=>{
 const entry=coverageEntryFor(row);
 return {...(entry||{status:'unconfirmed' as const,recordIds:[],sourceUrls:[],note:'本次尚未完成这一原文条目的对应核验；不生成已发布产品参数。'}),requestedName:row.requestedName,brand:row.brand,category:row.category};
});
export const unmatchedCoverage = requestedModels.filter(row=>!coverageEntryFor(row));
export const expansionRecords:CatalogRecord[] = additions.flatMap(d=>d.records);
const prior:CatalogRecord[] = priorReferences.map(d=>({ ...d, category:d.category as Category, sourceLabel:'品牌官方资料（版本见来源）', requestedNames:[], referenceId:d.id, facts:d.facts as CatalogFacts }));
export const brandLabels:Record<string,string>={Apple:'苹果 Apple',HUAWEI:'华为 HUAWEI',Samsung:'三星 Samsung',Xiaomi:'小米 Xiaomi',Redmi:'REDMI 红米',OnePlus:'一加 OnePlus',iQOO:'iQOO 爱酷',RedMagic:'红魔 REDMAGIC',OPPO:'OPPO',vivo:'vivo',HONOR:'荣耀 HONOR'};
export function normalizeCatalogQuery(text:string) {
 return text.normalize('NFKC').toLowerCase().replace(/苹果/g,'apple').replace(/华为/g,'huawei').replace(/三星/g,'samsung').replace(/小米平板/g,'xiaomipad').replace(/小米/g,'xiaomi').replace(/红米/g,'redmi').replace(/一加/g,'oneplus').replace(/红魔/g,'redmagic').replace(/爱酷/g,'iqoo').replace(/英寸|inch/g,'').replace(/[^a-z0-9\u4e00-\u9fff+]/g,'');
}
function identity(brand:string,name:string) {
 let normalized=normalizeCatalogQuery(name),b=normalizeCatalogQuery(brand);
 if(normalized.startsWith(b))normalized=normalized.slice(b.length);
 return b+':'+normalized;
}
function numeric(text:string|undefined|null,kind:'weight'|'screen'|'storage'|'ram') {
 if(!text)return null;
 // Store a numeric hard-constraint only for a single explicit configuration, never an option range.
 if(kind==='weight') { const m=text.match(/^\s*(?:约|大约|approximately)?\s*(\d+(?:\.\d+)?)\s*(kg|千克|g|克)(?:\s*[（(].*)?$/i);return m?Number(m[1])*(/kg|千克/i.test(m[2])?1000:1):null; }
 if(kind==='screen') { const m=text.match(/^\s*(\d+(?:\.\d+)?)\s*(?:英寸|inch|″|")/i);return m?Number(m[1]):null; }
 if(kind==='storage'||kind==='ram') { const m=text.match(/^\s*(\d+)\s*(GB|TB|G|T)(?:\s*(?:统一内存|内存|存储|SSD))?\s*$/i);return m?Number(m[1])*(/^T/i.test(m[2])?1024:1):null; }
 return null;
}
function asProduct(d:CatalogRecord):Product {
 const f=d.facts;
 const brand=({apple:'Apple',huawei:'HUAWEI',samsung:'Samsung',xiaomi:'Xiaomi',redmi:'Xiaomi',oppo:'OPPO',vivo:'vivo',oneplus:'OnePlus',iqoo:'iQOO',redmagic:'RedMagic'} as Record<string,string>)[d.brand.toLowerCase()]||d.brand;
 const facts=Object.fromEntries(Object.entries(f).filter(([,v])=>typeof v==='string'&&v.trim())) as CatalogFacts;
 const unknown='尚未整理，请核对下方品牌官方资料。';
 const strengths=[f.processor?`处理器：${f.processor}`:null,f.display?`屏幕：${f.display}`:null,f.stylus?`手写笔：${f.stylus}`:null].filter((v):v is string=>!!v).slice(0,3);
 return {id:d.id,brand,name:d.name,category:d.category,year:d.year,tagline:'按具体代际与地区，查清配置再选择。',processor:f.processor||unknown,ram:numeric(f.ram,'ram'),storage:numeric(f.storage,'storage'),screen:f.display||unknown,screenSize:numeric(f.display,'screen'),battery:f.battery||unknown,camera:f.rearCamera||f.frontCamera||unknown,weight:numeric(f.weight,'weight'),os:f.os||'尚未整理',configuration:f.configuration||'容量、内存与版本以官方配置列表为准',pros:strengths.length?strengths:['已找到这一正式型号的官方资料，可继续核对具体配置'],cons:['暂无可靠报价，不能据此确认预算匹配','未整理的参数保持为空，不套用相邻型号或地区配置','标称参数不能代替实际续航、游戏或软件兼容测试'],suitable:['正在核对这一正式型号、代际与地区配置的用户'],unsuitable:['需要完整实测与当前成交价格后立即下单的用户'],useScores:{},newPrice:null,usedPrice:null,source:{label:d.sourceLabel,url:d.sourceUrl},updatedAt:d.updatedAt||'2026-10-17',color:d.category==='tablet'?'purple':d.category==='laptop'?'silver':'blue',region:d.region,aliases:[...new Set([...d.aliases,...d.requestedNames])],catalogRecordIds:[d.id],facts,catalogNotes:d.notes,sourceUrls:[...new Set([d.sourceUrl,...(d.sourceUrls||[])])],referenceId:d.referenceId,specificationStatus:'partial'};
}
export function expandProducts(base:Product[]) {
 const result=base.map(p=>({...p}));
 for(const d of [...prior,...expansionRecords]) {
  const p=asProduct(d);
  const regionKey=(value:string)=>{const region=value.split(/[，；;。]/)[0];return /印度/.test(region)?'in':/美国|美版/.test(region)?'us':/中国大陆|国行/.test(region)?'cn':/加拿大/.test(region)?'ca':/菲律宾/.test(region)?'ph':/新加坡/.test(region)?'sg':region;};
  const compatible=(v:Product)=>v.brand==='Apple'||(v.region?regionKey(v.region)===regionKey(p.region||''):!/(?:美国|美版|加拿大|印度|菲律宾|拉脱维亚|国际|全球|新加坡)/.test(p.region||''));
  const oldRoute= d.id==='catalog-ipad-air-13-m2'?'ipad-air-m2':d.id==='macbook-pro-14-m3'?'macbook-pro-m3':null;
  const existing=result.findIndex(v=>(v.id===p.id||v.id===oldRoute||identity(v.brand,v.name)===identity(p.brand,p.name))&&compatible(v));
  if(existing<0&&result.some(v=>v.id===p.id))p.id=p.id+'-catalog';
  if(existing<0){result.push(p);continue;}
  const old=result[existing];
  // Preserve existing priced/editorial fixtures and stable public routes; enrich only sourced fields.
  const facts={...old.facts,...p.facts};
  result[existing]={...old,name:p.name,source:p.source,region:p.region,catalogRecordIds:[...new Set([...(old.catalogRecordIds||[]),...(p.catalogRecordIds||[])])],aliases:[...new Set([...(old.aliases||[]),p.name,...(p.aliases||[])])],facts,catalogNotes:[...new Set([...(old.catalogNotes||[]),...(p.catalogNotes||[])])],sourceUrls:[...new Set([old.source.url,...(old.sourceUrls||[]),...(p.sourceUrls||[])])],processor:facts.processor||old.processor,screen:facts.display||old.screen,battery:facts.battery||old.battery,camera:facts.rearCamera||old.camera,updatedAt:old.updatedAt>p.updatedAt?old.updatedAt:p.updatedAt,referenceId:old.referenceId||p.referenceId};
 }
 return result;
}
