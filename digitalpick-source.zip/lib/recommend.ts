import { products, uses as categoryUses, type Category, type PurchaseMode, type Product, type Price } from './products';
import { eligiblePrices } from './prices';
import { planningOffers, type PriceEvidence } from './recommendation-prices';
export type PurchasePriority = 'balanced' | 'peace-of-mind' | 'price';
export interface Preferences {
  category: Category; maxBudget: number; mode: PurchaseMode; uses: string[]; primaryUse?: string;
  brand: string; os: string; storage: number; maxWeight: number | null; maxScreen: number | null;
  reserveBudget?: number; purchasePriority?: PurchasePriority;
}
export const recommendationPolicy = { version: '2.1', minimumUseGrade: 3, primaryUseWeight: .6, weights: { use: 60, budget: 20, purchase: 10, brand: 5, configuration: 5 } } as const;
export interface OfferAssessment { mode: 'new' | 'used'; price: Price; evidence?: PriceEvidence; totalCeiling: number; budgetScore: number; purchaseScore: number; score: number }
export interface Recommendation {
  product: Product; score: number; breakdown: { label: string; score: number; max: number; reason: string }[];
  offer: OfferAssessment; offers: OfferAssessment[];
  useAssessments: { use: string; grade: number; primary: boolean; basis: string }[]; cautions: string[];
}
export interface BudgetContext { stage: 'original' | 'relaxed' | 'closest'; original: number; relaxedLimit: number; message: string }
export interface RecommendationAudit { budgetContext?: BudgetContext; recommendations: Recommendation[]; exclusions: { productId: string; code: string; reason: string }[]; inputError: string | null }
export interface RecommendationOptions { pricePolicy?: 'demo-or-verified' | 'verified-only' | 'reference-guidance' }
function inputError(p: Preferences) {
  if (!p || !['phone', 'tablet', 'laptop'].includes(p.category) || !['new', 'used', 'either'].includes(p.mode)) return '请选择有效的设备类型和购买方式。';
  if (!Number.isInteger(p.maxBudget) || p.maxBudget <= 0 || p.maxBudget > 100000) return '预算须为1–100,000元的整数。';
  if (!Number.isInteger(p.reserveBudget ?? 0) || (p.reserveBudget ?? 0) < 0 || (p.reserveBudget ?? 0) >= p.maxBudget) return '预留费用须为小于总预算的非负整数。';
  if (!Array.isArray(p.uses) || !p.uses.length || p.uses.some(use => !categoryUses[p.category].includes(use))) return '请确认至少一个有效的主要用途。';
  if (p.primaryUse && !p.uses.includes(p.primaryUse)) return '主用途必须包含在已选用途中。';
  if (!Number.isFinite(p.storage) || p.storage < 0 || !Number.isInteger(p.storage) || [p.maxWeight, p.maxScreen].some(value => value !== null && (!Number.isFinite(value) || value <= 0))) return '配置限制无效，请重新确认。';
  if (p.purchasePriority && !['balanced', 'peace-of-mind', 'price'].includes(p.purchasePriority)) return '购买取舍无效，请重新确认。';
  return null;
}
/** Review-inspired editorial policy, never a reviewer ranking or a popularity score. */
function analyzeAtBudget(preferences: Preferences, dataset: Product[], now: Date, options: RecommendationOptions, budgetLimit: number, closest = false): RecommendationAudit {
  const error = inputError(preferences);
  if (error) return { recommendations: [], exclusions: [], inputError: error };
  const selectedUses = [...new Set(preferences.uses)], primaryUse = preferences.primaryUse || selectedUses[0];
  const reserve = preferences.reserveBudget ?? 0, priority = preferences.purchasePriority ?? 'balanced';
  const exclusions: RecommendationAudit['exclusions'] = [];
  const excluded = (p: Product, code: string, reason: string): [] => { exclusions.push({ productId: p.id, code, reason }); return []; };
  const candidates = dataset.flatMap((product): Recommendation[] => {
    if (product.category !== preferences.category) return [];
    const configurationIssues = [
      ...(preferences.os && product.os !== preferences.os ? [`系统为${product.os}，需要${preferences.os}`] : []),
      ...(preferences.storage > 0 && (product.storage === null || product.storage < preferences.storage) ? [`存储${product.storage === null ? '尚未核实' : `${product.storage}GB`}，需要至少${preferences.storage}GB`] : []),
      ...(preferences.maxWeight !== null && (product.weight === null || product.weight > preferences.maxWeight) ? [`重量${product.weight === null ? '尚未核实' : `${product.weight}g`}，上限${preferences.maxWeight}g`] : []),
      ...(preferences.maxScreen !== null && (product.screenSize === null || product.screenSize > preferences.maxScreen) ? [`屏幕${product.screenSize === null ? '尚未核实' : `${product.screenSize}英寸`}，上限${preferences.maxScreen}英寸`] : []),
    ];
    if (configurationIssues.length) return excluded(product, 'configuration', configurationIssues.join('；') + '。');
    if (selectedUses.includes('AI和系统可玩性')) return excluded(product, 'capability-unverified', 'AI与Root能力尚缺逐型号、地区和版本的核验，不能用旧编辑等级或未来承诺替代。');
    const useAssessments = selectedUses.map(use => ({ use, grade: product.useScores[use], primary: use === primaryUse, basis: '本站编辑适配等级；基于资料库特性，非实测跑分、博主评分或用户评价。' }));
    const missing = useAssessments.filter(a => !Number.isFinite(a.grade) || a.grade < 0 || a.grade > 5);
    if (missing.length) return excluded(product, 'use-unverified', `尚未整理“${missing.map(a => a.use).join('、')}”的适配依据，不将未知当作通过。`);
    const weak = useAssessments.filter(a => a.grade < recommendationPolicy.minimumUseGrade);
    if (weak.length) return excluded(product, 'use-shortfall', `${weak.map(a => `“${a.use}”为${a.grade}/5`).join('；')}，低于3/5适配门槛，其他高分不能补偿。`);
    const guidance = options.pricePolicy === 'reference-guidance';
    const available = guidance ? planningOffers(product, preferences.mode, preferences.storage, now) : eligiblePrices(product, preferences.mode, Number.MAX_SAFE_INTEGER, now).filter(o => options.pricePolicy !== 'verified-only' || !o.price.demo);
    const eligible = available.filter(offer => offer.price.max + reserve <= budgetLimit);
    if (!eligible.length) {
      if (available.length) {
        const cheapest = Math.min(...available.map(offer => offer.price.max + reserve));
        return excluded(product, 'budget', `最低可用方案按区间上限加预留为¥${cheapest.toLocaleString('zh-CN')}，超过本轮预算上限¥${budgetLimit.toLocaleString('zh-CN')}，差额¥${(cheapest - budgetLimit).toLocaleString('zh-CN')}。${guidance ? '参考价不代表可成交价格。' : ''}`);
      }
      return excluded(product, 'price', guidance ? `所选${preferences.mode === 'new' ? '全新' : preferences.mode === 'used' ? '二手' : '全新或二手'}方式缺少有效报价或有来源、符合所需存储配置的参考价格；不套用其他型号、地区或未知价格。` : '没有符合购买方式与有效日期的报价；正式推荐还须为非演示报价。');
    }
    const primary = useAssessments.find(a => a.primary)!;
    const other = useAssessments.filter(a => !a.primary);
    const weightedGrade = other.length ? primary.grade * .6 + other.reduce((sum, a) => sum + a.grade, 0) / other.length * .4 : primary.grade;
    const useScore = Math.round(weightedGrade / 5 * 60);
    const brandScore = !preferences.brand || preferences.brand === product.brand ? 5 : 0;
    const fixedScore = useScore + brandScore + 5;
    const offers: OfferAssessment[] = eligible.map(offer => {
      const totalCeiling = offer.price.max + reserve;
      const budgetScore = Math.max(0, Math.min(20, Math.round(20 * (1 - totalCeiling / preferences.maxBudget * .5))));
      const purchaseScore = offer.mode === 'new' || priority === 'price' ? 10 : priority === 'peace-of-mind' ? 2 : 6;
      return { ...offer, totalCeiling, budgetScore, purchaseScore, score: fixedScore + budgetScore + purchaseScore };
    }).sort((a, b) => (closest ? a.totalCeiling - b.totalCeiling : 0) || b.score - a.score || (a.mode === b.mode ? 0 : a.mode === 'new' ? -1 : 1) || a.totalCeiling - b.totalCeiling);
    const offer = offers[0];
    const breakdown = [
      { label: '用途匹配', score: useScore, max: 60, reason: `每项均须达到3/5；${primaryUse}为主用途${other.length ? '，占用途权重60%，其余合计40%' : ''}。等级来自本站编辑规则，不是MKBHD评分。` },
      { label: '总预算余量', score: offer.budgetScore, max: 20, reason: `按${offer.evidence?.estimated ? '参考价格或估算区间上限' : '报价上限'}加用户预留${reserve}元核算；${offer.totalCeiling > preferences.maxBudget ? `超过原预算¥${offer.totalCeiling - preferences.maxBudget}，不视为原预算内推荐。` : offer.evidence?.estimated ? '未超过原预算，但参考价格不代表可购买报价。' : '有效报价已通过本轮预算门槛，购买前仍须重新核实。'}` },
      { label: '购买取舍', score: offer.purchaseScore, max: 10, reason: `本站公开策略：全新10分；二手在省心/均衡/低价倾向下为2/6/10分。当前${priority === 'peace-of-mind' ? '更重省心' : priority === 'price' ? '更重低价' : '均衡考虑'}，仍需核实来源、保修与成色。` },
      { label: '品牌偏好', score: brandScore, max: 5, reason: preferences.brand ? `品牌软偏好：${preferences.brand}，不突破任何硬限制。` : '未指定品牌，保持中立。' },
      { label: '配置要求', score: 5, max: 5, reason: '系统、存储、重量和屏幕的硬条件已通过。屏幕对角线不能代替机身宽度与握持体验。' },
    ];
    const cautions = [
      '适配等级是本站编辑判断，不等于在你的地区、版本和使用场景下完成实测。',
      ...(offer.evidence?.estimated ? ['基于估算价：仅作预算规划，购买前核实同配置的实际报价与库存。', offer.evidence.note] : []),
      ...(offer.totalCeiling > preferences.maxBudget ? [`按当前核算，此机比原预算高¥${offer.totalCeiling - preferences.maxBudget}，请先决定是否调整预算，不建议直接下单。`] : []),
      ...(offer.mode === 'used' ? ['二手成色、电池健康、维修史与剩余保修须逐台核验；预留金额不代表维修报价。'] : ['全新也须核对销售主体、配置、激活时间与实际售后。']),
      ...(selectedUses.includes('续航') ? ['续航受网络、信号、系统版本、应用负载和电池状态影响，不等同于不同条件下的屏幕亮起时长。'] : []),
      ...(selectedUses.includes('拍照摄影') ? ['请进一步区分静态照片、视频、人像、夜景与长焦；单次照片盲测不能代表完整相机体验。'] : []),
      ...(selectedUses.includes('AI和系统可玩性') ? ['AI与刷机能力需分别核验具体型号、地区、语言和已交付版本；未来功能承诺不加分。'] : []),
    ];
    return [{ product, offer, offers, useAssessments, cautions, breakdown, score: offer.score }];
  });
  const ranked = candidates.sort((a, b) => (closest ? a.offer.totalCeiling - b.offer.totalCeiling : 0) || b.score - a.score || a.offer.totalCeiling - b.offer.totalCeiling || a.product.id.localeCompare(b.product.id));
  for (const candidate of ranked.slice(3)) exclusions.push({ productId: candidate.product.id, code: 'ranking', reason: `已满足本轮筛选条件，但${closest ? '按预算差额优先排序' : `按用途与取舍排序（${candidate.score}/100分）`}未进入前三；不代表设备质量不合格。` });
  return { recommendations: ranked.slice(0, 3), exclusions, inputError: null };
}
/** The questionnaire opts into reference planning. Verified AI candidates retain the strict quote policy. */
export function analyzeRecommendations(preferences: Preferences, dataset = products, now = new Date(), options: RecommendationOptions = {}): RecommendationAudit {
  const original = analyzeAtBudget(preferences, dataset, now, options, preferences?.maxBudget);
  if (options.pricePolicy !== 'reference-guidance' || original.inputError) return original;
  const relaxedLimit = Math.floor(preferences.maxBudget * 1.2);
  if (original.recommendations.length) return { ...original, budgetContext: { stage: 'original', original: preferences.maxBudget, relaxedLimit, message: '按原预算筛选；缺少有效报价的方案基于参考价或估算价，购买前必须核价。' } };
  const relaxed = analyzeAtBudget(preferences, dataset, now, options, relaxedLimit);
  if (relaxed.recommendations.length) return { ...relaxed, budgetContext: { stage: 'relaxed', original: preferences.maxBudget, relaxedLimit, message: `已放宽预算条件：原预算¥${preferences.maxBudget.toLocaleString('zh-CN')} → ¥${relaxedLimit.toLocaleString('zh-CN')}（增加20%），其余硬条件保持。` } };
  const nearest = analyzeAtBudget(preferences, dataset, now, options, Number.MAX_SAFE_INTEGER, true);
  return { ...nearest, budgetContext: { stage: 'closest', original: preferences.maxBudget, relaxedLimit, message: nearest.recommendations.length ? `已放宽预算条件：尝试增加20%至¥${relaxedLimit.toLocaleString('zh-CN')}后仍无匹配。以下是预算差额最小的备选，仍超预算，仅供提高预算前参考，不属于预算内可购买推荐。` : `原预算及放宽20%至¥${relaxedLimit.toLocaleString('zh-CN')}后仍无可展示的备选；其余硬条件、用途或价格资料存在缺口，未进一步放宽。` } };
}
export function recommend(preferences: Preferences, dataset = products, now = new Date(), options: RecommendationOptions = {}): Recommendation[] { return analyzeRecommendations(preferences, dataset, now, options).recommendations; }
export const budgets = [ { label: '1000 元以下', max: 999 }, { label: '1000–2000 元', max: 2000 }, { label: '2000–3000 元', max: 3000 }, { label: '3000–5000 元', max: 5000 }, { label: '5000–8000 元', max: 8000 }, { label: '8000 元以上', max: 10000 } ];
/** Carry every confirmed condition into the reviewable questionnaire, without silently relaxing it. */
export function preferenceHref(p: Preferences) {
  const query = new URLSearchParams({ category: p.category, budget: String(p.maxBudget), mode: p.mode });
  if (p.os) query.set('os', p.os);
  if (p.brand) query.set('brand', p.brand);
  query.set('reserve', String(p.reserveBudget ?? 0));
  query.set('purchasePriority', p.purchasePriority || 'balanced');
  for (const use of [...new Set(p.uses)]) query.append('use', use);
  if (p.primaryUse) query.set('primaryUse', p.primaryUse);
  if (p.storage) query.set('storage', String(p.storage));
  if (p.maxWeight !== null) query.set('maxWeight', String(p.maxWeight));
  if (p.maxScreen !== null) query.set('maxScreen', String(p.maxScreen));
  return `/recommend/?${query}`;
}
