import { products, uses as categoryUses, type Category, type PurchaseMode, type Product, type Price } from './products';
import { eligiblePrices } from './prices';
export type PurchasePriority = 'balanced' | 'peace-of-mind' | 'price';
export interface Preferences {
  category: Category; maxBudget: number; mode: PurchaseMode; uses: string[]; primaryUse?: string;
  brand: string; os: string; storage: number; maxWeight: number | null; maxScreen: number | null;
  reserveBudget?: number; purchasePriority?: PurchasePriority;
}
export const recommendationPolicy = { version: '2.0', minimumUseGrade: 3, primaryUseWeight: .6, weights: { use: 60, budget: 20, purchase: 10, brand: 5, configuration: 5 } } as const;
export interface OfferAssessment { mode: 'new' | 'used'; price: Price; totalCeiling: number; budgetScore: number; purchaseScore: number; score: number }
export interface Recommendation {
  product: Product; score: number; breakdown: { label: string; score: number; max: number; reason: string }[];
  offer: OfferAssessment; offers: OfferAssessment[];
  useAssessments: { use: string; grade: number; primary: boolean; basis: string }[]; cautions: string[];
}
export interface RecommendationAudit { recommendations: Recommendation[]; exclusions: { productId: string; code: string; reason: string }[]; inputError: string | null }
export interface RecommendationOptions { pricePolicy?: 'demo-or-verified' | 'verified-only' }
function inputError(p: Preferences) {
  if (!p || !['phone', 'tablet', 'laptop'].includes(p.category) || !['new', 'used', 'either'].includes(p.mode)) return '请选择有效的设备类型和购买方式。';
  if (!Number.isInteger(p.maxBudget) || p.maxBudget <= 0 || p.maxBudget > 100000) return '预算须为1–100,000元的整数。';
  if (!Number.isInteger(p.reserveBudget ?? 0) || (p.reserveBudget ?? 0) < 0 || (p.reserveBudget ?? 0) >= p.maxBudget) return '预留费用须为小于总预算的非负整数。';
  if (!Array.isArray(p.uses) || !p.uses.length || p.uses.some(use => !categoryUses[p.category].includes(use))) return '请确认至少一个有效的主要用途。';
  if (p.primaryUse && !p.uses.includes(p.primaryUse)) return '主用途必须包含在已选用途中。';
  if (!Number.isFinite(p.storage) || p.storage < 0 || !Number.isInteger(p.storage) || [p.maxWeight, p.maxScreen].some(value => value !== null && (!Number.isFinite(value) || value <= 0))) return '配置限制无效，请重新确认。';
  if (p.purchasePriority && !['balanced', 'peace-of-mind', 'price'].includes(p.purchasePriority)) return '购买取舍无效，请重新确认。';
  return null;
}
/** Review-inspired editorial policy, never a reviewer ranking or a popularity score. */
export function analyzeRecommendations(preferences: Preferences, dataset = products, now = new Date(), options: RecommendationOptions = {}): RecommendationAudit {
  const error = inputError(preferences);
  if (error) return { recommendations: [], exclusions: [], inputError: error };
  const selectedUses = [...new Set(preferences.uses)], primaryUse = preferences.primaryUse || selectedUses[0];
  const reserve = preferences.reserveBudget ?? 0, priority = preferences.purchasePriority ?? 'balanced';
  const exclusions: RecommendationAudit['exclusions'] = [];
  const excluded = (p: Product, code: string, reason: string): [] => { exclusions.push({ productId: p.id, code, reason }); return []; };
  const candidates = dataset.flatMap((product): Recommendation[] => {
    if (product.category !== preferences.category) return [];
    if ((preferences.storage > 0 && (product.storage === null || product.storage < preferences.storage)) || (preferences.os && product.os !== preferences.os) || (preferences.maxWeight !== null && (product.weight === null || product.weight > preferences.maxWeight)) || (preferences.maxScreen !== null && (product.screenSize === null || product.screenSize > preferences.maxScreen))) return excluded(product, 'configuration', '不满足系统、容量、重量或屏幕的硬性限制。');
    if (selectedUses.includes('AI和系统可玩性')) return excluded(product, 'capability-unverified', 'AI与Root能力尚缺逐型号、地区和版本的核验，不能用旧编辑等级或未来承诺替代。');
    const useAssessments = selectedUses.map(use => ({ use, grade: product.useScores[use], primary: use === primaryUse, basis: '本站编辑适配等级；基于资料库特性，非实测跑分、博主评分或用户评价。' }));
    const missing = useAssessments.filter(a => !Number.isFinite(a.grade) || a.grade < 0 || a.grade > 5);
    if (missing.length) return excluded(product, 'use-unverified', `尚未整理“${missing.map(a => a.use).join('、')}”的适配依据，不将未知当作通过。`);
    const weak = useAssessments.filter(a => a.grade < recommendationPolicy.minimumUseGrade);
    if (weak.length) return excluded(product, 'use-shortfall', `“${weak.map(a => a.use).join('、')}”低于3/5适配门槛，其他高分不能补偿。`);
    const eligible = eligiblePrices(product, preferences.mode, preferences.maxBudget - reserve, now).filter(o => options.pricePolicy !== 'verified-only' || !o.price.demo);
    if (!eligible.length) return excluded(product, 'price', '没有符合购买方式、有效日期与总预算（含预留）的报价；正式推荐还须为非演示报价。');
    const primary = useAssessments.find(a => a.primary)!;
    const other = useAssessments.filter(a => !a.primary);
    const weightedGrade = other.length ? primary.grade * .6 + other.reduce((sum, a) => sum + a.grade, 0) / other.length * .4 : primary.grade;
    const useScore = Math.round(weightedGrade / 5 * 60);
    const brandScore = !preferences.brand || preferences.brand === product.brand ? 5 : 0;
    const fixedScore = useScore + brandScore + 5;
    const offers: OfferAssessment[] = eligible.map(offer => {
      const totalCeiling = offer.price.max + reserve;
      const budgetScore = Math.round(20 * (1 - totalCeiling / preferences.maxBudget * .5));
      const purchaseScore = offer.mode === 'new' || priority === 'price' ? 10 : priority === 'peace-of-mind' ? 2 : 6;
      return { ...offer, totalCeiling, budgetScore, purchaseScore, score: fixedScore + budgetScore + purchaseScore };
    }).sort((a, b) => b.score - a.score || (a.mode === b.mode ? 0 : a.mode === 'new' ? -1 : 1) || a.totalCeiling - b.totalCeiling);
    const offer = offers[0];
    const breakdown = [
      { label: '用途匹配', score: useScore, max: 60, reason: `每项均须达到3/5；${primaryUse}为主用途${other.length ? '，占用途权重60%，其余合计40%' : ''}。等级来自本站编辑规则，不是MKBHD评分。` },
      { label: '总预算余量', score: offer.budgetScore, max: 20, reason: `按报价上限加用户预留${reserve}元审核；不估算未知维修费或配件价格。` },
      { label: '购买取舍', score: offer.purchaseScore, max: 10, reason: `本站公开策略：全新10分；二手在省心/均衡/低价倾向下为2/6/10分。当前${priority === 'peace-of-mind' ? '更重省心' : priority === 'price' ? '更重低价' : '均衡考虑'}，仍需核实来源、保修与成色。` },
      { label: '品牌偏好', score: brandScore, max: 5, reason: preferences.brand ? `品牌软偏好：${preferences.brand}，不突破任何硬限制。` : '未指定品牌，保持中立。' },
      { label: '配置要求', score: 5, max: 5, reason: '系统、存储、重量和屏幕的硬条件已通过。屏幕对角线不能代替机身宽度与握持体验。' },
    ];
    const cautions = [
      '适配等级是本站编辑判断，尚不等于在你的地区、版本和使用场景下完成实测。',
      ...(offer.mode === 'used' ? ['二手成色、电池健康、维修史与剩余保修须逐台核验；预留金额不代表维修报价。'] : ['全新也须核对销售主体、配置、激活时间与实际售后。']),
      ...(selectedUses.includes('续航') ? ['续航应核对网络、信号、系统版本、应用负载和电池状态，不混算不同条件的亮屏时长。'] : []),
      ...(selectedUses.includes('拍照摄影') ? ['请进一步区分静态照片、视频、人像、夜景与长焦；单次照片盲测不能代表完整相机体验。'] : []),
      ...(selectedUses.includes('AI和系统可玩性') ? ['AI与刷机能力需分别核验具体型号、地区、语言和已交付版本；未来功能承诺不加分。'] : []),
    ];
    return [{ product, offer, offers, useAssessments, cautions, breakdown, score: offer.score }];
  });
  return { recommendations: candidates.sort((a, b) => b.score - a.score || a.offer.totalCeiling - b.offer.totalCeiling || a.product.id.localeCompare(b.product.id)).slice(0, 3), exclusions, inputError: null };
}
export function recommend(preferences: Preferences, dataset = products, now = new Date(), options: RecommendationOptions = {}): Recommendation[] { return analyzeRecommendations(preferences, dataset, now, options).recommendations; }
export const budgets = [ { label: '1000 元以下', max: 999 }, { label: '1000–2000 元', max: 2000 }, { label: '2000–3000 元', max: 3000 }, { label: '3000–5000 元', max: 5000 }, { label: '5000–8000 元', max: 8000 }, { label: '8000 元以上', max: 10000 } ];
/** Carry every confirmed condition into the reviewable questionnaire, without silently relaxing it. */
export function preferenceHref(p: Preferences) {
  const query = new URLSearchParams({ category: p.category, budget: String(p.maxBudget), mode: p.mode });
  if (p.os) query.set('os', p.os);
  if (p.brand) query.set('brand', p.brand);
  query.set('reserve', String(p.reserveBudget ?? 0));
  query.set('purchasePriority', p.purchasePriority || 'balanced');
  for (const use of [...new Set(p.uses)]) query.append('use', use);
  if (p.primaryUse) query.set('primaryUse', p.primaryUse);
  if (p.storage) query.set('storage', String(p.storage));
  if (p.maxWeight !== null) query.set('maxWeight', String(p.maxWeight));
  if (p.maxScreen !== null) query.set('maxScreen', String(p.maxScreen));
  return `/recommend/?${query}`;
}
