export const WISHLIST_KEY = 'dp-wishlist-v1';
export const WISHLIST_LIMIT = 200;
export interface WishlistSnapshot { ids: readonly string[]; ready: boolean; error: boolean }
export interface WishlistStorage { getItem(key: string): string | null; setItem(key: string, value: string): void }
export function parseWishlist(raw: string | null, validIds: ReadonlySet<string>): string[] {
 try { const value: unknown = JSON.parse(raw || '[]'); return Array.isArray(value) ? [...new Set(value.filter((id): id is string => typeof id === 'string' && validIds.has(id)))].slice(0, WISHLIST_LIMIT) : []; } catch { return []; }
}
/** No storage access at import or during server rendering. Writes happen only on explicit user actions. */
export function createWishlistStore(validIds: ReadonlySet<string>, getStorage: () => WishlistStorage) {
 const initial: WishlistSnapshot = { ids: [], ready: false, error: false };
 let state = initial; let memoryOnly = false; const listeners = new Set<() => void>();
 function update(ids: readonly string[], error: boolean) {
  if (state.ready && state.error === error && JSON.stringify(ids) === JSON.stringify(state.ids)) return;
  state = { ids, ready: true, error }; listeners.forEach(listener => listener());
 }
 function refresh() { if (memoryOnly) return; try { update(parseWishlist(getStorage().getItem(WISHLIST_KEY), validIds), false); } catch { update(state.ids, true); } }
 function toggle(id: string) {
  if (!validIds.has(id)) return;
  refresh();
  const saved = state.ids.includes(id);
  if (!saved && state.ids.length >= WISHLIST_LIMIT) return;
  const ids = saved ? state.ids.filter(item => item !== id) : [...state.ids, id];
  try { getStorage().setItem(WISHLIST_KEY, JSON.stringify(ids)); memoryOnly = false; update(ids, false); } catch { memoryOnly = true; update(ids, true); }
 }
 return { getSnapshot: () => state, getServerSnapshot: () => initial,
  subscribe(listener: () => void) { listeners.add(listener); return () => { listeners.delete(listener); }; }, refresh, toggle };
}
