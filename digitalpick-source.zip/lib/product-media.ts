import { officialProductMedia } from './official-product-media';
import { catalogAssets } from './catalog-assets';

export interface ProductMedia {
  src: string; alt: string; label: string; owner: string; sourceUrl: string;
  rights: string; rightsUrl: string; notes: string; checkedAt: string;
  width?: number; height?: number; paper?: boolean; clip?: { viewBox: string; path: string; width: number; height: number };
}
export function primaryMedia(id: string): ProductMedia | undefined {
  const image = officialProductMedia[id];
  return image ? { src: image.imageUrl, alt: image.alt, label: image.mediaType, owner: image.owner, sourceUrl: image.officialPage,
    rights: '品牌版权', rightsUrl: image.officialPage, notes: image.notes, checkedAt: image.checkedAt, width: image.width, height: image.height,
    paper: /\.(?:jpg|jpeg)(?:\?|$)/i.test(image.imageUrl),
  } : undefined;
}
// Display masks retain the original photographed pixels. No generated cameras, logos or hidden parts.
const photoClips: Record<string, ProductMedia['clip']> = {
  '/products/iphone-15.webp': { width: 720, height: 960, viewBox: '188 64 372 729', path: 'M254 71 L476 71 Q534 71 536 129 L554 711 Q558 772 508 779 L266 786 Q206 790 203 729 L197 133 Q196 74 254 71 Z' },
  '/products/iphone-x-front.webp': { width: 627, height: 960, viewBox: '121 86 394 786', path: 'M193 92 L445 94 Q508 96 508 157 L502 798 Q502 862 442 863 L195 863 Q129 865 128 803 L125 158 Q125 94 193 92 Z' },
  '/products/iphone-x-back.webp': { width: 681, height: 960, viewBox: '117 84 466 790', path: 'M207 91 L471 92 Q531 94 537 151 L575 785 Q578 859 508 864 L199 863 Q123 858 123 793 L141 152 Q143 91 207 91 Z' },
  '/products/iphone-14.webp': { width: 570, height: 960, viewBox: '83 80 409 738', path: 'M154 86 L425 84 Q486 84 487 143 L461 752 Q459 812 407 813 L179 813 Q128 811 123 760 L88 152 Q84 91 154 86 Z' },
};
export function galleryMedia(id: string): ProductMedia[] {
  const official = primaryMedia(id), asset = catalogAssets[id];
  const photos = asset ? [asset, ...(asset.views || [])].filter(item => photoClips[item.src]).map(item => ({
    src: item.src, alt: item.alt + '，原片轮廓遮罩去背景', label: /front/.test(item.src) ? '实拍正面' : '实拍背面',
    owner: item.author, sourceUrl: item.sourceUrl, rights: item.license, rightsUrl: item.licenseUrl,
    notes: '原片像素展示，轮廓遮罩去背景；未重绘机身、镜头或标识。', checkedAt: item.acquiredAt, clip: photoClips[item.src],
  })) : [];
  return [...(official ? [official] : []), ...photos];
}
