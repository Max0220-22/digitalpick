import type { Category } from './products';
export interface CheckItem { id: string; title: string; instruction: string; critical?: boolean }
export type CheckStatus = 'pending' | 'pass' | 'issue';
export const checklist: Record<Category, CheckItem[]> = {
 phone: [
  { id: 'screen', title: '屏幕显示和触控', instruction: '打开纯白、纯黑和彩色图片，检查亮点、暗斑和烧屏；拖动图标覆盖屏幕四角，确认触控连续。' },
  { id: 'battery', title: '电池健康度', instruction: '在系统电池设置中查看可用的健康信息；短时观察掉电与发热。第三方读数仅作辅助，健康百分比不能单独证明原装。' },
  { id: 'camera', title: '摄像头', instruction: '前后镜头分别拍照和录像，切换焦段、对焦与闪光灯，查看黑点、抖动及收音。' },
  { id: 'biometric', title: 'Face ID / 指纹识别', instruction: '在卖家同意下删除旧记录并录入一次，锁屏后测试多次解锁；无法录入应记为异常。' },
  { id: 'audio', title: '扬声器与麦克风', instruction: '播放音乐、录制语音并回放，再测试通话听筒；留意破音、音量异常和麦克风失声。' },
  { id: 'charging', title: '充电接口', instruction: '使用确认正常的线材充电，并轻触线头确认接触稳定；如有电脑可测试数据传输。' },
  { id: 'network', title: '网络与信号', instruction: '插入自己的 SIM 卡测试通话和移动数据；连接 Wi-Fi 与蓝牙，核对地区版本频段是否适用。' },
  { id: 'repair', title: '维修记录', instruction: '询问拆修、换屏、换电池和进液史，核对可用的系统零件记录及维修凭证；不能仅凭螺丝外观判断。' },
  { id: 'lock', title: '账号锁和激活锁', instruction: '由卖家退出全部账号并解除查找功能，在卖家同意并备份后抹除设备、联网重新激活。不要接收需要他人账号或管理权限的设备。', critical: true },
  { id: 'identity', title: '序列号与型号信息', instruction: '在设置中核对型号、容量和序列号，与交易描述及凭证比对。序列号正确也不能单独证明整机无维修。', critical: true },
 ],
 tablet: [
  { id: 'screen', title: '屏幕显示', instruction: '打开纯色页面并调整亮度，查看暗斑、亮点、漏光和压痕；弯曲机身需进一步检测。' },
  { id: 'touch', title: '触控', instruction: '在笔记软件中用手指连续画线，覆盖屏幕边缘，再测试多指缩放，查看断触。' },
  { id: 'battery', title: '电池与充电', instruction: '查看系统可用电池信息，播放视频并观察掉电、发热；测试充电及数据接口。短时测试不能推断完整续航。' },
  { id: 'pen', title: '手写笔支持', instruction: '先在品牌官网核对兼容型号，再连接实际手写笔，测试充电、压感（若支持）和屏幕边缘划线。' },
  { id: 'lock', title: '账号锁与设备管理', instruction: '请卖家退出账号和查找功能；在同意备份后抹除并联网激活，确认没有激活锁或组织远程管理。', critical: true },
  { id: 'repair', title: '维修情况与型号', instruction: '询问维修、进液史并核对凭证；在设置中检查型号和容量，测试按键、扬声器与摄像头。' },
 ],
 laptop: [
  { id: 'battery', title: '电池循环次数', instruction: 'macOS 查看系统信息中的电源；Windows 可运行系统电池报告。对照设计与满充容量，循环次数和健康度都只作参考。' },
  { id: 'screen', title: '屏幕显示', instruction: '用纯色图片检查坏点、暗斑和残影；开合屏幕观察是否闪烁，并核对分辨率。' },
  { id: 'keyboard', title: '键盘和触控板', instruction: '逐个输入按键，测试功能键、背光、触控板点击和多指手势。' },
  { id: 'ports', title: '接口与连接', instruction: '用正常外设逐一测试 USB、音频和视频接口；确认充电、Wi-Fi 和蓝牙稳定。' },
  { id: 'thermal', title: '散热与稳定性', instruction: '在卖家同意下运行日常负载，观察温度、风扇和异响；若关机、花屏或严重卡顿，记录异常。不要用极端烤机替代专业检测。' },
  { id: 'ssd', title: 'SSD 健康情况', instruction: '使用系统诊断或可信工具查看可用的 SMART 信息与错误记录。没有警告不等于无故障，重要数据仍需备份。' },
  { id: 'management', title: '设备管理锁', instruction: '确认没有 BIOS / 固件密码和组织管理限制；让卖家解除账号，在同意备份后重置联网完成初始化。出现组织注册提示应暂停交易。', critical: true },
  { id: 'warranty', title: '型号、保修与凭证', instruction: '核对机身与系统序列号、配置和发票，使用品牌官方支持入口查看保修；跨地区保修需单独确认。', critical: true },
 ],
};
export function summarize(items: CheckItem[], statuses: Record<string, CheckStatus>) { const passed = items.filter(i => statuses[i.id] === 'pass'); const issues = items.filter(i => statuses[i.id] === 'issue'); const pending = items.filter(i => !statuses[i.id] || statuses[i.id] === 'pending'); return { passed, issues, pending, criticalIssue: issues.some(i => i.critical) }; }
