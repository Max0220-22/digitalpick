import { getProduct } from './products';
import { pricingFor, pricingSummary, usedPriceScenario } from './price-reference';
import type { Preferences, BudgetContext } from './recommend';
export const shareDisclaimer = '基于演示数据，购买前请核实';
export interface ShareItem { id: string; reason?: string; caution?: string; pricingNote?: string; configuration?: string }
function line(value: string) { return value.replace(/[\r\n\t]+/g, ' ').trim(); }
export function recommendationText({ items, preferences, scope = 'reference', budgetContext, gapNotes }: { items: ShareItem[]; preferences?: Preferences; scope?: 'reference' | 'verified'; budgetContext?: BudgetContext; gapNotes?: string[] }) {
 const rows = ['DigitalPick 数码选购清单', shareDisclaimer, '非实时价格 · 不承诺库存或交易结果'];
 if (preferences) {
  rows.push('', `设备：${{ phone: '手机', tablet: '平板', laptop: '笔记本电脑' }[preferences.category]}`, `总预算：¥${preferences.maxBudget.toLocaleString('zh-CN')}（预留 ¥${(preferences.reserveBudget || 0).toLocaleString('zh-CN')}）`, `购买方式：${{ new: '全新', used: '二手', either: '全新、二手都可以' }[preferences.mode]}`, `主要用途：${line(preferences.uses.join('、')) || '待确认'}`);
 }
 if (budgetContext) rows.push('', line(budgetContext.message));
 if (gapNotes?.length) rows.push('', '待核实的缺口：', ...gapNotes.map(note => `- ${line(note)}`));
 const valid = [...new Map(items.map(item => [item.id, item])).values()].map(item => ({ item, product: getProduct(item.id) })).filter(row => !!row.product).slice(0, 3);
 if (!valid.length) rows.push('', '当前没有通过全部条件审核的具体机型。', '请先补充需求或核实同配置报价；参考价规划仍不能确认的条件见缺口说明，不会把估算价充当可购买报价。');
 for (const { item, product } of valid) {
  if (!product) continue;
  const pricing = pricingFor(product.id), estimate = usedPriceScenario(product);
  rows.push('', `${valid.findIndex(row => row.item.id === item.id) + 1}. ${line(product.name)}`, `配置：${line(item.configuration || product.configuration)}`, scope === 'reference' ? '核价备选：尚未通过实时购买预算审核' : '问卷匹配：仅通过当前资料的规则审核，购买前仍须核价');
  if (item.pricingNote) rows.push(`本次规划：${line(item.pricingNote)}`);
  rows.push(`价格资料：${pricingSummary(product, 'new')}`);
  const quote = pricing.official || pricing.launch || pricing.msrp;
  if (quote) rows.push(`核价记录：${quote.checkedAt}；${quote.sourceLabel}；${quote.sourceUrl}`);
  rows.push(`二手资料：${pricingSummary(product, 'used')}`);
  if (estimate) rows.push(`估算日期：${estimate.date}；低置信度，非成交价，不用于硬预算审核`);
  if (item.reason) rows.push(`了解理由：${line(item.reason)}`);
  if (item.caution) rows.push(`注意：${line(item.caution)}`);
  rows.push(`参数更新：${product.updatedAt}`);
 }
 rows.push('', '请核对地区、容量、成色、实际到手价与售后；官网起价、历史价和模型估算不可混用。', '以上为选购参考，不保证交易结果。');
 return rows.join('\n');
}
