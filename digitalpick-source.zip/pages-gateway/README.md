# 免费 AI 入口

`https://digitalpick-gateway.pages.dev` 通过 Cloudflare Service Binding 调用现有 `digitalpick-ai`。入口中没有模型 Key，也不通过公网 workers.dev 请求原服务，所有来源、签名、输入、超时及额度检查仍由原 Worker 统一执行。

发布：在本目录运行 `npm exec -- wrangler pages deploy public --project-name digitalpick-gateway --branch main`。Wrangler 已获用户批准的 Pages 权限；不要更改成 `wrangler deploy`，那会发布到 workers.dev。

首次重建 Pages 项目时，可用 `wrangler pages project create digitalpick-gateway --production-branch main --force`：此处 force 只表示创建真正的 Pages 项目、不接受 CLI 的自动 Workers 迁移，不删除或覆盖现有项目。已有 Pages 项目直接部署即可。

健康检查 `/health` 不调用模型；会话 GET 必须带正式网站 Origin。不要增加新的 API Key 或放宽来源为通配符。免费 Pages Functions 与 Worker 请求共享账号配额；DeepSeek 调用仍按供应商计费。
