/** Free Pages entry. All model credentials and quota enforcement stay in digitalpick-ai. */
export default {
  async fetch(request, env) {
    const started=performance.now();
    const url = new URL(request.url);
    const health = url.pathname === '/health';
    if (!health && !['/api/assistant', '/api/assistant/'].includes(url.pathname)) return new Response('Not found', { status: 404 });
    if (health && !['GET', 'HEAD'].includes(request.method)) return new Response(null, { status: 405 });
    const origin = request.headers.get('origin');
    const permitted = origin === env.ALLOWED_ORIGIN;
    const headers = { 'Content-Type': 'application/json', 'Cache-Control': 'no-store', 'Vary': 'Origin', 'X-Content-Type-Options': 'nosniff', ...(permitted ? { 'Access-Control-Allow-Origin': origin } : {}) };
    if (!health && !permitted) return Response.json({ error: '请从已授权的网站发起对话。' }, { status: 403, headers });
    if (!env.AI_BACKEND) return Response.json({ error: 'AI 入口尚未配置。' }, { status: 503, headers });
    try {
      // Service binding uses Cloudflare's internal network; never fetches the public workers.dev hostname.
      const target = new URL(health ? '/health' : '/api/assistant/', 'https://digitalpick.internal');
      const backend=await env.AI_BACKEND.fetch(new Request(target, request));
      const response=new Response(backend.body,backend),duration=Math.max(0,performance.now()-started).toFixed(1);
      response.headers.set('Server-Timing',[response.headers.get('Server-Timing'),`dp-gateway;dur=${duration}`].filter(Boolean).join(', '));
      if(permitted)response.headers.set('Access-Control-Expose-Headers','Server-Timing, X-Request-ID, X-Quota-Scope');
      if(env.AI_TIMING_LOGS==='true')console.info('[gateway:timing]',{requestId:response.headers.get('X-Request-ID'),status:response.status,durationMs:Number(duration)});
      return response;
    } catch { return Response.json({ error: 'AI 入口暂时不可用，请稍后重试。' }, { status: 503, headers }); }
  },
};
