/** Free Pages entry. All model credentials and quota enforcement stay in digitalpick-ai. */
export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    const health = url.pathname === '/health';
    if (!health && !['/api/assistant', '/api/assistant/'].includes(url.pathname)) return new Response('Not found', { status: 404 });
    if (health && !['GET', 'HEAD'].includes(request.method)) return new Response(null, { status: 405 });
    const origin = request.headers.get('origin');
    const permitted = origin === env.ALLOWED_ORIGIN;
    const headers = { 'Content-Type': 'application/json', 'Cache-Control': 'no-store', 'Vary': 'Origin', 'X-Content-Type-Options': 'nosniff', ...(permitted ? { 'Access-Control-Allow-Origin': origin } : {}) };
    if (!health && !permitted) return Response.json({ error: '请从已授权的网站发起对话。' }, { status: 403, headers });
    if (!env.AI_BACKEND) return Response.json({ error: 'AI 入口尚未配置。' }, { status: 503, headers });
    try {
      // Service binding uses Cloudflare's internal network; never fetches the public workers.dev hostname.
      const target = new URL(health ? '/health' : '/api/assistant/', 'https://digitalpick.internal');
      return await env.AI_BACKEND.fetch(new Request(target, request));
    } catch { return Response.json({ error: 'AI 入口暂时不可用，请稍后重试。' }, { status: 503, headers }); }
  },
};
