import type { Metadata } from 'next';
import { WishlistBrowser } from '@/components/wishlist-browser';
export const metadata: Metadata = { title: '我的收藏', description: '把想了解的数码设备存进本机心愿单，无需注册，随时查看与对比。', robots: { index: false, follow: true } };
export default function WishlistPage() { return <div className="container page-space wishlist-page"><header className="feature-page-heading"><span className="section-kicker">A LITTLE ROOM FOR YOUR NEXT DEVICE</span><h1>我的收藏</h1><p>不急着下决定。把喜欢的留下，再慢慢了解。</p></header><WishlistBrowser/></div>; }
