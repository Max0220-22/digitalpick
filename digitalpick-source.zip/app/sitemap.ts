import type { MetadataRoute } from 'next';
import { products } from '@/lib/products';
import { articles } from '@/lib/articles';
export const dynamic = 'force-static';
export default function sitemap(): MetadataRoute.Sitemap { const base = process.env.NEXT_PUBLIC_SITE_URL?.replace(/\/$/, ''); if (!base) return []; return ['', 'products/', 'library/', 'recommend/', 'channels/', 'checklist/', 'guides/', 'compare/', 'about/', 'sources/', 'methodology/', ...products.map(p => `products/${p.id}/`), ...articles.map(a => `guides/${a.slug}/`)].map(route => ({ url: `${base}/${route}`, lastModified: '2026-10-16' })); }
