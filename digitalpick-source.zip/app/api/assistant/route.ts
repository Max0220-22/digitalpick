import { NextRequest, NextResponse } from 'next/server';
import { createHmac, randomBytes, timingSafeEqual } from 'node:crypto';
import { requestSchema } from '@/lib/ai/schema';
import { buildContext, modelSystemPrompt } from '@/lib/ai/context';
import { completeModelReply } from '@/lib/ai/reply';
import { withQuota } from '@/lib/ai/quota';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';
const headers = { 'Cache-Control': 'no-store' };
const isConfigured = () => process.env.AI_ENABLED === 'true' && !!process.env.AI_API_KEY && (process.env.AI_SESSION_SECRET?.length || 0) >= 32;
export function GET(request: NextRequest) {
  const response = NextResponse.json({ enabled: isConfigured(), model: isConfigured() ? process.env.AI_MODEL || 'deepseek-flash' : null, knowledgeVersion:'library-20261017-v1' }, { headers });
  if (isConfigured()) response.cookies.set('dp-ai-session', session(request).cookie, { httpOnly: true, sameSite: 'strict', secure: request.nextUrl.protocol === 'https:', maxAge: 86400, path: '/' });
  return response;
}
function error(message: string, status: number, retry?: string) { return NextResponse.json({ error: message }, { status, headers: { ...headers, ...(retry ? { 'Retry-After': retry } : {}) } }); }
function session(request: NextRequest) {
  const sign = (id: string) => createHmac('sha256', process.env.AI_SESSION_SECRET!).update(id).digest('hex');
  const raw = request.cookies.get('dp-ai-session')?.value || '';
  const [id, signature] = raw.split('.');
  if (/^[a-f0-9]{32}$/.test(id || '') && /^[a-f0-9]{64}$/.test(signature || '') && timingSafeEqual(Buffer.from(sign(id)), Buffer.from(signature))) return { id, cookie: raw };
  const next = randomBytes(16).toString('hex'); return { id: next, cookie: `${next}.${sign(next)}` };
}
export async function POST(request: NextRequest) {
  if (!isConfigured()) return error('AI 暂未启用。你仍可使用规则选购、产品库和验机清单。', 503);
  const origin = request.headers.get('origin');
  const allowed = [new URL(request.url).origin, `${request.nextUrl.protocol}//${request.headers.get('host')}`, process.env.NEXT_PUBLIC_SITE_URL ? new URL(process.env.NEXT_PUBLIC_SITE_URL).origin : null].filter(Boolean);
  if (!origin || !allowed.includes(origin)) return error('请从本站页面发起对话。', 403);
  if (!request.headers.get('content-type')?.startsWith('application/json')) return error('请求格式不正确。', 415);
  let input;
  try {
    if (Number(request.headers.get('content-length')) > 16000) return error('对话内容过长，请重新开始。', 413);
    const reader = request.body?.getReader(); if (!reader) return error('请输入你的问题。', 400);
    let size = 0; const chunks: Uint8Array[] = [];
    while (true) { const part = await reader.read(); if (part.done) break; size += part.value.byteLength; if (size > 16000) { await reader.cancel(); return error('对话内容过长，请重新开始。', 413); } chunks.push(part.value); }
    input = requestSchema.parse(JSON.parse(Buffer.concat(chunks).toString('utf8')));
  } catch { return error('请输入 800 字以内的问题，或重新开始对话。', 400); }
  const identity = session(request);
  const context = buildContext(input);
  const model = process.env.AI_MODEL || 'deepseek-flash';
  let base: URL;
  try { base = new URL(process.env.AI_BASE_URL || 'https://api.deepseek.com'); if (base.protocol !== 'https:' || base.hostname !== 'api.deepseek.com' || base.username || base.password) throw new Error(); }
  catch { return error('AI 服务配置待修复，请稍后再试。', 503); }
  const body = JSON.stringify({ model, messages: [{ role: 'system', content: modelSystemPrompt(context.task.intent) }, ...input.history, { role: 'user', content: JSON.stringify({ question: input.message, data: context.payload }) }], thinking: { type: 'disabled' }, response_format: { type: context.task.intent === 'purchase-advice' ? 'json_object' : 'text' }, max_tokens: 1600, stream: false });
  try { withQuota(identity.id, Buffer.byteLength(body, 'utf8') + 1600); }
  catch (cause) {
    const code = cause instanceof Error ? cause.message : '';
    return error(code === 'USER_LIMIT' ? '对话次数已达本轮限额，请稍后再聊。你仍可使用规则选购。' : code === 'GLOBAL_LIMIT' ? '今日 AI 体验额度已用完，规则选购与产品库仍可使用。' : 'AI 额度服务暂不可用，请稍后再试。', code.endsWith('LIMIT') ? 429 : 503, '60');
  }
  try {
    const response = await fetch(`${base.origin}${base.pathname.replace(/\/$/, '')}/chat/completions`, { method: 'POST', headers: { Authorization: `Bearer ${process.env.AI_API_KEY}`, 'Content-Type': 'application/json' }, body, signal: AbortSignal.any([AbortSignal.timeout(35000), request.signal]), cache: 'no-store', redirect: 'error' });
    if (!response.ok) return error(response.status === 401 || response.status === 402 ? 'AI 服务凭据或余额待检查，请联系站点维护者。' : 'AI 服务暂时繁忙，请稍后重试。', 502);
    const result = await response.json();
    const payload = completeModelReply(result, context, model);
    const answer = NextResponse.json(payload, { headers });
    answer.cookies.set('dp-ai-session', identity.cookie, { httpOnly: true, sameSite: 'strict', secure: request.nextUrl.protocol === 'https:', maxAge: 86400, path: '/' });
    return answer;
  } catch (cause) {
    return error(cause instanceof Error && (cause.name === 'TimeoutError' || cause.name === 'AbortError') ? '这次回复超时了，请稍后重试。' : 'AI 服务这次没有完成回复。你的问题无需改写，可以稍后重试，或继续使用规则选购。', 502);
  }
}
