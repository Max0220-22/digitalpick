import type { Metadata } from 'next';
import { ChecklistTool } from '@/components/checklist-tool';
export const metadata: Metadata = { title: '二手验机清单' };
export default function ChecklistPage() { return <div className="container page-space"><div className="page-intro"><span className="section-kicker">CHECK BEFORE YOU COMMIT</span><h1>买二手，多一份确定。</h1><p>按类别逐项检查，记录通过与异常，生成一份你自己的验机摘要。</p></div><div className="notice-box"><p>先与卖家确认测试方式。重置或抹除设备前，应由卖家备份并同意。账号锁、组织管理限制等关键项目未解除时，应暂停交易。当前清单为通用操作参考。</p></div><ChecklistTool /></div>; }
