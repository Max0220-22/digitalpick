import type { Metadata } from 'next';
import { CompareTool } from '@/components/compare-tool';
import { DemoNotice } from '@/components/site-shell';
export const metadata: Metadata = { title: '产品对比' };
export default function ComparePage() { return <div className="container page-space"><div className="page-intro"><span className="section-kicker">SIDE BY SIDE</span><h1>放在一起，取舍更清楚。</h1><p>最多 3 款设备，逐项看清参数与全新、二手购买方式。</p></div><DemoNotice /><CompareTool /></div>; }
