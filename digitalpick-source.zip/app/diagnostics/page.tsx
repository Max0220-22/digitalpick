import type { Metadata } from 'next';
import { RuntimeDiagnostics } from '@/components/companion/diagnostics';
export const metadata: Metadata = { title: '连接与3D自检', robots: { index: false, follow: false } };
export default function DiagnosticsPage() { return <RuntimeDiagnostics />; }
