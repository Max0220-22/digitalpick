import type { Metadata } from 'next';
import { ProductBrowser } from '@/components/product-browser';
import Link from 'next/link';
import report from '@/lib/library/import-report.json';
import { DemoNotice } from '@/components/site-shell';
export const metadata: Metadata = { title: '产品库' };
export default function Products() { return <div className="container page-space"><div className="page-intro"><span className="section-kicker">THE DEVICE LIBRARY</span><h1>看懂设备，再做决定。</h1><p>参数、优缺点和适用场景放在一起，让选择更有依据。</p></div><div className="library-entry"><div><strong>设备参数素材库</strong><p>新增 {report.pendingConfigurations} 条配置素材；已核对参数与待核验资料分开展示。</p></div><Link href="/library/" className="text-link">查参数与来源 ↗</Link></div><DemoNotice /><ProductBrowser /></div>; }
