import type { Metadata } from 'next';
import { ProductBrowser } from '@/components/product-browser';
import Link from 'next/link';
import report from '@/lib/library/import-report.json';
import { DemoNotice } from '@/components/site-shell';
export const metadata: Metadata = { title: '产品库' };
export default function Products() { return <div className="container page-space"><div className="page-intro"><span className="section-kicker">THE DEVICE LIBRARY</span><h1>看懂设备，再做决定。</h1><p>按品牌、代际和设备类型浏览。已确认的型号直接入库，缺失参数与报价如实留空。</p></div><div className="library-entry"><div><strong>设备参数素材库</strong><p>另有 {report.pendingConfigurations} 条待核验配置素材。正式产品与清单核验结果可在下方直接查找。</p></div><Link href="/library/" className="text-link">查参数与来源 ↗</Link></div><DemoNotice /><ProductBrowser /></div>; }
