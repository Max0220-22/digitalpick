import type { Metadata } from 'next';
import { ProductBrowser } from '@/components/product-browser';
import { DemoNotice } from '@/components/site-shell';
export const metadata: Metadata = { title: '产品库' };
export default function Products() { return <div className="container page-space"><div className="page-intro"><span className="section-kicker">THE DEVICE LIBRARY</span><h1>看懂设备，再做决定。</h1><p>参数、优缺点和适用场景放在一起，让选择更有依据。</p></div><DemoNotice /><ProductBrowser /></div>; }
