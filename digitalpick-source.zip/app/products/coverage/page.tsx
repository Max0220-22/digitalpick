import type { Metadata } from 'next';
import { CatalogCoverage } from '@/components/catalog-coverage';
export const metadata:Metadata={title:'型号清单核验',description:'逐项核对2021—2026设备清单中的正式型号、名称纠正、官方来源和暂未确认条目。'};
export default function Page(){return <CatalogCoverage/>;}
