import type { Metadata } from 'next';
import { Suspense } from 'react';
import { LibraryBrowser } from '@/components/library-browser';
export const metadata: Metadata = { title:'设备参数素材库', description:'手机、平板和笔记本的参数资料、配置与来源。已核对字段与待核验素材明确区分，不提供虚构现价。' };
export default function LibraryPage() { return <Suspense fallback={<div className="container page-space">正在加载参数素材库…</div>}><LibraryBrowser /></Suspense>; }
