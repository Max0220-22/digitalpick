import type { Metadata } from 'next';
import { DemoNotice } from '@/components/site-shell';
import { RecommendWizard } from '@/components/recommend-wizard';
export const metadata: Metadata = { title: '智能选购' };
export default function RecommendPage() { return <div className="container page-space recommend-page"><div className="page-intro"><span className="section-kicker">YOUR NEEDS. YOUR NEXT DEVICE.</span><h1>适合你的，才是好选择。</h1><p>先满足每项必要用途，再按你的优先级与完整预算，找到最多3款值得了解的设备。</p></div><DemoNotice /><RecommendWizard /></div>; }
