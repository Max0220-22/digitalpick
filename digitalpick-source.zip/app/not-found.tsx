import Link from 'next/link';
import { Button } from '@/components/ui/button';
export default function NotFound() { return <div className="container page-space"><div className="empty-state"><span className="section-kicker">404 · PAGE NOT FOUND</span><h1>这一页，暂时没找到。</h1><p>试着从产品库重新寻找你感兴趣的设备。</p><Button asChild><Link href="/products/">前往产品库</Link></Button></div></div>; }
