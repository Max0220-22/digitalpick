import type { Metadata } from 'next';
import { ChannelBrowser } from '@/components/channel-browser';
export const metadata: Metadata = { title: '购买渠道导航' };
export default function Channels() { return <div className="container page-space"><div className="page-intro"><span className="section-kicker">WHERE TO LOOK</span><h1>选好之后，去哪里买？</h1><p>把平台特点与风险放在一起，选一个你了解的购买渠道。</p></div><ChannelBrowser /></div>; }
