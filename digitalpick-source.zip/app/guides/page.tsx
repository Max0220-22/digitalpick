import type { Metadata } from 'next';
import { articles, articleCategories } from '@/lib/articles';
import { GuideBrowser } from '@/components/guide-browser';
export const metadata: Metadata = { title: '数码选购知识库' };
export default function Guides() { return <div className="container page-space"><div className="page-intro"><span className="section-kicker">THE DIGITALPICK NOTES</span><h1>多懂一点，少纠结一点。</h1><p>从购买到使用，把复杂的数码问题讲清楚。文章以 Markdown 管理，便于持续更新。</p></div><GuideBrowser articles={articles} categories={articleCategories} /></div>; }
