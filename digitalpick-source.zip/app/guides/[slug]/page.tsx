import { assetPath } from '@/lib/deployment';
import type { Metadata } from 'next';
import Link from 'next/link';
import { notFound } from 'next/navigation';
import { ArrowLeft, ArrowUpRight } from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import { articles, getArticle } from '@/lib/articles';
import { Badge } from '@/components/ui/badge';
export function generateStaticParams() { return articles.map(a => ({ slug: a.slug })); }
export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> { const a = getArticle((await params).slug); return { title: a?.title || '文章未找到', description: a?.excerpt }; }
export default async function ArticlePage({ params }: { params: Promise<{ slug: string }> }) { const a = getArticle((await params).slug); if (!a) notFound(); return <div className="container page-space"><Link className="back-link" href="/guides/"><ArrowLeft size={16} />返回选购知识</Link><article className="article"><header><Badge>{a.category}</Badge><h1>{a.title}</h1><p>{a.excerpt}</p><span>未域 ELVORA 编辑 · 原创示例文章 · 更新于 {a.updatedAt} · 约 {a.minutes} 分钟阅读</span></header><div className="markdown"><ReactMarkdown components={{ a: ({ href, children }) => <a href={href ? assetPath(href) : undefined} target={href?.startsWith('https://') ? '_blank' : undefined} rel="noopener noreferrer">{children}</a> }}>{a.content}</ReactMarkdown></div><footer><p>本文为通用选购知识与编辑判断，不是实机评测。实际设备状况、软件支持与服务条款请向品牌和交易主体核实。</p><Link href="/recommend/" className="text-link">把需求整理成一份选购建议 <ArrowUpRight size={15} /></Link></footer></article></div>; }
