import type { Metadata } from 'next';
import Link from 'next/link';
import { ArrowLeft, Compass } from 'lucide-react';
import { BeginnerGuide } from '@/components/beginner-guide';
export const metadata: Metadata = { title: '从零开始 · 新人数码选购指南', description: '五步整理数码选购需求，查阅常见参数术语，再决定适合自己的手机、平板或笔记本。' };
export default function StartPage() { return <div className="container page-space start-page"><Link href="/" className="back-link"><ArrowLeft size={16}/>返回首页</Link><header className="feature-page-heading"><span className="feature-eyebrow"><Compass size={14}/>FIRST THINGS FIRST</span><h1>第一次买，<br/>也可以心里有数。</h1><p>不用一次弄懂所有参数。跟着这五步，把你的选择变简单。</p></header><BeginnerGuide/><aside className="after-purchase-note"><span>已经收到设备了？</span><Link href="/guides/after-unboxing/" className="text-link">看看“开箱之后” <span aria-hidden="true">↗</span></Link></aside></div>; }
