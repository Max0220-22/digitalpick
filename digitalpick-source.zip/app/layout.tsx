import type { Metadata, Viewport } from 'next';
import { SiteFooter, SiteHeader } from '@/components/site-shell';
import { CompanionProvider } from '@/components/companion/provider';
import { CompanionDock } from '@/components/companion/dock';
import './globals.css';
import './companion.css';
import './refinements.css';
import './cosmos.css';
import { GalaxyBackground } from '@/components/companion/galaxy-background';
import { LiquidEffects } from '@/components/ui/liquid-effects';
import { assetPath } from '@/lib/deployment';
const siteUrl = process.env.NEXT_PUBLIC_SITE_URL;
export const metadata: Metadata = { ...(siteUrl ? { metadataBase: new URL(siteUrl) } : {}), title: { default: 'DigitalPick 数码指南 — 不买最贵的，只买最适合的', template: '%s · DigitalPick 数码指南' }, description: '从预算和真实需求出发，了解手机、平板与笔记本。透明的选购规则、产品参数、购买渠道和二手验机清单。当前产品库与价格为演示数据。', applicationName: 'DigitalPick', openGraph: { title: 'DigitalPick 数码指南', description: '你的下一台数码设备，应该更适合你。', locale: 'zh_CN', type: 'website' }, icons: { icon: assetPath('/icon.svg') } };
export const viewport: Viewport = { width: 'device-width', initialScale: 1, themeColor: '#2563eb' };
const themeScript = `try{var t=localStorage.getItem('dp-theme');document.documentElement.classList.toggle('dark',t!=='light')}catch(e){document.documentElement.classList.add('dark')}`;
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) { return <html lang="zh-CN" className="dark" data-scroll-behavior="smooth" suppressHydrationWarning><head><script dangerouslySetInnerHTML={{ __html: themeScript }} /></head><body><CompanionProvider><GalaxyBackground /><LiquidEffects /><SiteHeader /><main id="main">{children}</main><SiteFooter /><CompanionDock /></CompanionProvider></body></html>; }
