# DigitalPick 数码指南

**不买最贵的，只买最适合的。**

一个可运行的中文数码购买决策网站。Next.js App Router + TypeScript + Tailwind CSS 4 + Radix / CVA 基础组件 + Lucide + Three.js。基础功能无需账号或付费 API；小派可选择接入服务端 DeepSeek V4 Pro。

## 小派对话修复（2026-10-17）

- 修复“预算2000，打游戏 → 王者荣耀”被当成新话题的问题；游戏名、预算、购买方式可连续补充，手机方向的推断会标明假设。
- 追问一次只保留一项，已知预算和游戏不重复询问。“可以 / 不接受 / 2000”结合上一问解析。
- 正文开头可复述数值一致的已确认预算；商品售价、任意链接和未知推荐仍拦截。完整 JSON 围栏可恢复。
- 模型输出不合规时明确转为“本地整理”，接续既有条件，不伪装成模型回复、不自动产生第二次付费请求。
- 本轮74项测试、两种构建与模拟浏览器回归通过；未训练模型、未调用付费推理。详见 [对话质量说明](docs/CONVERSATION.md)。

## 免费部署已适配

优先方案为 **GitHub Pages 静态前端 + Cloudflare Worker AI 代理 + SQLite Durable Object 持久额度**。星河、小派、聊天和所有页面保留，原 Node 运行方式也保留。部署入口：[完整免费部署步骤](docs/FREE-DEPLOYMENT.md)。

- `npm run build:pages` 独立生成 `out-pages/`，支持仓库子路径；GitHub Actions 自动构建发布。
- 密钥只放 Cloudflare Secrets；浏览器仅接收公开代理地址与一天有效的匿名签名会话。
- 全站 / 会话 / IP 频率、每日次数和 token 预留、输入长度、超时与错误处理已实现。
- **托管可使用免费额度，DeepSeek 仍按实际调用收费。此前分享过的 Key 必须先撤销轮换。**
- 未执行账号授权、真实云端发布或本轮付费推理。密钥与历史检查边界见 [安全检查](docs/SECURITY-AUDIT.md)。

## 既有推荐与界面功能

- 推荐规则 v2：每项用途先过适配门槛，再按主用途排序；加入完整预算预留、全新 / 二手分别评估和省心 / 均衡 / 低价取舍。结果可展开评分、购买方案与未入选原因。
- 新增 `/methodology/` 推荐方法与研究来源页。核验 10 条 MKBHD 视频的公开简介 / 章节及 6 条社交帖正文，明确记录已读范围、年份、地区与证据限制。Google / X 访问受限，未声称找到全网最高赞内容。
- 小派使用同一推荐规则筛选正式候选，并读取有来源边界的编辑原则；未确认的硬要求先澄清。此次是规则与上下文优化，没有训练模型，也没有把博主观点、奖项或社交热度变成产品分数。
- 现有用途等级仍是早期本站编辑判断，尚非逐台实测。正式 AI 继续排除演示报价；当前没有可靠报价候选，不会凑出预算内购买推荐。详见 [推荐维护说明](docs/RECOMMENDATION.md)。

### 已保留的星河界面与设备展示

- 流动星河首页：程序生成的旋臂星尘、柔和星云、光标避让、点击扩散与引力波环；无需下载背景视频。
- 小派在太空漂浮与挥手，头部随光标转动，点击后向光标短距离飞近；手机拖动、暂停星河与小派、2D 降级及减少动态适配。
- 真实 DeepSeek 对话：服务端密钥、输入边界、35 秒超时、JSON 校验、候选 ID 审核、持久原子额度。没有替代模型或伪造 AI 回复。
- 24 款资料设备，含 20 款手机：苹果从 iPhone X（2017）起的主要代际；小米、三星、OPPO、vivo、荣耀、一加部分主流型号。不是所有颜色、容量、Pro / Max 分支的全量库。
- 24 款设备主图均使用已核对的官方商城 / 产品 / 归档页远程图；图片失效时明确提示。停售设备标为官方归档，不暗示仍在售。公开发布前须确认品牌素材使用许可，详见 [官方图像说明](docs/OFFICIAL-MEDIA.md)。
- 放大首页与详情的设备占比；iPhone X 正背面、iPhone 14 / 15 背面共 4 张无遮挡实拍提供去背景补充视图，使用原片轮廓遮罩，不生成补画。平面视差不是 360° 模型。
- iOS 26 灵感的网页液态玻璃：折射层、透光边缘、随光标移动的高光和弹性按压；导航、按钮和 Radix 菜单统一。Safari / Firefox 使用模糊和高光降级。

## 本地运行

推荐 Node.js 24 LTS 或更新版本；本机验证 Node.js 26.8.1 / npm 11.19.0。

```bash
npm ci
npm run dev
```

打开 http://127.0.0.1:3000 。开发服务默认仅绑定本机。当前工作目录已配置忽略的服务端环境文件；源码包不附带任何密钥。

其他环境无需配置即可运行基础功能。需要 AI 时复制 `.env.example` 为 `.env.local`，仅在服务端填写 `AI_API_KEY`、随机 `AI_SESSION_SECRET`、`AI_ENABLED=true`；默认模型为 `deepseek-v4-pro`。详见 [AI 接入与额度](docs/AI.md)。

```bash
npm run typecheck
npm test
npm run build
npm run check:site
npm start
```

默认生产构建在 `.next/`，通过 Next.js Node 服务运行；免费静态目标另外使用 `npm run build:pages` 生成 `out-pages/`。`npm run preview` 与 `npm start` 相同。默认使用 Webpack。保留在目录中的旧 `out/` 和 legacy 静态归档属于历史版本，请使用新工作流部署。

## 基础功能

- 首页搜索、预算、分类、全新 / 二手入口与知识文章。
- 产品库关键词 / 中文品牌搜索、分类、品牌筛选、购买方式和年份 / 重量排序。
- 独立详情页：具体配置、来源、更新时间、优缺点、适合场景、全新与二手建议。
- 五步规则选购：类型、总预算与预留、购买取舍、用途与主用途、品牌 / 系统 / 容量 / 重量 / 屏幕。
- 最多 3 款：每项用途须达到 3/5 编辑适配门槛；报价上限加预留不能超预算。缺价、过期、能力未知或必要用途不适配时不凑数。
- 公开用途 / 预算 / 购买取舍 / 品牌 / 配置分项，保留两种合格购买方案，并解释被排除设备的原因。
- 官方平台渠道、风险和关键词复制；没有可靠商品直达链接时不生成商品地址。
- 手机 / 平板 / 电脑验机清单：通过 / 异常 / 未查，关键异常提示、本地持久化、TXT 摘要。
- 最多三款横向参数对比，8 类 Markdown 知识库，文章搜索与分类。
- 无登录、支付、用户评论、爬虫、广告追踪或交易流程。

## 数据边界

**所有数字价格仍为演示数值，不代表当前行情。** 旧的 7 条 MVP 数据保留演示报价用于规则流程，新扩充型号的价格均为 `null`。缺价显示“暂无可靠报价”；没有伪造成交、优惠、库存、评分、热度或折旧率。

AI 完全排除演示价格。当前没有真实报价候选，所以不会声称已有预算内可买机型；会给出配置取舍、验机建议和工具入口。新收录资料未经用途评分，不编造测评结论。五步规则问答可继续以明确演示模式体验。

- 产品参数附官方来源，未知 RAM、相机、电池等字段明确未知；地区版本写在配置和来源中。
- 优缺点 / 场景为编辑判断，不能当作实机测试。不同来源续航不生成统一排名。
- 报价有效期 30 天，非法范围、未来 / 无效日期和缺少来源的非演示价格不参与推荐。
- 添加真实报价须核对同配置、实际采集日期及可靠来源，并设置 `demo: false`，不能直接把示例价格改为真实。
- 官方图像来源不等于开放许可，本地原型使用品牌公开地址；官方图与有 CC 许可的补充实拍分别标注。详情见 [官方图像](docs/OFFICIAL-MEDIA.md)、[素材清单](docs/ASSETS.md) 与 `/sources/`。照片不作为价格依据。
- 主题、验机和对比保存在本机浏览器。发送 AI 对话后，最近消息经服务端转交 DeepSeek；本站不保存正文。Node 版使用匿名 Cookie 与本机 SQLite；Worker 版使用内存签名会话、每日 IP 摘要及持久 Durable Object 计数，仅用于额度。

## 项目结构

```text
app/                       页面、样式、SEO、来源页
  api/assistant/           服务端模型接口
  products/[id]/           设备详情
  recommend/ checklist/    规则问答、验机
components/
  companion/               3D 精灵、聊天、首页与悬浮入口
  ui/                      Button、Badge、GlassSelect
  product-gallery.tsx      官方图 / 去背景实拍与视差
  product-media-image.tsx  图片失败降级、原片轮廓遮罩
  device-showcase.tsx      首页设备档案
lib/
  products.ts              演示资料与完整设备集合
  catalog-assets.ts        官方参数、摄影作者和许可
  official-product-media.ts 官方远程图、出处与版权状态
  product-media.ts          统一图片与原片遮罩映射
  ai/                      输入/输出验证、上下文、SQLite 额度
  recommend.ts prices.ts   逐项用途门槛、购买方案与价格规则
  research.ts              研究来源、访问范围与编辑原则
  deployment.ts            公开代理地址、仓库路径与本地资源前缀
content/articles/          Markdown 原创示例文章
public/products/           带许可的 WebP 图像
worker/                    Web API 代理、签名与持久事务额度
wrangler.toml              Worker 正式配置（无密钥）
.github/workflows/pages.yml GitHub Pages 自动构建与发布
scripts/*pages.mjs         静态构建、路径检查与本地预览
scripts/check-site.mjs     Node 生产构建页面链接检查
tests/                     规则、AI 边界、额度与精灵状态
```

## 验证

当前产品库扩充版本：前端与Worker TypeScript、98项行为测试通过；GitHub Pages构建生成514个HTML、检查20208条本地引用。来源、缺失字段与清单状态见 [产品库扩充记录](docs/CATALOG-EXPANSION.md)。本轮未调用付费模型；Node全栈构建与Docker没有在此轮重新验收。

## 部署与维护

优先使用 [免费部署步骤](docs/FREE-DEPLOYMENT.md)：GitHub Pages + Worker，已完成 SQLite Durable Object 适配。[部署说明](DEPLOYMENT.md) 同时保留 Node 单机与 Docker 路线。Node 版仍需要单主机持久 SQLite 文件，不能放进临时 Serverless 文件系统。已部署GitHub Pages + Cloudflare Worker，经Pages网关连接；记录见 docs/GITHUB-LIVE.md。Docker 镜像未在本机运行验证。

修改 `lib/products.ts`、`lib/catalog-assets.ts` 与 Markdown 后重新构建。正文不执行原始 HTML。渠道链接有 HTTPS 白名单；无赞助或佣金。如未来存在合作，应逐项披露。

[验证记录](docs/VERIFICATION.md) · [推荐维护说明](docs/RECOMMENDATION.md) · [小派实现](docs/COMPANION.md) · [AI 说明](docs/AI.md) · [UI 参考与许可](docs/UI-REFERENCES.md)

后续优先补齐可信价格与更多官方核验参数，再完善专门评测、按需防刷验证、内容编辑和价格历史；保留当前无登录即可试用的体验。

## 参数素材库与短提示理解（2026-10-17）

早期新增 `/library/`，最初37条官方字段资料与1,775条待核验配置分开展示；后者不进入AI事实和预算推荐。支持中文型号、对比后短答和明确中文/k预算。仍使用DeepSeek V4 Pro，未训练模型权重，未新增图片。来源、许可、覆盖缺口与维护说明见 [docs/DEVICE-LIBRARY.md](docs/DEVICE-LIBRARY.md)。离线导入：`python3 scripts/import-device-library.py`，构建无需联网或付费数据API。

## 正式产品库扩充（2026-10-17）

正式产品库现有490条型号/地区版本：339手机、90平板、61笔记本。按用户清单逐项核验520项（445确认、18纠正、57未确认），结果见 `/products/coverage/`。缺报价不会隐藏产品；未读到的参数保持空值，不伪造完整规格。详情、数据维护及验证范围见 [CATALOG-EXPANSION.md](docs/CATALOG-EXPANSION.md)。
