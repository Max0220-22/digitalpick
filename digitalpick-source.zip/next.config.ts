import type { NextConfig } from "next";
const staticBuild = process.env.DIGITALPICK_TARGET === "static";
const nextConfig: NextConfig = {
  output: staticBuild ? "export" : "standalone",
  basePath: staticBuild ? process.env.NEXT_PUBLIC_BASE_PATH || "" : "", trailingSlash: true, images: { unoptimized: true }, poweredByHeader: false,
  outputFileTracingRoot: process.cwd(),
  ...(staticBuild ? {} : { async headers() { return [{ source: '/:path*', headers: [
    { key: 'X-Content-Type-Options', value: 'nosniff' },
    { key: 'Referrer-Policy', value: 'strict-origin-when-cross-origin' },
    { key: 'X-Frame-Options', value: 'DENY' },
    { key: 'Permissions-Policy', value: 'camera=(), microphone=(), geolocation=()' },
  ] }]; } }),
};
export default nextConfig;
