import type { NextConfig } from "next";
import {createReleaseVersion} from './lib/release-version';
const release=createReleaseVersion(new Date(process.env.ELVORA_BUILD_AT||Date.now()),process.env.GITHUB_SHA);
const staticBuild = process.env.DIGITALPICK_TARGET === "static";
const nextConfig: NextConfig = {
  env:{NEXT_PUBLIC_RELEASE_DATE:release.date,NEXT_PUBLIC_RELEASE_ID:release.id},
  output: staticBuild ? "export" : "standalone",
  basePath: staticBuild ? process.env.NEXT_PUBLIC_BASE_PATH || "" : "", trailingSlash: true, images: { unoptimized: true }, poweredByHeader: false,
  outputFileTracingRoot: process.cwd(),
  ...(staticBuild ? {} : { async headers() { return [{ source: '/:path*', headers: [
    { key: 'X-Content-Type-Options', value: 'nosniff' },
    { key: 'Referrer-Policy', value: 'strict-origin-when-cross-origin' },
    { key: 'X-Frame-Options', value: 'DENY' },
    { key: 'Permissions-Policy', value: 'camera=(), microphone=(), geolocation=()' },
  ] }]; } }),
};
export default nextConfig;
