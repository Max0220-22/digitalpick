import { readdir, readFile, stat } from 'node:fs/promises';
import { spawnSync } from 'node:child_process';
import { join, resolve, relative } from 'node:path';
const root = process.cwd(), ignored = new Set(['node_modules', '.git', '.data', '.codex', '.agents', '.wrangler']);
const known = [];
for (const name of ['.env.local', '.dev.vars']) {
  try { for (const line of (await readFile(join(root, name), 'utf8')).split(/\r?\n/)) if (/^(AI_API_KEY|AI_SESSION_SECRET)=/.test(line)) { const value = line.split('=').slice(1).join('=').trim().replace(/^['"]|['"]$/g, ''); if (value.length >= 20) known.push(value); } } catch {}
}
const keyPattern = /(?:sk-[a-zA-Z0-9]{24,}|gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{40,})/;
let scanned = 0; const findings = [];
async function walk(dir) {
  for (const entry of await readdir(dir, { withFileTypes: true })) {
    if (ignored.has(entry.name) || entry.isSymbolicLink()) continue;
    const file = join(dir, entry.name);
    if (entry.isDirectory()) { await walk(file); continue; }
    if ((entry.name.startsWith('.env') && entry.name !== '.env.example') || (entry.name.startsWith('.dev.vars') && !entry.name.endsWith('.example')) || /\.(zip|tsbuildinfo|sqlite|sqlite-wal|sqlite-shm)$/.test(entry.name) || entry.name === '.DS_Store') continue;
    const content = await readFile(file); scanned++;
    if (known.some(value => content.includes(Buffer.from(value))) || keyPattern.test(content.toString('utf8'))) findings.push({ scope: 'file', path: relative(root, file) });
  }
}
await walk(root);
const inside = spawnSync('git', ['rev-parse', '--show-toplevel'], { cwd: root, encoding: 'utf8' });
let history = 'No local Git repository: history unavailable';
if (inside.status === 0 && resolve(inside.stdout.trim()) === resolve(root)) {
  const commits = spawnSync('git', ['rev-list', '--all'], { cwd: root, encoding: 'utf8', maxBuffer: 20 * 1024 * 1024 });
  if (commits.status !== 0) throw new Error('Unable to inspect Git history.');
  let count = 0;
  for (const revision of commits.stdout.trim().split('\n').filter(Boolean)) {
    const result = spawnSync('git', ['grep', '-I', '-l', '-E', 'sk-[a-zA-Z0-9]{24,}|gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{40,}', revision, '--'], { cwd: root, encoding: 'utf8', maxBuffer: 20 * 1024 * 1024 });
    if (result.status !== 0 && result.status !== 1) throw new Error('Unable to inspect a Git revision.');
    for (const path of result.stdout.trim().split('\n').filter(Boolean)) findings.push({ scope: 'git', path });
    for (const secret of known) {
      const found = spawnSync('git', ['grep', '-I', '-l', '-F', '-f', '-', revision, '--'], { cwd: root, encoding: 'utf8', input: `${secret}\n`, maxBuffer: 20 * 1024 * 1024 });
      if (found.status !== 0 && found.status !== 1) throw new Error('Unable to inspect a Git revision for local credentials.');
      for (const path of found.stdout.trim().split('\n').filter(Boolean)) findings.push({ scope: 'git', path });
    }
    count++;
  }
  history = `Scanned ${count} reachable Git commits`;
}
console.log(`Credential scan: ${scanned} files; ${history}. Secret values are never printed.`);
if (findings.length) { console.error(JSON.stringify(findings, null, 2)); process.exitCode = 1; }
else console.log('No supported credential pattern or local credential value found outside ignored secret files.');
