import { spawn } from 'node:child_process';
import { mkdir, mkdtemp, rm } from 'node:fs/promises';
import { resolve, join } from 'node:path';
import assert from 'node:assert/strict';
const root = process.cwd(), port = Number(process.env.WORKER_CHECK_PORT || 8789), base = `http://127.0.0.1:${port}`, origin = 'http://127.0.0.1:4173';
await mkdir(resolve('.deploy'), { recursive: true });
const state = await mkdtemp(resolve('.deploy/quota-check-'));
let child, output = '';
async function stop() {
  if (!child || child.exitCode !== null) return;
  const processToStop = child;
  const done = new Promise(accept => processToStop.once('exit', accept));
  try { process.platform === 'win32' ? processToStop.kill('SIGTERM') : process.kill(-processToStop.pid, 'SIGTERM'); } catch {}
  await Promise.race([done, new Promise(accept => setTimeout(accept, 3000))]);
  if (processToStop.exitCode === null) try { process.platform === 'win32' ? processToStop.kill('SIGKILL') : process.kill(-processToStop.pid, 'SIGKILL'); } catch {}
}
async function start() {
  const args = [resolve('node_modules/wrangler/bin/wrangler.js'), 'dev', '--local', '--ip', '127.0.0.1', '--port', String(port), '--config', 'wrangler.local-test.toml', '--persist-to', state];
  child = spawn(process.execPath, args, { cwd: root, detached: process.platform !== 'win32', env: { ...process.env, CI: 'true', WRANGLER_SEND_METRICS: 'false', CLOUDFLARE_LOAD_DEV_VARS_FROM_DOT_ENV: 'false' }, stdio: ['ignore', 'pipe', 'pipe'] });
  child.stdout.on('data', data => { output = (output + data.toString()).slice(-6000); }); child.stderr.on('data', data => { output = (output + data.toString()).slice(-6000); });
  const deadline = Date.now() + 30000;
  while (Date.now() < deadline) {
    if (child.exitCode !== null) throw new Error('Local Worker exited before readiness.');
    try { if ((await fetch(`${base}/health`, { signal: AbortSignal.timeout(500) })).ok) return; } catch {}
    await new Promise(accept => setTimeout(accept, 200));
  }
  throw new Error('Local Worker did not become ready.');
}
const status = () => fetch(`${base}/api/assistant/`, { headers: { origin } });
const post = token => fetch(`${base}/api/assistant/`, { method: 'POST', headers: { origin, authorization: `Bearer ${token}`, 'content-type': 'application/json' }, body: JSON.stringify({ message: '预算5000元手机日常使用' }) });
try {
  await start();
  const preflight = await fetch(`${base}/api/assistant/`, { method: 'OPTIONS', headers: { origin, 'access-control-request-method': 'POST', 'access-control-request-headers': 'authorization,content-type' } });
  assert.equal(preflight.status, 204);
  const tokens = [];
  for (let i = 0; i < 3; i++) { const response = await status(); assert.equal(response.status, 200); tokens.push((await response.json()).sessionToken); }
  const responses = await Promise.all(Array.from({ length: 10 }, (_, i) => post(tokens[i % 3])));
  assert.equal(responses.filter(r => r.status === 200).length, 2); assert.equal(responses.filter(r => r.status === 429).length, 8);
  for (const response of responses.filter(r => r.status === 200)) assert.equal((await response.json()).model, 'local-proxy-fixture');
  await stop(); await start();
  assert.equal((await post(tokens[0])).status, 429);
  console.log('Local workerd passed: CORS preflight, 10 concurrent calls limited to 2, persisted quota after process restart. Mock model only; no DeepSeek requests.');
} catch (error) {
  console.error(error.message); console.error(output.replace(/sk-[A-Za-z0-9]{12,}/g, '[redacted]')); process.exitCode = 1;
} finally { await stop(); await rm(state, { recursive: true, force: true }); }
