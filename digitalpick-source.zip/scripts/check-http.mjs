import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
const base = process.env.CHECK_SITE_URL || 'http://127.0.0.1:3000';
const manifest = JSON.parse(await readFile('.next/prerender-manifest.json', 'utf8'));
let count = 0;
for (const route of Object.keys(manifest.routes)) {
  if (route.startsWith('/_')) continue;
  const response = await fetch(`${base}${route === '/' || route.includes('.') ? route : `${route}/`}`);
  assert.equal(response.status, 200, route); assert.equal(response.headers.get('x-content-type-options'), 'nosniff'); count++;
}
assert.equal((await fetch(`${base}/missing-digitalpick-page/`)).status, 404);
const api = `${base}/api/assistant/`;
const status = await fetch(api); assert.equal(status.status, 200);
assert.equal(status.headers.get('cache-control'), 'no-store');
const origin = new URL(base).origin;
const post = (body, extra = {}) => fetch(api, { method: 'POST', headers: { origin, 'content-type': 'application/json', ...extra }, body });
const enabled = (await status.json()).enabled;
if (enabled) {
  assert.equal((await post('{')).status, 400);
  assert.equal((await post(JSON.stringify({ message: 'x'.repeat(801) }))).status, 400);
  assert.equal((await post('x'.repeat(16001))).status, 413);
  assert.equal((await post(JSON.stringify({ message: '你好' }), { origin: 'https://unrelated.example' })).status, 403);
  assert.equal((await post('你好', { 'content-type': 'text/plain' })).status, 415);
}
console.log(`生产 HTTP 检查通过：${count} 个预渲染路由、404、响应头及 API 输入边界；未发起模型调用。`);
