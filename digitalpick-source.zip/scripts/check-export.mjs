import { readdir, readFile, stat } from 'node:fs/promises';
import { resolve, join } from 'node:path';
const root = resolve('out');
async function files(dir) { return (await Promise.all((await readdir(dir, { withFileTypes: true })).map(d => d.isDirectory() ? files(join(dir, d.name)) : join(dir, d.name)))).flat(); }
const htmlFiles = (await files(root)).filter(f => f.endsWith('.html'));
const broken = [];
let links = 0;
for (const file of htmlFiles) {
 const content = await readFile(file, 'utf8');
 for (const m of content.matchAll(/(?:href|src)="(\/[^"\s]*)"/g)) {
  const pathname = decodeURIComponent(new URL(m[1].replaceAll('&amp;', '&'), 'https://local.test').pathname);
  if (pathname.startsWith('//')) continue;
  let target = resolve(root, `.${pathname}`);
  try { if ((await stat(target)).isDirectory()) target = join(target, 'index.html'); await stat(target); links++; }
  catch { broken.push({ file: file.slice(root.length), url: pathname }); }
 }
}
if (broken.length) { console.error(broken); process.exitCode = 1; }
else console.log(`静态导出检查通过：${htmlFiles.length} 个 HTML 文件，${links} 个内部链接/资源引用，无失效路径。`);
