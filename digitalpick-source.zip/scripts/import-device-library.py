"""Offline deterministic import from licensed, price-free CSV snapshots. Python 3 standard library only."""
from pathlib import Path
import csv, json, re, hashlib, collections
ROOT=Path(__file__).resolve().parents[1]
DATE='2026-10-17'
BRANDS={'apple':'Apple','samsung':'Samsung','xiaomi':'Xiaomi','vivo':'vivo','iqoo':'iQOO','oppo':'OPPO','realme':'realme','honor':'HONOR','huawei':'HUAWEI','poco':'POCO','oneplus':'OnePlus','lenovo':'Lenovo','asus':'ASUS','dell':'Dell','acer':'Acer','hp':'HP','msi':'MSI','microsoft':'Microsoft','sony':'Sony','google':'Google','motorola':'Motorola','nokia':'Nokia','tecno':'TECNO','infinix':'Infinix','gigabyte':'GIGABYTE','colorful':'Colorful','alienware':'Alienware','chuwi':'CHUWI'}
def clean(v):
 s=str(v or '').strip()
 return None if s.lower() in ('','nan','n/a','none','unknown') else re.sub(r'[\x00-\x08\x0b\x0c\x0e-\x1f]','',s)[:500]
def brand(v):return BRANDS.get(v.lower(),v)
def ident(prefix,row):return prefix+'-'+hashlib.sha256(json.dumps(row,sort_keys=True).encode()).hexdigest()[:16]
def item(row,category,source,year,region,facts):
 return {'id':ident(source,row),'brand':brand(row.get('Company Name',row.get('brand',''))),'name':clean(row.get('Model Name',row.get('model',''))),'category':category,'year':year,'region':region,'sourceId':source,'sourceUrl':'https://www.kaggle.com/datasets/abdulmalik1518/mobiles-dataset-2025' if source=='mobiles-2025' else 'https://github.com/abhinavflac/laptops-specs-dataset/blob/79f2b96d4382598eb31f230e278b01a18b117176/data/processed/laptops_cleaned.csv','sourceUpdatedAt':'2025-02-18' if source=='mobiles-2025' else None,'importedAt':DATE,'review':'pending','facts':{k:clean(v) for k,v in facts.items()},'aliases':[],'notes':['第三方素材，参数尚未逐项核验；不进入小派事实检索或购买推荐。','来源没有完整地区版本信息，不能套用到国行。']}
records=[];excluded=collections.Counter();seen=set()
with (ROOT/'data/library-sources/mobiles.csv').open(newline='') as f:
 for row in csv.DictReader(f):
  year=int(row['Launched Year']) if re.fullmatch(r'20\d{2}',row['Launched Year']) else None
  if not year or not (2021<=year<=2026 or (row['Company Name']=='Apple' and 2017<=year<2021)):
   excluded['mobile-outside-window']+=1;continue
  if not clean(row['Model Name']):excluded['missing-name']+=1;continue
  cat='tablet' if re.search(r'ipad|matepad|(?:^|[ \-])(?:pad|tab)(?:[ \-]|$)',row['Model Name'],re.I) else 'phone'
  record=item(row,cat,'mobiles-2025',year,'来源未区分地区 / 容量版本',{'processor':row['Processor'],'ram':row['RAM'],'rearCamera':row['Back Camera'],'frontCamera':row['Front Camera'],'battery':row['Battery Capacity'],'display':row['Screen Size'],'weight':row['Mobile Weight'],'configuration':row['Model Name']})
  record['notes'].append('只有发布年份；2021 年是否落在滚动五年边界内尚未确认。')
  if re.search(r'iPhone 16(?: |$)',row['Model Name']) and 'A17' in row['Processor']:
   record['notes'].insert(0,'已发现来源冲突：来源写 A17，Apple 官方 iPhone 16 规格为 A18；此条不得作为参数事实。')
  fingerprint=(record['brand'],record['name'],tuple(sorted(record['facts'].items())))
  if fingerprint in seen:excluded['exact-duplicate']+=1;continue
  seen.add(fingerprint);records.append(record)
with (ROOT/'data/library-sources/laptops.csv').open(newline='') as f:
 for row in csv.DictReader(f):
  if not clean(row['model']):excluded['missing-name']+=1;continue
  facts={'processor':' '.join(filter(None,[clean(row['cpu_brand']),clean(row['cpu_series']),clean(row['cpu_model']),clean(row['cpu_suffix'])])),'ram':row['ram_gb']+' GB' if clean(row['ram_gb']) else None,'storage':row['storage_gb']+' GB' if clean(row['storage_gb']) else None,'display':row['display_size_inch']+' 英寸（来源值）' if clean(row['display_size_inch']) else None,'displayResolution':row['display_width_px']+' × '+row['display_height_px'] if clean(row['display_width_px']) and clean(row['display_height_px']) else None,'gpu':' '.join(filter(None,[clean(row['gpu_brand']),clean(row['gpu_model']),clean(row['gpu_type'])])),'gpuMemory':row['gpu_vram_gb']+' GB' if clean(row['gpu_vram_gb']) else None,'cpuCores':row['cpu_core_count'],'cpuThreads':row['cpu_thread_count'],'performanceCores':row['cpu_p_cores'],'efficiencyCores':row['cpu_e_cores'],'lowPowerCores':row['cpu_lp_e_cores'],'os':row['os_name'],'warranty':row['warranty_years']+' 年（印度来源，不能套用国行）' if clean(row['warranty_years']) else None,'configuration':row['model']}
  record=item(row,'laptop','laptops-2025',None,'印度市场配置；未逐项核对',facts)
  record['notes'].append('来源未提供发布日期，采集批次为 2025 年不代表机型发布于 2025 年；不计入近五年已确认机型。')
  fingerprint=(record['brand'],record['name'],tuple(sorted(record['facts'].items())))
  if fingerprint in seen:excluded['exact-duplicate']+=1;continue
  seen.add(fingerprint);records.append(record)
records.sort(key=lambda x:(x['category'],x['brand'],x['name'],x['id']))
for record in records:
 assert record['review']=='pending' and record['name'] and re.fullmatch(r'[a-z0-9-]+',record['id'])
 assert not any(re.search(r'price|rating|image|score',k,re.I) for k in record['facts'])
(ROOT/'lib/library/archive.json').write_text(json.dumps(records,ensure_ascii=False,separators=(',',':'))+'\n')
report={'importedAt':DATE,'pendingConfigurations':len(records),'byCategory':dict(collections.Counter(x['category'] for x in records)),'byBrand':dict(collections.Counter(x['brand'] for x in records)),'byYear':dict(collections.Counter(str(x['year']) if x['year'] else 'unknown' for x in records)),'excluded':dict(excluded),'snapshotSha256':{name:hashlib.sha256((ROOT/'data/library-sources'/name).read_bytes()).hexdigest() for name in ['mobiles.csv','laptops.csv']},'completeCoverage':False,'missingCoverage':['2026 新品未全量收录','部分品牌与地区配置未覆盖','笔记本缺发布日期','公开手机资料有已确认错误，全部待核验','屏幕、接口、系统维护等字段未完整披露'],'excludedSource':{'url':'https://github.com/lihongvst/gsmarena-scraper2','reason':'代码许可不等于原始参数数据库授权；原站限制再发布，且 JSON 覆盖了重名字段，未导入。'}}
(ROOT/'lib/library/import-report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:report[k] for k in ['pendingConfigurations','byCategory','byYear','excluded']},ensure_ascii=False))
