import { cp, mkdir, rm, symlink, writeFile, readFile } from 'node:fs/promises';
import { spawn } from 'node:child_process';
import { resolve, join } from 'node:path';
const root = process.cwd(), stage = resolve(root, '.deploy/pages'), output = resolve(root, 'out-pages');
const prefix = (process.env.NEXT_PUBLIC_BASE_PATH || '').replace(/\/$/, '');
if (prefix && !/^\/[a-zA-Z0-9._-]+$/.test(prefix)) throw new Error('NEXT_PUBLIC_BASE_PATH must be empty or /repository-name.');
const proxy = process.env.NEXT_PUBLIC_AI_PROXY_URL?.trim();
if (!proxy) throw new Error('Set NEXT_PUBLIC_AI_PROXY_URL to your public Worker URL. Do not supply an API key.');
const endpoint = new URL(proxy);
if ((endpoint.protocol !== 'https:' && !(endpoint.protocol === 'http:' && ['localhost', '127.0.0.1', '[::1]'].includes(endpoint.hostname))) || endpoint.username || endpoint.password || endpoint.search || endpoint.hash || !['/', '/api/assistant', '/api/assistant/'].includes(endpoint.pathname)) throw new Error('Invalid public Worker URL.');
for (const [key, value] of Object.entries(process.env)) if (key.startsWith('NEXT_PUBLIC_') && /(?:API_KEY|TOKEN|SECRET)/.test(key) && value) throw new Error(`Do not expose credentials through ${key}.`);
await mkdir(resolve(root, '.deploy'), { recursive: true });
await rm(stage, { recursive: true, force: true }); await mkdir(stage);
for (const name of ['app', 'components', 'lib', 'content', 'public', 'data', 'package.json', 'package-lock.json', 'tsconfig.json', 'next-env.d.ts', 'next.config.ts', 'postcss.config.mjs']) {
  await cp(resolve(root, name), join(stage, name), { recursive: true, filter: source => source !== resolve(root, 'app/api') });
}
// The Node API remains in the source checkout. Only the isolated static build omits it.
await symlink(resolve(root, 'node_modules'), join(stage, 'node_modules'), 'dir');
const config = JSON.parse(await readFile(join(stage, 'tsconfig.json'), 'utf8'));
config.exclude = ['node_modules']; await writeFile(join(stage, 'tsconfig.json'), JSON.stringify(config));
const env = { ...process.env, DIGITALPICK_TARGET: 'static', NEXT_PUBLIC_DEPLOYMENT: 'static', NEXT_PUBLIC_BASE_PATH: prefix, NEXT_PUBLIC_AI_PROXY_URL: proxy, NEXT_TELEMETRY_DISABLED: '1' };
for (const key of Object.keys(env)) if (/^(?:AI_|CLOUDFLARE_|CF_API_|GITHUB_TOKEN$|GH_TOKEN$)/.test(key)) delete env[key];
await new Promise((accept, reject) => {
  const child = spawn(process.execPath, [resolve(root, 'node_modules/next/dist/bin/next'), 'build', '--webpack'], { cwd: stage, env, stdio: 'inherit' });
  child.on('error', reject); child.on('exit', code => code === 0 ? accept() : reject(new Error(`Static build failed (${code}).`)));
});
await rm(output, { recursive: true, force: true });
await cp(join(stage, 'out'), output, { recursive: true });
await writeFile(join(output, '.nojekyll'), '');
await writeFile(join(output, 'deployment.json'), JSON.stringify({ basePath: prefix, assistantEndpoint: `${endpoint.origin}/api/assistant/`, mode: 'static-with-worker' }));
console.log('Static frontend ready in out-pages/. No server credentials were copied.');
