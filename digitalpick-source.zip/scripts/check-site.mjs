import { readdir, readFile, stat } from 'node:fs/promises';
import { resolve, join } from 'node:path';
const root = resolve('.next/server/app');
async function files(dir) { return (await Promise.all((await readdir(dir, { withFileTypes: true })).map(d => d.isDirectory() ? files(join(dir, d.name)) : join(dir, d.name)))).flat(); }
async function exists(path) { try { return (await stat(path)).isFile(); } catch { return false; } }
const htmlFiles = (await files(root)).filter(f => f.endsWith('.html'));
const broken = []; let links = 0;
for (const file of htmlFiles) {
  const content = await readFile(file, 'utf8');
  for (const m of content.matchAll(/(?:href|src)="(\/[^"\s]*)"/g)) {
    const path = decodeURIComponent(new URL(m[1].replaceAll('&amp;', '&'), 'https://local.test').pathname);
    if (path.startsWith('//')) continue;
    const route = path.replace(/\/$/, '') || '/index';
    const valid = path.startsWith('/_next/') ? await exists(resolve('.next', `.${path.replace('/_next', '')}`)) : await exists(resolve('public', `.${path}`)) || await exists(resolve(root, `.${route}.html`)) || ['/robots.txt', '/sitemap.xml', '/api/assistant/'].includes(path);
    if (valid) links++; else broken.push({ file: file.slice(root.length), url: path });
  }
}
if (broken.length) { console.error(broken); process.exitCode = 1; }
else console.log(`构建页面检查通过：${htmlFiles.length} 个 HTML，${links} 个内部链接/资源引用，无失效路径。`);
