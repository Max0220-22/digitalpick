import { cp, stat } from 'node:fs/promises';
import { loadEnvFile } from 'node:process';
import { resolve } from 'node:path';
import { spawn } from 'node:child_process';
const root = process.cwd();
try { loadEnvFile(resolve(root, '.env.local')); } catch (error) { if (error.code !== 'ENOENT') throw new Error('Unable to load local server environment'); }
const standalone = resolve(root, '.next/standalone');
try { await stat(resolve(standalone, 'server.js')); } catch { console.error('请先运行 npm run build。'); process.exit(1); }
await cp(resolve(root, '.next/static'), resolve(standalone, '.next/static'), { recursive: true });
await cp(resolve(root, 'public'), resolve(standalone, 'public'), { recursive: true });
const server = spawn(process.execPath, [resolve(standalone, 'server.js')], { cwd: standalone, stdio: 'inherit', env: { ...process.env, HOSTNAME: process.env.DIGITALPICK_HOST || '127.0.0.1', AI_QUOTA_PATH: resolve(root, process.env.AI_QUOTA_PATH || '.data/ai-quota.sqlite') } });
for (const signal of ['SIGINT', 'SIGTERM']) process.on(signal, () => server.kill(signal));
server.on('exit', (code, signal) => { process.exitCode = signal ? 0 : code || 0; });
