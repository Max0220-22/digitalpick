import { readFile, readdir } from 'node:fs/promises';
import { resolve, relative } from 'node:path';
import { fileURLToPath } from 'node:url';
const extensions=/\.(?:ts|tsx|js|mjs|json|md|mdx|css|html|csv|txt|svg|yml|toml)$/;
export function textEncodingIssue(bytes, {allowReplacement=false}={}) {
 if(bytes[0]===0xef&&bytes[1]===0xbb&&bytes[2]===0xbf)return 'UTF8_BOM';
 let text;try{text=new TextDecoder('utf-8',{fatal:true}).decode(bytes);}catch{return 'INVALID_UTF8';}
 if(!allowReplacement&&text.includes(String.fromCodePoint(0xfffd)))return 'REPLACEMENT_CHARACTER';
 if(text.includes('\u951f\u65a4\u62f7'))return 'MOJIBAKE_MARKER';
 return null;
}
export async function checkTextEncoding(roots=['app','components','lib','data','content','public','scripts','tests','worker','pages-gateway','docs']) {
 const findings=[];let count=0;
 async function walk(path){
  let entries;try{entries=await readdir(path,{withFileTypes:true});}catch(error){if(error.code==='ENOENT')return;throw error;}
  for(const entry of entries){const file=resolve(path,entry.name);if(entry.isDirectory()){await walk(file);continue;}if(!extensions.test(entry.name))continue;
   const issue=textEncodingIssue(await readFile(file),{allowReplacement:/[/\\]_next[/\\]static[/\\]chunks[/\\]polyfills-[\da-f]+\.js$/.test(file)});count++;if(issue)findings.push({file:relative(process.cwd(),file),issue});
  }
 }
 for(const root of typeof roots==='string'?[roots]:roots)await walk(root);
 if(findings.length)throw new Error('Text encoding check failed: '+JSON.stringify(findings));
 console.log(`Text encoding passed: ${count} files, strict UTF-8, no BOM or unintended replacement characters.`);return count;
}
if(process.argv[1]&&resolve(process.argv[1])===fileURLToPath(import.meta.url))checkTextEncoding(process.argv[2]||undefined).catch(error=>{console.error(error.message);process.exitCode=1;});
