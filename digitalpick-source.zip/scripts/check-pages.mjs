import { checkTextEncoding } from './check-text-encoding.mjs';
import { readdir, readFile, stat } from 'node:fs/promises';
import { resolve, join } from 'node:path';
const root = resolve('out-pages'), metadata = JSON.parse(await readFile(join(root, 'deployment.json'), 'utf8'));
async function files(dir) { return (await Promise.all((await readdir(dir, { withFileTypes: true })).map(d => d.isDirectory() ? files(join(dir, d.name)) : join(dir, d.name)))).flat(); }
await checkTextEncoding(root);
const html = (await files(root)).filter(f => f.endsWith('.html')); let links = 0; const broken = [];
for (const file of html) for (const match of (await readFile(file, 'utf8')).matchAll(/(?:href|src|action)="(\/[^"\s]*)"/g)) {
  let path = decodeURIComponent(new URL(match[1].replaceAll('&amp;', '&'), 'https://local.test').pathname);
  if (path.startsWith('//')) continue;
  if (metadata.basePath) {
    if (path !== metadata.basePath && !path.startsWith(`${metadata.basePath}/`)) { broken.push({ file, path, reason: 'missing basePath' }); continue; }
    path = path.slice(metadata.basePath.length) || '/';
  }
  let target = resolve(root, `.${path}`);
  try { if ((await stat(target)).isDirectory()) target = join(target, 'index.html'); if (!(await stat(target)).isFile()) throw new Error(); links++; }
  catch { broken.push({ file: file.slice(root.length), path }); }
}
if (broken.length) { console.error(broken); process.exitCode = 1; }
else console.log(`Static check passed: ${html.length} HTML pages, ${links} local references, basePath=${metadata.basePath || '/'}.`);
